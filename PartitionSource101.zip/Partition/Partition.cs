﻿using MSCLoader;
using UnityEngine;

namespace Partition
{
    public class Partition : Mod
    {
        public override string ID => "Partition";
        public override string Name => "Partition";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => true;
		
		private GameObject SATSUMA;

		public override void OnLoad()
        {
			SATSUMA = GameObject.Find("SATSUMA(557kg)");
			
            GameObject Roman266PARTITION = LoadAssets.LoadOBJ(this, "partition.obj");
			Roman266PARTITION.transform.parent = SATSUMA.transform;
			Roman266PARTITION.transform.localScale = new Vector3(1, 1, 1);
			Roman266PARTITION.transform.localPosition = new Vector3(0, 0, 0);
			Roman266PARTITION.transform.localEulerAngles= new Vector3(0, 0, 0);
			
			Texture2D loadtexture = LoadAssets.LoadTexture(this, "partition.png");
			Roman266PARTITION.GetComponent<MeshRenderer>().material.mainTexture = loadtexture;
			
			GameObject PARTITC1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            PARTITC1.name = "Roman266PARTITC1";
			PARTITC1.transform.parent = SATSUMA.transform;
            PARTITC1.transform.localScale = new Vector3(1.25f, 0.355f, 0.01f);
			PARTITC1.transform.localPosition = new Vector3(0f, 0.14f, -1.125f);
			PARTITC1.transform.localEulerAngles= new Vector3(0, 0, 0);
            PARTITC1.GetComponent<MeshRenderer>().enabled = false;
			
			GameObject PARTITC2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            PARTITC2.name = "Roman266PARTITC2";
			PARTITC2.transform.parent = SATSUMA.transform;
            PARTITC2.transform.localScale = new Vector3(1.25f, 0.01f, 0.2f);
			PARTITC2.transform.localPosition = new Vector3(0f, 0.4f, -1.45f);
			PARTITC2.transform.localEulerAngles= new Vector3(45, 0, 0);
            PARTITC2.GetComponent<MeshRenderer>().enabled = false;
        }
    }
}
