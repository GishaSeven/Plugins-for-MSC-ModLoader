﻿using System;
using System.IO;
using MSCLoader;
using UnityEngine;

namespace ClearanceTool
{
    public class ClearanceTool : Mod
    {
        public override string ID { get { return "ClearanceTool"; } }
        public override string Name { get { return "Clearance Tool(Adjustment)"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private GameObject SATSUMA;
		private GameObject AIRINTAKE;
		private GameObject DRIVERHEADPIVOT;
		private GameObject HOOKFRONT;
		private GameObject HOOKREAR;
		private GameObject INTERIOR;
		private GameObject BODY;
		private GameObject CHASSIS;
		private GameObject MISCPARTS;
		private GameObject DASHBOARD;
		private GameObject WIPERS;
		private GameObject HOOKS;
		private GameObject SOUNDS;
		private GameObject CARSIMULATION;
		private GameObject ELECTRICITY;
		private GameObject PLAYERTRIGGER;
		private GameObject COLIDERS;
		private GameObject FIRE;
		private GameObject COG;
		private GameObject GENERALPIVOT;
		private GameObject SOUNDPOSITION;
		private GameObject STAGINGWHEEL;
		private GameObject CARSHADOWPROJECTOR;
		private GameObject PATHSLAYER;
		private GameObject CARREARMIRRORPIVOT;
		private GameObject GETINPIVOT;
		private GameObject DEADBODY;
		
		public GameObject FERNDALE;
		public GameObject WHEELFL2;
		public GameObject WHEELFR2;
		public GameObject WHEELRL2;
		public GameObject WHEELRR2;
		
		public GameObject HAYOSIKO;
		public GameObject WHEELFL3;
		public GameObject WHEELFR3;
		public GameObject WHEELRL3;
		public GameObject WHEELRR3;
		
		private float WheelYPos = 0.001f;

        private Keybind satsumaUpKey = new Keybind("SatsumaUpKey", "Satsuma Up", KeyCode.Keypad7);
        private Keybind satsumaDownKey = new Keybind("SatsumaDownKey", "Satsuma Down", KeyCode.Keypad1);
		private Keybind ferndaleUpKey = new Keybind("FerndaleUpKey", "Ferndale Up", KeyCode.Keypad8);
        private Keybind ferndaleDownKey = new Keybind("FerndaleDownKey", "Ferndale Down", KeyCode.Keypad2);
		private Keybind hayosikoUpKey = new Keybind("HayosikoUpKey", "Hayosiko Up", KeyCode.Keypad9);
        private Keybind hayosikoDownKey = new Keybind("HayosikoDownKey", "Hayosiko Down", KeyCode.Keypad3);
		private Keybind saveKey = new Keybind("SaveKey", "Save", KeyCode.Keypad5);
		

        public override void OnLoad()
        {
            Keybind.Add(this, satsumaUpKey);
            Keybind.Add(this, satsumaDownKey);
            Keybind.Add(this, ferndaleUpKey);
			Keybind.Add(this, ferndaleDownKey);
            Keybind.Add(this, hayosikoUpKey);
            Keybind.Add(this, hayosikoDownKey);
			Keybind.Add(this, saveKey);
        }

        public override void Update()
        {
            if (satsumaUpKey.IsDown()) { SatsumaUp(); };
            if (satsumaDownKey.IsDown()) { SatsumaDown(); };
            if (ferndaleUpKey.IsDown()) { FerndaleUp(); };
			if (ferndaleDownKey.IsDown()) { FerndaleDown(); };
            if (hayosikoUpKey.IsDown()) { HayosikoUp(); };
            if (hayosikoDownKey.IsDown()) { HayosikoDown(); };
			if (saveKey.IsDown()) { Save(); };
			
			this.SATSUMA = GameObject.Find("SATSUMA(557kg)");
			this.AIRINTAKE = this.SATSUMA.transform.FindChild("AirIntake").gameObject;
			this.DRIVERHEADPIVOT = this.SATSUMA.transform.FindChild("DriverHeadPivot").gameObject;
			this.HOOKFRONT = this.SATSUMA.transform.FindChild("HookFront").gameObject;
			this.HOOKREAR = this.SATSUMA.transform.FindChild("HookRear").gameObject;
			this.INTERIOR = this.SATSUMA.transform.FindChild("Interior").gameObject;
			this.BODY = this.SATSUMA.transform.FindChild("Body").gameObject;
			this.CHASSIS = this.SATSUMA.transform.FindChild("Chassis").gameObject;
			this.MISCPARTS = this.SATSUMA.transform.FindChild("MiscParts").gameObject;
			this.DASHBOARD = this.SATSUMA.transform.FindChild("Dashboard").gameObject;
			this.WIPERS = this.SATSUMA.transform.FindChild("Wipers").gameObject;
			this.HOOKS = this.SATSUMA.transform.FindChild("Hooks").gameObject;
			this.SOUNDS = this.SATSUMA.transform.FindChild("Sounds").gameObject;
			this.CARSIMULATION = this.SATSUMA.transform.FindChild("CarSimulation").gameObject;
			this.ELECTRICITY = this.SATSUMA.transform.FindChild("Electricity").gameObject;
			this.PLAYERTRIGGER = this.SATSUMA.transform.FindChild("PlayerTrigger").gameObject;
			this.COLIDERS = this.SATSUMA.transform.FindChild("Colliders").gameObject;
			this.FIRE = this.SATSUMA.transform.FindChild("FIRE").gameObject;
			this.COG = this.SATSUMA.transform.FindChild("CoG").gameObject;
			this.GENERALPIVOT = this.SATSUMA.transform.FindChild("generalPivot").gameObject;
			this.SOUNDPOSITION = this.SATSUMA.transform.FindChild("Soundposition").gameObject;
			this.STAGINGWHEEL = this.SATSUMA.transform.FindChild("StagingWheel").gameObject;
			this.CARSHADOWPROJECTOR = this.SATSUMA.transform.FindChild("CarShadowProjector").gameObject;
			this.PATHSLAYER = this.SATSUMA.transform.FindChild("PathSlayer").gameObject;
			this.CARREARMIRRORPIVOT = this.SATSUMA.transform.FindChild("CarRearMirrorPivot").gameObject;
			this.GETINPIVOT = this.SATSUMA.transform.FindChild("GetInPivot").gameObject;
			this.DEADBODY = this.SATSUMA.transform.FindChild("DeadBody").gameObject;
			
			this.FERNDALE = GameObject.Find("FERNDALE");
			this.WHEELFL2 = this.FERNDALE.transform.FindChild("wheelFL").gameObject;
			this.WHEELFR2 = this.FERNDALE.transform.FindChild("wheelFR").gameObject;
			this.WHEELRL2 = this.FERNDALE.transform.FindChild("wheelRL").gameObject;
			this.WHEELRR2 = this.FERNDALE.transform.FindChild("wheelRR").gameObject;
		
			this.HAYOSIKO = GameObject.Find("HAYOSIKO(1500kg)");
			this.WHEELFL3 = this.HAYOSIKO.transform.FindChild("wheelFL").gameObject;
			this.WHEELFR3 = this.HAYOSIKO.transform.FindChild("wheelFR").gameObject;
			this.WHEELRL3 = this.HAYOSIKO.transform.FindChild("wheelRL").gameObject;
			this.WHEELRR3 = this.HAYOSIKO.transform.FindChild("wheelRR").gameObject;
        }

        private void SatsumaUp()
        {
			this.AIRINTAKE.transform.localPosition = new Vector3(this.AIRINTAKE.transform.localPosition.x, this.AIRINTAKE.transform.localPosition.y + this.WheelYPos, this.AIRINTAKE.transform.localPosition.z);
			this.DRIVERHEADPIVOT.transform.localPosition = new Vector3(this.DRIVERHEADPIVOT.transform.localPosition.x, this.DRIVERHEADPIVOT.transform.localPosition.y + this.WheelYPos, this.DRIVERHEADPIVOT.transform.localPosition.z);
			this.HOOKFRONT.transform.localPosition = new Vector3(this.HOOKFRONT.transform.localPosition.x, this.HOOKFRONT.transform.localPosition.y + this.WheelYPos, this.HOOKFRONT.transform.localPosition.z);
			this.HOOKREAR.transform.localPosition = new Vector3(this.HOOKREAR.transform.localPosition.x, this.HOOKREAR.transform.localPosition.y + this.WheelYPos, this.HOOKREAR.transform.localPosition.z);
			this.INTERIOR.transform.localPosition = new Vector3(this.INTERIOR.transform.localPosition.x, this.INTERIOR.transform.localPosition.y + this.WheelYPos, this.INTERIOR.transform.localPosition.z);
			this.BODY.transform.localPosition = new Vector3(this.BODY.transform.localPosition.x, this.BODY.transform.localPosition.y + this.WheelYPos, this.BODY.transform.localPosition.z);
			this.CHASSIS.transform.localPosition = new Vector3(this.CHASSIS.transform.localPosition.x, this.CHASSIS.transform.localPosition.y + this.WheelYPos, this.CHASSIS.transform.localPosition.z);
			this.MISCPARTS.transform.localPosition = new Vector3(this.MISCPARTS.transform.localPosition.x, this.MISCPARTS.transform.localPosition.y + this.WheelYPos, this.MISCPARTS.transform.localPosition.z);
			this.DASHBOARD.transform.localPosition = new Vector3(this.DASHBOARD.transform.localPosition.x, this.DASHBOARD.transform.localPosition.y + this.WheelYPos, this.DASHBOARD.transform.localPosition.z);
			this.WIPERS.transform.localPosition = new Vector3(this.WIPERS.transform.localPosition.x, this.WIPERS.transform.localPosition.y + this.WheelYPos, this.WIPERS.transform.localPosition.z);
			this.HOOKS.transform.localPosition = new Vector3(this.HOOKS.transform.localPosition.x, this.HOOKS.transform.localPosition.y + this.WheelYPos, this.HOOKS.transform.localPosition.z);
			this.SOUNDS.transform.localPosition = new Vector3(this.SOUNDS.transform.localPosition.x, this.SOUNDS.transform.localPosition.y + this.WheelYPos, this.SOUNDS.transform.localPosition.z);
			this.CARSIMULATION.transform.localPosition = new Vector3(this.CARSIMULATION.transform.localPosition.x, this.CARSIMULATION.transform.localPosition.y + this.WheelYPos, this.CARSIMULATION.transform.localPosition.z);
			this.ELECTRICITY.transform.localPosition = new Vector3(this.ELECTRICITY.transform.localPosition.x, this.ELECTRICITY.transform.localPosition.y + this.WheelYPos, this.ELECTRICITY.transform.localPosition.z);
			this.PLAYERTRIGGER.transform.localPosition = new Vector3(this.PLAYERTRIGGER.transform.localPosition.x, this.PLAYERTRIGGER.transform.localPosition.y + this.WheelYPos, this.PLAYERTRIGGER.transform.localPosition.z);
			this.COLIDERS.transform.localPosition = new Vector3(this.COLIDERS.transform.localPosition.x, this.COLIDERS.transform.localPosition.y + this.WheelYPos, this.COLIDERS.transform.localPosition.z);
			this.FIRE.transform.localPosition = new Vector3(this.FIRE.transform.localPosition.x, this.FIRE.transform.localPosition.y + this.WheelYPos, this.FIRE.transform.localPosition.z);
			this.COG.transform.localPosition = new Vector3(this.COG.transform.localPosition.x, this.COG.transform.localPosition.y + this.WheelYPos, this.COG.transform.localPosition.z);
			this.GENERALPIVOT.transform.localPosition = new Vector3(this.GENERALPIVOT.transform.localPosition.x, this.GENERALPIVOT.transform.localPosition.y + this.WheelYPos, this.GENERALPIVOT.transform.localPosition.z);
			this.SOUNDPOSITION.transform.localPosition = new Vector3(this.SOUNDPOSITION.transform.localPosition.x, this.SOUNDPOSITION.transform.localPosition.y + this.WheelYPos, this.SOUNDPOSITION.transform.localPosition.z);
			this.STAGINGWHEEL.transform.localPosition = new Vector3(this.STAGINGWHEEL.transform.localPosition.x, this.STAGINGWHEEL.transform.localPosition.y + this.WheelYPos, this.STAGINGWHEEL.transform.localPosition.z);
			this.CARSHADOWPROJECTOR.transform.localPosition = new Vector3(this.CARSHADOWPROJECTOR.transform.localPosition.x, this.CARSHADOWPROJECTOR.transform.localPosition.y + this.WheelYPos, this.CARSHADOWPROJECTOR.transform.localPosition.z);
			this.PATHSLAYER.transform.localPosition = new Vector3(this.PATHSLAYER.transform.localPosition.x, this.PATHSLAYER.transform.localPosition.y + this.WheelYPos, this.PATHSLAYER.transform.localPosition.z);
			this.CARREARMIRRORPIVOT.transform.localPosition = new Vector3(this.CARREARMIRRORPIVOT.transform.localPosition.x, this.CARREARMIRRORPIVOT.transform.localPosition.y + this.WheelYPos, this.CARREARMIRRORPIVOT.transform.localPosition.z);
			this.GETINPIVOT.transform.localPosition = new Vector3(this.GETINPIVOT.transform.localPosition.x, this.GETINPIVOT.transform.localPosition.y + this.WheelYPos, this.GETINPIVOT.transform.localPosition.z);
			this.DEADBODY.transform.localPosition = new Vector3(this.DEADBODY.transform.localPosition.x, this.DEADBODY.transform.localPosition.y + this.WheelYPos, this.DEADBODY.transform.localPosition.z);
        }

        private void SatsumaDown()
        {
            this.AIRINTAKE.transform.localPosition = new Vector3(this.AIRINTAKE.transform.localPosition.x, this.AIRINTAKE.transform.localPosition.y - this.WheelYPos, this.AIRINTAKE.transform.localPosition.z);
			this.DRIVERHEADPIVOT.transform.localPosition = new Vector3(this.DRIVERHEADPIVOT.transform.localPosition.x, this.DRIVERHEADPIVOT.transform.localPosition.y - this.WheelYPos, this.DRIVERHEADPIVOT.transform.localPosition.z);
			this.HOOKFRONT.transform.localPosition = new Vector3(this.HOOKFRONT.transform.localPosition.x, this.HOOKFRONT.transform.localPosition.y - this.WheelYPos, this.HOOKFRONT.transform.localPosition.z);
			this.HOOKREAR.transform.localPosition = new Vector3(this.HOOKREAR.transform.localPosition.x, this.HOOKREAR.transform.localPosition.y - this.WheelYPos, this.HOOKREAR.transform.localPosition.z);
			this.INTERIOR.transform.localPosition = new Vector3(this.INTERIOR.transform.localPosition.x, this.INTERIOR.transform.localPosition.y - this.WheelYPos, this.INTERIOR.transform.localPosition.z);
			this.BODY.transform.localPosition = new Vector3(this.BODY.transform.localPosition.x, this.BODY.transform.localPosition.y - this.WheelYPos, this.BODY.transform.localPosition.z);
			this.CHASSIS.transform.localPosition = new Vector3(this.CHASSIS.transform.localPosition.x, this.CHASSIS.transform.localPosition.y - this.WheelYPos, this.CHASSIS.transform.localPosition.z);
			this.MISCPARTS.transform.localPosition = new Vector3(this.MISCPARTS.transform.localPosition.x, this.MISCPARTS.transform.localPosition.y - this.WheelYPos, this.MISCPARTS.transform.localPosition.z);
			this.DASHBOARD.transform.localPosition = new Vector3(this.DASHBOARD.transform.localPosition.x, this.DASHBOARD.transform.localPosition.y - this.WheelYPos, this.DASHBOARD.transform.localPosition.z);
			this.WIPERS.transform.localPosition = new Vector3(this.WIPERS.transform.localPosition.x, this.WIPERS.transform.localPosition.y - this.WheelYPos, this.WIPERS.transform.localPosition.z);
			this.HOOKS.transform.localPosition = new Vector3(this.HOOKS.transform.localPosition.x, this.HOOKS.transform.localPosition.y - this.WheelYPos, this.HOOKS.transform.localPosition.z);
			this.SOUNDS.transform.localPosition = new Vector3(this.SOUNDS.transform.localPosition.x, this.SOUNDS.transform.localPosition.y - this.WheelYPos, this.SOUNDS.transform.localPosition.z);
			this.CARSIMULATION.transform.localPosition = new Vector3(this.CARSIMULATION.transform.localPosition.x, this.CARSIMULATION.transform.localPosition.y - this.WheelYPos, this.CARSIMULATION.transform.localPosition.z);
			this.ELECTRICITY.transform.localPosition = new Vector3(this.ELECTRICITY.transform.localPosition.x, this.ELECTRICITY.transform.localPosition.y - this.WheelYPos, this.ELECTRICITY.transform.localPosition.z);
			this.PLAYERTRIGGER.transform.localPosition = new Vector3(this.PLAYERTRIGGER.transform.localPosition.x, this.PLAYERTRIGGER.transform.localPosition.y - this.WheelYPos, this.PLAYERTRIGGER.transform.localPosition.z);
			this.COLIDERS.transform.localPosition = new Vector3(this.COLIDERS.transform.localPosition.x, this.COLIDERS.transform.localPosition.y - this.WheelYPos, this.COLIDERS.transform.localPosition.z);
			this.FIRE.transform.localPosition = new Vector3(this.FIRE.transform.localPosition.x, this.FIRE.transform.localPosition.y - this.WheelYPos, this.FIRE.transform.localPosition.z);
			this.COG.transform.localPosition = new Vector3(this.COG.transform.localPosition.x, this.COG.transform.localPosition.y - this.WheelYPos, this.COG.transform.localPosition.z);
			this.GENERALPIVOT.transform.localPosition = new Vector3(this.GENERALPIVOT.transform.localPosition.x, this.GENERALPIVOT.transform.localPosition.y - this.WheelYPos, this.GENERALPIVOT.transform.localPosition.z);
			this.SOUNDPOSITION.transform.localPosition = new Vector3(this.SOUNDPOSITION.transform.localPosition.x, this.SOUNDPOSITION.transform.localPosition.y - this.WheelYPos, this.SOUNDPOSITION.transform.localPosition.z);
			this.STAGINGWHEEL.transform.localPosition = new Vector3(this.STAGINGWHEEL.transform.localPosition.x, this.STAGINGWHEEL.transform.localPosition.y - this.WheelYPos, this.STAGINGWHEEL.transform.localPosition.z);
			this.CARSHADOWPROJECTOR.transform.localPosition = new Vector3(this.CARSHADOWPROJECTOR.transform.localPosition.x, this.CARSHADOWPROJECTOR.transform.localPosition.y - this.WheelYPos, this.CARSHADOWPROJECTOR.transform.localPosition.z);
			this.PATHSLAYER.transform.localPosition = new Vector3(this.PATHSLAYER.transform.localPosition.x, this.PATHSLAYER.transform.localPosition.y - this.WheelYPos, this.PATHSLAYER.transform.localPosition.z);
			this.CARREARMIRRORPIVOT.transform.localPosition = new Vector3(this.CARREARMIRRORPIVOT.transform.localPosition.x, this.CARREARMIRRORPIVOT.transform.localPosition.y - this.WheelYPos, this.CARREARMIRRORPIVOT.transform.localPosition.z);
			this.GETINPIVOT.transform.localPosition = new Vector3(this.GETINPIVOT.transform.localPosition.x, this.GETINPIVOT.transform.localPosition.y - this.WheelYPos, this.GETINPIVOT.transform.localPosition.z);
			this.DEADBODY.transform.localPosition = new Vector3(this.DEADBODY.transform.localPosition.x, this.DEADBODY.transform.localPosition.y - this.WheelYPos, this.DEADBODY.transform.localPosition.z);
        }
		
		private void FerndaleUp()
        {
            this.WHEELFL2.transform.localPosition = new Vector3(this.WHEELFL2.transform.localPosition.x, this.WHEELFL2.transform.localPosition.y - this.WheelYPos, this.WHEELFL2.transform.localPosition.z);
			this.WHEELFR2.transform.localPosition = new Vector3(this.WHEELFR2.transform.localPosition.x, this.WHEELFR2.transform.localPosition.y - this.WheelYPos, this.WHEELFR2.transform.localPosition.z);
			this.WHEELRL2.transform.localPosition = new Vector3(this.WHEELRL2.transform.localPosition.x, this.WHEELRL2.transform.localPosition.y - this.WheelYPos, this.WHEELRL2.transform.localPosition.z);
			this.WHEELRR2.transform.localPosition = new Vector3(this.WHEELRR2.transform.localPosition.x, this.WHEELRR2.transform.localPosition.y - this.WheelYPos, this.WHEELRR2.transform.localPosition.z);
        }
		
		private void FerndaleDown()
        {
            this.WHEELFL2.transform.localPosition = new Vector3(this.WHEELFL2.transform.localPosition.x, this.WHEELFL2.transform.localPosition.y + this.WheelYPos, this.WHEELFL2.transform.localPosition.z);
			this.WHEELFR2.transform.localPosition = new Vector3(this.WHEELFR2.transform.localPosition.x, this.WHEELFR2.transform.localPosition.y + this.WheelYPos, this.WHEELFR2.transform.localPosition.z);
			this.WHEELRL2.transform.localPosition = new Vector3(this.WHEELRL2.transform.localPosition.x, this.WHEELRL2.transform.localPosition.y + this.WheelYPos, this.WHEELRL2.transform.localPosition.z);
			this.WHEELRR2.transform.localPosition = new Vector3(this.WHEELRR2.transform.localPosition.x, this.WHEELRR2.transform.localPosition.y + this.WheelYPos, this.WHEELRR2.transform.localPosition.z);
        }
		
		private void HayosikoUp()
        {
            this.WHEELFL3.transform.localPosition = new Vector3(this.WHEELFL3.transform.localPosition.x, this.WHEELFL3.transform.localPosition.y - this.WheelYPos, this.WHEELFL3.transform.localPosition.z);
			this.WHEELFR3.transform.localPosition = new Vector3(this.WHEELFR3.transform.localPosition.x, this.WHEELFR3.transform.localPosition.y - this.WheelYPos, this.WHEELFR3.transform.localPosition.z);
			this.WHEELRL3.transform.localPosition = new Vector3(this.WHEELRL3.transform.localPosition.x, this.WHEELRL3.transform.localPosition.y - this.WheelYPos, this.WHEELRL3.transform.localPosition.z);
			this.WHEELRR3.transform.localPosition = new Vector3(this.WHEELRR3.transform.localPosition.x, this.WHEELRR3.transform.localPosition.y - this.WheelYPos, this.WHEELRR3.transform.localPosition.z);
        }
		
		private void HayosikoDown()
        {
            this.WHEELFL3.transform.localPosition = new Vector3(this.WHEELFL3.transform.localPosition.x, this.WHEELFL3.transform.localPosition.y + this.WheelYPos, this.WHEELFL3.transform.localPosition.z);
			this.WHEELFR3.transform.localPosition = new Vector3(this.WHEELFR3.transform.localPosition.x, this.WHEELFR3.transform.localPosition.y + this.WheelYPos, this.WHEELFR3.transform.localPosition.z);
			this.WHEELRL3.transform.localPosition = new Vector3(this.WHEELRL3.transform.localPosition.x, this.WHEELRL3.transform.localPosition.y + this.WheelYPos, this.WHEELRL3.transform.localPosition.z);
			this.WHEELRR3.transform.localPosition = new Vector3(this.WHEELRR3.transform.localPosition.x, this.WHEELRR3.transform.localPosition.y + this.WheelYPos, this.WHEELRR3.transform.localPosition.z);
        }
		
		private void Save()
        {
            string[] array = new string[34];
			
			string[] arg_00_0 = array;
			int arg_00_1 = 0;
			float num0 = this.AIRINTAKE.transform.localPosition.y;
			arg_00_0[arg_00_1] = num0.ToString();
			
			string[] arg_01_0 = array;
			int arg_01_1 = 1;
			float num1 = this.DRIVERHEADPIVOT.transform.localPosition.y;
			arg_01_0[arg_01_1] = num1.ToString();
			
			string[] arg_02_0 = array;
			int arg_02_1 = 2;
			float num2 = this.HOOKFRONT.transform.localPosition.y;
			arg_02_0[arg_02_1] = num2.ToString();
			
			string[] arg_03_0 = array;
			int arg_03_1 = 3;
			float num3 = this.HOOKREAR.transform.localPosition.y;
			arg_03_0[arg_03_1] = num3.ToString();
			
			string[] arg_04_0 = array;
			int arg_04_1 = 4;
			float num4 = this.INTERIOR.transform.localPosition.y;
			arg_04_0[arg_04_1] = num4.ToString();
			
			string[] arg_05_0 = array;
			int arg_05_1 = 5;
			float num5 = this.BODY.transform.localPosition.y;
			arg_05_0[arg_05_1] = num5.ToString();
			
			string[] arg_06_0 = array;
			int arg_06_1 = 6;
			float num6 = this.CHASSIS.transform.localPosition.y;
			arg_06_0[arg_06_1] = num6.ToString();
			
			string[] arg_07_0 = array;
			int arg_07_1 = 7;
			float num7 = this.MISCPARTS.transform.localPosition.y;
			arg_07_0[arg_07_1] = num7.ToString();
			
			string[] arg_08_0 = array;
			int arg_08_1 = 8;
			float num8 = this.DASHBOARD.transform.localPosition.y;
			arg_08_0[arg_08_1] = num8.ToString();
			
			string[] arg_09_0 = array;
			int arg_09_1 = 9;
			float num9 = this.WIPERS.transform.localPosition.y;
			arg_09_0[arg_09_1] = num9.ToString();
			
			string[] arg_10_0 = array;
			int arg_10_1 = 10;
			float num10 = this.HOOKS.transform.localPosition.y;
			arg_10_0[arg_10_1] = num10.ToString();
			
			string[] arg_11_0 = array;
			int arg_11_1 = 11;
			float num11 = this.SOUNDS.transform.localPosition.y;
			arg_11_0[arg_11_1] = num11.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 12;
			float num12 = this.CARSIMULATION.transform.localPosition.y;
			arg_12_0[arg_12_1] = num12.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 13;
			float num13 = this.ELECTRICITY.transform.localPosition.y;
			arg_13_0[arg_13_1] = num13.ToString();
			
			string[] arg_14_0 = array;
			int arg_14_1 = 14;
			float num14 = this.PLAYERTRIGGER.transform.localPosition.y;
			arg_14_0[arg_14_1] = num14.ToString();
			
			string[] arg_15_0 = array;
			int arg_15_1 = 15;
			float num15 = this.COLIDERS.transform.localPosition.y;
			arg_15_0[arg_15_1] = num15.ToString();
			
			string[] arg_16_0 = array;
			int arg_16_1 = 16;
			float num16 = this.FIRE.transform.localPosition.y;
			arg_16_0[arg_16_1] = num16.ToString();
			
			string[] arg_17_0 = array;
			int arg_17_1 = 17;
			float num17 = this.COG.transform.localPosition.y;
			arg_17_0[arg_17_1] = num17.ToString();
			
			string[] arg_18_0 = array;
			int arg_18_1 = 18;
			float num18 = this.GENERALPIVOT.transform.localPosition.y;
			arg_18_0[arg_18_1] = num18.ToString();
			
			string[] arg_19_0 = array;
			int arg_19_1 = 19;
			float num19 = this.SOUNDPOSITION.transform.localPosition.y;
			arg_19_0[arg_19_1] = num19.ToString();
			
			string[] arg_20_0 = array;
			int arg_20_1 = 20;
			float num20 = this.STAGINGWHEEL.transform.localPosition.y;
			arg_20_0[arg_20_1] = num20.ToString();
			
			string[] arg_21_0 = array;
			int arg_21_1 = 21;
			float num21 = this.CARSHADOWPROJECTOR.transform.localPosition.y;
			arg_21_0[arg_21_1] = num21.ToString();
			
			string[] arg_22_0 = array;
			int arg_22_1 = 22;
			float num22 = this.PATHSLAYER.transform.localPosition.y;
			arg_22_0[arg_22_1] = num22.ToString();
			
			string[] arg_23_0 = array;
			int arg_23_1 = 23;
			float num23 = this.CARREARMIRRORPIVOT.transform.localPosition.y;
			arg_23_0[arg_23_1] = num23.ToString();
			
			string[] arg_24_0 = array;
			int arg_24_1 = 24;
			float num24 = this.GETINPIVOT.transform.localPosition.y;
			arg_24_0[arg_24_1] = num24.ToString();
			
			string[] arg_25_0 = array;
			int arg_25_1 = 25;
			float num25 = this.DEADBODY.transform.localPosition.y;
			arg_25_0[arg_25_1] = num25.ToString();
			
			string[] arg_26_0 = array;
			int arg_26_1 = 26;
			float num26 = this.WHEELFL2.transform.localPosition.y;
			arg_26_0[arg_26_1] = num26.ToString();
			
			string[] arg_27_0 = array;
			int arg_27_1 = 27;
			float num27 = this.WHEELFR2.transform.localPosition.y;
			arg_27_0[arg_27_1] = num27.ToString();
			
			string[] arg_28_0 = array;
			int arg_28_1 = 28;
			float num28 = this.WHEELRL2.transform.localPosition.y;
			arg_28_0[arg_28_1] = num28.ToString();
			
			string[] arg_29_0 = array;
			int arg_29_1 = 29;
			float num29 = this.WHEELRR2.transform.localPosition.y;
			arg_29_0[arg_29_1] = num29.ToString();
			
			string[] arg_30_0 = array;
			int arg_30_1 = 30;
			float num30 = this.WHEELFL2.transform.localPosition.y;
			arg_30_0[arg_30_1] = num30.ToString();
			
			string[] arg_31_0 = array;
			int arg_31_1 = 31;
			float num31 = this.WHEELFR2.transform.localPosition.y;
			arg_31_0[arg_31_1] = num31.ToString();
			
			string[] arg_32_0 = array;
			int arg_32_1 = 32;
			float num32 = this.WHEELRL2.transform.localPosition.y;
			arg_32_0[arg_32_1] = num32.ToString();
			
			string[] arg_33_0 = array;
			int arg_33_1 = 33;
			float num33 = this.WHEELRR2.transform.localPosition.y;
			arg_33_0[arg_33_1] = num33.ToString();
			
			string str = Environment.GetFolderPath(Environment.SpecialFolder.Personal).Replace("\\", "/");
			Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "/MySummerCar/Mods/ClearanceTool/");
			File.WriteAllLines(str + "/MySummerCar/Mods/ClearanceTool/save.txt", array);
			if (!File.Exists(str + "/MySummerCar/Mods/ClearanceTool/save.txt"))
			{
				ModConsole.Print("ClearanceTool: Error on saving.");
			}
			else
			{
				ModConsole.Print("ClearanceTool: Saved settings.");
			}
        }
    }
}
