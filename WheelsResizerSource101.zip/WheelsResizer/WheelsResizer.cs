﻿using System;
using System.IO;
using MSCLoader;
using UnityEngine;

namespace WheelsResizer
{
    public class WheelsResizer : Mod
    {
        public override string ID { get { return "WheelsResizer"; } }
        public override string Name { get { return "Wheels Resizer"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.1"; } }

        private bool IsActive;
		private bool GetData;
		private bool IsWheelStartScaleSet;
		private float WheelScale;
		private float WheelXScale;
		private float originalFrontRadius;
		private float originalRearRadius;
		private Vector3 originalFrontWheelScale;
		private Vector3 originalRearWheelScale;
		private Vector4 WheelStartScale;
		private GameObject SATSUMA;
		private GameObject WHEELRR;
		private GameObject WHEELRL;
		private GameObject WHEELFR;
		private GameObject WHEELFL;
		
		private Keybind activateKey = new Keybind("Open", "Open Wheel Resizer", KeyCode.F8);
		private Keybind resetValuesKey = new Keybind("ResetAll", "Reset values", KeyCode.R);
		private Keybind saveValuesKey = new Keybind("SaveFile", "Save values to file", KeyCode.F5);
		private Keybind loadValuesKey = new Keybind("LoadFile", "Load values from file", KeyCode.F7);
		private Keybind biggerKey = new Keybind("BiggerAllWheels", "Bigger All Wheels", KeyCode.Keypad6);
		private Keybind smallerKey = new Keybind("SmallerAllWheels", "Smaller All Wheels", KeyCode.Keypad4);
		private Keybind frontBiggerKey = new Keybind("BiggerFrontWheels", "Bigger Front Wheels", KeyCode.Keypad9);
		private Keybind frontSmallerKey = new Keybind("SmallerFrontWheels", "Smaller Front Wheels", KeyCode.Keypad7);
		private Keybind rearBiggerKey = new Keybind("BiggerRearWheels", "Bigger Rear Wheels", KeyCode.Keypad3);
		private Keybind rearSmallerKey = new Keybind("SmallerRearWheels", "Smaller Rear Wheels", KeyCode.Keypad1);
		private Keybind narrowerKey = new Keybind("NarrowerAllWheels", "Narrower All Wheels", KeyCode.Alpha5);
		private Keybind widerKey = new Keybind("WiderAllWheels", "Wider All Wheels", KeyCode.Alpha6);
		private Keybind frontNarrowerKey = new Keybind("NarrowerFrontWheels", "Narrower Front Wheels", KeyCode.Alpha7);
		private Keybind frontWiderKey = new Keybind("WiderFrontWheels", "Wider Front Wheels", KeyCode.Alpha8);
		private Keybind rearNarrowerKey = new Keybind("NarrowerRearWheels", "Narrower Rear Wheels", KeyCode.Alpha9);
		private Keybind rearWiderKey = new Keybind("WiderRearWheels", "Wider Rear Wheels", KeyCode.Alpha0);
		
		public override void OnLoad()
        {
            Keybind.Add(this, activateKey);
			Keybind.Add(this, resetValuesKey);
			Keybind.Add(this, saveValuesKey);
			Keybind.Add(this, loadValuesKey);
			Keybind.Add(this, biggerKey);
			Keybind.Add(this, smallerKey);
			Keybind.Add(this, frontBiggerKey);
			Keybind.Add(this, frontSmallerKey);
			Keybind.Add(this, rearBiggerKey);
			Keybind.Add(this, rearSmallerKey);
			Keybind.Add(this, widerKey);
			Keybind.Add(this, narrowerKey);
			Keybind.Add(this, frontWiderKey);
			Keybind.Add(this, frontNarrowerKey);
			Keybind.Add(this, rearWiderKey);
			Keybind.Add(this, rearNarrowerKey);
        }
		
        public override void Update()
        {
			if (activateKey.IsDown()) { activate1(); };
			if (resetValuesKey.IsDown()) { resetwheels1(); };
			if (saveValuesKey.IsDown()) { savesettings1(); };
			if (loadValuesKey.IsDown()) { loadsettings1(); };
			if (Input.GetKey(biggerKey.Key)) { setnewscales1(); };
			if (Input.GetKey(smallerKey.Key)) { setnewscales2(); };
			if (Input.GetKey(frontBiggerKey.Key)) { setnewscales3(); };
			if (Input.GetKey(frontSmallerKey.Key)) { setnewscales4(); };
			if (Input.GetKey(rearBiggerKey.Key)) { setnewscales5(); };
			if (Input.GetKey(rearSmallerKey.Key)) { setnewscales6(); };
			if (Input.GetKey(widerKey.Key)) { setnewwidth1(); };
			if (Input.GetKey(narrowerKey.Key)) { setnewwidth2(); };
			if (Input.GetKey(frontWiderKey.Key)) { setnewwidth3(); };
			if (Input.GetKey(frontNarrowerKey.Key)) { setnewwidth4(); };
			if (Input.GetKey(rearWiderKey.Key)) { setnewwidth5(); };
			if (Input.GetKey(rearNarrowerKey.Key)) { setnewwidth6(); };
        }
		
		public override void OnGUI()
        {			
            GUIStyle myStyle = new GUIStyle();
			myStyle.fontSize = (int)(12.0f * (float)(Screen.width)/1000f);
			myStyle.normal.textColor = Color.white;
			
			if (this.GetData)
			{
				string text = string.Concat(new object[]
				{
					"Wheels Resizer\n\nPress ",
					this.activateKey.Key,
					" to hide/show this menu.\n\n",
					this.smallerKey.Key,
					" / ",
					this.biggerKey.Key,
					": All wheels size: ",
					this.WHEELFL.transform.localScale.y,
					"\n",
					this.frontSmallerKey.Key,
					" / ",
					this.frontBiggerKey.Key,
					": Front wheels size: ",
					this.WHEELFL.transform.localScale.y,
					"\n",
					this.rearSmallerKey.Key,
					" / ",
					this.rearBiggerKey.Key,
					": Rear wheels size: ",
					this.WHEELRL.transform.localScale.y,
					"\n\n",
					this.narrowerKey.Key,
					" / ",
					this.widerKey.Key,
					": All wheels width: ",
					this.WHEELFL.transform.localScale.x,
					"\n",
					this.frontNarrowerKey.Key,
					" / ",
					this.frontWiderKey.Key,
					": Front wheels width: ",
					this.WHEELFL.transform.localScale.x,
					"\n",
					this.rearNarrowerKey.Key,
					" / ",
					this.rearWiderKey.Key,
					": Rear wheels width: ",
					this.WHEELRL.transform.localScale.x,
					"\n\nPress ",
					this.resetValuesKey.Key,
					" to reset values.\nPress ",
					this.saveValuesKey.Key,
					" to save values to file.\nPress ",
					this.loadValuesKey.Key,
					" to load values from file."
				});
				if (this.IsActive)
				{
					GUI.Label(new Rect(10f, 10f, (float)Screen.width, (float)Screen.height), text, myStyle);
				}
			}
        }
		
		private void activate1()
        {
			if (!this.SATSUMA)
			{
				if (GameObject.Find("SATSUMA(557kg)") != null)
				{
					this.SATSUMA = GameObject.Find("SATSUMA(557kg)");
				}
			}
			else
			{
				if (!this.WHEELRL)
				{
					this.WHEELRL = this.SATSUMA.transform.FindChild("wheelRL").gameObject;
				}
				if (!this.WHEELRR)
				{
					this.WHEELRR = this.SATSUMA.transform.FindChild("wheelRR").gameObject;
				}
				if (!this.WHEELFR)
				{
					this.WHEELFR = this.SATSUMA.transform.FindChild("wheelFR").gameObject;
				}
				if (!this.WHEELFL)
				{
					this.WHEELFL = this.SATSUMA.transform.FindChild("wheelFL").gameObject;
				}
			}
			if (this.WHEELFL != null && this.WHEELRL != null && this.WHEELRR != null && this.WHEELFR != null && !this.IsWheelStartScaleSet)
			{
				if (!this.GetData)
				{
					this.originalFrontWheelScale = this.WHEELFL.transform.localScale;
					this.originalRearWheelScale = this.WHEELRL.transform.localScale;
					this.originalFrontRadius = this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius;
					this.originalRearRadius = this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius;
					this.GetData = true;
				}
				if (!this.IsWheelStartScaleSet && this.GetData)
				{
					this.WheelStartScale = new Vector4(this.WHEELFL.transform.localScale.x, this.WHEELFR.transform.localScale.x, this.WHEELRL.transform.localScale.x, this.WHEELRR.transform.localScale.x);
					this.IsWheelStartScaleSet = true;
				}
			}
			
			this.IsActive = !this.IsActive;
        }
		
		private void resetwheels1()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.ResetWheels();
			}
        }
		
		private void savesettings1()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.SaveSettings();
			}
        }
		
		private void loadsettings1()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.LoadSettings();
			}
        }
		
		private void setnewscales1()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.SetNewWheelScales(false, true, true);
				this.SetWheelRadius(true, true, 1);
			}
        }
		
		private void setnewscales2()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.SetNewWheelScales(true, true, true);
				this.SetWheelRadius(true, true, 0);
			}
        }
		
		private void setnewscales3()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.SetNewWheelScales(false, true, false);
				this.SetWheelRadius(true, false, 1);
			}
        }
		
		private void setnewscales4()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.SetNewWheelScales(true, true, false);
				this.SetWheelRadius(true, false, 0);
			}
        }
		
		private void setnewscales5()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.SetNewWheelScales(false, false, true);
				this.SetWheelRadius(false, true, 1);
			}
        }
		
		private void setnewscales6()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.SetNewWheelScales(true, false, true);
				this.SetWheelRadius(false, true, 0);
			}
        }
		
		private void setnewwidth1()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.SetNewWheelWidth(true, true, true);
			}
        }
		
		private void setnewwidth2()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.SetNewWheelWidth(false, true, true);
			}
        }
		
		private void setnewwidth3()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.SetNewWheelWidth(true, true, false);
			}
        }
		
		private void setnewwidth4()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.SetNewWheelWidth(false, true, false);
			}
        }
		
		private void setnewwidth5()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.SetNewWheelWidth(true, false, true);
			}
        }
		
		private void setnewwidth6()
        {
			if (this.IsActive && this.GetData && this.IsWheelStartScaleSet)
			{
				this.SetNewWheelWidth(false, false, true);
			}
        }
		
		public void SaveSettings()
		{
			string[] array = new string[16];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = this.WHEELFL.transform.localScale.x;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = this.WHEELFL.transform.localScale.y;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = this.WHEELFL.transform.localScale.z;
			arg_13_0[arg_13_1] = num3.ToString();
			
			string[] arg_14_0 = array;
			int arg_14_1 = 3;
			float num4 = this.WHEELFR.transform.localScale.x;
			arg_14_0[arg_14_1] = num4.ToString();
			
			string[] arg_15_0 = array;
			int arg_15_1 = 4;
			float num5 = this.WHEELFR.transform.localScale.y;
			arg_15_0[arg_15_1] = num5.ToString();
			
			string[] arg_16_0 = array;
			int arg_16_1 = 5;
			float num6 = this.WHEELFR.transform.localScale.z;
			arg_16_0[arg_16_1] = num6.ToString();
			
			string[] arg_17_0 = array;
			int arg_17_1 = 6;
			float num7 = this.WHEELRL.transform.localScale.x;
			arg_17_0[arg_17_1] = num7.ToString();
			
			string[] arg_18_0 = array;
			int arg_18_1 = 7;
			float num8 = this.WHEELRL.transform.localScale.y;
			arg_18_0[arg_18_1] = num8.ToString();
			
			string[] arg_19_0 = array;
			int arg_19_1 = 8;
			float num9 = this.WHEELRL.transform.localScale.z;
			arg_19_0[arg_19_1] = num9.ToString();
			
			string[] arg_20_0 = array;
			int arg_20_1 = 9;
			float num10 = this.WHEELRR.transform.localScale.x;
			arg_20_0[arg_20_1] = num10.ToString();
			
			string[] arg_21_0 = array;
			int arg_21_1 = 10;
			float num11 = this.WHEELRR.transform.localScale.y;
			arg_21_0[arg_21_1] = num11.ToString();
			
			string[] arg_22_0 = array;
			int arg_22_1 = 11;
			float num12 = this.WHEELRR.transform.localScale.z;
			arg_22_0[arg_22_1] = num12.ToString();
			
			array[12] = this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius.ToString();
			array[13] = this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius.ToString();
			array[14] = this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius.ToString();
			array[15] = this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius.ToString();
			
			string str = Environment.GetFolderPath(Environment.SpecialFolder.Personal).Replace("\\", "/");
			Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "/MySummerCar/Mods/WheelsResizer/");
			File.WriteAllLines(str + "/MySummerCar/Mods/WheelsResizer/satsuma.txt", array);
			if (!File.Exists(str + "/MySummerCar/Mods/WheelsResizer/satsuma.txt"))
			{
				ModConsole.Print("Wheels Resizer: Error on saving.");
			}
			else
			{
				ModConsole.Print("Wheels Resizer: Saved settings.");
			}
		}
		
		public void LoadSettings()
		{
			string[] array = new string[9];
			string str = Environment.GetFolderPath(Environment.SpecialFolder.Personal).Replace("\\", "/");
			if (File.Exists(str + "/MySummerCar/Mods/WheelsResizer/satsuma.txt"))
			{
				array = File.ReadAllLines(str + "/MySummerCar/Mods/WheelsResizer/satsuma.txt");
				
				this.WHEELFL.transform.localScale = new Vector3(float.Parse(array[0]), float.Parse(array[1]), float.Parse(array[2]));
				
				this.WHEELFR.transform.localScale = new Vector3(float.Parse(array[3]), float.Parse(array[4]), float.Parse(array[5]));
				
				this.WHEELRL.transform.localScale = new Vector3(float.Parse(array[6]), float.Parse(array[7]), float.Parse(array[8]));
				
				this.WHEELRR.transform.localScale = new Vector3(float.Parse(array[9]), float.Parse(array[10]), float.Parse(array[11]));
				
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = float.Parse(array[12]);
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = float.Parse(array[13]);
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = float.Parse(array[14]);
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = float.Parse(array[15]);
				
				ModConsole.Print("Wheels Resizer: Saved settings loaded.");
			}
			else
			{
				ModConsole.Print("Wheels Resizer: No saved settings found!");
			}
		}

		public void ResetWheels()
        {
            this.WHEELFL.transform.localScale = originalFrontWheelScale;
			this.WHEELFR.transform.localScale = originalFrontWheelScale;
			this.WHEELRR.transform.localScale = originalRearWheelScale;
			this.WHEELRL.transform.localScale = originalRearWheelScale;
			this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = this.originalFrontRadius;
			this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = this.originalFrontRadius;
			this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = this.originalRearRadius;
			this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = this.originalRearRadius;
        }
		
		public void SetNewWheelScales(bool IsDirectionLeft, bool IsFrontWheels, bool IsRearWheels)
        {
            if (IsDirectionLeft)
			{
				this.WheelScale = -0.001f;
			}
			else
			{
				this.WheelScale = 0.001f;
			}
			if (IsFrontWheels)
			{
				this.WHEELFL.transform.localScale = new Vector3(this.WHEELFL.transform.localScale.x + this.WheelScale, this.WHEELFL.transform.localScale.y + this.WheelScale, this.WHEELFL.transform.localScale.z + this.WheelScale);
				this.WHEELFR.transform.localScale = new Vector3(this.WHEELFR.transform.localScale.x + this.WheelScale, this.WHEELFR.transform.localScale.y + this.WheelScale, this.WHEELFR.transform.localScale.z + this.WheelScale);
			}
			if (IsRearWheels)
			{
				this.WHEELRR.transform.localScale = new Vector3(this.WHEELRR.transform.localScale.x + this.WheelScale, this.WHEELRR.transform.localScale.y + this.WheelScale, this.WHEELRR.transform.localScale.z + this.WheelScale);
				this.WHEELRL.transform.localScale = new Vector3(this.WHEELRL.transform.localScale.x + this.WheelScale, this.WHEELRL.transform.localScale.y + this.WheelScale, this.WHEELRL.transform.localScale.z + this.WheelScale);
			}
        }
		
		public void SetNewWheelWidth(bool IsDirectionUp, bool IsFrontWheels, bool IsRearWheels)
		{
			if (IsDirectionUp)
			{
				this.WheelXScale = 0.001f;
			}
			else
			{
				this.WheelXScale = -0.001f;
			}
			if (IsFrontWheels)
			{
				this.WHEELFL.transform.localScale = new Vector3(this.WHEELFL.transform.localScale.x + this.WheelXScale, this.WHEELFL.transform.localScale.y, this.WHEELFL.transform.localScale.z);
				this.WHEELFR.transform.localScale = new Vector3(this.WHEELFR.transform.localScale.x + this.WheelXScale, this.WHEELFR.transform.localScale.y, this.WHEELFR.transform.localScale.z);
			}
			if (IsRearWheels)
			{
				this.WHEELRR.transform.localScale = new Vector3(this.WHEELRR.transform.localScale.x + this.WheelXScale, this.WHEELRR.transform.localScale.y, this.WHEELRR.transform.localScale.z);
				this.WHEELRL.transform.localScale = new Vector3(this.WHEELRL.transform.localScale.x + this.WheelXScale, this.WHEELRL.transform.localScale.y, this.WHEELRL.transform.localScale.z);
			}
		}
		
		public void SetWheelRadius(bool IsFront, bool IsRear, int Direction)
        {
            if (Direction == 0)
			{
				if (IsFront)
				{
					this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius -= this.originalFrontRadius/1000f;
					this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius -= this.originalFrontRadius/1000f;
				}
				if (IsRear)
				{
					this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius -= this.originalRearRadius/1000f;
					this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius -= this.originalRearRadius/1000f;
				}
			}
			else
			{
				if (IsFront)
				{
					this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius += this.originalFrontRadius/1000f;
					this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius += this.originalFrontRadius/1000f;
				}
				if (IsRear)
				{
					this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius += this.originalRearRadius/1000f;
					this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius += this.originalRearRadius/1000f;
				}
			}
        }
    }
}
