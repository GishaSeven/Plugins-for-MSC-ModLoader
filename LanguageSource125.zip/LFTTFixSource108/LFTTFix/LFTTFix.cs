﻿using MSCLoader;
using System.Linq;
using UnityEngine;
using HutongGames.PlayMaker;

namespace LFTTFix
{
    public class LFTTFix : Mod
    {
        public override string ID => "LFTTFix";
        public override string Name => "LFTTFix";
        public override string Author => "Roman266";
        public override string Version => "1.0.8";
		
		private bool endingtranslated;

		public override bool LoadInMenu => true;
		public override bool UseAssetsFolder => false;
		
		public override void OnMenuLoad() 
		{
			GameObject.Find("Interface/Buttons").transform.localPosition = new Vector3(GameObject.Find("Interface/Buttons").transform.localPosition.x + 0.058f, GameObject.Find("Interface/Buttons").transform.localPosition.y, GameObject.Find("Interface/Buttons").transform.localPosition.z);
			
			Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/1").transform.localPosition = new Vector3(Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/1").transform.localPosition.x, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/1").transform.localPosition.y + -0.032f, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/1").transform.localPosition.z);
			
			Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/2").transform.localPosition = new Vector3(Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/2").transform.localPosition.x, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/2").transform.localPosition.y + -0.032f, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/2").transform.localPosition.z);
			
			Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/3").transform.localPosition = new Vector3(Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/3").transform.localPosition.x, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/3").transform.localPosition.y + -0.032f, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/3").transform.localPosition.z);
			
			Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/4").transform.localPosition = new Vector3(Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/4").transform.localPosition.x, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/4").transform.localPosition.y + -0.032f, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/4").transform.localPosition.z);
			
			Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/5").transform.localPosition = new Vector3(Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/5").transform.localPosition.x, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/5").transform.localPosition.y + -0.032f, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/5").transform.localPosition.z);
			
			Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/6").transform.localPosition = new Vector3(Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/6").transform.localPosition.x, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/6").transform.localPosition.y + -0.032f, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/6").transform.localPosition.z);
			
			Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/7").transform.localPosition = new Vector3(Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/7").transform.localPosition.x, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/7").transform.localPosition.y + -0.032f, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/7").transform.localPosition.z);
			
			Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/8").transform.localPosition = new Vector3(Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/8").transform.localPosition.x, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/8").transform.localPosition.y + -0.02f, Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "Licence").transform.Find("Card/8").transform.localPosition.z);
		}
		
		public override void OnLoad()
		{
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/Fatigue/TextFI").GetComponent<TextMesh>().characterSize = 0.0035f;
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/Fatigue/TextEN").GetComponent<TextMesh>().characterSize = 0.003f;
			
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/HitAndRun/TextFI").GetComponent<TextMesh>().characterSize = 0.0035f;
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/HitAndRun/TextEN").GetComponent<TextMesh>().characterSize = 0.003f;
			
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/RunOverRally/TextFI").GetComponent<TextMesh>().characterSize = 0.0035f;
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/RunOverRally/TextEN").GetComponent<TextMesh>().characterSize = 0.003f;
			
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/Hitchhiker/TextFI").GetComponent<TextMesh>().characterSize = 0.0035f;
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/Hitchhiker/TextEN").GetComponent<TextMesh>().characterSize = 0.003f;
			
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/Rally/TextFI").GetComponent<TextMesh>().characterSize = 0.0035f;
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/Rally/TextEN").GetComponent<TextMesh>().characterSize = 0.003f;
			
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/Shit/TextFI").GetComponent<TextMesh>().characterSize = 0.0035f;
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/Shit/TextEN").GetComponent<TextMesh>().characterSize = 0.003f;
			
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/Thirst/TextFI").GetComponent<TextMesh>().characterSize = 0.0035f;
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/Thirst/TextEN").GetComponent<TextMesh>().characterSize = 0.003f;
			
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/Urine/TextFI").GetComponent<TextMesh>().characterSize = 0.0035f;
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/Urine/TextEN").GetComponent<TextMesh>().characterSize = 0.003f;
			
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/Murder/TextFI").GetComponent<TextMesh>().characterSize = 0.0035f;
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/Murder/TextEN").GetComponent<TextMesh>().characterSize = 0.003f;
			
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/GasolineFire/TextFI").GetComponent<TextMesh>().characterSize = 0.0035f;
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/GasolineFire/TextEN").GetComponent<TextMesh>().characterSize = 0.003f;
			
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/EDM/TextFI").GetComponent<TextMesh>().characterSize = 0.0035f;
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/EDM/TextEN").GetComponent<TextMesh>().characterSize = 0.003f;
			
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/PissTV/TextFI").GetComponent<TextMesh>().characterSize = 0.0035f;
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/PissTV/TextEN").GetComponent<TextMesh>().characterSize = 0.003f;
			
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/InJail/TextFI").GetComponent<TextMesh>().characterSize = 0.0035f;
			GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/InJail/TextEN").GetComponent<TextMesh>().characterSize = 0.003f;
			
			GameObject.Find("Sheets").transform.Find("TrafficTicket/Texts").transform.localPosition = new Vector3(GameObject.Find("Sheets").transform.Find("TrafficTicket/Texts").transform.localPosition.x, GameObject.Find("Sheets").transform.Find("TrafficTicket/Texts").transform.localPosition.y + -0.004f, GameObject.Find("Sheets").transform.Find("TrafficTicket/Texts").transform.localPosition.z);
			
			GameObject.Find("Sheets").transform.Find("LottoTicket/Kierros").transform.localPosition = new Vector3(GameObject.Find("Sheets").transform.Find("LottoTicket/Kierros").transform.localPosition.x + 0.008f, GameObject.Find("Sheets").transform.Find("LottoTicket/Kierros").transform.localPosition.y + -0.0033f, GameObject.Find("Sheets").transform.Find("LottoTicket/Kierros").transform.localPosition.z);
			
			GameObject.Find("Sheets").transform.Find("LottoTicket/Pay/01_name").transform.localPosition = new Vector3(GameObject.Find("Sheets").transform.Find("LottoTicket/Pay/01_name").transform.localPosition.x + 0.0091f, GameObject.Find("Sheets").transform.Find("LottoTicket/Pay/01_name").transform.localPosition.y, GameObject.Find("Sheets").transform.Find("LottoTicket/Pay/01_name").transform.localPosition.z);
			
			GameObject.Find("Sheets").transform.Find("Arrestwarrant/Texts").transform.localPosition = new Vector3(GameObject.Find("Sheets").transform.Find("Arrestwarrant/Texts").transform.localPosition.x, GameObject.Find("Sheets").transform.Find("Arrestwarrant/Texts").transform.localPosition.y + -0.004f, GameObject.Find("Sheets").transform.Find("Arrestwarrant/Texts").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/HEADER/Texts/Status").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/HEADER/Texts/Status").transform.localPosition.x + 1f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/HEADER/Texts/Status").transform.localPosition.y, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/HEADER/Texts/Status").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/100/Texts").gameObject.transform.GetChild(0).transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/100/Texts").gameObject.transform.GetChild(0).transform.localPosition.x + 1f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/100/Texts").gameObject.transform.GetChild(0).transform.localPosition.y, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/100/Texts").gameObject.transform.GetChild(0).transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/101/Texts").gameObject.transform.GetChild(0).transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/101/Texts").gameObject.transform.GetChild(0).transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/101/Texts").gameObject.transform.GetChild(0).transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/101/Texts").gameObject.transform.GetChild(0).transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Header").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Header").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Header").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Header").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Day").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Day").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Day").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Day").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Bottomline").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Bottomline").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Bottomline").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Bottomline").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Header").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Header").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Header").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Header").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Day").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Day").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Day").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Day").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Bottomline").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Bottomline").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Bottomline").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Bottomline").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Header").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Header").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Header").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Header").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Day").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Day").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Day").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Day").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Bottomline").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Bottomline").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Bottomline").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Bottomline").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/180/Texts").gameObject.transform.GetChild(0).transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/180/Texts").gameObject.transform.GetChild(0).transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/180/Texts").gameObject.transform.GetChild(0).transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/180/Texts").gameObject.transform.GetChild(0).transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Header").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Header").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Header").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Header").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Day").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Day").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Day").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Day").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Bottomline").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Bottomline").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Bottomline").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Bottomline").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Weather").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Weather").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Weather").transform.localPosition.y + 0.08f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Weather").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Header").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Header").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Header").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Header").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Day").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Day").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Day").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Day").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Bottomline").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Bottomline").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Bottomline").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Bottomline").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Header").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Header").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Header").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Header").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Day").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Day").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Day").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Day").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Bottomline").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Bottomline").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Bottomline").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Bottomline").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/200/Texts").gameObject.transform.GetChild(0).transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/200/Texts").gameObject.transform.GetChild(0).transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/200/Texts").gameObject.transform.GetChild(0).transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/200/Texts").gameObject.transform.GetChild(0).transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Header").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Header").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Header").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Header").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Day").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Day").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Day").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Day").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Bottomline").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Bottomline").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Bottomline").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Bottomline").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Header").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Header").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Header").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Header").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Day").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Day").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Day").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Day").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Bottomline").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Bottomline").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Bottomline").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Bottomline").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Header").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Header").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Header").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Header").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Day").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Day").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Day").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Day").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Bottomline").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Bottomline").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Bottomline").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Bottomline").transform.localPosition.z);
			
			GameObject.Find("RALLY").transform.Find("RallyTV/Program/RallyTVGUI/Onboard/Speed").transform.localPosition = new Vector3(GameObject.Find("RALLY").transform.Find("RallyTV/Program/RallyTVGUI/Onboard/Speed").transform.localPosition.x, GameObject.Find("RALLY").transform.Find("RallyTV/Program/RallyTVGUI/Onboard/Speed").transform.localPosition.y + -0.015f, GameObject.Find("RALLY").transform.Find("RallyTV/Program/RallyTVGUI/Onboard/Speed").transform.localPosition.z);
			
			GameObject.Find("RALLY").transform.Find("RallyTV/Program/RallyTVGUI/Onboard/RPM").transform.localPosition = new Vector3(GameObject.Find("RALLY").transform.Find("RallyTV/Program/RallyTVGUI/Onboard/RPM").transform.localPosition.x, GameObject.Find("RALLY").transform.Find("RallyTV/Program/RallyTVGUI/Onboard/RPM").transform.localPosition.y + -0.015f, GameObject.Find("RALLY").transform.Find("RallyTV/Program/RallyTVGUI/Onboard/RPM").transform.localPosition.z);
			
			GameObject.Find("RALLY").transform.Find("RallyTV/Program/RallyTVGUI/Onboard/Text").transform.localPosition = new Vector3(GameObject.Find("RALLY").transform.Find("RallyTV/Program/RallyTVGUI/Onboard/Text").transform.localPosition.x, GameObject.Find("RALLY").transform.Find("RallyTV/Program/RallyTVGUI/Onboard/Text").transform.localPosition.y + -0.02f, GameObject.Find("RALLY").transform.Find("RallyTV/Program/RallyTVGUI/Onboard/Text").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Header").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Header").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Header").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Header").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Day").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Day").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Day").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Day").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Round").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Round").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Round").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Round").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts").gameObject.transform.GetChild(8).transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts").gameObject.transform.GetChild(8).transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts").gameObject.transform.GetChild(8).transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts").gameObject.transform.GetChild(8).transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/400/Texts").gameObject.transform.GetChild(0).transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/400/Texts").gameObject.transform.GetChild(0).transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/400/Texts").gameObject.transform.GetChild(0).transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/400/Texts").gameObject.transform.GetChild(0).transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Header").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Header").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Header").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Header").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Day").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Day").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Day").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Day").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Bottomline").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Bottomline").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Bottomline").transform.localPosition.y + 0.09f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Bottomline").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/500/Texts").gameObject.transform.GetChild(0).transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/500/Texts").gameObject.transform.GetChild(0).transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/500/Texts").gameObject.transform.GetChild(0).transform.localPosition.y + 0.067f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/500/Texts").gameObject.transform.GetChild(0).transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/501/Texts/BottomLine").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/501/Texts/BottomLine").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/501/Texts/BottomLine").transform.localPosition.y + 0.067f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/501/Texts/BottomLine").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/502/Texts/Header").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/502/Texts/Header").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/502/Texts/Header").transform.localPosition.y + 0.067f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/502/Texts/Header").transform.localPosition.z);
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/502/Texts/BottomLine").transform.localPosition = new Vector3(GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/502/Texts/BottomLine").transform.localPosition.x, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/502/Texts/BottomLine").transform.localPosition.y + 0.067f, GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/502/Texts/BottomLine").transform.localPosition.z);
			
			if(GameObject.Find("YARD/Building/BEDROOM1") != null)
			{
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/Software").gameObject.transform.GetChild(1).GetComponent<TextMesh>().characterSize = 2.8f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/Software").gameObject.transform.GetChild(1).GetComponent<TextMesh>().lineSpacing = 0.77f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/Software").gameObject.transform.GetChild(2).GetComponent<TextMesh>().characterSize = 2.8f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/Software").gameObject.transform.GetChild(2).GetComponent<TextMesh>().lineSpacing = 0.77f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/Software/text 2").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/Software/BaudRate").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/Software/StatusBar").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/POS/Command").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/POS/Command").GetComponent<TextMesh>().lineSpacing = 0.8f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/POS/Text").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/POS/Text").GetComponent<TextMesh>().lineSpacing = 0.8f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/CommandLine").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/CommandLine").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/DownloadError").transform.localPosition = new Vector3(GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/DownloadError").localPosition.x + -0.5f, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/DownloadError").transform.localPosition.y, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/DownloadError").transform.localPosition.z);
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/DownloadError").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/DownloadError").GetComponent<TextMesh>().lineSpacing = 0.1f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/DownloadStatus").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/DownloadStatus").GetComponent<TextMesh>().lineSpacing = 0.1f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/DownloadStatus/1").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/DownloadStatus/1").GetComponent<TextMesh>().lineSpacing = 0.1f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/DownloadStatus/TotalKB").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/DownloadStatus/TotalKB").GetComponent<TextMesh>().lineSpacing = 0.1f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/SPLASH/Welcome").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/SPLASH/Welcome").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/SPLASH/Welcome/Name").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/SPLASH/Welcome/Name").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/text").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/text").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 1").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 1").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 2").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 2").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 3").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 3").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 4").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 4").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 5").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 5").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 6").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 6").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 7").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 7").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 8").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 8").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 9").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 9").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 10").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/FILES/game 10").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/GFX").gameObject.transform.GetChild(2).transform.localPosition = new Vector3(GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/GFX").gameObject.transform.GetChild(2).transform.localPosition.x + -1.1f, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/GFX").gameObject.transform.GetChild(2).transform.localPosition.y, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/GFX").gameObject.transform.GetChild(2).transform.localPosition.z);
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/GFX").gameObject.transform.GetChild(2).GetComponent<TextMesh>().characterSize = 2f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/GFX").gameObject.transform.GetChild(3).GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/GFX").gameObject.transform.GetChild(3).GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/GFX").gameObject.transform.GetChild(4).GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/GFX").gameObject.transform.GetChild(4).GetComponent<TextMesh>().lineSpacing = 0.1f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/RANKS/text").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/RANKS/text").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/POS/BIOS/WAIT").GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/POS/BIOS/WAIT").GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/POS/BIOS").gameObject.transform.GetChild(0).GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/POS/BIOS").gameObject.transform.GetChild(0).GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/POS/BIOS").gameObject.transform.GetChild(1).GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/POS/BIOS").gameObject.transform.GetChild(1).GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/POS/BIOS").gameObject.transform.GetChild(2).GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/POS/BIOS").gameObject.transform.GetChild(2).GetComponent<TextMesh>().lineSpacing = 0.79f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/POS/BIOS").gameObject.transform.GetChild(3).GetComponent<TextMesh>().characterSize = 2.5f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/POS/BIOS").gameObject.transform.GetChild(3).GetComponent<TextMesh>().lineSpacing = 0.6f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Filosofiapeli/Filosofi-aika-text").transform.localPosition = new Vector3(GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Filosofiapeli/Filosofi-aika-text").transform.localPosition.x + -0.32f, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Filosofiapeli/Filosofi-aika-text").transform.localPosition.y, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Filosofiapeli/Filosofi-aika-text").transform.localPosition.z);
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Score").transform.localPosition = new Vector3(GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Score").transform.localPosition.x + -0.7f, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Score").transform.localPosition.y, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Score").transform.localPosition.z);
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/PasejaVoitettu").transform.localPosition = new Vector3(GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/PasejaVoitettu").transform.localPosition.x + 0.3f, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/PasejaVoitettu").transform.localPosition.y, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/PasejaVoitettu").transform.localPosition.z);
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Lopputulos/Score-Final").transform.localPosition = new Vector3(GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Lopputulos/Score-Final").transform.localPosition.x + -2f, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Lopputulos/Score-Final").transform.localPosition.y, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Lopputulos/Score-Final").transform.localPosition.z);
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Lopputulos/Score-Final-Pasit").transform.localPosition = new Vector3(GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Lopputulos/Score-Final-Pasit").transform.localPosition.x + -4.31f, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Lopputulos/Score-Final-Pasit").transform.localPosition.y, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Lopputulos/Score-Final-Pasit").transform.localPosition.z);
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Alkuvalikko/Asetukset/Nimi").GetComponent<TextMesh>().characterSize = 0.19f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Alkuvalikko/Asetukset/Nimi").GetComponent<TextMesh>().lineSpacing = 0.76f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/CPUpelaajat/Kello").transform.localPosition = new Vector3(GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/CPUpelaajat/Kello").transform.localPosition.x + 0.101f, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/CPUpelaajat/Kello").transform.localPosition.y, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/CPUpelaajat/Kello").transform.localPosition.z + -0.067f);
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Tulokset/TuloksetKisa/Otsikko").transform.localPosition = new Vector3(GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Tulokset/TuloksetKisa/Otsikko").transform.localPosition.x + -0.2f, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Tulokset/TuloksetKisa/Otsikko").transform.localPosition.y, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Tulokset/TuloksetKisa/Otsikko").transform.localPosition.z);
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Rapula/Rapula-Text-LivesNumber").transform.localPosition = new Vector3(GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Rapula/Rapula-Text-LivesNumber").transform.localPosition.x + 0.15f, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Rapula/Rapula-Text-LivesNumber").transform.localPosition.y, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Rapula/Rapula-Text-LivesNumber").transform.localPosition.z);
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Sormileikki/Laskuri-push").transform.localPosition = new Vector3(GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Sormileikki/Laskuri-push").transform.localPosition.x + -1f, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Sormileikki/Laskuri-push").transform.localPosition.y, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Sormileikki/Laskuri-push").transform.localPosition.z);
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Sormileikki/Text-Aika").transform.localPosition = new Vector3(GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Sormileikki/Text-Aika").transform.localPosition.x + -0.8f, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Sormileikki/Text-Aika").transform.localPosition.y, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Sormileikki/Text-Aika").transform.localPosition.z);
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest/Mekaanikka/Level/GameObject").transform.localPosition = new Vector3(GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest/Mekaanikka/Level/GameObject").transform.localPosition.x + -5f, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest/Mekaanikka/Level/GameObject").transform.localPosition.y, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest/Mekaanikka/Level/GameObject").transform.localPosition.z);
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest/Mekaanikka/Level").transform.localPosition = new Vector3(GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest/Mekaanikka/Level").transform.localPosition.x + 0.2f, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest/Mekaanikka/Level").transform.localPosition.y, GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest/Mekaanikka/Level").transform.localPosition.z);
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-WorldsMan/WorldsMan-Instructions/WorldsMan-Instructions-GrassText").GetComponent<TextMesh>().characterSize = 1.2f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-WorldsMan/WorldsMan-Instructions/WorldsMan-Instructions-ForestText").GetComponent<TextMesh>().characterSize = 1.2f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-WorldsMan/WorldsMan-Instructions/WorldsMan-Instructions-DesertText").GetComponent<TextMesh>().characterSize = 1.2f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-WorldsMan/WorldsMan-Instructions/WorldsMan-Instructions-OceanText").GetComponent<TextMesh>().characterSize = 1.2f;
				GameObject.Find("YARD").transform.Find("Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-WorldsMan/WorldsMan-Instructions/WorldsMan-Instructions-MountainsText").GetComponent<TextMesh>().characterSize = 1.2f;
			}
			
			GameObject.Find("GUI/Indicators/Subtitles").transform.GetComponent<TextMesh>().alignment = TextAlignment.Center;
			GameObject.Find("GUI/Indicators/Subtitles/Shadow").transform.GetComponent<TextMesh>().alignment = TextAlignment.Center;
			
			GameObject.Find("GUI/Indicators/Fluids").transform.localPosition = new Vector3(GameObject.Find("GUI/Indicators/Fluids").transform.localPosition.x, GameObject.Find("GUI/Indicators/Fluids").transform.localPosition.y + 0.9f, GameObject.Find("GUI/Indicators/Fluids").transform.localPosition.z);
			GameObject.Find("GUI/Indicators/Partname").transform.localPosition = new Vector3(GameObject.Find("GUI/Indicators/Partname").transform.localPosition.x, GameObject.Find("GUI/Indicators/Partname").transform.localPosition.y + 0.9f, GameObject.Find("GUI/Indicators/Partname").transform.localPosition.z);
			GameObject.Find("GUI/Indicators/Subtitles").transform.localPosition = new Vector3(GameObject.Find("GUI/Indicators/Subtitles").transform.localPosition.x, GameObject.Find("GUI/Indicators/Subtitles").transform.localPosition.y + 0.9f, GameObject.Find("GUI/Indicators/Subtitles").transform.localPosition.z);
			
			HutongGames.PlayMaker.Actions.FloatClamp subtitletime1 = GameObject.Find("GUI/Indicators/Subtitles").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[4] as HutongGames.PlayMaker.Actions.FloatClamp;
			subtitletime1.maxValue = 120f;
			
			HutongGames.PlayMaker.Actions.FloatClamp subtitletime2 = GameObject.Find("GUI/Indicators/Subtitles/Shadow").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[4] as HutongGames.PlayMaker.Actions.FloatClamp;
			subtitletime2.maxValue = 120f;
			
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Antialiasing/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Antialiasing/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Bloom/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Bloom/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_RefProbes/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_RefProbes/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Sunshafts/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Sunshafts/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Contrast/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Contrast/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_HDR/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_HDR/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_HeadBob/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_HeadBob/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_DriveBob/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_DriveBob/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_FOV/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_FOV/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Draw/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Draw/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_ShadowsSun/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_ShadowsSun/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_ShadowsHouse/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_ShadowsHouse/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Water/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Water/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Skidmarks/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Skidmarks/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Dustclouds/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Dustclouds/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Mirrors/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Mirrors/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Subtitles/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Subtitles/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Gear/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_Gear/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_FPS/GUITextlabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Buttons/Btn_FPS/GUITextlabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/SteeringLeft/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/SteeringLeft/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/SteeringRight/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/SteeringRight/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/ThrottleCombined/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/ThrottleCombined/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/BrakeCombined/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/BrakeCombined/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/ClutchCombined/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/ClutchCombined/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/ThrottleNonCom/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/ThrottleNonCom/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/BrakeNonCom/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/BrakeNonCom/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/ClutchNonCom/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/ClutchNonCom/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/ThrottleButton/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/ThrottleButton/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/BrakeButton/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/BrakeButton/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/ClutchButton/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Buttons/ClutchButton/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/SettingThrottle/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/SettingThrottle/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/SettingBrake/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/SettingBrake/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/SettingClutch/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/SettingClutch/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page2/Calibrate/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page2/Calibrate/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page2/DeadzoneS/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page2/DeadzoneS/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page2/DeadzoneT/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page2/DeadzoneT/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page2/DeadzoneB/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page2/DeadzoneB/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page2/DeadzoneC/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page2/DeadzoneC/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
						
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/AssignWindow/WindowThrottle/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/AssignWindow/WindowThrottle/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/AssignWindow/WindowBrake/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/AssignWindow/WindowBrake/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/AssignWindow/WindowClutch/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/AssignWindow/WindowClutch/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/AssignWindow/WindowThrottle/Stage1/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/AssignWindow/WindowThrottle/Stage1/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/AssignWindow/WindowBrake/Stage1/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/AssignWindow/WindowBrake/Stage1/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/AssignWindow/WindowClutch/Stage1/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/AssignWindow/WindowClutch/Stage1/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;

			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Handbrake/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Handbrake/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Shift Up/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Shift Up/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Shift Down/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Shift Down/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Neutral/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Neutral/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/1/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/1/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/2/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/2/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/3/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/3/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/4/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/4/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/5/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/5/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/6/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/6/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Reverse/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Reverse/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Range/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Range/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Beams/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Beams/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Wipers/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Wipers/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/TurnSignalLeft/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/TurnSignalLeft/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/TurnSignalRight/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/TurnSignalRight/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Boost/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Buttons/Boost/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;

			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/AutoClutch/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/AutoClutch/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/Shifter/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/Shifter/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/BrakeDelay/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/BrakeDelay/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/ThrottleDelay/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/ThrottleDelay/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/ClutchSensitivity/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/ClutchSensitivity/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/SteerRotation/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/SteerRotation/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/SteerHelp").gameObject.transform.GetChild(0).transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/SteerHelp").gameObject.transform.GetChild(0).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/SteerHelp").gameObject.transform.GetChild(1).transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/SteerHelp").gameObject.transform.GetChild(1).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/SteerHelp").gameObject.transform.GetChild(2).transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/SteerHelp").gameObject.transform.GetChild(2).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/FFB").gameObject.transform.GetChild(0).transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/FFB").gameObject.transform.GetChild(0).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/FFB").gameObject.transform.GetChild(1).transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/FFB").gameObject.transform.GetChild(1).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/FFB").gameObject.transform.GetChild(2).transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/FFB").gameObject.transform.GetChild(2).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/FFB").gameObject.transform.GetChild(3).transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Buttons/FFB").gameObject.transform.GetChild(3).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Forward/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Forward/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Backward/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Backward/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Left/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Left/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Right/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Right/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Use/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Use/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Jump/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Jump/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Run/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Run/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/DrivingMode/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/DrivingMode/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Zoom/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Zoom/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Crouch/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Crouch/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/ReachLeft/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/ReachLeft/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/ReachRight/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/ReachRight/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Swear/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Swear/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Drunk/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Drunk/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Hit/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Hit/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Push/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Push/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Finger/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Finger/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Urinate/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Urinate/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Hitchhike/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Hitchhike/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Smoking/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Smoking/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Watch/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons/Watch/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons").gameObject.transform.GetChild(21).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons").gameObject.transform.GetChild(21).GetChild(0).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons").gameObject.transform.GetChild(22).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Buttons").gameObject.transform.GetChild(22).GetChild(0).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2").gameObject.transform.GetChild(8).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2").gameObject.transform.GetChild(8).GetChild(0).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2").gameObject.transform.GetChild(9).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2").gameObject.transform.GetChild(9).GetChild(0).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2").gameObject.transform.GetChild(10).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2").gameObject.transform.GetChild(10).GetChild(0).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2").gameObject.transform.GetChild(11).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2").gameObject.transform.GetChild(11).GetChild(0).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2").gameObject.transform.GetChild(12).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2").gameObject.transform.GetChild(12).GetChild(0).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseLeft").gameObject.transform.GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseLeft").gameObject.transform.GetChild(0).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseLeft").gameObject.transform.GetChild(1).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseLeft").gameObject.transform.GetChild(1).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseLeft").gameObject.transform.GetChild(2).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseLeft").gameObject.transform.GetChild(2).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseLeft").gameObject.transform.GetChild(3).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseLeft").gameObject.transform.GetChild(3).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;			
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseMiddle").gameObject.transform.GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseMiddle").gameObject.transform.GetChild(0).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseMiddle").gameObject.transform.GetChild(1).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseMiddle").gameObject.transform.GetChild(1).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseMiddle").gameObject.transform.GetChild(2).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseMiddle").gameObject.transform.GetChild(2).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseRight").gameObject.transform.GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseRight").gameObject.transform.GetChild(0).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseRight").gameObject.transform.GetChild(1).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseRight").gameObject.transform.GetChild(1).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseRight").gameObject.transform.GetChild(2).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Mouse/MouseRight").gameObject.transform.GetChild(2).GetChild(0).transform.transform.GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Btn_Mouse/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Btn_Mouse/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Btn_SensitivityX/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Btn_SensitivityX/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Btn_SensitivityY/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Btn_SensitivityY/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_Resume/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_Resume/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_Graphics/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_Graphics/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_CarControls/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_CarControls/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_CarButtons/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_CarButtons/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_PlayerControls/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_PlayerControls/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_Reset/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_Reset/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_Quit/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_Quit/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_Quit/GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Btn_Quit/GUITextLabel/GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu").transform.Find("Btn_ConfirmQuit").transform.Find("GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu").transform.Find("Btn_ConfirmQuit").transform.Find("GUITextLabel").transform.Find("GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu").transform.Find("Btn_ConfirmQuit").transform.Find("Text").GetComponent<TextMesh>().characterSize = 0.09f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu").transform.Find("Btn_ConfirmReset").transform.Find("GUITextLabel").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu").transform.Find("Btn_ConfirmReset").transform.Find("GUITextLabel").transform.Find("GUITextLabelShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu").transform.Find("Btn_ConfirmReset").transform.Find("Text").GetComponent<TextMesh>().characterSize = 0.09f;
			
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Header 4/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Menu/Header 4/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Header 4/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Header 4/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Header 5/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Header 5/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Header 6/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Header 6/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Header 7/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/Graphics/Page1/Header 7/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Header 8/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Header 8/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Header 9/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page1/Header 9/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Header 9/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Header 9/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Header 10/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Header 10/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Header 11/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/PlayerControls/Page2/Header 11/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Header 3/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Header 3/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Header 5/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Header 5/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Header 6/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Header 6/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Header 4/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Header 4/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Header 8/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page1/Header 8/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page2/Header 7/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DrivingControls/Page2/Header 7/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DEBUG/Header3/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/DEBUG/Header3/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Header 3/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page1/Header 3/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Header2/GUITextHeader").GetComponent<TextMesh>().characterSize = 0.07f;
			GameObject.Find("Systems").transform.Find("OptionsMenu/VehicleControls/Page2/Header2/GUITextHeader/GUITextHeaderShadow").GetComponent<TextMesh>().characterSize = 0.07f;
		}
		
		public override void Update()
		{
			if(Application.loadedLevelName == "Ending")
			{
				if(!endingtranslated)
				{
					GameObject.Find("Intro/Credits/name").GetComponent<TextMesh>().lineSpacing = 0.8f;
					endingtranslated = true;
				}
			}
		}
    }
}
