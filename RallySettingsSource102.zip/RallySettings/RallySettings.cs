﻿using MSCLoader;
using UnityEngine;
using HutongGames.PlayMaker;
using System.Linq;

namespace RallySettings
{
    public class RallySettings : Mod
    {
        public override string ID => "RallySettings";
        public override string Name => "Rally Settings";
        public override string Author => "EasyAnarchy";
        public override string Version => "1.0.2";
		
		private bool SaturdayRouteChanged;
		private bool SundayRouteChanged;
		private bool CheckPointsVisualizated;
		private bool TrafficDisabled;
		private GameObject SATStartTent;
		private GameObject SATStartTable;
		private GameObject SATStartFleetari;
		private GameObject SATStartSender;
		private GameObject SATStartSign05;
		private GameObject SATStartSign08;
		private GameObject StagingSAT;
		private GameObject StartSAT;
		private GameObject Checpoint1SAT;
		private GameObject Checpoint2SAT;
		private GameObject Checpoint3SAT;
		private GameObject Checpoint4SAT;
		private GameObject VisualStagingSAT;
		private GameObject VisualStartSAT;
		private GameObject VisualCheck1SAT;
		private GameObject VisualCheck2SAT;
		private GameObject VisualCheck3SAT;
		private GameObject VisualCheck4SAT;
		private GameObject StagingSUN;
		private GameObject StartSUN;
		private GameObject Checpoint1SUN;
		private GameObject Checpoint2SUN;
		private GameObject Checpoint3SUN;
		private GameObject Checpoint4SUN;
		private GameObject VisualStagingSUN;
		private GameObject VisualStartSUN;
		private GameObject VisualCheck1SUN;
		private GameObject VisualCheck2SUN;
		private GameObject VisualCheck3SUN;
		private GameObject VisualCheck4SUN;
		private GameObject SUNStartFleetari;
		private GameObject SUNStartSender;
		private GameObject SUNStartSign05;
		private GameObject SUNStartSign08;
		
		private GameObject SATFinishSign03;
		private GameObject SATFinishSign05;
		private GameObject SATFinishSign04;
		private GameObject SATFinishSign06;
		private GameObject SATFinishResults;
		private GameObject SATFinishTable;
		private GameObject SATFinishChair;
		private GameObject SATFinishTent;
		private GameObject SUNFinishSign03;
		private GameObject SUNFinishSign05;
		private GameObject SUNFinishSign04;
		private GameObject SUNFinishSign06;
		private GameObject SUNFinishResults;
		private GameObject SUNFinishTable;
		private GameObject SUNFinishChair;
		private GameObject SUNFinishTent;
		
		private Vector3 SATStartTentPos;
		private Vector3 SATStartTentAng;
		private Vector3 SATStartTablePos;
		private Vector3 SATStartTableAng;
		private Vector3 SATStartFleetariPos;
		private Vector3 SATStartFleetariAng;
		private Vector3 SATStartSenderPos;
		private Vector3 SATStartSenderAng;
		private Vector3 SATStartSign05Pos;
		private Vector3 SATStartSign05Ang;
		private Vector3 SATStartSign08Pos;
		private Vector3 SATStartSign08Ang;
		private Vector3 StagingSATPos;
		private Vector3 StagingSATAng;
		private Vector3 StartSATPos;
		private Vector3 StartSATAng;
		private Vector3 SUNStartFleetariPos;
		private Vector3 SUNStartFleetariAng;
		private Vector3 SUNStartSenderPos;
		private Vector3 SUNStartSenderAng;
		private Vector3 SUNStartSign05Pos;
		private Vector3 SUNStartSign05Ang;
		private Vector3 SUNStartSign08Pos;
		private Vector3 SUNStartSign08Ang;
		private Vector3 StagingSUNPos;
		private Vector3 StagingSUNAng;
		private Vector3 StartSUNPos;
		private Vector3 StartSUNAng;
		
		private Vector3 CheckPos1SAT;
		private Vector3 CheckAng1SAT;
		private Vector3 CheckPos2SAT;
		private Vector3 CheckAng2SAT;
		private Vector3 CheckPos3SAT;
		private Vector3 CheckAng3SAT;
		private Vector3 CheckPos4SAT;
		private Vector3 CheckAng4SAT;
		private Vector3 CheckPos1SUN;
		private Vector3 CheckAng1SUN;
		private Vector3 CheckPos2SUN;
		private Vector3 CheckAng2SUN;
		private Vector3 CheckPos3SUN;
		private Vector3 CheckAng3SUN;
		private Vector3 CheckPos4SUN;
		private Vector3 CheckAng4SUN;
		
		private Vector3 SATFinishSign03Pos;
		private Vector3 SATFinishSign03Ang;
		private Vector3 SATFinishSign05Pos;
		private Vector3 SATFinishSign05Ang;
		private Vector3 SATFinishSign04Pos;
		private Vector3 SATFinishSign04Ang;
		private Vector3 SATFinishSign06Pos;
		private Vector3 SATFinishSign06Ang;
		private Vector3 SATFinishResultsPos;
		private Vector3 SATFinishResultsAng;
		private Vector3 SATFinishTablePos;
		private Vector3 SATFinishTableAng;
		private Vector3 SATFinishChairPos;
		private Vector3 SATFinishChairAng;
		private Vector3 SATFinishTentPos;
		private Vector3 SATFinishTentAng;
		private Vector3 SUNFinishSign03Pos;
		private Vector3 SUNFinishSign03Ang;
		private Vector3 SUNFinishSign05Pos;
		private Vector3 SUNFinishSign05Ang;
		private Vector3 SUNFinishSign04Pos;
		private Vector3 SUNFinishSign04Ang;
		private Vector3 SUNFinishSign06Pos;
		private Vector3 SUNFinishSign06Ang;
		private Vector3 SUNFinishResultsPos;
		private Vector3 SUNFinishResultsAng;
		private Vector3 SUNFinishTablePos;
		private Vector3 SUNFinishTableAng;
		private Vector3 SUNFinishChairPos;
		private Vector3 SUNFinishChairAng;
		private Vector3 SUNFinishTentPos;
		private Vector3 SUNFinishTentAng;
		private HutongGames.PlayMaker.Actions.RandomFloat SaturdayOpponentTimes;
		private HutongGames.PlayMaker.Actions.RandomFloat SundayOpponentTimes;
		
		private GameObject JuniorForm;
		private PlayMakerFSM JuniorFormFSM;
		private PlayMakerFSM JuniorButtonFSM;
		private GameObject AmateurForm;
		private PlayMakerFSM AmateurFormFSM;
		private PlayMakerFSM AmateurButtonFSM;
		private HutongGames.PlayMaker.Actions.FloatCompare DistanceSaturday1;
		private HutongGames.PlayMaker.Actions.FloatCompare DistanceSaturday2;
		private HutongGames.PlayMaker.Actions.FloatCompare DistanceSunday1;
		private HutongGames.PlayMaker.Actions.FloatCompare DistanceSunday2;
		
		private PlayMakerFSM TimingSaturdayFSM;
		private PlayMakerFSM TimingSundayFSM;
		private PlayMakerFSM ResultsFSM;
		private GUIStyle TimerGUIStyle;
		
		private GameObject TimingSaturday;
		private GameObject TimingSunday;
		private GameObject NPCCARS;
		private GameObject RALLYCARS;
		private GameObject TRAFFIC;
		private GameObject TRAIN;
		private GameObject RallyResults;
		
		Settings saturdaybuttons1;
		Settings saturdaybuttons2;
		Settings saturdaybuttons3;
		Settings saturdaybuttons4;
		Settings saturdaybuttons5;
		Settings sundaybuttons1;
		Settings sundaybuttons2;
		Settings sundaybuttons3;
		Settings sundaybuttons4;
		Settings sundaybuttons5;
		Settings satopptimeminslider;
		Settings satopptimemaxslider;
		Settings sunopptimeminslider;
		Settings sunopptimemaxslider;
		Settings showtimertoggle;
		Settings timeroffsetwidthslider;
		Settings timeroffsetheightslider;
		Settings vusualchecktoggle;
		Settings disabletraffictoggle;
		Settings disablerequiretoggle;
		
		public override void ModSettings()
		{
			Settings.AddHeader(this, "Routes");
			Settings.AddText(this, "Route on Saturday");
			saturdaybuttons1 = new Settings("saturdaybuttons1", "Default", true, SaturdayRoute);
			Settings.AddCheckBox(this, saturdaybuttons1, "group1");
			saturdaybuttons2 = new Settings("saturdaybuttons2", "2/3", false, SaturdayRoute);
			Settings.AddCheckBox(this, saturdaybuttons2, "group1");
			saturdaybuttons3 = new Settings("saturdaybuttons3", "1/3", false, SaturdayRoute);
			Settings.AddCheckBox(this, saturdaybuttons3, "group1");
			saturdaybuttons4 = new Settings("saturdaybuttons4", "0/3 (For debug)", false, SaturdayRoute);
			Settings.AddCheckBox(this, saturdaybuttons4, "group1");
			saturdaybuttons5 = new Settings("saturdaybuttons5", "Highway", false, SaturdayRoute);
			Settings.AddCheckBox(this, saturdaybuttons5, "group1");
			Settings.AddText(this, "");
			Settings.AddText(this, "Route on Sunday");
			sundaybuttons1 = new Settings("sundaybuttons1", "Default", true, SundayRoute);
			Settings.AddCheckBox(this, sundaybuttons1, "group2");
			sundaybuttons2 = new Settings("sundaybuttons2", "2/3", false, SundayRoute);
			Settings.AddCheckBox(this, sundaybuttons2, "group2");
			sundaybuttons3 = new Settings("sundaybuttons3", "1/3", false, SundayRoute);
			Settings.AddCheckBox(this, sundaybuttons3, "group2");
			sundaybuttons4 = new Settings("sundaybuttons4", "0/3 (For debug)", false, SundayRoute);
			Settings.AddCheckBox(this, sundaybuttons4, "group2");
			sundaybuttons5 = new Settings("sundaybuttons5", "Highway", false, SundayRoute);
			Settings.AddCheckBox(this, sundaybuttons5, "group2");
			Settings.AddHeader(this, "Opponent times");
			satopptimeminslider = new Settings("satopptimeminslider", "Saturday opponent min time (in sec)", 325, OpponentTimes);
			Settings.AddSlider(this, satopptimeminslider, 1, 1200);
			satopptimemaxslider = new Settings("satopptimemaxslider", "Saturday opponent max time (in sec)", 460, OpponentTimes);
			Settings.AddSlider(this, satopptimemaxslider, 1, 1200);
			Settings.AddText(this, "");
			sunopptimeminslider = new Settings("sunopptimeminslider", "Sunday opponent min time (in sec)", 355, OpponentTimes);
			Settings.AddSlider(this, sunopptimeminslider, 1, 1200);
			sunopptimemaxslider = new Settings("sunopptimemaxslider", "Sunday opponent max time (in sec)", 390, OpponentTimes);
			Settings.AddSlider(this, sunopptimemaxslider, 1, 1200);
			Settings.AddHeader(this, "Timer");
			showtimertoggle = new Settings("showtimertoggle", "Show timer", false);
			Settings.AddCheckBox(this, showtimertoggle);
			timeroffsetwidthslider = new Settings("timeroffsetwidthslider", "Timer width offset", 0);
			Settings.AddSlider(this, timeroffsetwidthslider, 0, 4096);
			timeroffsetheightslider = new Settings("timeroffsetheightslider", "Timer height offset", 0);
			Settings.AddSlider(this, timeroffsetheightslider, 0, 4096);
			Settings.AddHeader(this, "Advanced");
			disablerequiretoggle = new Settings("disablerequiretoggle", "Disable require for registration", false, DisableRequire);
			Settings.AddCheckBox(this, disablerequiretoggle);
			disabletraffictoggle = new Settings("disabletraffictoggle", "Disable highway and dirt road traffic during rally time", false);
			Settings.AddCheckBox(this, disabletraffictoggle);
			vusualchecktoggle = new Settings("vusualchecktoggle", "Visualize checkpoints (For debug)", false, VisualizeCheckpoints);
			Settings.AddCheckBox(this, vusualchecktoggle);
		}
		
		public override void OnLoad()
		{
			SATStartTent = GameObject.Find("RALLY").transform.Find("Scenery/Objects").transform.GetChild(7).gameObject;
			SATStartTable = GameObject.Find("RALLY").transform.Find("Scenery/Objects").transform.GetChild(1).gameObject;
			SATStartFleetari = GameObject.Find("RALLY").transform.Find("Saturday/StartArea/StartAreaObjects").gameObject;
			SATStartSender = GameObject.Find("RALLY").transform.Find("Saturday/StartArea/Sender").gameObject;
			SATStartSign05 = GameObject.Find("RALLY").transform.Find("Saturday/StartArea/rally_sign05").gameObject;
			SATStartSign08 = GameObject.Find("RALLY").transform.Find("Saturday/StartArea/rally_sign08").gameObject;

			StagingSAT = GameObject.Find("RALLY").transform.Find("Saturday/TimingSaturday/Staging").gameObject;
			StartSAT = GameObject.Find("RALLY").transform.Find("Saturday/TimingSaturday/Start").gameObject;
			Checpoint1SAT = GameObject.Find("RALLY").transform.Find("Saturday/TimingSaturday/Checkpoint01").gameObject;
			Checpoint2SAT = GameObject.Find("RALLY").transform.Find("Saturday/TimingSaturday/Checkpoint02").gameObject;
			Checpoint3SAT = GameObject.Find("RALLY").transform.Find("Saturday/TimingSaturday/Checkpoint03").gameObject;
			Checpoint4SAT = GameObject.Find("RALLY").transform.Find("Saturday/TimingSaturday/Checkpoint04").gameObject;

			SATFinishSign03 = GameObject.Find("RALLY").transform.Find("Saturday/FinishArea/rally_sign03").gameObject;
			SATFinishSign05 = GameObject.Find("RALLY").transform.Find("Saturday/FinishArea/rally_sign05").gameObject;
			SATFinishSign04 = GameObject.Find("RALLY").transform.Find("Saturday/FinishArea/rally_sign04").gameObject;
			SATFinishSign06 = GameObject.Find("RALLY").transform.Find("Saturday/FinishArea/rally_sign06").gameObject;
			SATFinishResults = GameObject.Find("RALLY").transform.Find("Saturday/FinishArea/RallyResultsSheetSAT").gameObject;
			SATFinishTable = GameObject.Find("RALLY").transform.Find("Scenery/Objects").transform.GetChild(0).gameObject;
			SATFinishChair = GameObject.Find("RALLY").transform.Find("Scenery/Objects").transform.GetChild(3).gameObject;
			SATFinishTent = GameObject.Find("RALLY").transform.Find("Scenery/Objects").transform.GetChild(6).gameObject;

			StagingSUN = GameObject.Find("RALLY").transform.Find("Sunday/TimingSunday/Staging").gameObject;
			StartSUN = GameObject.Find("RALLY").transform.Find("Sunday/TimingSunday/Start").gameObject;
			Checpoint1SUN = GameObject.Find("RALLY").transform.Find("Sunday/TimingSunday/Checkpoint01").gameObject;
			Checpoint2SUN = GameObject.Find("RALLY").transform.Find("Sunday/TimingSunday/Checkpoint02").gameObject;
			Checpoint3SUN = GameObject.Find("RALLY").transform.Find("Sunday/TimingSunday/Checkpoint03").gameObject;
			Checpoint4SUN = GameObject.Find("RALLY").transform.Find("Sunday/TimingSunday/Checkpoint04").gameObject;

			SUNStartFleetari = GameObject.Find("RALLY").transform.Find("Sunday/StartArea/StartAreaObjects").gameObject;
			SUNStartSender = GameObject.Find("RALLY").transform.Find("Sunday/StartArea/Sender 1").gameObject;
			SUNStartSign05 = GameObject.Find("RALLY").transform.Find("Sunday/StartArea/rally_sign05").gameObject;
			SUNStartSign08 = GameObject.Find("RALLY").transform.Find("Sunday/StartArea/rally_sign08").gameObject;

			StagingSUN = GameObject.Find("RALLY").transform.Find("Sunday/TimingSunday/Staging").gameObject;
			StartSUN = GameObject.Find("RALLY").transform.Find("Sunday/TimingSunday/Start").gameObject;
			Checpoint1SUN = GameObject.Find("RALLY").transform.Find("Sunday/TimingSunday/Checkpoint01").gameObject;
			Checpoint2SUN = GameObject.Find("RALLY").transform.Find("Sunday/TimingSunday/Checkpoint02").gameObject;
			Checpoint3SUN = GameObject.Find("RALLY").transform.Find("Sunday/TimingSunday/Checkpoint03").gameObject;
			Checpoint4SUN = GameObject.Find("RALLY").transform.Find("Sunday/TimingSunday/Checkpoint04").gameObject;

			SUNFinishSign03 = GameObject.Find("RALLY").transform.Find("Sunday/FinishArea/rally_sign03").gameObject;
			SUNFinishSign05 = GameObject.Find("RALLY").transform.Find("Sunday/FinishArea/rally_sign05").gameObject;
			SUNFinishSign04 = GameObject.Find("RALLY").transform.Find("Sunday/FinishArea/rally_sign04").gameObject;
			SUNFinishSign06 = GameObject.Find("RALLY").transform.Find("Sunday/FinishArea/rally_sign06").gameObject;
			SUNFinishResults = GameObject.Find("RALLY").transform.Find("Sunday/FinishArea/Stuff").gameObject;
			SUNFinishTable = GameObject.Find("RALLY").transform.Find("Scenery/Objects").transform.GetChild(2).gameObject;
			SUNFinishChair = GameObject.Find("RALLY").transform.Find("Scenery/Objects").transform.GetChild(5).gameObject;
			SUNFinishTent = GameObject.Find("RALLY").transform.Find("Scenery/Objects").transform.GetChild(8).gameObject;

			SaturdayOpponentTimes = GameObject.Find("RALLY/ResultsWeekend").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Opponent time").Actions[4] as HutongGames.PlayMaker.Actions.RandomFloat;
			SundayOpponentTimes = GameObject.Find("RALLY/ResultsWeekend").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Opponent time 2").Actions[2] as HutongGames.PlayMaker.Actions.RandomFloat;

			JuniorForm = GameObject.Find("Sheets").transform.Find("RallyformJunior").gameObject;
			JuniorFormFSM = GameObject.Find("Sheets").transform.Find("RallyformJunior").GetComponent<PlayMakerFSM>();
			JuniorButtonFSM = GameObject.Find("Sheets").transform.Find("RallyformJunior/ButtonConfirm").GetComponent<PlayMakerFSM>();
			JuniorFormFSM.Fsm.InitData();
			JuniorButtonFSM.Fsm.InitData();

			AmateurForm = GameObject.Find("Sheets").transform.Find("RallyformAmateur").gameObject;
			AmateurFormFSM = GameObject.Find("Sheets").transform.Find("RallyformAmateur").GetComponent<PlayMakerFSM>();
			AmateurButtonFSM = GameObject.Find("Sheets").transform.Find("RallyformAmateur/ButtonConfirm").GetComponent<PlayMakerFSM>();
			AmateurFormFSM.Fsm.InitData();
			AmateurButtonFSM.Fsm.InitData();

			PlayMakerFSM DistanceSaturdayFSM = GameObject.Find("RALLY").transform.Find("Saturday/StartArea/StartAreaObjects/RegisterFormSaturday").GetComponent<PlayMakerFSM>();
			PlayMakerFSM DistanceSundayFSM = GameObject.Find("RALLY").transform.Find("Sunday/StartArea/StartAreaObjects/RegisterFormSunday").GetComponent<PlayMakerFSM>();
			DistanceSaturdayFSM.Fsm.InitData();
			DistanceSundayFSM.Fsm.InitData();
			DistanceSaturday1 = DistanceSaturdayFSM.FsmStates.FirstOrDefault(state => state.Name == "Wait player").Actions[4] as HutongGames.PlayMaker.Actions.FloatCompare;
			DistanceSaturday2 = DistanceSaturdayFSM.FsmStates.FirstOrDefault(state => state.Name == "Distance").Actions[1] as HutongGames.PlayMaker.Actions.FloatCompare;
			DistanceSunday1 = DistanceSundayFSM.FsmStates.FirstOrDefault(state => state.Name == "Wait player").Actions[4] as HutongGames.PlayMaker.Actions.FloatCompare;
			DistanceSunday2 = DistanceSundayFSM.FsmStates.FirstOrDefault(state => state.Name == "Distance").Actions[1] as HutongGames.PlayMaker.Actions.FloatCompare;

			TimingSaturdayFSM = GameObject.Find("RALLY").transform.Find("Saturday/TimingSaturday").GetComponents<PlayMakerFSM>()[0];
			TimingSaturdayFSM.Fsm.InitData();
			TimingSundayFSM = GameObject.Find("RALLY").transform.Find("Sunday/TimingSunday").GetComponents<PlayMakerFSM>()[0];
			TimingSundayFSM.Fsm.InitData();

			TimerGUIStyle = new GUIStyle();
			TimerGUIStyle.fontSize = 25;
			TimerGUIStyle.normal.textColor = Color.white;
			ResultsFSM = GameObject.Find("Sheets").transform.Find("RallyResults/Results").GetComponent<PlayMakerFSM>();
			ResultsFSM.Fsm.InitData();

			TimingSaturday = GameObject.Find("RALLY").transform.Find("Saturday/TimingSaturday").gameObject;
			TimingSunday = GameObject.Find("RALLY").transform.Find("Sunday/TimingSunday").gameObject;
			NPCCARS = GameObject.Find("NPC_CARS").gameObject;
			RALLYCARS = GameObject.Find("RALLY").transform.Find("RallyCars").gameObject;
			TRAFFIC = GameObject.Find("TRAFFIC").gameObject;
			TRAIN = Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("TRAIN") >= 0).Last().gameObject;
			RallyResults = GameObject.Find("Sheets").transform.Find("RallyResults").gameObject;

			SaveDefaultPositions();
			OpponentTimes();
			DisableRequire();
			VisualizeCheckpoints();
		}
		
		public override void OnGUI()
		{
			if((bool)showtimertoggle.Value)
			{
				if(ResultsFSM.FsmVariables.GetFsmString("1").Value == "")
				{
					int timeroffsetwidth = int.Parse(timeroffsetwidthslider.GetValue().ToString());
					int timeroffsetheight = int.Parse(timeroffsetheightslider.GetValue().ToString());
					GUI.Label(new Rect((float)(Screen.width - 100 - timeroffsetwidth), 0 + timeroffsetheight, 150, 50), TimingSaturdayFSM.FsmVariables.GetFsmString("TimeString").Value, TimerGUIStyle);
					GUI.Label(new Rect((float)(Screen.width - 100 - timeroffsetwidth), 0 + timeroffsetheight, 150, 50), TimingSundayFSM.FsmVariables.GetFsmString("TimeString").Value, TimerGUIStyle);
				}
			}
		}
		
		private void DisableRequire()
		{
			
			if(Application.loadedLevelName == "GAME")
			{
				if((bool)disablerequiretoggle.Value)
				{
					JuniorButtonFSM.FsmStates.FirstOrDefault(state => state.Name == "Check status").Actions[3].Enabled = false;
					AmateurButtonFSM.FsmStates.FirstOrDefault(state => state.Name == "Check status").Actions[3].Enabled = false;
					DistanceSaturday1.float2 = 5000f;
					DistanceSaturday2.float2 = 5000f;
					DistanceSunday1.float2 = 5000f;
					DistanceSunday2.float2 = 5000f;
				}
				else
				{
					JuniorButtonFSM.FsmStates.FirstOrDefault(state => state.Name == "Check status").Actions[3].Enabled = true;
					AmateurButtonFSM.FsmStates.FirstOrDefault(state => state.Name == "Check status").Actions[3].Enabled = true;
					DistanceSaturday1.float2 = 20f;
					DistanceSaturday2.float2 = 20f;
					DistanceSunday1.float2 = 20f;
					DistanceSunday2.float2 = 20f;
				}
			}
		}
		
		public override void Update()
		{
			if((bool)disablerequiretoggle.Value)
			{
				if(JuniorForm.activeSelf)
				{
					JuniorFormFSM.FsmVariables.GetFsmBool("CarExtinguisher").Value = true;
					JuniorFormFSM.FsmVariables.GetFsmBool("CarHarness").Value = true;
					JuniorFormFSM.FsmVariables.GetFsmBool("CarInspected").Value = true;
					JuniorFormFSM.FsmVariables.GetFsmBool("CarRollcage").Value = true;
					JuniorFormFSM.FsmVariables.GetFsmBool("CarTires").Value = true;
					JuniorFormFSM.FsmVariables.GetFsmBool("Required1").Value = true;
					JuniorFormFSM.FsmVariables.GetFsmBool("Required2").Value = true;
					JuniorFormFSM.FsmVariables.GetFsmBool("Required3").Value = true;
					JuniorFormFSM.FsmVariables.GetFsmBool("Required4").Value = true;
					JuniorButtonFSM.FsmVariables.GetFsmBool("ReqExtinguisher").Value = true;
					JuniorButtonFSM.FsmVariables.GetFsmBool("ReqHarness").Value = true;
					JuniorButtonFSM.FsmVariables.GetFsmBool("ReqHelmet").Value = true;
					JuniorButtonFSM.FsmVariables.GetFsmBool("ReqInspected").Value = true;
					JuniorButtonFSM.FsmVariables.GetFsmBool("ReqRollcage").Value = true;
					JuniorButtonFSM.FsmVariables.GetFsmBool("ReqTires").Value = true;
				}
				
				if(AmateurForm.activeSelf)
				{
					AmateurFormFSM.FsmVariables.GetFsmBool("CarExtinguisher").Value = true;
					AmateurFormFSM.FsmVariables.GetFsmBool("CarHarness").Value = true;
					AmateurFormFSM.FsmVariables.GetFsmBool("CarInspected").Value = true;
					AmateurFormFSM.FsmVariables.GetFsmBool("CarRollcage").Value = true;
					AmateurFormFSM.FsmVariables.GetFsmBool("CarTires").Value = true;
					AmateurFormFSM.FsmVariables.GetFsmBool("Required1").Value = true;
					AmateurFormFSM.FsmVariables.GetFsmBool("Required2").Value = true;
					AmateurFormFSM.FsmVariables.GetFsmBool("Required3").Value = true;
					AmateurFormFSM.FsmVariables.GetFsmBool("Required4").Value = true;
					AmateurButtonFSM.FsmVariables.GetFsmBool("ReqExtinguisher").Value = true;
					AmateurButtonFSM.FsmVariables.GetFsmBool("ReqHarness").Value = true;
					AmateurButtonFSM.FsmVariables.GetFsmBool("ReqHelmet").Value = true;
					AmateurButtonFSM.FsmVariables.GetFsmBool("ReqInspected").Value = true;
					AmateurButtonFSM.FsmVariables.GetFsmBool("ReqRollcage").Value = true;
					AmateurButtonFSM.FsmVariables.GetFsmBool("ReqTires").Value = true;
				}
			}
			
			if((bool)disabletraffictoggle.Value)
			{
				if(TimingSaturday.activeSelf)
				{
					if(!TrafficDisabled)
					{
						NPCCARS.SetActive(false);
						RALLYCARS.SetActive(false);
						TRAFFIC.SetActive(false);
						TRAIN.SetActive(false);
						TrafficDisabled = true;
					}
				}
				
				if(TimingSunday.activeSelf)
				{
					if(!TrafficDisabled)
					{
						NPCCARS.SetActive(false);
						RALLYCARS.SetActive(false);
						TRAFFIC.SetActive(false);
						TRAIN.SetActive(false);
						TrafficDisabled = true;
					}
				}
				
				if(TrafficDisabled)
				{
					if(RallyResults.activeSelf)
					{
						NPCCARS.SetActive(true);
						RALLYCARS.SetActive(true);
						TRAFFIC.SetActive(true);
						TRAIN.SetActive(true);
						TrafficDisabled = false;
					}
				}
			}
		}
		
		private void OpponentTimes()
		{
			if(Application.loadedLevelName == "GAME")
			{
				int satopptimemin = int.Parse(satopptimeminslider.GetValue().ToString());
				int satopptimemax = int.Parse(satopptimemaxslider.GetValue().ToString());
				int sunopptimemin = int.Parse(sunopptimeminslider.GetValue().ToString());
				int sunopptimemax = int.Parse(sunopptimemaxslider.GetValue().ToString());
				SaturdayOpponentTimes.min = satopptimemin;
				SaturdayOpponentTimes.max = satopptimemax;
				SundayOpponentTimes.min = sunopptimemin;
				SundayOpponentTimes.max = sunopptimemax;
			}
		}
		
		private void SaturdayRoute()
		{
			if(Application.loadedLevelName == "GAME")
			{
				if((bool)saturdaybuttons1.Value)
				{
					if(SaturdayRouteChanged)
					{
						SATStartTent.transform.localPosition = SATStartTentPos;
						SATStartTent.transform.localEulerAngles = SATStartTentAng;
						SATStartTable.transform.localPosition = SATStartTablePos;
						SATStartTable.transform.localEulerAngles = SATStartTableAng;
						SATStartFleetari.transform.localPosition = SATStartFleetariPos;
						SATStartFleetari.transform.localEulerAngles = SATStartFleetariAng;
						SATStartSender.transform.localPosition = SATStartSenderPos;
						SATStartSender.transform.localEulerAngles = SATStartSenderAng;
						SATStartSign05.transform.localPosition = SATStartSign05Pos;
						SATStartSign05.transform.localEulerAngles = SATStartSign05Ang;
						SATStartSign08.transform.localPosition = SATStartSign08Pos;
						SATStartSign08.transform.localEulerAngles = SATStartSign08Ang;
						StagingSAT.transform.localPosition = StagingSATPos;
						StagingSAT.transform.localEulerAngles = StagingSATAng;
						StartSAT.transform.localPosition = StartSATPos;
						StartSAT.transform.localEulerAngles = StartSATAng;
						
						Checpoint1SAT.transform.localPosition = CheckPos1SAT;
						Checpoint1SAT.transform.localEulerAngles = CheckAng1SAT;
						Checpoint2SAT.transform.localPosition = CheckPos2SAT;
						Checpoint2SAT.transform.localEulerAngles = CheckAng2SAT;
						Checpoint3SAT.transform.localPosition = CheckPos3SAT;
						Checpoint3SAT.transform.localEulerAngles = CheckAng3SAT;
						Checpoint4SAT.transform.localPosition = CheckPos4SAT;
						Checpoint4SAT.transform.localEulerAngles = CheckAng4SAT;
						
						SATFinishSign03.transform.localPosition = SATFinishSign03Pos;
						SATFinishSign03.transform.localEulerAngles = SATFinishSign03Ang;
						SATFinishSign05.transform.localPosition = SATFinishSign05Pos;
						SATFinishSign05.transform.localEulerAngles = SATFinishSign05Ang;
						SATFinishSign04.transform.localPosition = SATFinishSign04Pos;
						SATFinishSign04.transform.localEulerAngles = SATFinishSign04Ang;
						SATFinishSign06.transform.localPosition = SATFinishSign06Pos;
						SATFinishSign06.transform.localEulerAngles = SATFinishSign06Ang;
						SATFinishResults.transform.localPosition = SATFinishResultsPos;
						SATFinishResults.transform.localEulerAngles = SATFinishResultsAng;
						SATFinishTable.transform.localPosition = SATFinishTablePos;
						SATFinishTable.transform.localEulerAngles = SATFinishTableAng;
						SATFinishChair.transform.localPosition = SATFinishChairPos;
						SATFinishChair.transform.localEulerAngles = SATFinishChairAng;
						SATFinishTent.transform.localPosition = SATFinishTentPos;
						SATFinishTent.transform.localEulerAngles = SATFinishTentAng;
						
						SaturdayRouteChanged = false;
					}
				}
				if((bool)saturdaybuttons2.Value)
				{
					SATStartTent.transform.localPosition = SATStartTentPos;
					SATStartTent.transform.localEulerAngles = SATStartTentAng;
					SATStartTable.transform.localPosition = SATStartTablePos;
					SATStartTable.transform.localEulerAngles = SATStartTableAng;
					SATStartFleetari.transform.localPosition = SATStartFleetariPos;
					SATStartFleetari.transform.localEulerAngles = SATStartFleetariAng;
					SATStartSender.transform.localPosition = SATStartSenderPos;
					SATStartSender.transform.localEulerAngles = SATStartSenderAng;
					SATStartSign05.transform.localPosition = SATStartSign05Pos;
					SATStartSign05.transform.localEulerAngles = SATStartSign05Ang;
					SATStartSign08.transform.localPosition = SATStartSign08Pos;
					SATStartSign08.transform.localEulerAngles = SATStartSign08Ang;
					StagingSAT.transform.localPosition = StagingSATPos;
					StagingSAT.transform.localEulerAngles = StagingSATAng;
					StartSAT.transform.localPosition = StartSATPos;
					StartSAT.transform.localEulerAngles = StartSATAng;
					
					Checpoint1SAT.transform.localPosition = CheckPos1SAT;
					Checpoint1SAT.transform.localEulerAngles = CheckAng1SAT;
					Checpoint2SAT.transform.localPosition = CheckPos2SAT;
					Checpoint2SAT.transform.localEulerAngles = CheckAng2SAT;
					Checpoint3SAT.transform.localPosition = new Vector3 (1837f, 2f, -836f);
					Checpoint3SAT.transform.localEulerAngles = new Vector3 (0f, 0f, 0f);
					Checpoint4SAT.transform.localPosition = new Vector3 (1842.532f, 8f, -921f);
					Checpoint4SAT.transform.localEulerAngles = new Vector3 (0f, 180f, 0f);
					
					SATFinishSign03.transform.localPosition = new Vector3 (1840f, 4.35f, -920.8f);
					SATFinishSign03.transform.localEulerAngles = new Vector3 (270f, 273f, 0f);
					SATFinishSign05.transform.localPosition = new Vector3 (1844.8f, 4.35f, -920.8f);
					SATFinishSign05.transform.localEulerAngles = new Vector3 (270f, 268f, 0f);
					SATFinishSign04.transform.localPosition = new Vector3 (1835.5f, -2.3f, -835.5f);
					SATFinishSign04.transform.localEulerAngles = new Vector3 (270f, 274f, 0f);
					SATFinishSign06.transform.localPosition = new Vector3 (1840.2f, -2.3f, -835.5f);
					SATFinishSign06.transform.localEulerAngles = new Vector3 (270f, 265f, 0f);
					SATFinishResults.transform.localPosition = new Vector3 (1814.42f, 5.32f, -926f);
					SATFinishResults.transform.localEulerAngles = new Vector3 (0f, 190f, 0f);
					SATFinishTable.transform.localPosition = new Vector3 (1814.42f, 5f, -926f);
					SATFinishTable.transform.localEulerAngles = new Vector3 (270f, 96f, 0f);
					SATFinishChair.transform.localPosition = new Vector3 (1814.6f, 4.795f, -925f);
					SATFinishChair.transform.localEulerAngles = new Vector3 (273.782f, 136.5776f, 91.23801f);
					SATFinishTent.transform.localPosition = new Vector3 (1814.532f, 6.95f, -925f);
					SATFinishTent.transform.localEulerAngles = new Vector3 (270f, 96f, 0f);
					
					SaturdayRouteChanged = true;
				}
				if((bool)saturdaybuttons3.Value)
				{
					SATStartTent.transform.localPosition = SATStartTentPos;
					SATStartTent.transform.localEulerAngles = SATStartTentAng;
					SATStartTable.transform.localPosition = SATStartTablePos;
					SATStartTable.transform.localEulerAngles = SATStartTableAng;
					SATStartFleetari.transform.localPosition = SATStartFleetariPos;
					SATStartFleetari.transform.localEulerAngles = SATStartFleetariAng;
					SATStartSender.transform.localPosition = SATStartSenderPos;
					SATStartSender.transform.localEulerAngles = SATStartSenderAng;
					SATStartSign05.transform.localPosition = SATStartSign05Pos;
					SATStartSign05.transform.localEulerAngles = SATStartSign05Ang;
					SATStartSign08.transform.localPosition = SATStartSign08Pos;
					SATStartSign08.transform.localEulerAngles = SATStartSign08Ang;
					StagingSAT.transform.localPosition = StagingSATPos;
					StagingSAT.transform.localEulerAngles = StagingSATAng;
					StartSAT.transform.localPosition = StartSATPos;
					StartSAT.transform.localEulerAngles = StartSATAng;
					
					Checpoint1SAT.transform.localPosition = CheckPos1SAT;
					Checpoint1SAT.transform.localEulerAngles = CheckAng1SAT;
					Checpoint2SAT.transform.localPosition = new Vector3 (1404.374f, 4f, 749.5284f);
					Checpoint2SAT.transform.localEulerAngles = new Vector3 (0f, 102f, 0f);
					Checpoint3SAT.transform.localPosition = new Vector3 (1461.374f, 3f, 749.5284f);
					Checpoint3SAT.transform.localEulerAngles = new Vector3 (0f, 265f, 0f);
					Checpoint4SAT.transform.localPosition = new Vector3 (1525.374f, 9f, 757.5284f);
					Checpoint4SAT.transform.localEulerAngles = new Vector3 (0f, 87f, 0f);
					
					SATFinishSign03.transform.localPosition = new Vector3 (1525.374f, 5.1f, 755.3f);
					SATFinishSign03.transform.localEulerAngles = new Vector3 (270f, 180f, 0f);
					SATFinishSign05.transform.localPosition = new Vector3 (1525.1f, 5f, 759.5f);
					SATFinishSign05.transform.localEulerAngles = new Vector3 (270f, 175f, 0f);
					SATFinishSign04.transform.localPosition = new Vector3 (1461.1f, -1.68f, 752.3f);
					SATFinishSign04.transform.localEulerAngles = new Vector3 (270f, 174f, 0f);
					SATFinishSign06.transform.localPosition = new Vector3 (1461.41f, -1.68f, 747.8f);
					SATFinishSign06.transform.localEulerAngles = new Vector3 (270f, 174f, 0f);
					SATFinishResults.transform.localPosition = new Vector3 (1545.374f, 5.22f, 733.12f);
					SATFinishResults.transform.localEulerAngles = new Vector3 (0f, 250f, 0f);
					SATFinishTable.transform.localPosition = new Vector3 (1545.374f, 4.9f, 733.12f);
					SATFinishTable.transform.localEulerAngles = new Vector3 (270f, 158f, 0f);
					SATFinishChair.transform.localPosition = new Vector3 (1546.374f, 4.6f, 733.5284f);
					SATFinishChair.transform.localEulerAngles = new Vector3 (273.7818f, 136.5778f, 91.23836f);
					SATFinishTent.transform.localPosition = new Vector3 (1546.374f, 6.88f, 733.5284f);
					SATFinishTent.transform.localEulerAngles = new Vector3 (270f, 158f, 0f);
					
					SaturdayRouteChanged = true;
				}
				if((bool)saturdaybuttons4.Value)
				{
					SATStartTent.transform.localPosition = SATStartTentPos;
					SATStartTent.transform.localEulerAngles = SATStartTentAng;
					SATStartTable.transform.localPosition = SATStartTablePos;
					SATStartTable.transform.localEulerAngles = SATStartTableAng;
					SATStartFleetari.transform.localPosition = SATStartFleetariPos;
					SATStartFleetari.transform.localEulerAngles = SATStartFleetariAng;
					SATStartSender.transform.localPosition = SATStartSenderPos;
					SATStartSender.transform.localEulerAngles = SATStartSenderAng;
					SATStartSign05.transform.localPosition = SATStartSign05Pos;
					SATStartSign05.transform.localEulerAngles = SATStartSign05Ang;
					SATStartSign08.transform.localPosition = SATStartSign08Pos;
					SATStartSign08.transform.localEulerAngles = SATStartSign08Ang;
					StagingSAT.transform.localPosition = StagingSATPos;
					StagingSAT.transform.localEulerAngles = StagingSATAng;
					StartSAT.transform.localPosition = StartSATPos;
					StartSAT.transform.localEulerAngles = StartSATAng;
					
					Checpoint1SAT.transform.localPosition = new Vector3 (-1246.2f, 5f, 1287f);
					Checpoint1SAT.transform.localEulerAngles = new Vector3 (0f, 244.4328f, 0f);
					Checpoint2SAT.transform.localPosition = new Vector3 (-1235.2f, 5f, 1293f);
					Checpoint2SAT.transform.localEulerAngles = new Vector3 (0f, 64.4328f, 0f);
					Checpoint3SAT.transform.localPosition = new Vector3 (-1226.2f, 5f, 1298f);
					Checpoint3SAT.transform.localEulerAngles = new Vector3 (0f, 244.4328f, 0f);
					Checpoint4SAT.transform.localPosition = new Vector3 (-1215.2f, 5f, 1305f);
					Checpoint4SAT.transform.localEulerAngles = new Vector3 (0f, 64.4328f, 0f);
					
					SATFinishSign03.transform.localPosition = new Vector3 (-1215.2f, -0.3f, 1304f);
					SATFinishSign03.transform.localEulerAngles = new Vector3 (270f, 157f, 0f);
					SATFinishSign05.transform.localPosition = new Vector3 (-1217f, -0.3f, 1308f);
					SATFinishSign05.transform.localEulerAngles = new Vector3 (270f, 157f, 0f);
					SATFinishSign04.transform.localPosition = new Vector3 (-1228f, -0.7f, 1301.2f);
					SATFinishSign04.transform.localEulerAngles = new Vector3 (270f, 148f, 0f);
					SATFinishSign06.transform.localPosition = new Vector3 (-1226.3f, -0.7f, 1297.76f);
					SATFinishSign06.transform.localEulerAngles = new Vector3 (270f, 153f, 0f);
					SATFinishResults.transform.localPosition = new Vector3 (-1194.55f, 1.27f, 1319f);
					SATFinishResults.transform.localEulerAngles = new Vector3 (0f, 160f, 0f);
					SATFinishTable.transform.localPosition = new Vector3 (-1194.55f, 0.95f, 1319f);
					SATFinishTable.transform.localEulerAngles = new Vector3 (270f, 66f, 0f);
					SATFinishChair.transform.localPosition = new Vector3 (-1194.55f, 0.76f, 1320.5f);
					SATFinishChair.transform.localEulerAngles = new Vector3 (270f, 180f, 0f);
					SATFinishTent.transform.localPosition = new Vector3 (-1195f, 2.95f, 1320f);
					SATFinishTent.transform.localEulerAngles = new Vector3 (270f, 66f, 0f);
					
					SaturdayRouteChanged = true;
				}
				if((bool)saturdaybuttons5.Value)
				{
					SATStartTent.transform.localPosition = new Vector3 (-1724f, 5.73f, 1002.5f);
					SATStartTent.transform.localEulerAngles = new Vector3 (270f, 72.45614f, 0f);
					SATStartTable.transform.localPosition = new Vector3 (-1723.68f, 3.64f, 1001.5f);
					SATStartTable.transform.localEulerAngles = new Vector3 (270f, 72.45614f, 0f);
					SATStartFleetari.transform.localPosition = new Vector3 (-1723.68f, 5.98f, 1002.25f);
					SATStartFleetari.transform.localEulerAngles = new Vector3 (0f, 165f, 0f); 
					SATStartSender.transform.localPosition = new Vector3 (-1694.6f, 3.89f, 962f);
					SATStartSender.transform.localEulerAngles = new Vector3 (0f, 0f, 0f);
					SATStartSign05.transform.localPosition = new Vector3 (-1695.5f, 3.7f, 961.4f);
					SATStartSign05.transform.localEulerAngles = new Vector3 (270f, 254f, 0f);
					SATStartSign08.transform.localPosition = new Vector3 (-1682f, 3.6f, 965.27f);
					SATStartSign08.transform.localEulerAngles = new Vector3 (270f, 252f, 0f);
					StagingSAT.transform.localPosition = new Vector3 (-1694f, 8f, 982.25f);
					StagingSAT.transform.localEulerAngles = new Vector3 (0f, 344f, 0f);
					StartSAT.transform.localPosition = new Vector3 (-1689f, 8f, 963.25f);
					StartSAT.transform.localEulerAngles = new Vector3 (0f, 344f, 0f);
					
					Checpoint1SAT.transform.localPosition = new Vector3 (-1330.141f, 11f, -1201.99f);
					Checpoint1SAT.transform.localEulerAngles = new Vector3 (0f, 278.4335f, 0f);
					Checpoint2SAT.transform.localPosition = new Vector3 (2204.09f, 3f, -727.5204f);
					Checpoint2SAT.transform.localEulerAngles = new Vector3 (0f, 3.4f, 0f);
					Checpoint3SAT.transform.localPosition = new Vector3 (1878.452f, 16f, 841.8513f);
					Checpoint3SAT.transform.localEulerAngles = new Vector3 (0f, 119f, 0f);
					Checpoint4SAT.transform.localPosition = new Vector3 (-1724f, 9f, 1074.25f);
					Checpoint4SAT.transform.localEulerAngles = new Vector3 (0f, 164f, 0f);
					
					SATFinishSign03.transform.localPosition = new Vector3 (-1728.5f, 5f, 1073f);
					SATFinishSign03.transform.localEulerAngles = new Vector3 (270f, 257f, 0f);
					SATFinishSign05.transform.localPosition = new Vector3 (-1718.7f, 4.8f, 1075.8f);
					SATFinishSign05.transform.localEulerAngles = new Vector3 (270f, 249f, 0f);
					SATFinishSign04.transform.localPosition = new Vector3 (-1730.5f, 5.1f, 1117.8f);
					SATFinishSign04.transform.localEulerAngles = new Vector3 (270f, 254f, 0f);
					SATFinishSign06.transform.localPosition = new Vector3 (-1740.4f, 5.1f, 1115f);
					SATFinishSign06.transform.localEulerAngles = new Vector3 (270f, 254f, 0f);
					SATFinishResults.transform.localPosition = new Vector3 (-1723.3f, 3.96f, 1001.5f);
					SATFinishResults.transform.localEulerAngles = new Vector3 (0f, 160f, 0f);
					SATFinishTable.transform.localPosition = SATFinishTablePos;
					SATFinishTable.transform.localEulerAngles = SATFinishTableAng;
					SATFinishChair.transform.localPosition = SATFinishChairPos;
					SATFinishChair.transform.localEulerAngles = SATFinishChairAng;
					SATFinishTent.transform.localPosition = SATFinishTentPos;
					SATFinishTent.transform.localEulerAngles = SATFinishTentAng;
					
					SaturdayRouteChanged = true;
				}
				
				CheckForSunday();
			}
		}
		
		private void SundayRoute()
		{
			if(Application.loadedLevelName == "GAME")
			{
				if((bool)sundaybuttons1.Value)
				{
					if(SundayRouteChanged)
					{
						SUNStartFleetari.transform.localPosition = SUNStartFleetariPos;
						SUNStartFleetari.transform.localEulerAngles = SUNStartFleetariAng;
						SUNStartSender.transform.localPosition = SUNStartSenderPos;
						SUNStartSender.transform.localEulerAngles = SUNStartSenderAng;
						SUNStartSign05.transform.localPosition = SUNStartSign05Pos;
						SUNStartSign05.transform.localEulerAngles = SUNStartSign05Ang;
						SUNStartSign08.transform.localPosition = SUNStartSign08Pos;
						SUNStartSign08.transform.localEulerAngles = SUNStartSign08Ang;
						StagingSUN.transform.localPosition = StagingSUNPos;
						StagingSUN.transform.localEulerAngles = StagingSUNAng;
						StartSUN.transform.localPosition = StartSUNPos;
						StartSUN.transform.localEulerAngles = StartSUNAng;
						
						Checpoint1SUN.transform.localPosition = CheckPos1SUN;
						Checpoint1SUN.transform.localEulerAngles = CheckAng1SUN;
						Checpoint2SUN.transform.localPosition = CheckPos2SUN;
						Checpoint2SUN.transform.localEulerAngles = CheckAng2SUN;
						Checpoint3SUN.transform.localPosition = CheckPos3SUN;
						Checpoint3SUN.transform.localEulerAngles = CheckAng3SUN;
						Checpoint4SUN.transform.localPosition = CheckPos4SUN;
						Checpoint4SUN.transform.localEulerAngles = CheckAng4SUN;
						
						SUNFinishSign03.transform.localPosition = SUNFinishSign03Pos;
						SUNFinishSign03.transform.localEulerAngles = SUNFinishSign03Ang;
						SUNFinishSign05.transform.localPosition = SUNFinishSign05Pos;
						SUNFinishSign05.transform.localEulerAngles = SUNFinishSign05Ang;
						SUNFinishSign04.transform.localPosition = SUNFinishSign04Pos;
						SUNFinishSign04.transform.localEulerAngles = SUNFinishSign04Ang;
						SUNFinishSign06.transform.localPosition = SUNFinishSign06Pos;
						SUNFinishSign06.transform.localEulerAngles = SUNFinishSign06Ang;
						SUNFinishResults.transform.localPosition = SUNFinishResultsPos;
						SUNFinishResults.transform.localEulerAngles = SUNFinishResultsAng;
						SUNFinishTable.transform.localPosition = SUNFinishTablePos;
						SUNFinishTable.transform.localEulerAngles = SUNFinishTableAng;
						SUNFinishChair.transform.localPosition = SUNFinishChairPos;
						SUNFinishChair.transform.localEulerAngles = SUNFinishChairAng;
						SUNFinishTent.transform.localPosition = SUNFinishTentPos;
						SUNFinishTent.transform.localEulerAngles = SUNFinishTentAng;
						
						SundayRouteChanged = false;
					}
				}
				if((bool)sundaybuttons2.Value)
				{
					SUNStartFleetari.transform.localPosition = SUNStartFleetariPos;
					SUNStartFleetari.transform.localEulerAngles = SUNStartFleetariAng;
					SUNStartSender.transform.localPosition = SUNStartSenderPos;
					SUNStartSender.transform.localEulerAngles = SUNStartSenderAng;
					SUNStartSign05.transform.localPosition = SUNStartSign05Pos;
					SUNStartSign05.transform.localEulerAngles = SUNStartSign05Ang;
					SUNStartSign08.transform.localPosition = SUNStartSign08Pos;
					SUNStartSign08.transform.localEulerAngles = SUNStartSign08Ang;
					StagingSUN.transform.localPosition = StagingSUNPos;
					StagingSUN.transform.localEulerAngles = StagingSUNAng;
					StartSUN.transform.localPosition = StartSUNPos;
					StartSUN.transform.localEulerAngles = StartSUNAng;
					
					Checpoint1SUN.transform.localPosition = CheckPos1SUN;
					Checpoint1SUN.transform.localEulerAngles = CheckAng1SUN;
					Checpoint2SUN.transform.localPosition = CheckPos2SUN;
					Checpoint2SUN.transform.localEulerAngles = CheckAng2SUN;
					Checpoint3SUN.transform.localPosition = new Vector3 (1572.374f, 8f, 645.5284f);
					Checpoint3SUN.transform.localEulerAngles = new Vector3 (0f, 167.3776f, 0f);
					Checpoint4SUN.transform.localPosition = new Vector3 (1555.374f, 9f, 702.5284f);
					Checpoint4SUN.transform.localEulerAngles = new Vector3 (0f, 335f, 0f);
					
					SUNFinishSign03.transform.localPosition = new Vector3 (1557.8f, 4.1f, 703.65f);
					SUNFinishSign03.transform.localEulerAngles = new Vector3 (270f, 68f, 0f);
					SUNFinishSign05.transform.localPosition = new Vector3 (1554.1f, 4.1f, 701.9f);
					SUNFinishSign05.transform.localEulerAngles = new Vector3 (270f, 63f, 0f);
					SUNFinishSign04.transform.localPosition = new Vector3 (1571.6f, 3.7f, 645.3f);
					SUNFinishSign04.transform.localEulerAngles = new Vector3 (270f, 73f, 0f);
					SUNFinishSign06.transform.localPosition = new Vector3 (1575.6f, 3.55f, 646.22f);
					SUNFinishSign06.transform.localEulerAngles = new Vector3 (270f, 80f, 0f);
					SUNFinishResults.transform.localPosition = new Vector3 (1545f, 6.8f, 736.07f);
					SUNFinishResults.transform.localEulerAngles = new Vector3 (0f, 242.0022f, 0f);
					SUNFinishTable.transform.localPosition = new Vector3 (1544.2f, 4.83f, 735.9916f);
					SUNFinishTable.transform.localEulerAngles = new Vector3 (270f, 158f, 0f);
					SUNFinishChair.transform.localPosition = new Vector3 (1546.2f, 4.65f, 736.4f);
					SUNFinishChair.transform.localEulerAngles = new Vector3 (273.7817f, 136.5779f, 91.23843f);
					SUNFinishTent.transform.localPosition = new Vector3 (1545.2f, 6.81f, 736.4f);
					SUNFinishTent.transform.localEulerAngles = new Vector3 (270f, 158f, 0f);
					
					SundayRouteChanged = true;
				}
				if((bool)sundaybuttons3.Value)
				{
					SUNStartFleetari.transform.localPosition = SUNStartFleetariPos;
					SUNStartFleetari.transform.localEulerAngles = SUNStartFleetariAng;
					SUNStartSender.transform.localPosition = SUNStartSenderPos;
					SUNStartSender.transform.localEulerAngles = SUNStartSenderAng;
					SUNStartSign05.transform.localPosition = SUNStartSign05Pos;
					SUNStartSign05.transform.localEulerAngles = SUNStartSign05Ang;
					SUNStartSign08.transform.localPosition = SUNStartSign08Pos;
					SUNStartSign08.transform.localEulerAngles = SUNStartSign08Ang;
					StagingSUN.transform.localPosition = StagingSUNPos;
					StagingSUN.transform.localEulerAngles = StagingSUNAng;
					StartSUN.transform.localPosition = StartSUNPos;
					StartSUN.transform.localEulerAngles = StartSUNAng;
					
					Checpoint1SUN.transform.localPosition = CheckPos1SUN;
					Checpoint1SUN.transform.localEulerAngles = CheckAng1SUN;
					Checpoint2SUN.transform.localPosition = new Vector3 (1614.532f, 8f, -980f);
					Checpoint2SUN.transform.localEulerAngles = new Vector3 (0f, 268.5898f, 0f);
					Checpoint3SUN.transform.localPosition = new Vector3 (1696.532f, 9f, -962f);
					Checpoint3SUN.transform.localEulerAngles = new Vector3 (0f, 243f, 0f);
					Checpoint4SUN.transform.localPosition = new Vector3 (1765.532f, 10f, -933f);
					Checpoint4SUN.transform.localEulerAngles = new Vector3 (0f, 78f, 0f);
					
					SUNFinishSign03.transform.localPosition = new Vector3 (1766.1f, 5.1f, -935.9f);
					SUNFinishSign03.transform.localEulerAngles = new Vector3 (270f, 177f, 0f);
					SUNFinishSign05.transform.localPosition = new Vector3 (1765f, 5.1f, -930.7f);
					SUNFinishSign05.transform.localEulerAngles = new Vector3 (270f, 164f, 0f);
					SUNFinishSign04.transform.localPosition = new Vector3 (1695.5f, 3.85f, -960f);
					SUNFinishSign04.transform.localEulerAngles = new Vector3 (270f, 152f, 0f);
					SUNFinishSign06.transform.localPosition = new Vector3 (1698.38f, 3.85f, -965.65f);
					SUNFinishSign06.transform.localEulerAngles = new Vector3 (270f, 154f, 0f);
					SUNFinishResults.transform.localPosition = new Vector3 (1811.57f, 6.98f, -925.1f);
					SUNFinishResults.transform.localEulerAngles = new Vector3 (0f, 178f, 0f);
					SUNFinishTable.transform.localPosition = new Vector3 (1811.3f, 5f, -925.8f);
					SUNFinishTable.transform.localEulerAngles = new Vector3 (270f, 96f, 0f);
					SUNFinishChair.transform.localPosition = new Vector3 (1811.82f, 4.795f, -923.85f);
					SUNFinishChair.transform.localEulerAngles = new Vector3 (273.7805f, 91.57985f, 91.2409f);
					SUNFinishTent.transform.localPosition = new Vector3 (1811.4f, 6.95f, -924.66f);
					SUNFinishTent.transform.localEulerAngles = new Vector3 (270f, 96f, 0f);
					
					SundayRouteChanged = true;
				}
				if((bool)sundaybuttons4.Value)
				{
					SUNStartFleetari.transform.localPosition = SUNStartFleetariPos;
					SUNStartFleetari.transform.localEulerAngles = SUNStartFleetariAng;
					SUNStartSender.transform.localPosition = SUNStartSenderPos;
					SUNStartSender.transform.localEulerAngles = SUNStartSenderAng;
					SUNStartSign05.transform.localPosition = SUNStartSign05Pos;
					SUNStartSign05.transform.localEulerAngles = SUNStartSign05Ang;
					SUNStartSign08.transform.localPosition = SUNStartSign08Pos;
					SUNStartSign08.transform.localEulerAngles = SUNStartSign08Ang;
					StagingSUN.transform.localPosition = StagingSUNPos;
					StagingSUN.transform.localEulerAngles = StagingSUNAng;
					StartSUN.transform.localPosition = StartSUNPos;
					StartSUN.transform.localEulerAngles = StartSUNAng;
					
					Checpoint1SUN.transform.localPosition = new Vector3 (-1268.22f, 5f, -696.47f);
					Checpoint1SUN.transform.localEulerAngles = new Vector3 (0f, 286.1487f, 0f);
					Checpoint2SUN.transform.localPosition = new Vector3 (-1258.22f, 5f, -699.47f);
					Checpoint2SUN.transform.localEulerAngles = new Vector3 (0f, 286.1487f, 0f);
					Checpoint3SUN.transform.localPosition = new Vector3 (-1248.22f, 5f, -701.47f);
					Checpoint3SUN.transform.localEulerAngles = new Vector3 (0f, 286.1487f, 0f);
					Checpoint4SUN.transform.localPosition = new Vector3 (-1238.22f, 8f, -703.47f);
					Checpoint4SUN.transform.localEulerAngles = new Vector3 (0f, 105f, 0f);
					
					SUNFinishSign03.transform.localPosition = new Vector3 (-1237.7f, 3.4f, -701.47f);
					SUNFinishSign03.transform.localEulerAngles = new Vector3 (270f, 192f, 0f);
					SUNFinishSign05.transform.localPosition = new Vector3 (-1238.92f, 3.4f, -706f);
					SUNFinishSign05.transform.localEulerAngles = new Vector3 (270f, 199f, 0f);
					SUNFinishSign04.transform.localPosition = new Vector3 (-1248.816f, 0.545f, -703.5f);
					SUNFinishSign04.transform.localEulerAngles = new Vector3 (270f, 196f, 0f);
					SUNFinishSign06.transform.localPosition = new Vector3 (-1247.45f, 0.545f, -698.7f);
					SUNFinishSign06.transform.localEulerAngles = new Vector3 (270f, 193f, 0f);
					SUNFinishResults.transform.localPosition = new Vector3 (-1209.04f, 7.65f, -697.6f);
					SUNFinishResults.transform.localEulerAngles = new Vector3 (0f, 134f, 0f);
					SUNFinishTable.transform.localPosition = new Vector3 (-1208.78f, 5.68f, -698.25f);
					SUNFinishTable.transform.localEulerAngles = new Vector3 (270f, 52f, 0f);
					SUNFinishChair.transform.localPosition = new Vector3 (-1209.74f, 5.5f, -696.5f);
					SUNFinishChair.transform.localEulerAngles = new Vector3 (273.7795f, 53.58163f, 91.24319f);
					SUNFinishTent.transform.localPosition = new Vector3 (-1209.3f, 7.67f, -697.25f);
					SUNFinishTent.transform.localEulerAngles = new Vector3 (274f, 53f, 0f);
					
					SundayRouteChanged = true;
				}
				if((bool)sundaybuttons5.Value)
				{
					SUNStartFleetari.transform.localPosition = new Vector3 (-1727.3f, 5.83f, 1001.1f);
					SUNStartFleetari.transform.localEulerAngles = new Vector3 (0f, 162f, 0f);
					SUNStartSender.transform.localPosition = new Vector3 (-1719.5f, 5.05f, 1075.5f);
					SUNStartSender.transform.localEulerAngles = new Vector3 (0f, 170f, 0f);
					SUNStartSign05.transform.localPosition = new Vector3 (-1728.5f, 5f, 1073f);
					SUNStartSign05.transform.localEulerAngles = new Vector3 (270f, 71f, 0f);
					SUNStartSign08.transform.localPosition = new Vector3 (-1718.7f, 4.8f, 1075.8f);
					SUNStartSign08.transform.localEulerAngles = new Vector3 (270f, 76f, 0f);
					StagingSUN.transform.localPosition = new Vector3 (-1717f, 9f, 1052.25f);
					StagingSUN.transform.localEulerAngles = new Vector3 (0f, 164f, 0f);
					StartSUN.transform.localPosition = new Vector3 (-1724f, 9f, 1074.25f);
					StartSUN.transform.localEulerAngles = new Vector3 (0f, 164f, 0f);
					
					Checpoint1SUN.transform.localPosition = new Vector3 (1878.452f, 16f, 841.8513f);
					Checpoint1SUN.transform.localEulerAngles = new Vector3 (0f, 297f, 0f);
					Checpoint2SUN.transform.localPosition = new Vector3 (2204.09f, 3f, -727.5204f);
					Checpoint2SUN.transform.localEulerAngles = new Vector3 (0f, 3.4f, 0f);
					Checpoint3SUN.transform.localPosition = new Vector3 (-1330.141f, 11f, -1201.99f);
					Checpoint3SUN.transform.localEulerAngles = new Vector3 (0f, 94f, 0f);
					Checpoint4SUN.transform.localPosition = new Vector3 (-1689f, 8f, 963.25f);
					Checpoint4SUN.transform.localEulerAngles = new Vector3 (0f, 344f, 0f);
					
					SUNFinishSign03.transform.localPosition = new Vector3 (-1695.5f, 3.7f, 961.4f);
					SUNFinishSign03.transform.localEulerAngles = new Vector3 (270f, 74f, 0f);
					SUNFinishSign05.transform.localPosition = new Vector3 (-1682f, 3.6f, 965.27f);
					SUNFinishSign05.transform.localEulerAngles = new Vector3 (270f, 77f, 0f);
					SUNFinishSign04.transform.localPosition = new Vector3 (-1665.3f, 4.3f, 900f);
					SUNFinishSign04.transform.localEulerAngles = new Vector3 (270f, 77f, 0f);
					SUNFinishSign06.transform.localPosition = new Vector3 (-1675.1f, 4.3f, 896.5f);
					SUNFinishSign06.transform.localEulerAngles = new Vector3 (270f, 67f, 0f);
					SUNFinishResults.transform.localPosition = new Vector3 (-1726.3f, 5.65f, 1001.35f);
					SUNFinishResults.transform.localEulerAngles = new Vector3 (0f, 155f, 0f);
					SUNFinishTable.transform.localPosition = new Vector3 (-1726.7f, 3.64f, 1000.54f);
					SUNFinishTable.transform.localEulerAngles = new Vector3 (270f, 72.45614f, 0f);
					SUNFinishChair.transform.localPosition = new Vector3 (-1726.55f, 3.554f, 1002.6f);
					SUNFinishChair.transform.localEulerAngles = new Vector3 (270f, 163f, 0f);
					SUNFinishTent.transform.localPosition = new Vector3 (-1727f, 5.73f, 1001.54f);
					SUNFinishTent.transform.localEulerAngles = new Vector3 (270f, 72.45614f, 0f);
					
					SundayRouteChanged = true;
				}
				
				CheckForSunday();
			}
		}
		
		private void CheckForSunday()
		{
			if(FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value == 7 && SaturdayRouteChanged && !(bool)sundaybuttons5.Value)
			{
				if((bool)saturdaybuttons2.Value)
				{
					SATFinishTable.transform.localPosition = SATFinishTablePos;
					SATFinishTable.transform.localEulerAngles = SATFinishTableAng;
					SATFinishChair.transform.localPosition = SATFinishChairPos;
					SATFinishChair.transform.localEulerAngles = SATFinishChairAng;
					SATFinishTent.transform.localPosition = SATFinishTentPos;
					SATFinishTent.transform.localEulerAngles = SATFinishTentAng;
				}
				else
				{
					if((bool)saturdaybuttons3.Value)
					{
						SATFinishTable.transform.localPosition = SATFinishTablePos;
						SATFinishTable.transform.localEulerAngles = SATFinishTableAng;
						SATFinishChair.transform.localPosition = SATFinishChairPos;
						SATFinishChair.transform.localEulerAngles = SATFinishChairAng;
						SATFinishTent.transform.localPosition = SATFinishTentPos;
						SATFinishTent.transform.localEulerAngles = SATFinishTentAng;
					}
					
					if((bool)saturdaybuttons4.Value)
					{
						SATFinishTable.transform.localPosition = SATFinishTablePos;
						SATFinishTable.transform.localEulerAngles = SATFinishTableAng;
						SATFinishChair.transform.localPosition = SATFinishChairPos;
						SATFinishChair.transform.localEulerAngles = SATFinishChairAng;
						SATFinishTent.transform.localPosition = SATFinishTentPos;
						SATFinishTent.transform.localEulerAngles = SATFinishTentAng;
					}
				}
			}
		}
		
		private void VisualizeCheckpoints()
		{
			if(Application.loadedLevelName == "GAME")
			{
				if((bool)vusualchecktoggle.Value)
				{
					VisualStagingSAT = new GameObject();
					VisualStagingSAT.name = "StagingVisual";
					VisualStagingSAT.AddComponent<MeshFilter>();
					VisualStagingSAT.AddComponent<MeshRenderer>();
					VisualStagingSAT.transform.parent = StagingSAT.transform;
					VisualStagingSAT.transform.localScale = new Vector3(1, 1, -1);
					VisualStagingSAT.transform.localPosition = new Vector3(0, 0, 0);
					VisualStagingSAT.transform.localEulerAngles = new Vector3(0, 0, 0);
					VisualStagingSAT.GetComponent<MeshFilter>().mesh = StagingSAT.GetComponent<MeshCollider>().sharedMesh;
					
					VisualStartSAT = new GameObject();
					VisualStartSAT.name = "StartVisual";
					VisualStartSAT.AddComponent<MeshFilter>();
					VisualStartSAT.AddComponent<MeshRenderer>();
					VisualStartSAT.transform.parent = StartSAT.transform;
					VisualStartSAT.transform.localScale = new Vector3(1, 1, -1);
					VisualStartSAT.transform.localPosition = new Vector3(0, 0, 0);
					VisualStartSAT.transform.localEulerAngles = new Vector3(0, 0, 0);
					VisualStartSAT.GetComponent<MeshFilter>().mesh = StartSAT.GetComponent<MeshCollider>().sharedMesh;
					
					VisualCheck1SAT = new GameObject();
					VisualCheck1SAT.name = "CheckVisual1";
					VisualCheck1SAT.AddComponent<MeshFilter>();
					VisualCheck1SAT.AddComponent<MeshRenderer>();
					VisualCheck1SAT.transform.parent = Checpoint1SAT.transform;
					VisualCheck1SAT.transform.localScale = new Vector3(1, 1, -1);
					VisualCheck1SAT.transform.localPosition = new Vector3(0, 0, 0);
					VisualCheck1SAT.transform.localEulerAngles = new Vector3(0, 0, 0);
					VisualCheck1SAT.GetComponent<MeshFilter>().mesh = Checpoint1SAT.GetComponent<MeshCollider>().sharedMesh;
					
					VisualCheck2SAT = new GameObject();
					VisualCheck2SAT.name = "CheckVisual2";
					VisualCheck2SAT.AddComponent<MeshFilter>();
					VisualCheck2SAT.AddComponent<MeshRenderer>();
					VisualCheck2SAT.transform.parent = Checpoint2SAT.transform;
					VisualCheck2SAT.transform.localScale = new Vector3(1, 1, 1);
					VisualCheck2SAT.transform.localPosition = new Vector3(0, 0, 0);
					VisualCheck2SAT.transform.localEulerAngles = new Vector3(0, 0, 0);
					VisualCheck2SAT.GetComponent<MeshFilter>().mesh = Checpoint2SAT.GetComponent<MeshCollider>().sharedMesh;
					
					VisualCheck3SAT = new GameObject();
					VisualCheck3SAT.name = "CheckVisual3";
					VisualCheck3SAT.AddComponent<MeshFilter>();
					VisualCheck3SAT.AddComponent<MeshRenderer>();
					VisualCheck3SAT.transform.parent = Checpoint3SAT.transform;
					VisualCheck3SAT.transform.localScale = new Vector3(1, 1, -1);
					VisualCheck3SAT.transform.localPosition = new Vector3(0, 0, 0);
					VisualCheck3SAT.transform.localEulerAngles = new Vector3(0, 0, 0);
					VisualCheck3SAT.GetComponent<MeshFilter>().mesh = Checpoint3SAT.GetComponent<MeshCollider>().sharedMesh;
					
					VisualCheck4SAT = new GameObject();
					VisualCheck4SAT.name = "CheckVisual4";
					VisualCheck4SAT.AddComponent<MeshFilter>();
					VisualCheck4SAT.AddComponent<MeshRenderer>();
					VisualCheck4SAT.transform.parent = Checpoint4SAT.transform;
					VisualCheck4SAT.transform.localScale = new Vector3(1, 1, 1);
					VisualCheck4SAT.transform.localPosition = new Vector3(0, 0, 0);
					VisualCheck4SAT.transform.localEulerAngles = new Vector3(0, 0, 0);
					VisualCheck4SAT.GetComponent<MeshFilter>().mesh = Checpoint4SAT.GetComponent<MeshCollider>().sharedMesh;
					
					VisualStagingSUN = new GameObject();
					VisualStagingSUN.name = "StagingVisual";
					VisualStagingSUN.AddComponent<MeshFilter>();
					VisualStagingSUN.AddComponent<MeshRenderer>();
					VisualStagingSUN.transform.parent = StagingSUN.transform;
					VisualStagingSUN.transform.localScale = new Vector3(1, 1, -1);
					VisualStagingSUN.transform.localPosition = new Vector3(0, 0, 0);
					VisualStagingSUN.transform.localEulerAngles = new Vector3(0, 0, 0);
					VisualStagingSUN.GetComponent<MeshFilter>().mesh = StagingSUN.GetComponent<MeshCollider>().sharedMesh;
					
					VisualStartSUN = new GameObject();
					VisualStartSUN.name = "StartVisual";
					VisualStartSUN.AddComponent<MeshFilter>();
					VisualStartSUN.AddComponent<MeshRenderer>();
					VisualStartSUN.transform.parent = StartSUN.transform;
					VisualStartSUN.transform.localScale = new Vector3(1, 1, -1);
					VisualStartSUN.transform.localPosition = new Vector3(0, 0, 0);
					VisualStartSUN.transform.localEulerAngles = new Vector3(0, 0, 0);
					VisualStartSUN.GetComponent<MeshFilter>().mesh = StartSUN.GetComponent<MeshCollider>().sharedMesh;
					
					VisualCheck1SUN = new GameObject();
					VisualCheck1SUN.name = "CheckVisual1";
					VisualCheck1SUN.AddComponent<MeshFilter>();
					VisualCheck1SUN.AddComponent<MeshRenderer>();
					VisualCheck1SUN.transform.parent = Checpoint1SUN.transform;
					VisualCheck1SUN.transform.localScale = new Vector3(1, 1, -1);
					VisualCheck1SUN.transform.localPosition = new Vector3(0, 0, 0);
					VisualCheck1SUN.transform.localEulerAngles = new Vector3(0, 0, 0);
					VisualCheck1SUN.GetComponent<MeshFilter>().mesh = Checpoint1SUN.GetComponent<MeshCollider>().sharedMesh;
					
					VisualCheck2SUN = new GameObject();
					VisualCheck2SUN.name = "CheckVisual2";
					VisualCheck2SUN.AddComponent<MeshFilter>();
					VisualCheck2SUN.AddComponent<MeshRenderer>();
					VisualCheck2SUN.transform.parent = Checpoint2SUN.transform;
					VisualCheck2SUN.transform.localScale = new Vector3(1, 1, -1);
					VisualCheck2SUN.transform.localPosition = new Vector3(0, 0, 0);
					VisualCheck2SUN.transform.localEulerAngles = new Vector3(0, 0, 0);
					VisualCheck2SUN.GetComponent<MeshFilter>().mesh = Checpoint2SUN.GetComponent<MeshCollider>().sharedMesh;
					
					VisualCheck3SUN = new GameObject();
					VisualCheck3SUN.name = "CheckVisual3";
					VisualCheck3SUN.AddComponent<MeshFilter>();
					VisualCheck3SUN.AddComponent<MeshRenderer>();
					VisualCheck3SUN.transform.parent = Checpoint3SUN.transform;
					VisualCheck3SUN.transform.localScale = new Vector3(1, 1, -1);
					VisualCheck3SUN.transform.localPosition = new Vector3(0, 0, 0);
					VisualCheck3SUN.transform.localEulerAngles = new Vector3(0, 0, 0);
					VisualCheck3SUN.GetComponent<MeshFilter>().mesh = Checpoint3SUN.GetComponent<MeshCollider>().sharedMesh;
					
					VisualCheck4SUN = new GameObject();
					VisualCheck4SUN.name = "CheckVisual4";
					VisualCheck4SUN.AddComponent<MeshFilter>();
					VisualCheck4SUN.AddComponent<MeshRenderer>();
					VisualCheck4SUN.transform.parent = Checpoint4SUN.transform;
					VisualCheck4SUN.transform.localScale = new Vector3(1, 1, 1);
					VisualCheck4SUN.transform.localPosition = new Vector3(0, 0, 0);
					VisualCheck4SUN.transform.localEulerAngles = new Vector3(0, 0, 0);
					VisualCheck4SUN.GetComponent<MeshFilter>().mesh = Checpoint4SUN.GetComponent<MeshCollider>().sharedMesh;
					
					CheckPointsVisualizated = true;
				}
				else
				{
					if(CheckPointsVisualizated)
					{
						UnityEngine.Object.Destroy(VisualStagingSAT);
						UnityEngine.Object.Destroy(VisualStartSAT);
						UnityEngine.Object.Destroy(VisualCheck1SAT);
						UnityEngine.Object.Destroy(VisualCheck2SAT);
						UnityEngine.Object.Destroy(VisualCheck3SAT);
						UnityEngine.Object.Destroy(VisualCheck4SAT);
						UnityEngine.Object.Destroy(VisualStagingSUN);
						UnityEngine.Object.Destroy(VisualStartSUN);
						UnityEngine.Object.Destroy(VisualCheck1SUN);
						UnityEngine.Object.Destroy(VisualCheck2SUN);
						UnityEngine.Object.Destroy(VisualCheck3SUN);
						UnityEngine.Object.Destroy(VisualCheck4SUN);
						CheckPointsVisualizated = false;
					}
				}
			}
		}
		
		private void SaveDefaultPositions()
		{
			SATStartTentPos = SATStartTent.transform.localPosition;
			SATStartTentAng = SATStartTent.transform.localEulerAngles;
			SATStartTablePos = SATStartTable.transform.localPosition;
			SATStartTableAng = SATStartTable.transform.localEulerAngles;
			SATStartFleetariPos = SATStartFleetari.transform.localPosition;
			SATStartFleetariAng = SATStartFleetari.transform.localEulerAngles;
			SATStartSenderPos = SATStartSender.transform.localPosition;
			SATStartSenderAng = SATStartSender.transform.localEulerAngles;
			SATStartSign05Pos = SATStartSign05.transform.localPosition;
			SATStartSign05Ang = SATStartSign05.transform.localEulerAngles;
			SATStartSign08Pos = SATStartSign08.transform.localPosition;
			SATStartSign08Ang = SATStartSign08.transform.localEulerAngles;
			StagingSATPos = StagingSAT.transform.localPosition;
			StagingSATAng = StagingSAT.transform.localEulerAngles;
			StartSATPos = StartSAT.transform.localPosition;
			StartSATAng = StartSAT.transform.localEulerAngles;
			
			CheckPos1SAT = Checpoint1SAT.transform.localPosition;
			CheckAng1SAT = Checpoint1SAT.transform.localEulerAngles;
			CheckPos2SAT = Checpoint2SAT.transform.localPosition;
			CheckAng2SAT = Checpoint2SAT.transform.localEulerAngles;
			CheckPos3SAT = Checpoint3SAT.transform.localPosition;
			CheckAng3SAT = Checpoint3SAT.transform.localEulerAngles;
			CheckPos4SAT = Checpoint4SAT.transform.localPosition;
			CheckAng4SAT = Checpoint4SAT.transform.localEulerAngles;
			
			SATFinishSign03Pos = SATFinishSign03.transform.localPosition;
			SATFinishSign03Ang = SATFinishSign03.transform.localEulerAngles;
			SATFinishSign05Pos = SATFinishSign05.transform.localPosition;
			SATFinishSign05Ang = SATFinishSign05.transform.localEulerAngles;
			SATFinishSign04Pos = SATFinishSign04.transform.localPosition;
			SATFinishSign04Ang = SATFinishSign04.transform.localEulerAngles;
			SATFinishSign06Pos = SATFinishSign06.transform.localPosition;
			SATFinishSign06Ang = SATFinishSign06.transform.localEulerAngles;
			SATFinishResultsPos = SATFinishResults.transform.localPosition;
			SATFinishResultsAng = SATFinishResults.transform.localEulerAngles;
			SATFinishTablePos = SATFinishTable.transform.localPosition;
			SATFinishTableAng = SATFinishTable.transform.localEulerAngles;
			SATFinishChairPos = SATFinishChair.transform.localPosition;
			SATFinishChairAng = SATFinishChair.transform.localEulerAngles;
			SATFinishTentPos = SATFinishTent.transform.localPosition;
			SATFinishTentAng = SATFinishTent.transform.localEulerAngles;
			
			SUNStartFleetariPos = SUNStartFleetari.transform.localPosition;
			SUNStartFleetariAng = SUNStartFleetari.transform.localEulerAngles;
			SUNStartSenderPos = SUNStartSender.transform.localPosition;
			SUNStartSenderAng = SUNStartSender.transform.localEulerAngles;
			SUNStartSign05Pos = SUNStartSign05.transform.localPosition;
			SUNStartSign05Ang = SUNStartSign05.transform.localEulerAngles;
			SUNStartSign08Pos = SUNStartSign08.transform.localPosition;
			SUNStartSign08Ang = SUNStartSign08.transform.localEulerAngles;
			StagingSUNPos = StagingSUN.transform.localPosition;
			StagingSUNAng = StagingSUN.transform.localEulerAngles;
			StartSUNPos = StartSUN.transform.localPosition;
			StartSUNAng = StartSUN.transform.localEulerAngles;
			
			CheckPos1SUN = Checpoint1SUN.transform.localPosition;
			CheckAng1SUN = Checpoint1SUN.transform.localEulerAngles;
			CheckPos2SUN = Checpoint2SUN.transform.localPosition;
			CheckAng2SUN = Checpoint2SUN.transform.localEulerAngles;
			CheckPos3SUN = Checpoint3SUN.transform.localPosition;
			CheckAng3SUN = Checpoint3SUN.transform.localEulerAngles;
			CheckPos4SUN = Checpoint4SUN.transform.localPosition;
			CheckAng4SUN = Checpoint4SUN.transform.localEulerAngles;
			
			SUNFinishSign03Pos = SUNFinishSign03.transform.localPosition;
			SUNFinishSign03Ang = SUNFinishSign03.transform.localEulerAngles;
			SUNFinishSign05Pos = SUNFinishSign05.transform.localPosition;
			SUNFinishSign05Ang = SUNFinishSign05.transform.localEulerAngles;
			SUNFinishSign04Pos = SUNFinishSign04.transform.localPosition;
			SUNFinishSign04Ang = SUNFinishSign04.transform.localEulerAngles;
			SUNFinishSign06Pos = SUNFinishSign06.transform.localPosition;
			SUNFinishSign06Ang = SUNFinishSign06.transform.localEulerAngles;
			SUNFinishResultsPos = SUNFinishResults.transform.localPosition;
			SUNFinishResultsAng = SUNFinishResults.transform.localEulerAngles;
			SUNFinishTablePos = SUNFinishTable.transform.localPosition;
			SUNFinishTableAng = SUNFinishTable.transform.localEulerAngles;
			SUNFinishChairPos = SUNFinishChair.transform.localPosition;
			SUNFinishChairAng = SUNFinishChair.transform.localEulerAngles;
			SUNFinishTentPos = SUNFinishTent.transform.localPosition;
			SUNFinishTentAng = SUNFinishTent.transform.localEulerAngles;
			
			SaturdayRoute();
			SundayRoute();
		}
    }
}
