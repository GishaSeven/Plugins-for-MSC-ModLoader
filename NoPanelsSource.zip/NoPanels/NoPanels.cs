﻿using MSCLoader;
using UnityEngine;

namespace NoPanels
{
    public class NoPanels : Mod
    {
        public override string ID { get { return "NoPanels"; } }
        public override string Name { get { return "No Panels"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject SATSUMA;
		private GameObject INTERIOR;
		private GameObject LDOOR;
		private GameObject RDOOR;
		private GameObject PANEL1;
		private GameObject PANEL2;
		private GameObject PANEL3;
		private GameObject PANEL4;
		private GameObject PANEL5;
		private GameObject PANEL6;
		
        public override void Update()
        {
            if (Application.loadedLevelName == "GAME" && !loaded)
            {
				SATSUMA = GameObject.Find("SATSUMA(557kg)");
				INTERIOR = SATSUMA.transform.FindChild("Interior").gameObject;
				LDOOR = GameObject.Find("door left(Clone)");
				RDOOR = GameObject.Find("door right(Clone)");
				
				PANEL1 = INTERIOR.transform.FindChild("panel_floormat1").gameObject;
				PANEL1.GetComponent<MeshRenderer>().enabled = false;
				PANEL2 = INTERIOR.transform.FindChild("panel_floormat2").gameObject;
				PANEL2.GetComponent<MeshRenderer>().enabled = false;
				PANEL3 = LDOOR.transform.FindChild("panel_door_left1").gameObject;
				PANEL3.GetComponent<MeshRenderer>().enabled = false;
				PANEL4 = INTERIOR.transform.FindChild("panel_door_left2").gameObject;
				PANEL4.GetComponent<MeshRenderer>().enabled = false;
				PANEL5 = RDOOR.transform.FindChild("panel_door_right1").gameObject;
				PANEL5.GetComponent<MeshRenderer>().enabled = false;
				PANEL6 = INTERIOR.transform.FindChild("panel_door_right2").gameObject;
				PANEL6.GetComponent<MeshRenderer>().enabled = false;
								
				loaded = true;
            }
			
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
    }
}
