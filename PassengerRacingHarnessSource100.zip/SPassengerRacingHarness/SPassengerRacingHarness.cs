﻿using MSCLoader;
using UnityEngine;
using HutongGames.PlayMaker;

namespace SPassengerRacingHarness
{
    public class SPassengerRacingHarness : Mod
    {
        public override string ID => "SPassengerRacingHarness";
        public override string Name => "Passenger Racing Harness";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";
        public override string Description => "Add passenger racing harness";
		
		private GameObject open;
		private GameObject closed;
		SettingsDropDownList dropDownList;

        public override void ModSettings()
        {
			string[] ItemNames = new string[] { "Open", "Closed" };
			dropDownList = Settings.AddDropDownList("myList", "Open/Closed", ItemNames, 0, openclosed, true);
        }

        public override void OnLoad()
        {
            if(GameObject.Find("racing harness(xxxxx)") !=null)
			{
				GameObject harnessclone = Object.Instantiate(GameObject.Find("racing harness(xxxxx)"));
				harnessclone.name = "passanger_harness";
				Object.Destroy(harnessclone.GetComponents<PlayMakerFSM>()[0]);
				Object.Destroy(harnessclone.GetComponents<PlayMakerFSM>()[1]);
				Object.Destroy(harnessclone.GetComponent<SphereCollider>());
				Object.Destroy(harnessclone.GetComponent<PlayMakerArrayListProxy>());
				
				harnessclone.transform.parent = GameObject.Find("bucket seat passenger(Clone)").gameObject.transform;
				harnessclone.transform.localPosition = new Vector3 (0f, -0.16f, 0.1f);
				harnessclone.transform.localEulerAngles = Vector3.zero;
				harnessclone.transform.localScale = Vector3.one;
				
				Object.Destroy(harnessclone.transform.GetChild(0).GetComponent<PlayMakerFSM>());
				Object.Destroy(harnessclone.transform.GetChild(0).GetComponent<SphereCollider>());
				Object.Destroy(harnessclone.transform.GetChild(0).GetComponent<Rigidbody>());
				Object.Destroy(harnessclone.transform.GetChild(1).GetComponent<PlayMakerFSM>());
				Object.Destroy(harnessclone.transform.GetChild(1).GetComponent<SphereCollider>());
				Object.Destroy(harnessclone.transform.GetChild(1).GetComponent<Rigidbody>());
				Object.Destroy(harnessclone.transform.GetChild(2).GetComponent<PlayMakerFSM>());
				Object.Destroy(harnessclone.transform.GetChild(2).GetComponent<SphereCollider>());
				Object.Destroy(harnessclone.transform.GetChild(2).GetComponent<Rigidbody>());
				Object.Destroy(harnessclone.transform.GetChild(3).GetComponent<PlayMakerFSM>());
				Object.Destroy(harnessclone.transform.GetChild(3).GetComponent<SphereCollider>());
				Object.Destroy(harnessclone.transform.GetChild(3).GetComponent<Rigidbody>());
				Object.Destroy(harnessclone.transform.GetChild(4).gameObject);
				
				open = harnessclone.transform.FindChild("Open").gameObject;
				closed = harnessclone.transform.FindChild("Close").gameObject;
				
				openclosed();
			}
        }
		
		private void openclosed()
		{
			if(Application.loadedLevelName == "GAME")
			{
				if(dropDownList.GetSelectedItemIndex() == 0)
				{
					open.gameObject.SetActive(true);
					closed.gameObject.SetActive(false);
				}
			
				if(dropDownList.GetSelectedItemIndex() == 1)
				{
					open.gameObject.SetActive(false);
					closed.gameObject.SetActive(true);
				}
			}
		}
    }
}
