﻿using MSCLoader;
using UnityEngine;

namespace LFTTFix
{
    public class LFTTFix : Mod
    {
        public override string ID => "LFTTFix";
        public override string Name => "LFTTFix";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

		public override bool UseAssetsFolder => false;
		
		public override void OnLoad()
		{
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/HEADER/Texts").transform.localPosition = new Vector3(0.2f, -0.4f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/HEADER/Texts/PageCurrent").gameObject.GetComponent<MeshRenderer>().enabled = false;
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/HEADER/Texts/Time").transform.localPosition = new Vector3(-7.75f, 1f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/HEADER/Texts/Status").transform.localPosition = new Vector3(-14f, 1f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/100/Texts").gameObject.transform.GetChild(0).transform.localPosition = new Vector3(-2.5f, 5f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/101/Texts").gameObject.transform.GetChild(0).transform.localPosition = new Vector3(0f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/101/Texts").gameObject.transform.GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts").gameObject.transform.GetChild(0).transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts").gameObject.transform.GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Day").transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Day").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Bottomline").transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/102/Texts/Bottomline").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Header").transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Header").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Day").transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Day").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Bottomline").transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/130/Texts/Bottomline").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Header").transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Header").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Day").transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Day").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Bottomline").transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/160/Texts/Bottomline").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/180/Texts").gameObject.transform.GetChild(0).transform.localPosition = new Vector3(0f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/180/Texts").gameObject.transform.GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Header").transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Header").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Day").transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Day").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Weather").transform.localPosition = new Vector3(-0.15f, -0.22f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Bottomline").transform.localPosition = new Vector3(0.9f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/181/Texts/Bottomline").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Header").transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Header").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Day").transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Day").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Bottomline").transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Bottomline").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Header").transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Header").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Day").transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Day").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Bottomline").transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/190/Texts/Bottomline").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/200/Texts").gameObject.transform.GetChild(0).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/200/Texts").gameObject.transform.GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Header").transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Header").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Day").transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Day").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Bottomline").transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/201/Texts/Bottomline").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Header").transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Header").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Day").transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Day").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Bottomline").transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/240/Texts/Bottomline").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Header").transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Header").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Day").transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Day").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Bottomline").transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/Bottomline").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Header").transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Header").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Round").transform.localPosition = new Vector3(-8.9f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Round").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Day").transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Day").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts").gameObject.transform.GetChild(8).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts").gameObject.transform.GetChild(8).transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/1").transform.localPosition = new Vector3(-5.7f, 4f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts/Winnings/6/+1").transform.localPosition = new Vector3(0.4f, 0f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/301/Texts").gameObject.transform.GetChild(9).transform.localPosition = new Vector3(1f, 14f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/400/Texts").gameObject.transform.GetChild(0).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/400/Texts").gameObject.transform.GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Header").transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Header").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Day").transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Day").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Bottomline").transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/401/Texts/Bottomline").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/500/Texts").gameObject.transform.GetChild(0).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/500/Texts").gameObject.transform.GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/501/Texts/BottomLine").transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/501/Texts/BottomLine").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/501/Texts/Newsline").transform.localPosition = new Vector3(0f, 5.55f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/502/Texts/Header").transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/502/Texts/Header").transform.localScale = new Vector3(1f, 0.9f, 1f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/502/Texts/BottomLine").transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/502/Texts/BottomLine").transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			ModConsole.Print("TT position fixed!");
			
			if(GameObject.Find("YARD/Building/BEDROOM1") != null)
			{
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/RAMI-Filosofiapeli/Filosofi-lopputulokset").transform.localPosition = new Vector3(-0.5f, 0.2f, 0.46f);
				
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/RAMI-Joulupukki/Joulupukki-Laskuri-Items").transform.localPosition = new Vector3(7.54f, 0.46f, 7.54f);
				
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/RAMI-Joulupukki/Joulupukki-Laskuri-Level").transform.localPosition = new Vector3(1.83f, 0.46f, 7.54f);
				
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/RAMI-Joulupukki/Joulupukki-Laskuri-Lives").transform.localPosition = new Vector3(-4.02f, 0.45f, 7.54f);
				
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/RAMI-Massacre/Massacre-ammo").transform.localPosition = new Vector3(-2.59f, 0.22f, -6.25f);
				
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/CPUpelaajat/Kello").transform.localPosition = new Vector3(-9.91f, 0.46f, 7.67f);
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/CPUpelaajat/Kello").transform.localScale = new Vector3(0.8f, 0.8f, 1f);
				
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/PROCYON-ProPilkki/Tulokset/TuloksetKisa/SuurinKala").transform.localPosition = new Vector3(-8.38f, 1.2f, -5f);
				
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/RAMI-Sormileikki/Laskuri").transform.localPosition = new Vector3(7f, 2.01f, 6.96f);
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/RAMI-Sormileikki/Laskuri").transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
				
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/RAMI-Sormileikki/Laskuri-push").transform.localPosition = new Vector3(-7.49f, 2.01f, 6.96f);
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/RAMI-Sormileikki/Laskuri-push").transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
				
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/RAMI-Sormileikki/Sormileikki-Mode2/Mode2-Laskuri").transform.localPosition = new Vector3(7f, 2.01f, 6.96f);
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/RAMI-Sormileikki/Sormileikki-Mode2/Mode2-Laskuri").transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
				
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/RAMI-Sormileikki/Sormileikki-Mode2/Mode2-Laskuri-push").transform.localPosition = new Vector3(-7.49f, 2.01f, 6.96f);
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/RAMI-Sormileikki/Sormileikki-Mode2/Mode2-Laskuri-push").transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
				
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/TELEBBS/Software").gameObject.transform.GetChild(1).transform.localPosition = new Vector3(-9.86f, -7.41f, 11.57f);
				
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/TELEBBS/Software").gameObject.transform.GetChild(2).transform.localPosition = new Vector3(2.88f, -7.41f, 11.57f);
				
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/TELEBBS/CONLINE/CommandLine").transform.localPosition = new Vector3(-9.5f, -5.1f, 11.57f);
				
				GameObject.Find("YARD/Building/BEDROOM1").transform.Find("COMPUTER/SYSTEM/TELEBBS/CONLINE/SPLASH").transform.localPosition = new Vector3(0f, -0.8f, 0f);
			}
			
			ModConsole.Print("Computer position fixed!");
        }
    }
}
