﻿using MSCLoader;
using UnityEngine;
using System.Threading;

namespace Hood
{
    public class Hood : Mod
    {
        public override string ID => "Hood";
        public override string Name => "Hood";
        public override string Author => "Roman266";
        public override string Version => "1.0.2";

        public override bool UseAssetsFolder => true;
		
		private GameObject HOOD;

		public override void OnLoad()
        {			
			new Thread(waiting).Start();
        }
		
		private void waiting()
		{
			Thread.Sleep( 20 * 1000 );
			
			if(GameObject.Find("fiberglass hood(Clone)").activeSelf == true)
			{
				HOOD = GameObject.Find("fiberglass hood(Clone)");
				
				Mesh new_mesh0 = LoadAssets.LoadOBJMesh(this, "hood.obj");
				
				HOOD.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
			}
		}
    }
}
