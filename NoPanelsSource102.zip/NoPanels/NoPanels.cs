﻿using MSCLoader;
using UnityEngine;

namespace NoPanels
{
    public class NoPanels : Mod
    {
        public override string ID => "NoPanels";
        public override string Name => "No Panels";
        public override string Author => "Roman266";
        public override string Version => "1.0.2";

        public override bool UseAssetsFolder => false;

        public override void OnLoad()
        {
			GameObject.Find("SATSUMA(557kg, 248)/Interior/panel_floormat1").GetComponent<MeshRenderer>().enabled = false;
			GameObject.Find("SATSUMA(557kg, 248)/Interior/panel_floormat2").GetComponent<MeshRenderer>().enabled = false;
			GameObject.Find("SATSUMA(557kg, 248)/Interior/panel_door_left2").GetComponent<MeshRenderer>().enabled = false;
			GameObject.Find("SATSUMA(557kg, 248)/Interior/panel_door_right2").GetComponent<MeshRenderer>().enabled = false;
			GameObject.Find("door left(Clone)/panel_door_left1").GetComponent<MeshRenderer>().enabled = false;
			GameObject.Find("door right(Clone)/panel_door_right1").GetComponent<MeshRenderer>().enabled = false;
        }
    }
}
