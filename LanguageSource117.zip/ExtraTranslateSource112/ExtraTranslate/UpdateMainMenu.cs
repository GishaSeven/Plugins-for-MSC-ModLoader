﻿using UnityEngine;
using System.Linq;

namespace ExtraTranslate
{
    class UpdateMainMenu : MonoBehaviour
    {
		private bool Loaded;
		
		public void Update()
        {
			if(!Loaded)
			{																
				if(GameObject.Find("Radio/Folk").GetComponents<PlayMakerFSM>()[1].Fsm.Initialized & GameObject.Find("Radio/CD").GetComponent<PlayMakerFSM>().Fsm.Initialized) 
				{ 
					GameObject.Find("Radio/Folk").GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmString("Path").Value = ExtraMod.notimported;

					HutongGames.PlayMaker.Actions.SetStringValue radioimpstring = GameObject.Find("Radio/Folk").GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Off").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;
					radioimpstring.stringValue = ExtraMod.radioimported;
					
					GameObject.Find("Radio/CD").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("Path").Value = ExtraMod.notimported;
					
					HutongGames.PlayMaker.Actions.SetStringValue cdimpstring = GameObject.Find("Radio/CD").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
					cdimpstring.stringValue = ExtraMod.cdimported;
					
					Loaded = true;
				}
			}
		}
    }
}
