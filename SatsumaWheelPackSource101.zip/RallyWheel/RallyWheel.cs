﻿using MSCLoader;
using UnityEngine;
using System.Threading;

namespace RallyWheel
{
    public class RallyWheel : Mod
    {
        public override string ID => "RallyWheel";
        public override string Name => "Rally Wheel";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => true;

		private GameObject FLRIM;
		private GameObject FRRIM;
		private GameObject RLRIM;
		private GameObject RRRIM;
		
		public override void OnLoad()
        {				
			new Thread(waiting2r).Start();
        }
		
		private void waiting2r()
		{
			Thread.Sleep( 20 * 1000 );
			
			Mesh new_mesh1 = LoadAssets.LoadOBJMesh(this, "tire_rally.obj");
			
			Texture2D loadtexture2 = LoadAssets.LoadTexture(this, "tires_rally.dds");
			
			GameObject[] allObjects = UnityEngine.Object.FindObjectsOfType<GameObject>();
			foreach(GameObject findme in allObjects)
			{
				if(findme.name == "TireRally(Clone)")
				{
					findme.GetComponent<MeshFilter>().mesh = new_mesh1;
					findme.GetComponent<MeshRenderer>().material.mainTexture = loadtexture2;
				}
			}
			
			if(GameObject.Find("wheel rally fl(Clone)").activeSelf == true)
			{
				FLRIM = GameObject.Find("wheel rally fl(Clone)");
				FRRIM = GameObject.Find("wheel rally fr(Clone)");
				RLRIM = GameObject.Find("wheel rally rl(Clone)");
				RRRIM = GameObject.Find("wheel rally rr(Clone)");
				
				Mesh new_mesh0 = LoadAssets.LoadOBJMesh(this, "rim_rally.obj");
									
				FLRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				FRRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				RLRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				RRRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
			}
		}
    }
}
