﻿using MSCLoader;
using UnityEngine;
using System.Threading;

namespace DragWheel
{
    public class DragWheel : Mod
    {
        public override string ID => "DragWheel";
        public override string Name => "Drag Wheel";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => true;

		private GameObject FLRIM;
		private GameObject FLRIMCHRM;
		private GameObject FRRIM;
		private GameObject FRRIMCHRM;
		private GameObject RLRIM;
		private GameObject RLRIMCHRM;
		private GameObject RRRIM;
		private GameObject RRRIMCHRM;
		
		public override void OnLoad()
        {				
			new Thread(waiting4r).Start();
        }
			
		private void waiting4r()
		{
			Thread.Sleep( 20 * 1000 );
						
			Mesh new_mesh2 = LoadAssets.LoadOBJMesh(this, "tire_slick.obj");
			
			Texture2D loadtexture2 = LoadAssets.LoadTexture(this, "tires_slicks.dds");
						
			GameObject[] allObjects = UnityEngine.Object.FindObjectsOfType<GameObject>();
			foreach(GameObject findme in allObjects)
			{
				if(findme.name == "TireSlick(Clone)")
				{
					findme.GetComponent<MeshFilter>().mesh = new_mesh2;
					findme.GetComponent<MeshRenderer>().material.mainTexture = loadtexture2;
				}
			}
			
			if(GameObject.Find("wheel racing fl(Clone)").activeSelf == true)
			{
				FLRIM = GameObject.Find("wheel racing fl(Clone)");
				FLRIMCHRM = FLRIM.transform.FindChild("chrome").gameObject;
				FRRIM = GameObject.Find("wheel racing fr(Clone)");
				FRRIMCHRM = FRRIM.transform.FindChild("chrome").gameObject;
				RLRIM = GameObject.Find("wheel racing rl(Clone)");
				RLRIMCHRM = RLRIM.transform.FindChild("chrome").gameObject;
				RRRIM = GameObject.Find("wheel racing rr(Clone)");
				RRRIMCHRM = RRRIM.transform.FindChild("chrome").gameObject;
				
				Mesh new_mesh0 = LoadAssets.LoadOBJMesh(this, "rim_racing.obj");
				Mesh new_mesh1 = LoadAssets.LoadOBJMesh(this, "rim_racing_chrome.obj");
									
				FLRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				FLRIMCHRM.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				FRRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				FRRIMCHRM.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				RLRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				RLRIMCHRM.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				RRRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				RRRIMCHRM.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
			}
		}
    }
}
