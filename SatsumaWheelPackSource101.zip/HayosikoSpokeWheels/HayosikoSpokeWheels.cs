﻿using MSCLoader;
using UnityEngine;
using System.Threading;

namespace HayosikoSpokeWheels
{
    public class HayosikoSpokeWheels : Mod
    {
        public override string ID => "HayosikoSpokeWheels";
        public override string Name => "Hayosiko SpokeWheels";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => true;

		private GameObject FLRIMHAYO;
		private GameObject FLRIMHAYOIN;
		private GameObject FRRIMHAYO;
		private GameObject FRRIMHAYOIN;
		private GameObject RLRIMHAYO;
		private GameObject RLRIMHAYOIN;
		private GameObject RRRIMHAYO;
		private GameObject RRRIMHAYOIN;
		private GameObject FLRIMSPOK;
		private GameObject FRRIMSPOK;
		private GameObject RLRIMSPOK;
		private GameObject RRRIMSPOK;
		
		public override void OnLoad()
        {				
			new Thread(waiting3r).Start();
        }
		
		private void waiting3r()
		{
			Thread.Sleep( 20 * 1000 );
			
			Mesh new_mesh3 = LoadAssets.LoadOBJMesh(this, "tire_gobra.obj");
			
			Texture2D loadtexture3 = LoadAssets.LoadTexture(this, "tires_gobra.dds");
						
			GameObject[] allObjects = UnityEngine.Object.FindObjectsOfType<GameObject>();
			foreach(GameObject findme in allObjects)
			{
				if(findme.name == "TireGobra(Clone)")
				{
					findme.GetComponent<MeshFilter>().mesh = new_mesh3;
					findme.GetComponent<MeshRenderer>().material.mainTexture = loadtexture3;
				}
			}
			
			if(GameObject.Find("wheel hayosiko fl(Clone)").activeSelf == true)
			{
				FLRIMHAYO = GameObject.Find("wheel hayosiko fl(Clone)");
				FLRIMHAYOIN = FLRIMHAYO.transform.FindChild("inner").gameObject;
				FRRIMHAYO = GameObject.Find("wheel hayosiko fr(Clone)");
				FRRIMHAYOIN = FRRIMHAYO.transform.FindChild("inner").gameObject;
				RLRIMHAYO = GameObject.Find("wheel hayosiko rl(Clone)");
				RLRIMHAYOIN = RLRIMHAYO.transform.FindChild("inner").gameObject;
				RRRIMHAYO = GameObject.Find("wheel hayosiko rr(Clone)");
				RRRIMHAYOIN = RRRIMHAYO.transform.FindChild("inner").gameObject;
				
				Mesh new_mesh0 = LoadAssets.LoadOBJMesh(this, "rim_hayosiko.obj");
				Mesh new_mesh1 = LoadAssets.LoadOBJMesh(this, "rim_hayosiko_inner.obj");
					
				FLRIMHAYO.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				FLRIMHAYOIN.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				FRRIMHAYO.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				FRRIMHAYOIN.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				RLRIMHAYO.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				RLRIMHAYOIN.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				RRRIMHAYO.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				RRRIMHAYOIN.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
			}
				
			if(GameObject.Find("wheel spoke fl(Clone)").activeSelf == true)
			{
				FLRIMSPOK = GameObject.Find("wheel spoke fl(Clone)");
				FRRIMSPOK = GameObject.Find("wheel spoke fr(Clone)");
				RLRIMSPOK = GameObject.Find("wheel spoke rl(Clone)");
				RRRIMSPOK = GameObject.Find("wheel spoke rr(Clone)");
				
				Mesh new_mesh2 = LoadAssets.LoadOBJMesh(this, "rim_spoke.obj");
								
				FLRIMSPOK.transform.GetComponent<MeshFilter>().mesh = new_mesh2;
				FRRIMSPOK.transform.GetComponent<MeshFilter>().mesh = new_mesh2;
				RLRIMSPOK.transform.GetComponent<MeshFilter>().mesh = new_mesh2;
				RRRIMSPOK.transform.GetComponent<MeshFilter>().mesh = new_mesh2;
			}
		}
    }
}
