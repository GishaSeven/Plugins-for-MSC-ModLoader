﻿using HutongGames.PlayMaker;
using MSCLoader;
using UnityEngine;
using System;

namespace SpeedPower
{
    public class SpeedPower : Mod
    {
        public override string ID { get { return "SpeedPower"; } }
        public override string Name { get { return "SpeedPower"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.1"; } }
		
		public bool isShow;
		
		private Keybind show2Key = new Keybind("ShowKey", "Show Satsuma stat", KeyCode.F6);
		
		public override void OnLoad()
        {
            Keybind.Add(this, show2Key);
        }
		
        public override void Update()
        {
			if (show2Key.IsDown()) { ShowStat(); };
        }
		
		private void ShowStat()
        {
            this.isShow = !this.isShow;
        }
		
		public override void OnGUI()
		{
			GUIStyle myStyle = new GUIStyle();
			myStyle.fontSize = (int)(12.0f * (float)(Screen.width)/1000f);
			myStyle.normal.textColor = Color.white;
			
			if(isShow)
			{
			GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-160)/1, Screen.width, Screen.height), "RPM: " + FsmVariables.GlobalVariables.FindFsmFloat("RPM"), myStyle);
			GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-140)/1, Screen.width, Screen.height), "Speed: " + GameObject.Find("SATSUMA(557kg)").GetComponent<Drivetrain>().differentialSpeed, myStyle);			
			GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-120)/1, Screen.width, Screen.height), "Max Power: " + GameObject.Find("SATSUMA(557kg)").GetComponent<Drivetrain>().maxPower, myStyle);
			GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-100)/1, Screen.width, Screen.height), "Max Torque: " + GameObject.Find("SATSUMA(557kg)").GetComponent<Drivetrain>().maxTorque, myStyle);
			}
		}
    }
}
