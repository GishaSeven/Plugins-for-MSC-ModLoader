﻿using System;
using UnityEngine;

namespace GAZ24
{
    public class SaveDataList
    {
		public float fuel;
		public Vector3 pos;
		public float rotX, rotY, rotZ;
    }
}
