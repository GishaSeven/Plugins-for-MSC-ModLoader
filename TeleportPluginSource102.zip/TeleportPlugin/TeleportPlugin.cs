﻿using MSCLoader;
using UnityEngine;

namespace TeleportPlugin
{
    public class TeleportPlugin : Mod
    {
        public override string ID => "TeleportPlugin";
        public override string Name => "Teleport Plugin";
        public override string Author => "Djoe45(Update by Roman266)";
        public override string Version => "1.0.2";

        public override bool UseAssetsFolder => false;

		private Keybind tpToCar = new Keybind("Key01", "Teleport To Car", KeyCode.Alpha1, KeyCode.LeftControl);
        private Keybind tpCarToMe = new Keybind("Key02", "Teleport Car Me", KeyCode.Alpha2, KeyCode.LeftControl);
        private Keybind tpToMuscle = new Keybind("Key03", "Teleport To Muscle Car", KeyCode.Alpha3, KeyCode.LeftControl);
        private Keybind tpMuscleToMe = new Keybind("Key04", "Teleport Muscle Car To Me", KeyCode.Alpha4, KeyCode.LeftControl);
		private Keybind tpToTruck = new Keybind("Key05", "Teleport To Truck", KeyCode.Alpha5, KeyCode.LeftControl);
        private Keybind tpTruckToMe = new Keybind("Key06", "Teleport Truck To Me", KeyCode.Alpha6, KeyCode.LeftControl);
        private Keybind tpToTractor = new Keybind("Key07", "Teleport To Tractor", KeyCode.Alpha7, KeyCode.LeftControl);
        private Keybind tpTractorToMe = new Keybind("Key08", "Teleport Tractor To Me", KeyCode.Alpha8, KeyCode.LeftControl);
        private Keybind tpToVan = new Keybind("Key09", "Teleport To Van", KeyCode.Alpha9, KeyCode.LeftControl);
        private Keybind tpVanToMe = new Keybind("Key010", "Teleport Van To Me", KeyCode.Alpha0, KeyCode.LeftControl);
		private Keybind tpToMoped = new Keybind("Key011", "Teleport To Moped", KeyCode.Alpha9, KeyCode.RightControl);
        private Keybind tpMopedToMe = new Keybind("Key012", "Teleport Moped To Me", KeyCode.Alpha0, KeyCode.RightControl);
		private Keybind tpToRuscko = new Keybind("Key013", "Teleport To Ruscko", KeyCode.Alpha7, KeyCode.RightControl);
        private Keybind tpRusckoToMe = new Keybind("Key014", "Teleport Ruscko To Me", KeyCode.Alpha8, KeyCode.RightControl);

        private Keybind tpToHome = new Keybind("Key015", "Teleport To Home", KeyCode.Alpha1, KeyCode.RightControl);
        private Keybind tpToStore = new Keybind("Key016", "Teleport To Store", KeyCode.Alpha2, KeyCode.RightControl);
        private Keybind tpToRepair = new Keybind("Key017", "Teleport To Repair", KeyCode.Alpha3, KeyCode.RightControl);
        private Keybind tpToDrag = new Keybind("Key018", "Teleport To Drag", KeyCode.Alpha4, KeyCode.RightControl);
		private Keybind tpToCottage = new Keybind("Key019", "Teleport To Cottage", KeyCode.Alpha5, KeyCode.RightControl);
		private Keybind tpToVenttiPig = new Keybind("Key020", "Teleport To Ventti Pig", KeyCode.Alpha6, KeyCode.RightControl);

        public override void OnLoad()
		{
			Keybind.Add(this, tpToCar);
            Keybind.Add(this, tpCarToMe);
            Keybind.Add(this, tpToMuscle);
            Keybind.Add(this, tpMuscleToMe);
            Keybind.Add(this, tpToTruck);
            Keybind.Add(this, tpTruckToMe);
            Keybind.Add(this, tpToTractor);
            Keybind.Add(this, tpTractorToMe);
            Keybind.Add(this, tpToVan);
            Keybind.Add(this, tpVanToMe);
			Keybind.Add(this, tpToMoped);
            Keybind.Add(this, tpMopedToMe);
			Keybind.Add(this, tpToRuscko);
            Keybind.Add(this, tpRusckoToMe);

            Keybind.Add(this, tpToHome);
            Keybind.Add(this, tpToStore);
            Keybind.Add(this, tpToRepair);
            Keybind.Add(this, tpToDrag);
			Keybind.Add(this, tpToCottage);
			Keybind.Add(this, tpToVenttiPig);

            ModConsole.Print("Teleport Plugin has been loaded!");
        }

		public override void Update()
		{
            if (tpToCar.IsDown()) { TpTo("PLAYER", "SATSUMA(557kg, 248)"); }
            if (tpCarToMe.IsDown()) { TpMe("SATSUMA(557kg, 248)", "PLAYER"); }
            if (tpToMuscle.IsDown()) { TpTo("PLAYER", "FERNDALE(1630kg)"); }
            if (tpMuscleToMe.IsDown()) { TpMe("FERNDALE(1630kg)", "PLAYER"); }
			if (tpToTruck.IsDown()) { TpTo("PLAYER", "GIFU(750/450psi)"); }
            if (tpTruckToMe.IsDown()) { TpMe("GIFU(750/450psi)", "PLAYER"); }
            if (tpToTractor.IsDown()) { TpTo("PLAYER", "KEKMET(350-400psi)"); }
            if (tpTractorToMe.IsDown()) { TpTo("KEKMET(350-400psi)", "PLAYER"); }
            if (tpToVan.IsDown()) { TpTo("PLAYER", "HAYOSIKO(1500kg, 250)"); }
            if (tpVanToMe.IsDown()) { TpTo("HAYOSIKO(1500kg, 250)", "PLAYER"); }
			if (tpToMoped.IsDown()) { TpTo("PLAYER", "JONNEZ ES(Clone)"); }
            if (tpMopedToMe.IsDown()) { TpTo("JONNEZ ES(Clone)", "PLAYER"); }
			if (tpToRuscko.IsDown()) { TpTo("PLAYER", "RCO_RUSCKO12(270)"); }
            if (tpRusckoToMe.IsDown()) { TpTo("RCO_RUSCKO12(270)", "PLAYER"); }

            if (tpToHome.IsDown()) { TpTo("PLAYER", "GraveYardSpawn"); }
            if (tpToStore.IsDown()) { TpTo("PLAYER", "SpawnToStore"); }
            if (tpToRepair.IsDown()) { TpTo("PLAYER", "SpawnToRepair"); }
            if (tpToDrag.IsDown()) { TpTo("PLAYER", "SpawnToDrag"); }
			if (tpToCottage.IsDown()) { TpTo("PLAYER", "SpawnToCottage"); }
			if (tpToVenttiPig.IsDown()) { TpTo("PLAYER", "SpawnToVenttiPig"); }
        }

        private void TpTo(string tpObject, string tptoObject)
        {
            ModConsole.Print("Teleportation to:" + tptoObject);
            var posFinder = GameObject.Find(tptoObject);
            Vector3 newPlayerPos = new Vector3(posFinder.transform.position.x + 3, posFinder.transform.position.y, posFinder.transform.position.z);
            GameObject.Find(tpObject).transform.position = newPlayerPos;
        }

        private void TpMe(string tpObject, string tptoObject)
        {
            ModConsole.Print("Teleporte me to:" + tptoObject);
            var posFinder = GameObject.Find(tptoObject);
            Vector3 newCarPos = new Vector3(posFinder.transform.position.x + 3, posFinder.transform.position.y, posFinder.transform.position.z);
            GameObject.Find(tpObject).transform.position = newCarPos;
        }
    }
}
