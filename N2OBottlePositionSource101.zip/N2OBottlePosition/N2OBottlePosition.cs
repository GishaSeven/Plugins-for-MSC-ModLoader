﻿using MSCLoader;
using UnityEngine;

namespace N2OBottlePosition
{
    public class N2OBottlePosition : Mod
    {
        public override string ID => "N2OBottlePosition";
        public override string Name => "No Panels";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => false;

		private GameObject SATSUMA;
		private GameObject INTERIOR;
		private GameObject HOLDER;
		private GameObject TRIGGER;
		
        public override void OnLoad()
        {
			this.SATSUMA = GameObject.Find("SATSUMA(557kg, 248)");
			this.INTERIOR = this.SATSUMA.transform.FindChild("Interior").gameObject;
			this.HOLDER = this.INTERIOR.transform.FindChild("n2o bottle holder(xxxxx)").gameObject;
			this.TRIGGER = this.INTERIOR.transform.FindChild("trigger_n2o_holder").gameObject;
			
			this.HOLDER.transform.localPosition = new Vector3(0.36f, -0.185f, 0.5f);
			this.HOLDER.transform.localRotation = new Quaternion(-0.119646f, -0.942f, -0.12f, 0.908800f);
			this.TRIGGER.transform.localPosition = new Vector3(0.36f, -0.185f, 0.5f);
        }
    }
}
