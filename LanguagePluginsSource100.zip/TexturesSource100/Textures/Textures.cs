﻿using MSCLoader;
using UnityEngine;
using System.Threading;

namespace Textures
{
    public class Textures : Mod
    {
        public override string ID => "Textures";
        public override string Name => "Textures";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";

		public override bool LoadInMenu => true;
		public override bool UseAssetsFolder => true;
		private Texture2D texture1;
		private Texture2D texture2;
		private Texture2D texture3;
		private Texture2D texture4;
		private Texture2D texture5;
		private Texture2D texture6;
		private Texture2D texture7;
		private Texture2D texture8;
		private Texture2D texture9;
		private Texture2D texture10;
		private Texture2D texture11;
		private Texture2D texture12;
		private Texture2D texture13;
		
		public override void OnMenuLoad() 
		{
			texture1 = LoadAssets.LoadTexture(this, "drivers_lincence.dds");
			
			new Thread(MenuCheck).Start();
        }
		
		private void MenuCheck()
		{
			Thread.Sleep( 1 * 1000 );
			if(GameObject.Find("Licence/Card/mesh") != null)
			{
				GameObject.Find("Licence/Card/mesh").GetComponent<MeshRenderer>().material.mainTexture = texture1;
			}
			else
			{
				MenuCheck();
			}
		}
		
		public override void OnLoad()
		{
			texture2 = LoadAssets.LoadTexture(this, "repairshop_01.dds");
			texture3 = LoadAssets.LoadTexture(this, "repairshop_02.dds");
			texture4 = LoadAssets.LoadTexture(this, "repairshop_03.dds");
			texture5 = LoadAssets.LoadTexture(this, "repairshop_04.dds");
			texture6 = LoadAssets.LoadTexture(this, "repairshop_05.dds");
			texture7 = LoadAssets.LoadTexture(this, "repairshop_06.dds");
			texture8 = LoadAssets.LoadTexture(this, "repairshop_07.dds");
			texture9 = LoadAssets.LoadTexture(this, "repairshop_08.dds");
			texture10 = LoadAssets.LoadTexture(this, "inspection_recipiet_fi.dds");
			texture11 = LoadAssets.LoadTexture(this, "inspection_recipiet_en.dds");
			texture12 = LoadAssets.LoadTexture(this, "inspection_fail.dds");
			texture13 = LoadAssets.LoadTexture(this, "inspection_pass.dds");
			
			new Thread(RepairCheck).Start();
			
			if(GameObject.Find("register plate(Clone)") == null)
			{
				new Thread(InspectCheck).Start();
			}
        }
		
		private void RepairCheck()
		{
			Thread.Sleep( 2 * 1000 );
			if(GameObject.Find("Sheets/ServiceBrochure/PageFront/bg") != null)
			{
				GameObject.Find("Sheets/ServiceBrochure/PageFront/bg").GetComponent<MeshRenderer>().material.mainTexture = texture2;
				
				GameObject.Find("Sheets/ServiceBrochure/PageMisc/bg").GetComponent<MeshRenderer>().material.mainTexture = texture3;
				
				GameObject.Find("Sheets/ServiceBrochure/PageGearing/bg").GetComponent<MeshRenderer>().material.mainTexture = texture4;
				
				GameObject.Find("Sheets/ServiceBrochure/PageMetalwork/bg").GetComponent<MeshRenderer>().material.mainTexture = texture5;
				
				GameObject.Find("Sheets/ServiceBrochure/PagePaintCar/bg").GetComponent<MeshRenderer>().material.mainTexture = texture6;
				
				GameObject.Find("Sheets/ServiceBrochure/PagePaintRims/bg").GetComponent<MeshRenderer>().material.mainTexture = texture7;
				
				GameObject.Find("Sheets/ServiceBrochure/Background").GetComponent<MeshRenderer>().material.mainTexture = texture8;
				
				GameObject.Find("Sheets/ServiceBrochure/PageTirejob/bg").GetComponent<MeshRenderer>().material.mainTexture = texture9;
			}
			else
			{
				RepairCheck();
			}
		}
		
		private void InspectCheck()
		{
			Thread.Sleep( 2 * 1000 );
			if(GameObject.Find("Sheets/InspectionRecipiet/Background_FI") != null)
			{
				GameObject.Find("Sheets/InspectionRecipiet/Background_FI").GetComponent<MeshRenderer>().material.mainTexture = texture10;
				
				GameObject.Find("Sheets/InspectionRecipiet/Background_EN").GetComponent<MeshRenderer>().material.mainTexture = texture11;
				
				GameObject.Find("Sheets/InspectionRecipiet/Checkmarks/ResultFail").GetComponent<MeshRenderer>().material.mainTexture = texture12;
				
				GameObject.Find("Sheets/InspectionRecipiet/Checkmarks/ResultPass").GetComponent<MeshRenderer>().material.mainTexture = texture13;
			}
			else
			{
				InspectCheck();
			}
		}
    }
}
