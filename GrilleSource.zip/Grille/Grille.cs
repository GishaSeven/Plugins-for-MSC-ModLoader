﻿using MSCLoader;
using UnityEngine;
using System.Collections;

namespace Grille
{
    public class Grille : Mod
    {
        public override string ID { get { return "Grille"; } }
        public override string Name { get { return "Grille"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject GRILLE;
		private string path = ModLoader.ModsFolder+@"\Grille\";
		
        public override void Update()
        {
            if (Application.loadedLevelName == "GAME" && !loaded)
            {
				GRILLE = GameObject.Find("grille(Clone)");
							
				ObjImporter objimporter = new ObjImporter();
				Mesh new_mesh0 = new Mesh();
				new_mesh0 = objimporter.ImportFile(path + "grille.obj");
				
				GRILLE.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				
				GRILLE.transform.GetComponent<Renderer>().materials[1].color = new Color(0f, 0f, 0f, 0f);
										
				loaded = true;
            }
			
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
    }
}
