﻿using System;
using System.IO;
using MSCLoader;
using UnityEngine;
using System.Threading;
using HutongGames.PlayMaker;

namespace ClearanceTool
{
    public class ClearanceTool : Mod
    {
        public override string ID { get { return "ClearanceTool"; } }
        public override string Name { get { return "Clearance Tool"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "2.0.1"; } }
		
		private bool loaded;
		private bool loadedsettings;
		private bool guiShow;
		private GameObject SATSUMA;
		private GameObject WHEELRR;
		private GameObject WHEELRL;
		private GameObject WHEELFR;
		private GameObject WHEELFL;
		private float ScalePlus;
		private float ScaleMinus;
		private string path = ModLoader.ModsFolder;
		private Rect guiBox = new Rect((Screen.width-400)/2, 10f, 400f, 310f);
		private Keybind ToolGuiKey = new Keybind("ShowGUI", "Show GUI", KeyCode.F4);
		
        public override void OnLoad()
        {
            Keybind.Add(this, ToolGuiKey);
        }
		
		public override void OnGUI()
		{
			if (guiShow)
			{
				GUI.ModalWindow(1, this.guiBox, new GUI.WindowFunction(this.Window), "Clearance Tool");
			}
		}

        public override void Update()
        {
			if (ToolGuiKey.IsDown()) { GuiShow(); };
			
			if (Application.loadedLevelName == "GAME" && !loaded)
            {
				this.SATSUMA = GameObject.Find("SATSUMA(557kg)");
				this.WHEELFL = this.SATSUMA.transform.FindChild("wheelFL").gameObject;
				this.WHEELFR = this.SATSUMA.transform.FindChild("wheelFR").gameObject;
				this.WHEELRL = this.SATSUMA.transform.FindChild("wheelRL").gameObject;
				this.WHEELRR = this.SATSUMA.transform.FindChild("wheelRR").gameObject;
				this.ScalePlus = 0.001f;
				this.ScaleMinus = -0.001f;
                loaded = true;
            }
			
			if (loaded && !loadedsettings)
            {
				new Thread(waiting).Start();
				loadedsettings = true;
			}
			
            if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
				loadedsettings = false;
            }
        }
		
		private void waiting()
		{
			Thread.Sleep( 10 * 1000 );
			loadsettings();
		}
		
		private void GuiShow()
		{
			this.guiShow = !this.guiShow;
			
			if(guiShow)
			{
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = true;
			}
			else
			{
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
			}
		}
		
		private void Window(int windowId)
		{
			bool flag0 = GUI.Button(new Rect(150f, 270f, 100f, 30f), "Close");
			if (flag0)
			{
				GuiShow();
			}
			GUI.Label(new Rect(15f, 25f, 120f, 30f), "Front wheels");
			bool flag1 = GUI.RepeatButton(new Rect(15f, 50f, 70f, 30f), "Level -");
			if (flag1)
			{
				front_level_minus();
			}
			bool flag2 = GUI.RepeatButton(new Rect(85f, 50f, 70f, 30f), "Level +");
			if (flag2)
			{
				front_level_plus();
			}
			GUI.Label(new Rect(160f, 55f, 80f, 30f), this.WHEELFL.transform.localPosition.y.ToString());
			bool flag3 = GUI.RepeatButton(new Rect(15f, 80f, 70f, 30f), "Offset -");
			if (flag3)
			{
				front_offset_minus();
			}
			bool flag4 = GUI.RepeatButton(new Rect(85f, 80f, 70f, 30f), "Offset +");
			if (flag4)
			{
				front_offset_plus();
			}
			GUI.Label(new Rect(160f, 85f, 80f, 30f), this.WHEELFL.transform.localPosition.x.ToString());
			bool flag5 = GUI.RepeatButton(new Rect(15f, 110f, 70f, 30f), "Camber -");
			if (flag5)
			{
				front_camber_minus();
			}
			bool flag6 = GUI.RepeatButton(new Rect(85f, 110f, 70f, 30f), "Camber +");
			if (flag6)
			{
				front_camber_plus();
			}
			GUI.Label(new Rect(160f, 115f, 80f, 30f), this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.camber.ToString());
			GUI.Label(new Rect(15f, 145f, 120f, 30f), "Rear wheels");
			bool flag7 = GUI.RepeatButton(new Rect(15f, 170f, 70f, 30f), "Level -");
			if (flag7)
			{
				rear_level_minus();
			}
			bool flag8 = GUI.RepeatButton(new Rect(85f, 170f, 70f, 30f), "Level +");
			if (flag8)
			{
				rear_level_plus();
			}
			GUI.Label(new Rect(160f, 175f, 80f, 30f), this.WHEELRL.transform.localPosition.y.ToString());
			bool flag9 = GUI.RepeatButton(new Rect(15f, 200f, 70f, 30f), "Offset -");
			if (flag9)
			{
				rear_offset_minus();
			}
			bool flag10 = GUI.RepeatButton(new Rect(85f, 200f, 70f, 30f), "Offset +");
			if (flag10)
			{
				rear_offset_plus();
			}
			GUI.Label(new Rect(160f, 205f, 80f, 30f), this.WHEELRL.transform.localPosition.x.ToString());
			bool flag11 = GUI.RepeatButton(new Rect(15f, 230f, 70f, 30f), "Camber -");
			if (flag11)
			{
				rear_camber_minus();
			}
			bool flag12 = GUI.RepeatButton(new Rect(85f, 230f, 70f, 30f), "Camber +");
			if (flag12)
			{
				rear_camber_plus();
			}
			GUI.Label(new Rect(160f, 235f, 80f, 30f), this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.camber.ToString());
			GUI.Label(new Rect(245f, 25f, 120f, 30f), "All wheels");
			bool flag13 = GUI.RepeatButton(new Rect(245f, 50f, 70f, 30f), "Level -");
			if (flag13)
			{
				front_level_minus();
				rear_level_minus();
				
			}
			bool flag14 = GUI.RepeatButton(new Rect(315f, 50f, 70f, 30f), "Level +");
			if (flag14)
			{
				front_level_plus();
				rear_level_plus();
			}
			bool flag15 = GUI.RepeatButton(new Rect(245f, 80f, 70f, 30f), "Offset -");
			if (flag15)
			{
				front_offset_minus();
				rear_offset_minus();
			}
			bool flag16 = GUI.RepeatButton(new Rect(315f, 80f, 70f, 30f), "Offset +");
			if (flag16)
			{
				front_offset_plus();
				rear_offset_plus();
			}
			bool flag17 = GUI.RepeatButton(new Rect(245f, 110f, 70f, 30f), "Camber -");
			if (flag17)
			{
				front_camber_minus();
				rear_camber_minus();
			}
			bool flag18 = GUI.RepeatButton(new Rect(315f, 110f, 70f, 30f), "Camber +");
			if (flag18)
			{
				front_camber_plus();
				rear_camber_plus();
			}
			bool flag19 = GUI.Button(new Rect(245f, 170f, 140f, 30f), "Reset to default");
			if (flag19)
			{
				resetsettings();
			}
			bool flag20 = GUI.Button(new Rect(245f, 200f, 140f, 30f), "Save settings");
			if (flag20)
			{
				savesettings();
			}
			bool flag21 = GUI.Button(new Rect(245f, 230f, 140f, 30f), "Load settings");
			if (flag21)
			{
				loadsettings();
			}
			GUI.DragWindow();
		}
		
		private void resetsettings()
		{
			if (this.SATSUMA)
			{
				PlayMakerFSM[] componentsInChildren = this.SATSUMA.GetComponentsInChildren<PlayMakerFSM>();
				for (int i = 0; i < componentsInChildren.Length; i++)
				{
					PlayMakerFSM playMakerFSM = componentsInChildren[i];
					if (playMakerFSM.name == "Suspension")
					{
						playMakerFSM.enabled = true;
					}
				}
			}
			
			this.WHEELFL.transform.localPosition = new Vector3(-0.63f, -0.17f, this.WHEELFL.transform.localPosition.z);
			this.WHEELFR.transform.localPosition = new Vector3(0.63f, -0.17f, this.WHEELFR.transform.localPosition.z);
			this.WHEELRL.transform.localPosition = new Vector3(-0.6029996f, -0.17f, this.WHEELRL.transform.localPosition.z);
			this.WHEELRR.transform.localPosition = new Vector3(0.6029996f, -0.17f, this.WHEELRR.transform.localPosition.z);
			this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.camber = -1.4f;
			this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.camber = 1.4f;
			this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.camber = 0f;
			this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.camber = 0f;
		}
		
		private void savesettings()
		{
			string[] array = new string[6];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = this.WHEELFL.transform.localPosition.y;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = this.WHEELFL.transform.localPosition.x;
			arg_12_0[arg_12_1] = num2.ToString();
			
			array[2] = this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.camber.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 3;
			float num3 = this.WHEELRL.transform.localPosition.y;
			arg_13_0[arg_13_1] = num3.ToString();
			
			string[] arg_14_0 = array;
			int arg_14_1 = 4;
			float num4 = this.WHEELRL.transform.localPosition.x;
			arg_14_0[arg_14_1] = num4.ToString();
			
			array[5] = this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.camber.ToString();
			
			Directory.CreateDirectory(path + "/ClearanceTool/");
			File.WriteAllLines(path + "/ClearanceTool/Satsuma.txt", array);
		}
		
		private void loadsettings()
		{
			if (this.SATSUMA)
			{
				PlayMakerFSM[] componentsInChildren = this.SATSUMA.GetComponentsInChildren<PlayMakerFSM>();
				for (int i = 0; i < componentsInChildren.Length; i++)
				{
					PlayMakerFSM playMakerFSM = componentsInChildren[i];
					if (playMakerFSM.name == "Suspension")
					{
						playMakerFSM.enabled = false;
					}
				}
			}
			
			string[] array = new string[6];
			if (File.Exists(path + "/ClearanceTool/Satsuma.txt"))
			{
				array = File.ReadAllLines(path + "/ClearanceTool/Satsuma.txt");
				
				this.WHEELFL.transform.localPosition = new Vector3(float.Parse(array[1]), float.Parse(array[0]), this.WHEELFL.transform.localPosition.z);
				this.WHEELFR.transform.localPosition = new Vector3(-float.Parse(array[1]), float.Parse(array[0]), this.WHEELFR.transform.localPosition.z);
				this.WHEELRL.transform.localPosition = new Vector3(float.Parse(array[4]), float.Parse(array[3]), this.WHEELRL.transform.localPosition.z);
				this.WHEELRR.transform.localPosition = new Vector3(-float.Parse(array[4]), float.Parse(array[3]), this.WHEELRL.transform.localPosition.z);
				
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.camber = float.Parse(array[2]);
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.camber = -float.Parse(array[2]);
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.camber = float.Parse(array[5]);
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.camber = -float.Parse(array[5]);
			}
		}
		
		private void front_level_minus()
		{
			this.WHEELFL.transform.localPosition = new Vector3(this.WHEELFL.transform.localPosition.x, this.WHEELFL.transform.localPosition.y - this.ScaleMinus, this.WHEELFL.transform.localPosition.z);
			this.WHEELFR.transform.localPosition = new Vector3(this.WHEELFR.transform.localPosition.x, this.WHEELFR.transform.localPosition.y - this.ScaleMinus, this.WHEELFR.transform.localPosition.z);
		}
		
		private void front_level_plus()
		{
			this.WHEELFL.transform.localPosition = new Vector3(this.WHEELFL.transform.localPosition.x, this.WHEELFL.transform.localPosition.y - this.ScalePlus, this.WHEELFL.transform.localPosition.z);
			this.WHEELFR.transform.localPosition = new Vector3(this.WHEELFR.transform.localPosition.x, this.WHEELFR.transform.localPosition.y - this.ScalePlus, this.WHEELFR.transform.localPosition.z);
		}
		
		private void front_offset_minus()
		{
			this.WHEELFL.transform.localPosition = new Vector3(this.WHEELFL.transform.localPosition.x - this.ScaleMinus, this.WHEELFL.transform.localPosition.y, this.WHEELFL.transform.localPosition.z);
			this.WHEELFR.transform.localPosition = new Vector3(this.WHEELFR.transform.localPosition.x + this.ScaleMinus, this.WHEELFR.transform.localPosition.y, this.WHEELFR.transform.localPosition.z);
		}
		
		private void front_offset_plus()
		{
			this.WHEELFL.transform.localPosition = new Vector3(this.WHEELFL.transform.localPosition.x - this.ScalePlus, this.WHEELFL.transform.localPosition.y, this.WHEELFL.transform.localPosition.z);
			this.WHEELFR.transform.localPosition = new Vector3(this.WHEELFR.transform.localPosition.x + this.ScalePlus, this.WHEELFR.transform.localPosition.y, this.WHEELFR.transform.localPosition.z);
		}
		
		private void front_camber_minus()
		{
			this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.camber -= 0.05f;
			this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.camber += 0.05f;
		}
		
		private void front_camber_plus()
		{
			this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.camber += 0.05f;
			this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.camber -= 0.05f;
		}
		
		private void rear_level_minus()
		{
			this.WHEELRL.transform.localPosition = new Vector3(this.WHEELRL.transform.localPosition.x, this.WHEELRL.transform.localPosition.y - this.ScaleMinus, this.WHEELRL.transform.localPosition.z);
			this.WHEELRR.transform.localPosition = new Vector3(this.WHEELRR.transform.localPosition.x, this.WHEELRR.transform.localPosition.y - this.ScaleMinus, this.WHEELRR.transform.localPosition.z);
		}
		
		private void rear_level_plus()
		{
			this.WHEELRL.transform.localPosition = new Vector3(this.WHEELRL.transform.localPosition.x, this.WHEELRL.transform.localPosition.y - this.ScalePlus, this.WHEELRL.transform.localPosition.z);
			this.WHEELRR.transform.localPosition = new Vector3(this.WHEELRR.transform.localPosition.x, this.WHEELRR.transform.localPosition.y - this.ScalePlus, this.WHEELRR.transform.localPosition.z);
		}
		
		private void rear_offset_minus()
		{
			this.WHEELRL.transform.localPosition = new Vector3(this.WHEELRL.transform.localPosition.x - this.ScaleMinus, this.WHEELRL.transform.localPosition.y, this.WHEELRL.transform.localPosition.z);
			this.WHEELRR.transform.localPosition = new Vector3(this.WHEELRR.transform.localPosition.x + this.ScaleMinus, this.WHEELRR.transform.localPosition.y, this.WHEELRR.transform.localPosition.z);
		}
		
		private void rear_offset_plus()
		{
			this.WHEELRL.transform.localPosition = new Vector3(this.WHEELRL.transform.localPosition.x - this.ScalePlus, this.WHEELRL.transform.localPosition.y, this.WHEELRL.transform.localPosition.z);
			this.WHEELRR.transform.localPosition = new Vector3(this.WHEELRR.transform.localPosition.x + this.ScalePlus, this.WHEELRR.transform.localPosition.y, this.WHEELRR.transform.localPosition.z);
		}
		
		private void rear_camber_minus()
		{
			this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.camber -= 0.05f;
			this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.camber += 0.05f;
		}
		
		private void rear_camber_plus()
		{
			this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.camber += 0.05f;
			this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.camber -= 0.05f;
		}
    }
}
