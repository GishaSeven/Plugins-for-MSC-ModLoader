﻿using System;
using UnityEngine;
using System.Collections.Generic;

namespace SecondFerndale
{
    public class SaveData
    {
		public List<SaveDataList> save = new List<SaveDataList>();
    }
}
