﻿using System;
using System.IO;
using MSCLoader;
using UnityEngine;
using HutongGames.PlayMaker;

namespace Paint
{
    public class Paint : Mod
    {
        public override string ID => "Paint";
        public override string Name => "Paint";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";

        public override bool UseAssetsFolder => true;
		
		private bool GUI1;
		private bool GUI2;
		private bool BODY;
		private bool DOORL;
		private bool DOORR;
		private bool FENDERL;
		private bool FENDERR;
		private bool HOOD;
		private bool BOOTLID;
		private bool FIBERHOOD;
		private bool FLARESPOILER;
		private bool FLAREFL;
		private bool FLAREFR;
		private bool FLARERL;
		private bool FLARERR;
		private bool FSPOILER;
		private bool SPOILER;
		private bool SPOILER2;
		private bool GRILLE;
		private bool ROLL;
		private float r;
		private float g;
		private float b;
		private string path;
		private Rect gui1box = new Rect((Screen.width-270)/2, 10f, 270f, 620f);
		private Rect gui2box = new Rect((Screen.width-530)/2, 10f, 530f, 185f);
		private Keybind opengui = new Keybind("OpenGUI", "Open GUI", KeyCode.C, KeyCode.RightControl);

		public override void OnLoad()
        {				
			Keybind.Add(this, opengui);
			
			path = ModLoader.GetModAssetsFolder(this);
			
			r = 0f;
			g = 0f;
			b = 0f;
        }
		
		public override void Update()
        {
            if(opengui.IsDown()) { GuiShow(); };
			
			if(GUI2)
			{
				if(BODY)
				{
					GameObject.Find("car body(xxxxx)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(DOORL)
				{
					GameObject.Find("door left(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(DOORR)
				{
					GameObject.Find("door right(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(FENDERL)
				{
					GameObject.Find("fender left(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(FENDERR)
				{
					GameObject.Find("fender right(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(HOOD)
				{
					GameObject.Find("hood(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(BOOTLID)
				{
					GameObject.Find("bootlid(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(FIBERHOOD)
				{
					GameObject.Find("fiberglass hood(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(FLARESPOILER)
				{
					GameObject.Find("fender flare spoiler(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(FLAREFL)
				{
					GameObject.Find("fender flare fl(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(FLAREFR)
				{
					GameObject.Find("fender flare fr(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(FLARERL)
				{
					GameObject.Find("fender flare rl(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(FLARERR)
				{
					GameObject.Find("fender flare rr(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(FSPOILER)
				{
					GameObject.Find("front spoiler(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(SPOILER)
				{
					GameObject.Find("rear spoiler(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(SPOILER2)
				{
					GameObject.Find("rear spoiler2(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(GRILLE)
				{
					GameObject.Find("window grille(Clone)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
				
				if(ROLL)
				{
					GameObject.Find("roll cage(xxxxx)").transform.GetComponent<Renderer>().material.color = new Color(r, g, b, 1);
				}
			}
		}
		
		public override void OnGUI()
		{
			if(GUI1)
			{
				GUI.ModalWindow(1, this.gui1box, new GUI.WindowFunction(this.Window1), "Select parts to paint");
			}
			
			if(GUI2)
			{
				GUI.ModalWindow(1, this.gui2box, new GUI.WindowFunction(this.Window2), "Select color");
			}
		}
		
		private void GuiShow()
		{
			GUI1 = true;
			FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = true;
		}
		
		private void Window1(int windowId)
		{
			bool flag0 = GUI.Button(new Rect(135f, 585f, 120f, 30f), "Close");
			if (flag0)
			{
				GUI1 = false;
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
			}
			bool flag1 = GUI.Button(new Rect(15f, 585f, 120f, 30f), "Select color");
			if (flag1)
			{
				GUI1 = false;
				GUI2 = true;
			}
			bool flag2 = GUI.Button(new Rect(15f, 25f, 120f, 30f), "Body");
			if (flag2)
			{
				BODY = !BODY;
			}
			
			if(BODY)
			{
				GUI.Label(new Rect(135f, 30f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 30f, 120f, 30f), " NO");
			}
			
			bool flag3 = GUI.Button(new Rect(15f, 55f, 120f, 30f), "Door left");
			if (flag3)
			{
				DOORL = !DOORL;
			}
			
			if(DOORL)
			{
				GUI.Label(new Rect(135f, 60f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 60f, 120f, 30f), " NO");
			}
			
			bool flag4 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Door right");
			if (flag4)
			{
				DOORR = !DOORR;
			}
			
			if(DOORR)
			{
				GUI.Label(new Rect(135f, 90f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 90f, 120f, 30f), " NO");
			}
			
			bool flag5 = GUI.Button(new Rect(15f, 115f, 120f, 30f), "Fender left");
			if (flag5)
			{
				FENDERL = !FENDERL;
			}
			
			if(FENDERL)
			{
				GUI.Label(new Rect(135f, 120f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 120f, 120f, 30f), " NO");
			}
			
			bool flag6 = GUI.Button(new Rect(15f, 145f, 120f, 30f), "Fender right");
			if (flag6)
			{
				FENDERR = !FENDERR;
			}
			
			if(FENDERR)
			{
				GUI.Label(new Rect(135f, 150f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 150f, 120f, 30f), " NO");
			}
			
			bool flag7 = GUI.Button(new Rect(15f, 175f, 120f, 30f), "Hood");
			if (flag7)
			{
				HOOD = !HOOD;
			}
			
			if(HOOD)
			{
				GUI.Label(new Rect(135f, 180f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 180f, 120f, 30f), " NO");
			}
			
			bool flag8 = GUI.Button(new Rect(15f, 205f, 120f, 30f), "Boot lid");
			if (flag8)
			{
				BOOTLID = !BOOTLID;
			}
			
			if(BOOTLID)
			{
				GUI.Label(new Rect(135f, 210f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 210f, 120f, 30f), " NO");
			}
			
			bool flag9 = GUI.Button(new Rect(15f, 235f, 120f, 30f), "Fiberglass hood");
			if (flag9)
			{
				FIBERHOOD = !FIBERHOOD;
			}
			
			if(FIBERHOOD)
			{
				GUI.Label(new Rect(135f, 240f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 240f, 120f, 30f), " NO");
			}
			
			bool flag10 = GUI.Button(new Rect(15f, 265f, 120f, 30f), "Fender fl. spoiler");
			if (flag10)
			{
				FLARESPOILER = !FLARESPOILER;
			}
			
			if(FLARESPOILER)
			{
				GUI.Label(new Rect(135f, 270f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 270f, 120f, 30f), " NO");
			}
			
			bool flag11 = GUI.Button(new Rect(15f, 295f, 120f, 30f), "Fender flare FL");
			if (flag11)
			{
				FLAREFL = !FLAREFL;
			}
			
			if(FLAREFL)
			{
				GUI.Label(new Rect(135f, 300f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 300f, 120f, 30f), " NO");
			}
			
			bool flag12 = GUI.Button(new Rect(15f, 325f, 120f, 30f), "Fender flare FR");
			if (flag12)
			{
				FLAREFR = !FLAREFR;
			}
			
			if(FLAREFR)
			{
				GUI.Label(new Rect(135f, 330f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 330f, 120f, 30f), " NO");
			}
			
			bool flag13 = GUI.Button(new Rect(15f, 355f, 120f, 30f), "Fender flare RL");
			if (flag13)
			{
				FLARERL = !FLARERL;
			}
			
			if(FLARERL)
			{
				GUI.Label(new Rect(135f, 360f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 360f, 120f, 30f), " NO");
			}
			
			bool flag14 = GUI.Button(new Rect(15f, 385f, 120f, 30f), "Fender flare RR");
			if (flag14)
			{
				FLARERR = !FLARERR;
			}
			
			if(FLARERR)
			{
				GUI.Label(new Rect(135f, 390f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 390f, 120f, 30f), " NO");
			}
			
			bool flag15 = GUI.Button(new Rect(15f, 415f, 120f, 30f), "Front spoiler");
			if (flag15)
			{
				FSPOILER = !FSPOILER;
			}
			
			if(FSPOILER)
			{
				GUI.Label(new Rect(135f, 420f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 420f, 120f, 30f), " NO");
			}
			
			bool flag16 = GUI.Button(new Rect(15f, 445f, 120f, 30f), "Rear spoiler");
			if (flag16)
			{
				SPOILER = !SPOILER;
			}
			
			if(SPOILER)
			{
				GUI.Label(new Rect(135f, 450f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 450f, 120f, 30f), " NO");
			}
			
			bool flag17 = GUI.Button(new Rect(15f, 475f, 120f, 30f), "Rear spoiler 2");
			if (flag17)
			{
				SPOILER2 = !SPOILER2;
			}
			
			if(SPOILER2)
			{
				GUI.Label(new Rect(135f, 480f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 480f, 120f, 30f), " NO");
			}
			
			bool flag18 = GUI.Button(new Rect(15f, 505f, 120f, 30f), "Window grille");
			if (flag18)
			{
				GRILLE = !GRILLE;
			}
			
			if(GRILLE)
			{
				GUI.Label(new Rect(135f, 510f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 510f, 120f, 30f), " NO");
			}
			
			bool flag19 = GUI.Button(new Rect(15f, 535f, 120f, 30f), "Roll cage");
			if (flag19)
			{
				ROLL = !ROLL;
			}
			
			if(ROLL)
			{
				GUI.Label(new Rect(135f, 540f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 540f, 120f, 30f), " NO");
			}
			GUI.DragWindow();
		}
		
		private void Window2(int windowId)
		{
			GUI.Label(new Rect(15f, 25f, 300f, 30f), "Color code: " + r + ", " + g + ", " + b);
			bool flag0 = GUI.Button(new Rect(355f, 150f, 160f, 30f), "Close");
			if (flag0)
			{
				GUI2 = false;
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
			}
			bool flag1 = GUI.Button(new Rect(15f, 50f, 80f, 30f), "red ---");
			if (flag1)
			{
				if(r > 0.1f)
				{
					r = r - 0.1f;
				}
				else
				{
					r = 0f;
				}
			}
			bool flag2 = GUI.Button(new Rect(95f, 50f, 80f, 30f), "red +++");
			if (flag2)
			{
				if(r < 0.9f)
				{
					r = r + 0.1f;
				}
				else
				{
					r = 1f;
				}
			}
			bool flag3 = GUI.Button(new Rect(15f, 80f, 80f, 30f), "red --");
			if (flag3)
			{
				if(r > 0.01f)
				{
					r = r - 0.01f;
				}
				else
				{
					r = 0f;
				}
			}
			bool flag4 = GUI.Button(new Rect(95f, 80f, 80f, 30f), "red ++");
			if (flag4)
			{
				if(r < 0.99f)
				{
					r = r + 0.01f;
				}
				else
				{
					r = 1f;
				}
			}
			bool flag5 = GUI.Button(new Rect(15f, 110f, 80f, 30f), "red -");
			if (flag5)
			{
				if(r > 0.001f)
				{
					r = r - 0.001f;
				}
				else
				{
					r = 0f;
				}
			}
			bool flag6 = GUI.Button(new Rect(95f, 110f, 80f, 30f), "red +");
			if (flag6)
			{
				if(r < 0.999f)
				{
					r = r + 0.001f;
				}
				else
				{
					r = 1f;
				}
			}
			bool flag7 = GUI.Button(new Rect(185f, 50f, 80f, 30f), "green ---");
			if (flag7)
			{
				if(g > 0.1f)
				{
					g = g - 0.1f;
				}
				else
				{
					g = 0f;
				}
			}
			bool flag8 = GUI.Button(new Rect(265f, 50f, 80f, 30f), "green +++");
			if (flag8)
			{
				if(g < 0.9f)
				{
					g = g + 0.1f;
				}
				else
				{
					g = 1f;
				}
			}
			bool flag9 = GUI.Button(new Rect(185f, 80f, 80f, 30f), "green --");
			if (flag9)
			{
				if(g > 0.01f)
				{
					g = g - 0.01f;
				}
				else
				{
					g = 0f;
				}
			}
			bool flag10 = GUI.Button(new Rect(265f, 80f, 80f, 30f), "green ++");
			if (flag10)
			{
				if(g < 0.99f)
				{
					g = g + 0.01f;
				}
				else
				{
					g = 1f;
				}
			}
			bool flag11 = GUI.Button(new Rect(185f, 110f, 80f, 30f), "green -");
			if (flag11)
			{
				if(g > 0.001f)
				{
					g = g - 0.001f;
				}
				else
				{
					g = 0f;
				}
			}
			bool flag12 = GUI.Button(new Rect(265f, 110f, 80f, 30f), "green +");
			if (flag12)
			{
				if(g < 0.999f)
				{
					g = g + 0.001f;
				}
				else
				{
					g = 1f;
				}
			}
			bool flag13 = GUI.Button(new Rect(355f, 50f, 80f, 30f), "blue ---");
			if (flag13)
			{
				if(b > 0.1f)
				{
					b = b - 0.1f;
				}
				else
				{
					b = 0f;
				}
			}
			bool flag14 = GUI.Button(new Rect(435f, 50f, 80f, 30f), "blue +++");
			if (flag14)
			{
				if(b < 0.9f)
				{
					b = b + 0.1f;
				}
				else
				{
					b = 1f;
				}
			}
			bool flag15 = GUI.Button(new Rect(355f, 80f, 80f, 30f), "blue --");
			if (flag15)
			{
				if(b > 0.01f)
				{
					b = b - 0.01f;
				}
				else
				{
					b = 0f;
				}
			}
			bool flag16 = GUI.Button(new Rect(435f, 80f, 80f, 30f), "blue ++");
			if (flag16)
			{
				if(b < 0.99f)
				{
					b = b + 0.01f;
				}
				else
				{
					b = 1f;
				}
			}
			bool flag17 = GUI.Button(new Rect(355f, 110f, 80f, 30f), "blue -");
			if (flag17)
			{
				if(b > 0.001f)
				{
					b = b - 0.001f;
				}
				else
				{
					b = 0f;
				}
			}
			bool flag18 = GUI.Button(new Rect(435f, 110f, 80f, 30f), "blue +");
			if (flag18)
			{
				if(b < 0.999f)
				{
					b = b + 0.001f;
				}
				else
				{
					b = 1f;
				}
			}
			bool flag19 = GUI.Button(new Rect(185f, 150f, 160f, 30f), "Load from file");
			if (flag19)
			{
				loadsettings();
			}
			bool flag20 = GUI.Button(new Rect(15f, 150f, 160f, 30f), "Save to file");
			if (flag20)
			{
				savesettings();
			}
			GUI.DragWindow();
		}
		
		private void savesettings()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = r;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = g;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = b;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/Color.txt", array);
		}
		
		private void loadsettings()
		{
			string[] array = new string[3];
			if (File.Exists(path + "/Color.txt"))
			{
				array = File.ReadAllLines(path + "/Color.txt");
				
				r = float.Parse(array[0]);
				g = float.Parse(array[1]);
				b = float.Parse(array[2]);
			}
		}
    }
}
