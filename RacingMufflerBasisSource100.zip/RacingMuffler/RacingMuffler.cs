﻿using MSCLoader;
using System.Linq;
using UnityEngine;

namespace RacingMuffler
{
    public class RacingMuffler : Mod
    {
        public override string ID => "RacingMuffler";
        public override string Name => "Racing muffler";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";

        public override bool UseAssetsFolder => true;
		
		public override void OnLoad()
        {			
			GameObject newmuffler = LoadAssets.LoadOBJ(this, "racingmuffler.obj");
			Object.Destroy(newmuffler.GetComponent<MeshCollider>());
			AssetBundle bundle = LoadAssets.LoadBundle(this,"material.unity3d");
			Material metallic = bundle.LoadAsset<Material>("MyMetallicMaterial.mat");
			
			foreach (GameObject muffler in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "racing muffler(Clone)" && g.GetComponent<MeshFilter>() !=null))
            {
				newmuffler.transform.parent = muffler.transform;
				newmuffler.transform.localPosition = Vector3.zero;
				newmuffler.transform.localEulerAngles = Vector3.zero;
				newmuffler.transform.localScale = Vector3.one;
				newmuffler.GetComponent<MeshRenderer>().material = metallic;
				Object.Destroy(muffler.GetComponent<MeshRenderer>());
            }
			
			bundle.Unload(false); 
        }
    }
}
