﻿using MSCLoader;
using System.Linq;
using UnityEngine;

namespace RacingInteriorBasis
{
    public class RacingInteriorBasis : Mod
    {
        public override string ID => "RacingInteriorBasis";
        public override string Name => "Racing Interior Basis";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";

        public override bool UseAssetsFolder => true;
		
		public override void OnLoad()
        {			
			//Chrome material
			AssetBundle bundle = LoadAssets.LoadBundle(this,"material.unity3d");
			Material metallic = bundle.LoadAsset<Material>("MyMetallicMaterial.mat");
			bundle.Unload(false); 
			
			//Bucket seats
			Mesh bucketmesh = LoadAssets.LoadOBJMesh(this, "racing_seat.obj");
			Texture2D buckettexture = LoadAssets.LoadTexture(this, "racing_seat.dds");
			
			foreach (GameObject bucket in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "bucket seat driver(Clone)" && g.GetComponent<MeshFilter>() !=null))
            {
				bucket.GetComponent<MeshFilter>().sharedMesh = bucketmesh;
				bucket.GetComponent<MeshRenderer>().material.mainTexture = buckettexture;
				GameObject bucketchromego = LoadAssets.LoadOBJ(this, "racing_seat_chrome.obj");
				Object.Destroy(bucketchromego.GetComponent<MeshCollider>());
				bucketchromego.transform.parent = bucket.transform;
				bucketchromego.transform.localPosition = Vector3.zero;
				bucketchromego.transform.localEulerAngles = Vector3.zero;
				bucketchromego.transform.localScale = Vector3.one;
				bucketchromego.GetComponent<MeshRenderer>().material = metallic;
            }
			
			foreach (GameObject bucket in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "bucket seat passenger(Clone)" && g.GetComponent<MeshFilter>() !=null))
            {
				bucket.GetComponent<MeshFilter>().sharedMesh = bucketmesh;
				bucket.GetComponent<MeshRenderer>().material.mainTexture = buckettexture;
				GameObject bucketchromego = LoadAssets.LoadOBJ(this, "racing_seat_chrome.obj");
				Object.Destroy(bucketchromego.GetComponent<MeshCollider>());
				bucketchromego.transform.parent = bucket.transform;
				bucketchromego.transform.localPosition = Vector3.zero;
				bucketchromego.transform.localEulerAngles = Vector3.zero;
				bucketchromego.transform.localScale = Vector3.one;
				bucketchromego.GetComponent<MeshRenderer>().material = metallic;
            }
			
			//Harness
			Mesh harnessopenmesh = LoadAssets.LoadOBJMesh(this, "racing_harness_open.obj");
			Mesh harnessclosedmesh = LoadAssets.LoadOBJMesh(this, "racing_harness_closed.obj");
			Texture2D harnesstexture = LoadAssets.LoadTexture(this, "racing_harness.dds");
			
			foreach (GameObject harness in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "racing harness(xxxxx)" && g.GetComponent<PlayMakerFSM>() !=null))
            {
				harness.transform.Find("Open").gameObject.GetComponent<MeshFilter>().sharedMesh = harnessopenmesh;
				harness.transform.Find("Open").gameObject.GetComponent<MeshRenderer>().material.mainTexture = harnesstexture;
				GameObject harnesschromego = LoadAssets.LoadOBJ(this, "racing_harness_open_chrome.obj");
				Object.Destroy(harnesschromego.GetComponent<MeshCollider>());
				harnesschromego.transform.parent = harness.transform.Find("Open").gameObject.transform;
				harnesschromego.transform.localPosition = Vector3.zero;
				harnesschromego.transform.localEulerAngles = Vector3.zero;
				harnesschromego.transform.localScale = Vector3.one;
				harnesschromego.GetComponent<MeshRenderer>().material = metallic;
				
				harness.transform.Find("Close").gameObject.GetComponent<MeshFilter>().sharedMesh = harnessclosedmesh;
				harness.transform.Find("Close").gameObject.GetComponent<MeshRenderer>().material.mainTexture = harnesstexture;
				GameObject harnesschromego2 = LoadAssets.LoadOBJ(this, "racing_harness_closed_chrome.obj");
				Object.Destroy(harnesschromego2.GetComponent<MeshCollider>());
				harnesschromego2.transform.parent = harness.transform.Find("Close").gameObject.transform;
				harnesschromego2.transform.localPosition = Vector3.zero;
				harnesschromego2.transform.localEulerAngles = Vector3.zero;
				harnesschromego2.transform.localScale = Vector3.one;
				harnesschromego2.GetComponent<MeshRenderer>().material = metallic;
            }
			
			//Roll cage
			Mesh rollmesh = LoadAssets.LoadOBJMesh(this, "rollbar.obj");
			
			foreach (GameObject roll in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "roll cage(xxxxx)" && g.GetComponent<PlayMakerFSM>() !=null))
            {
				roll.GetComponent<MeshFilter>().sharedMesh = rollmesh;
				GameObject rollchromego = LoadAssets.LoadOBJ(this, "rollbar_chrome.obj");
				Object.Destroy(rollchromego.GetComponent<MeshCollider>());
				rollchromego.transform.parent = roll.transform;
				rollchromego.transform.localPosition = Vector3.zero;
				rollchromego.transform.localEulerAngles = Vector3.zero;
				rollchromego.transform.localScale = Vector3.one;
				rollchromego.GetComponent<MeshRenderer>().material = metallic;
			}
        }
    }
}
