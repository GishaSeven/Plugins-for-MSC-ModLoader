using MSCLoader;
using UnityEngine;
using HutongGames.PlayMaker;


namespace Pause
{
    public class Pause : Mod
    {
        public override string ID { get { return "Pause"; } }
        public override string Name { get { return "Pause"; } }
        public override string Author { get { return "Roman266(fix by mads232)"; } }
        public override string Version { get { return "1.0.3"; } }

        private bool isPaused;
        private float timing;
        private bool needs;
        private float originalFatigue;
        private float originalDirtiness;
        private float originalDrunk;
        private float originalHunger;
        private float originalThirst;
        private float originalUrine;

        private Keybind pauseKey = new Keybind("PauseKey", "Pause", KeyCode.Pause);

        public override void OnLoad()
        {
            Keybind.Add(this, pauseKey);
        }

        public override void Update()
        {
            if (pauseKey.IsDown())
            {
                Pause1();

                if (isPaused == true)
                {
                    timing = 0;
					
					FsmVariables.GlobalVariables.FindFsmBool("PlayerStop").Value = true;
					FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = true;
                }
                else if (isPaused == false)
                {
                    timing = 1;
					
					FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
					
                    if (FsmVariables.GlobalVariables.FindFsmString("PlayerCurrentVehicle").Value == "")
                    {
                        FsmVariables.GlobalVariables.FindFsmBool("PlayerStop").Value = false;
                    }
                }

                Time.timeScale = timing;


                if (needs)
                {
                    FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value = 0.0f;
                    FsmVariables.GlobalVariables.FindFsmFloat("PlayerDirtiness").Value = 0.0f;
                    FsmVariables.GlobalVariables.FindFsmFloat("PlayerDrunk").Value = 0.0f;
                    FsmVariables.GlobalVariables.FindFsmFloat("PlayerHunger").Value = 0.0f;
                    FsmVariables.GlobalVariables.FindFsmFloat("PlayerThirst").Value = 0.0f;
                    FsmVariables.GlobalVariables.FindFsmFloat("PlayerUrine").Value = 0.0f;
                }
            }
        }

        private void Pause1()
        {
            this.isPaused = !this.isPaused;

            if (isPaused == true)
            {
                this.originalFatigue = FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value;
                this.originalDirtiness = FsmVariables.GlobalVariables.FindFsmFloat("PlayerDirtiness").Value;
                this.originalDrunk = FsmVariables.GlobalVariables.FindFsmFloat("PlayerDrunk").Value;
                this.originalHunger = FsmVariables.GlobalVariables.FindFsmFloat("PlayerHunger").Value;
                this.originalThirst = FsmVariables.GlobalVariables.FindFsmFloat("PlayerThirst").Value;
                this.originalUrine = FsmVariables.GlobalVariables.FindFsmFloat("PlayerUrine").Value;
                this.needs = true;
            }
            else if (isPaused == false)
            {
                FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value = this.originalFatigue;
                FsmVariables.GlobalVariables.FindFsmFloat("PlayerDirtiness").Value = this.originalDirtiness;
                FsmVariables.GlobalVariables.FindFsmFloat("PlayerDrunk").Value = this.originalDrunk;
                FsmVariables.GlobalVariables.FindFsmFloat("PlayerHunger").Value = this.originalHunger;
                FsmVariables.GlobalVariables.FindFsmFloat("PlayerThirst").Value = this.originalThirst;
                FsmVariables.GlobalVariables.FindFsmFloat("PlayerUrine").Value = this.originalUrine;
                this.needs = false;
            }
        }

        public override void OnGUI()
        {
            GUIStyle myStyle = new GUIStyle();
            myStyle.fontSize = (int)(40.0f * (float)(Screen.width) / 1000f);
            myStyle.normal.textColor = Color.red;

            if (isPaused)
            {
                GUI.Label(new Rect((Screen.width - 230) / 2, (Screen.height - 100) / 2, Screen.width, Screen.height), "PAUSED", myStyle);
            }
        }
    }
}