﻿using MSCLoader;
using UnityEngine;

namespace SpeedPower
{
    public class SpeedPower : Mod
    {
        public override string ID => "SpeedPower";
		public override string Name => "Speed Power";
		public override string Author => "Roman266";
		public override string Version => "1.0.5";
		public override string Description => "Show current RPM, speed, max power, max torque and mass of Satsuma.";
		
        private bool isShow;
		private bool isPower;
		private Drivetrain SatDrivetr;
		private Rigidbody SatRigidb;
		
		private Keybind show2Key = new Keybind("ShowSpeed", "Show Satsuma speed", KeyCode.F6);
		private Keybind show3Key = new Keybind("ShowPower", "Show Satsuma power", KeyCode.F5);
		
		public override void OnLoad()
        {
            SatDrivetr = GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Drivetrain>();
			SatRigidb = GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Rigidbody>();
			
			Keybind.Add(this, show2Key);
			Keybind.Add(this, show3Key);
        }
		
        public override void Update()
        {
			if (show2Key.GetKeybindDown()) { ShowStat(); };
			if (show3Key.GetKeybindDown()) { ShowStat2(); };
        }
		
		private void ShowStat()
        {
            this.isShow = !this.isShow;
        }
		
		private void ShowStat2()
        {
            this.isPower = !this.isPower;
        }
		
		public override void OnGUI()
		{
			GUIStyle myStyle = new GUIStyle();
			myStyle.fontSize = (int)(12.0f * (float)(Screen.width)/1000f);
			myStyle.normal.textColor = Color.white;
			
			if(isShow)
			{
				GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-120)/1, Screen.width, Screen.height), "RPM: " + Mathf.Round(SatDrivetr.rpm), myStyle);			
				GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-100)/1, Screen.width, Screen.height), "Speed: " + Mathf.Round(SatDrivetr.differentialSpeed), myStyle);
				if(isPower)
				{	
					GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-180)/1, Screen.width, Screen.height), "Max Power: " + Mathf.Round(SatDrivetr.maxPower), myStyle);
					GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-160)/1, Screen.width, Screen.height), "Max Torque: " + Mathf.Round(SatDrivetr.maxTorque), myStyle);
					GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-140)/1, Screen.width, Screen.height), "Mass: " + SatRigidb.mass, myStyle);
				}
			}
		}
    }
}
