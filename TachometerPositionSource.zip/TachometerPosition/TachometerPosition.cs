﻿using HutongGames.PlayMaker;
using MSCLoader;
using UnityEngine;
using System.Collections;

namespace TachometerPosition
{
    public class TachometerPosition : Mod
    {
        public override string ID { get { return "TachometerPosition"; } }
        public override string Name { get { return "Tachometer Position"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private GameObject SATSUMA;
		private GameObject DASHBOARD;
		private GameObject STEERING;
		private GameObject COLUMN;
		private GameObject TACHOMETER;
		private GameObject TRIGGER;
		
        public override void Update()
        {
			this.SATSUMA = GameObject.Find("SATSUMA(557kg)");
			this.DASHBOARD = this.SATSUMA.transform.FindChild("Dashboard").gameObject;
			this.STEERING = this.DASHBOARD.transform.FindChild("Steering").gameObject;
			this.COLUMN = this.STEERING.transform.FindChild("steering_column2").gameObject;
			this.TACHOMETER = this.COLUMN.transform.FindChild("tachometer(xxxxx)").gameObject;
			this.TRIGGER = this.COLUMN.transform.FindChild("trigger_tachometer").gameObject;
			
			this.TACHOMETER.transform.localPosition = new Vector3(0.25f, -0.35f, 0.21f);
			this.TACHOMETER.transform.localRotation = new Quaternion(1f, 0.5f, -1f, 7f);
			this.TRIGGER.transform.localPosition = new Vector3(0.25f, -0.35f, 0.21f);
			
			GameObject.Find("fuel mixture gauge(xxxxx)").transform.localPosition = new Vector3(0.11f, -0.02f, 0.15f);
			GameObject.Find("fuel mixture gauge(xxxxx)").transform.localRotation = new Quaternion(1f, 0f, 25f, 90f);
        }
    }
}
