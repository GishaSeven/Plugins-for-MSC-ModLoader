﻿using MSCLoader;
using UnityEngine;

namespace Hood
{
    public class Hood : Mod
    {
        public override string ID => "Hood";
        public override string Name => "Hood";
        public override string Author => "Roman266";
        public override string Version => "1.0.3";

        public override bool UseAssetsFolder => true;
		
		public override void OnLoad()
        {			
			if(GameObject.Find("fiberglass hood(Clone)") != null)
			{
				Mesh new_mesh0 = LoadAssets.LoadOBJMesh(this, "hood.obj");
				GameObject.Find("fiberglass hood(Clone)").transform.GetComponent<MeshFilter>().mesh = new_mesh0;
			}
        }
    }
}
