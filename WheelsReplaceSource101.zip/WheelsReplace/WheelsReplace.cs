﻿using MSCLoader;
using UnityEngine;
using System.Linq;

namespace WheelsReplace
{
    public class WheelsReplace : Mod
    {
        public override string ID => "WheelsReplace";
        public override string Name => "WheelsReplace";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => true;
		
		public override void OnLoad()
        {										
			//Textures load
			Texture2D RimsAO = LoadAssets.LoadTexture(this, "rims_ao.dds");
			Texture2D RustPatches = LoadAssets.LoadTexture(this, "rims_rust_patches.dds");
			Texture2D RustyNormal = LoadAssets.LoadTexture(this, "rims_rusty_n.dds");
			Texture2D RimsSPEC = LoadAssets.LoadTexture(this, "rims_spec.dds");
			Texture2D RimsAOInners = LoadAssets.LoadTexture(this, "rim_ao_inners.dds");
			Texture2D ATLASMOTORPARTS = LoadAssets.LoadTexture(this, "ATLAS_MOTORPARTS.dds");
			Texture2D MotorAtlasNormal = LoadAssets.LoadTexture(this, "motorparts_atlas_n.dds");
			Texture2D MotorAtlasSpec = LoadAssets.LoadTexture(this, "motorparts_atlas_spec.dds");
			Texture2D TiresStandard2 = LoadAssets.LoadTexture(this, "tires_standard2.dds");
			Texture2D TiresNew2 = LoadAssets.LoadTexture(this, "tires_new_2.dds");
			Texture2D TiresGobra = LoadAssets.LoadTexture(this, "tires_gobra.dds");
			Texture2D TiresGobraN = LoadAssets.LoadTexture(this, "tires_gobra_n.dds");
			Texture2D TiresRally = LoadAssets.LoadTexture(this, "tires_rally.dds");
			Texture2D TiresRallyN = LoadAssets.LoadTexture(this, "tires_rally_n.dds");
			Texture2D TiresSlicks = LoadAssets.LoadTexture(this, "tires_slicks.dds");
			Texture2D TiresSlicksN = LoadAssets.LoadTexture(this, "tires_slicks_n.dds");
			
			//Meshes load
			Mesh HubcapMesh = LoadAssets.LoadOBJMesh(this, "tire_fl_hubcap.obj");
			Mesh RimSteelMesh = LoadAssets.LoadOBJMesh(this, "rim_steel.obj");
			Mesh RimGTChromeMesh = LoadAssets.LoadOBJMesh(this, "rim_gt_chrome.obj");
			Mesh RimGTMesh = LoadAssets.LoadOBJMesh(this, "rim_gt.obj");
			Mesh RimHayosikoMesh = LoadAssets.LoadOBJMesh(this, "rim_hayosiko.obj");
			Mesh RimHayoInnerMesh = LoadAssets.LoadOBJMesh(this, "rim_hayosiko_inner.obj");
			Mesh RimOctoMesh = LoadAssets.LoadOBJMesh(this, "rim_octo.obj");
			Mesh RimRacingMesh = LoadAssets.LoadOBJMesh(this, "rim_racing.obj");
			Mesh RimRacChrMesh = LoadAssets.LoadOBJMesh(this, "rim_racing_chrome.obj");
			Mesh RimRallyMesh = LoadAssets.LoadOBJMesh(this, "rim_rally.obj");
			Mesh RimSlotMesh = LoadAssets.LoadOBJMesh(this, "rim_slot.obj");
			Mesh RimSpokeMesh = LoadAssets.LoadOBJMesh(this, "rim_spoke.obj");
			Mesh RimSteel14Mesh = LoadAssets.LoadOBJMesh(this, "rim_steel_14.obj");
			Mesh RimTurbineMesh = LoadAssets.LoadOBJMesh(this, "rim_turbine.obj");
			Mesh RimTurbineInnerMesh = LoadAssets.LoadOBJMesh(this, "rim_turbine_inner.obj");
			Mesh TireStockMesh = LoadAssets.LoadOBJMesh(this, "tire_stock.obj");
			Mesh TireStockNewMesh = LoadAssets.LoadOBJMesh(this, "tire_stock_new.obj");
			Mesh TireGobra2Mesh = LoadAssets.LoadOBJMesh(this, "tire_gobra_2.obj");
			Mesh TireGobraMesh = LoadAssets.LoadOBJMesh(this, "tire_gobra.obj");
			Mesh TireRally2Mesh = LoadAssets.LoadOBJMesh(this, "tire_rally2.obj");
			Mesh TireRallyMesh = LoadAssets.LoadOBJMesh(this, "tire_rally.obj");
			Mesh TireSlick2Mesh = LoadAssets.LoadOBJMesh(this, "tire_slick_2.obj");
			Mesh TireSlickMesh = LoadAssets.LoadOBJMesh(this, "tire_slick.obj");
			
			//Backup rusko wheels material
			GameObject.Find("RCO_RUSCKO12(270)").transform.Find("wheelFL/tire/rim").gameObject.GetComponent<MeshRenderer>().material.name = "RIM_PAINT_RUSTY (Instance)B";
			GameObject.Find("RCO_RUSCKO12(270)").transform.Find("wheelFR/tire/rim").gameObject.GetComponent<MeshRenderer>().material.name = "RIM_PAINT_RUSTY (Instance)B";
			GameObject.Find("RCO_RUSCKO12(270)").transform.Find("wheelRL/tire/rim").gameObject.GetComponent<MeshRenderer>().material.name = "RIM_PAINT_RUSTY (Instance)B";
			GameObject.Find("RCO_RUSCKO12(270)").transform.Find("wheelRR/tire/rim").gameObject.GetComponent<MeshRenderer>().material.name = "RIM_PAINT_RUSTY (Instance)B";
			
			//Replace textures in rims materials
			foreach (Material RustyMat in Resources.FindObjectsOfTypeAll<Material>().Where(g => g.name == "RIM_PAINT_RUSTY"))
            {
				RustyMat.mainTexture = RimsAO;
				RustyMat.SetTexture("_DetailAlbedoMap", RustPatches);
				RustyMat.SetTexture("_DetailNormalMap", RustyNormal);
				RustyMat.SetTexture("_SpecGlossMap", RimsSPEC);
			}
			
			foreach (Material RustyMat in Resources.FindObjectsOfTypeAll<Material>().Where(g => g.name == "RIM_PAINT_RUSTY (Instance)"))
            {
				RustyMat.mainTexture = RimsAO;
				RustyMat.SetTexture("_DetailAlbedoMap", RustPatches);
				RustyMat.SetTexture("_DetailNormalMap", RustyNormal);
				RustyMat.SetTexture("_SpecGlossMap", RimsSPEC);
			}
			
			foreach (Material MetallicMat in Resources.FindObjectsOfTypeAll<Material>().Where(g => g.name == "RIM_PAINT_METALLIC"))
            {
				MetallicMat.mainTexture = RimsAO;
			}
			
			foreach (Material MetallicMat in Resources.FindObjectsOfTypeAll<Material>().Where(g => g.name == "RIM_PAINT_METALLIC (Instance)"))
            {
				MetallicMat.mainTexture = RimsAO;
			}
			
			foreach (Material RegularMat in Resources.FindObjectsOfTypeAll<Material>().Where(g => g.name == "RIM_PAINT_REGULAR"))
            {
				RegularMat.mainTexture = RimsAO;
				RegularMat.SetTexture("_SpecGlossMap", RimsSPEC);
			}
			
			foreach (Material RegularMat in Resources.FindObjectsOfTypeAll<Material>().Where(g => g.name == "RIM_PAINT_REGULAR (Instance)"))
            {
				RegularMat.mainTexture = RimsAO;
				RegularMat.SetTexture("_SpecGlossMap", RimsSPEC);
			}
			
			//Hubcap replace
			foreach (GameObject hubcap in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "hubcap(Clone)"))
			{
				hubcap.GetComponent<MeshFilter>().sharedMesh = HubcapMesh;
				hubcap.GetComponent<MeshRenderer>().material.mainTexture = ATLASMOTORPARTS;
				hubcap.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", MotorAtlasNormal);
				hubcap.GetComponent<MeshRenderer>().material.SetTexture("_ScecGlossMap", MotorAtlasSpec);
			}
			
			//Rims meshes replace
			PlayMakerArrayListProxy WheelsList = GameObject.Find("REPAIRSHOP").transform.Find("Jobs/WheelArray1").gameObject.GetComponents<PlayMakerArrayListProxy>()[0];
			
			WheelsList.preFillGameObjectList[0].GetComponent<MeshFilter>().sharedMesh = RimSteelMesh;
			WheelsList.preFillGameObjectList[1].GetComponent<MeshFilter>().sharedMesh = RimSteelMesh;
			WheelsList.preFillGameObjectList[2].GetComponent<MeshFilter>().sharedMesh = RimSteelMesh;
			WheelsList.preFillGameObjectList[3].GetComponent<MeshFilter>().sharedMesh = RimSteelMesh;
			WheelsList.preFillGameObjectList[4].GetComponent<MeshFilter>().sharedMesh = RimSteelMesh;
			WheelsList.preFillGameObjectList[5].GetComponent<MeshFilter>().sharedMesh = RimSpokeMesh;
			WheelsList.preFillGameObjectList[6].GetComponent<MeshFilter>().sharedMesh = RimSpokeMesh;
			WheelsList.preFillGameObjectList[7].GetComponent<MeshFilter>().sharedMesh = RimSpokeMesh;
			WheelsList.preFillGameObjectList[8].GetComponent<MeshFilter>().sharedMesh = RimSpokeMesh;
			WheelsList.preFillGameObjectList[9].GetComponent<MeshFilter>().sharedMesh = RimHayosikoMesh;
			WheelsList.preFillGameObjectList[9].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimHayoInnerMesh;
			WheelsList.preFillGameObjectList[9].transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
			WheelsList.preFillGameObjectList[10].GetComponent<MeshFilter>().sharedMesh = RimHayosikoMesh;
			WheelsList.preFillGameObjectList[10].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimHayoInnerMesh;
			WheelsList.preFillGameObjectList[10].transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
			WheelsList.preFillGameObjectList[11].GetComponent<MeshFilter>().sharedMesh = RimHayosikoMesh;
			WheelsList.preFillGameObjectList[11].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimHayoInnerMesh;
			WheelsList.preFillGameObjectList[11].transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
			WheelsList.preFillGameObjectList[12].GetComponent<MeshFilter>().sharedMesh = RimHayosikoMesh;
			WheelsList.preFillGameObjectList[12].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimHayoInnerMesh;
			WheelsList.preFillGameObjectList[12].transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
			WheelsList.preFillGameObjectList[13].GetComponent<MeshFilter>().sharedMesh = RimRacingMesh;
			WheelsList.preFillGameObjectList[13].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimRacChrMesh;
			WheelsList.preFillGameObjectList[14].GetComponent<MeshFilter>().sharedMesh = RimRacingMesh;
			WheelsList.preFillGameObjectList[14].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimRacChrMesh;
			WheelsList.preFillGameObjectList[15].GetComponent<MeshFilter>().sharedMesh = RimRacingMesh;
			WheelsList.preFillGameObjectList[15].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimRacChrMesh;
			WheelsList.preFillGameObjectList[16].GetComponent<MeshFilter>().sharedMesh = RimRacingMesh;
			WheelsList.preFillGameObjectList[16].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimRacChrMesh;
			WheelsList.preFillGameObjectList[17].GetComponent<MeshFilter>().sharedMesh = RimOctoMesh;
			WheelsList.preFillGameObjectList[18].GetComponent<MeshFilter>().sharedMesh = RimOctoMesh;
			WheelsList.preFillGameObjectList[19].GetComponent<MeshFilter>().sharedMesh = RimOctoMesh;
			WheelsList.preFillGameObjectList[20].GetComponent<MeshFilter>().sharedMesh = RimOctoMesh;
			WheelsList.preFillGameObjectList[21].GetComponent<MeshFilter>().sharedMesh = RimTurbineMesh;
			WheelsList.preFillGameObjectList[21].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimTurbineInnerMesh;
			WheelsList.preFillGameObjectList[21].transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
			WheelsList.preFillGameObjectList[22].GetComponent<MeshFilter>().sharedMesh = RimTurbineMesh;
			WheelsList.preFillGameObjectList[22].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimTurbineInnerMesh;
			WheelsList.preFillGameObjectList[22].transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
			WheelsList.preFillGameObjectList[23].GetComponent<MeshFilter>().sharedMesh = RimTurbineMesh;
			WheelsList.preFillGameObjectList[23].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimTurbineInnerMesh;
			WheelsList.preFillGameObjectList[23].transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
			WheelsList.preFillGameObjectList[24].GetComponent<MeshFilter>().sharedMesh = RimTurbineMesh;
			WheelsList.preFillGameObjectList[24].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimTurbineInnerMesh;
			WheelsList.preFillGameObjectList[24].transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
			WheelsList.preFillGameObjectList[25].GetComponent<MeshFilter>().sharedMesh = RimSlotMesh;
			WheelsList.preFillGameObjectList[26].GetComponent<MeshFilter>().sharedMesh = RimSlotMesh;
			WheelsList.preFillGameObjectList[27].GetComponent<MeshFilter>().sharedMesh = RimSlotMesh;
			WheelsList.preFillGameObjectList[28].GetComponent<MeshFilter>().sharedMesh = RimSlotMesh;
			WheelsList.preFillGameObjectList[29].GetComponent<MeshFilter>().sharedMesh = RimSteel14Mesh;
			WheelsList.preFillGameObjectList[30].GetComponent<MeshFilter>().sharedMesh = RimSteel14Mesh;
			WheelsList.preFillGameObjectList[31].GetComponent<MeshFilter>().sharedMesh = RimSteel14Mesh;
			WheelsList.preFillGameObjectList[32].GetComponent<MeshFilter>().sharedMesh = RimSteel14Mesh;
			WheelsList.preFillGameObjectList[33].GetComponent<MeshFilter>().sharedMesh = RimRallyMesh;
			WheelsList.preFillGameObjectList[34].GetComponent<MeshFilter>().sharedMesh = RimRallyMesh;
			WheelsList.preFillGameObjectList[35].GetComponent<MeshFilter>().sharedMesh = RimRallyMesh;
			WheelsList.preFillGameObjectList[36].GetComponent<MeshFilter>().sharedMesh = RimRallyMesh;
			WheelsList.preFillGameObjectList[37].GetComponent<MeshFilter>().sharedMesh = RimGTChromeMesh;
			WheelsList.preFillGameObjectList[37].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimGTMesh;
			WheelsList.preFillGameObjectList[37].transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
			WheelsList.preFillGameObjectList[38].GetComponent<MeshFilter>().sharedMesh = RimGTChromeMesh;
			WheelsList.preFillGameObjectList[38].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimGTMesh;
			WheelsList.preFillGameObjectList[38].transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
			WheelsList.preFillGameObjectList[39].GetComponent<MeshFilter>().sharedMesh = RimGTChromeMesh;
			WheelsList.preFillGameObjectList[39].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimGTMesh;
			WheelsList.preFillGameObjectList[39].transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
			WheelsList.preFillGameObjectList[40].GetComponent<MeshFilter>().sharedMesh = RimGTChromeMesh;
			WheelsList.preFillGameObjectList[40].transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimGTMesh;
			WheelsList.preFillGameObjectList[40].transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
			
			//Stock tires replace
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireOld"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireStockMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresStandard2;
			}
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireOld(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireStockMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresStandard2;
			}
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireStock13"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireStockMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresNew2;
			}
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireStock13(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireStockMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresNew2;
			}
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireStock14"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireStockNewMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresNew2;
			}
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireStock14(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireStockNewMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresNew2;
			}
			
			//Gobra tires replace
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireGobra"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireGobraMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresGobra;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresGobraN);
			}
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireGobra(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireGobraMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresGobra;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresGobraN);
			}
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireGobra2"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireGobra2Mesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresGobra;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresGobraN);
			}
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireGobra2(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireGobra2Mesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresGobra;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresGobraN);
			}
			
			//Rally tires replace
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireRally"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireRallyMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresRally;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresRallyN);
			}
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireRally(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireRallyMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresRally;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresRallyN);
			}
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireRally2"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireRally2Mesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresRally;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresRallyN);
			}
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireRally2(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireRally2Mesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresRally;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresRallyN);
			}
			
			//Slick tires replace
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireSlick"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireSlickMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresSlicks;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresSlicksN);
			}
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireSlick(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireSlickMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresSlicks;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresSlicksN);
			}
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireSlick2"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireSlick2Mesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresSlicks;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresSlicksN);
			}
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireSlick2(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireSlick2Mesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresSlicks;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresSlicksN);
			}
        }
    }
}
