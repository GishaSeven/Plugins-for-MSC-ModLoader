﻿using MSCLoader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

namespace LanguageFramework
{
    public class LanguageFramework : Mod
    {
        public override string ID => "LanguageFramework";
        public override string Name => "LanguageFramework";
        public override string Author => "jinnin0105";
        public override string Version => "1.2.3";

		public override bool LoadInMenu => true;
		public override bool UseAssetsFolder => true;
		
		private static Font _font;
		private SceneType _currentScene;
		private string _currentLanguage;
		private string _assetsPath;
		private string _fontAssetName;
		private string _fontName;
		private static Dictionary<string, string> _translates = new Dictionary<string, string>();
		private bool endingtranslated;
		
		public bool isAssetsLoaded
		{
			get;
			set;
		}
		
		public override void OnMenuLoad() 
		{
			_assetsPath = ModLoader.GetModAssetsFolder(this);
			bool flag = string.IsNullOrEmpty(_currentLanguage);
			if (flag)
			{
				Dictionary<string, string> dictionary = ParseStringKeyValue(_assetsPath, "settings");
				bool flag2 = dictionary == null && dictionary.Count < 2;
				if (flag2)
				{
					return;
				}
				bool flag3 = dictionary.ContainsKey("LANGUAGE");
				if (flag3)
				{
					_currentLanguage = dictionary["LANGUAGE"];
					_fontAssetName = dictionary["FONTASSETNAME"];
					_fontName = dictionary["FONTNAME"];
				}
			}
			ModConsole.Print(string.Concat(new string[]
			{
				_currentLanguage,
				" ",
				_fontAssetName,
				" ",
				_fontName
			}));
			InitFont();
			ParseCurrentLanguage();
			TranslateAll();
		}
		
		public override void OnNewGame()
		{
			TranslateAll();
		}
		
		private void TranslateAll()
		{
			TextMesh[] array = Resources.FindObjectsOfTypeAll<TextMesh>();
			List<Transform> list = new List<Transform>();
			StringBuilder stringBuilder = new StringBuilder();
			int num = array.Length;
			for (int i = 0; i < num; i++)
			{
				TextMesh textMesh = array[i];
				list.Clear();
				Transform transform = textMesh.transform;
				while (transform != null)
				{
					list.Add(transform);
					transform = transform.parent;
				}
				stringBuilder.Length = 0;
				int count = list.Count;
				while (count-- > 0)
				{
					string text = list[count].name;
					text = text.Replace(" ", string.Empty);
					stringBuilder.Append(text);
					bool flag = count != 0;
					if (flag)
					{
						stringBuilder.Append("/");
					}
				}
				string text2 = stringBuilder.ToString();
				bool flag2 = text2.StartsWith("Licence/") || text2.StartsWith("Interface/") || text2.StartsWith("Loading/") || text2.StartsWith("GUI/") || text2.StartsWith("Systems/") || text2.StartsWith("Sheets/") || text2.StartsWith("RALLY/RallyTV/") || text2.StartsWith("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/") || text2.StartsWith("Intro/") || text2.StartsWith("YARD/PlayerMailBox/mailbox_bottom_player/") || text2.StartsWith("BUTTONS/");
				if (flag2)
				{
					SetTextMeshFont(textMesh);
					Translate(textMesh);
				}
			}
		}
		
		private void OnPreGameSceneLoaded()
		{
			TranslateAll();
			GameObject gameObject = new GameObject("MainObject", new Type[]
			{
				typeof(MainObject)
			});
			MainObject component = gameObject.GetComponent<MainObject>();
			component.SetMod(this);
		}
		
		private SceneType GetSceneType()
		{
			string loadedLevelName = Application.loadedLevelName;
			SceneType result;
			if (!(loadedLevelName == "MainMenu"))
			{
				if (!(loadedLevelName == "GAME"))
				{
					result = SceneType.None;
				}
				else
				{
					result = SceneType.Game;
				}
			}
			else
			{
				result = SceneType.MainMenu;
			}
			return result;
		}
		
		public override void Update()
        {
			SceneType sceneType = GetSceneType();
			bool flag = GetSceneType() == SceneType.Game;
			if (flag)
			{
				bool flag2 = _currentScene != sceneType;
				if (flag2)
				{
					_currentScene = sceneType;
					SceneType sceneType2 = GetSceneType();
					if (sceneType2 == SceneType.Game)
					{
						OnPreGameSceneLoaded();
					}
				}
			}
			
			if(Application.loadedLevelName == "Ending")
			{
				if(!endingtranslated)
				{
					TranslateAll();
					endingtranslated = true;
				}
			}
		}
		
		public void ParseCurrentLanguage()
		{
			LanguageFramework._translates.Clear();
			LanguageFramework._translates = ParseStringKeyValue(_assetsPath, _currentLanguage);
			ModConsole.Print(string.Format("Set {0}", _currentLanguage));
		}
		
		public Dictionary<string, string> ParseStringKeyValue(string assetPath, string fileName)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			try
			{
				string[] array = File.ReadAllLines(string.Format("{0}/{1}.txt", assetPath, fileName), Encoding.UTF8);
				int num = array.Length;
				for (int i = 0; i < num; i++)
				{
					string text = array[i];
					bool flag = string.IsNullOrEmpty(text);
					if (!flag)
					{
						bool flag2 = text.Contains("//");
						if (!flag2)
						{
							string[] array2 = array[i].Split(new char[]
							{
								'='
							});
							bool flag3 = array2.Length < 2;
							if (!flag3)
							{
								string text2 = StringExtensions.FormatUpperKey(array2[0]);
								string text3 = StringExtensions.TrimStartEnd(array2[1]);
								text3 = text3.Replace("\\n", "\n");
								bool flag4 = !dictionary.ContainsKey(text2);
								if (flag4)
								{
									dictionary.Add(text2, text3);
								}
								else
								{
									ModConsole.Error(string.Concat(new object[]
									{
										text2,
										" key is already! delete this line (",
										i + 1,
										" line)"
									}));
								}
							}
						}
					}
				}
			}
			catch (Exception)
			{
				ModConsole.Error(fileName + ".txt not found! " + dictionary.Count);
			}
			return dictionary;
		}
		
		public void Translate(TextMesh textMesh)
		{
			string text;
			bool flag = !LanguageFramework._translates.TryGetValue(StringExtensions.FormatUpperKey(textMesh.text), out text);
			if (!flag)
			{
				textMesh.text = text;
			}
		}
		
		public TextMesh GetTextMesh(string path)
		{
			GameObject gameObject = GameObject.Find(path);
			bool flag = gameObject == null;
			TextMesh result;
			if (flag)
			{
				result = null;
			}
			else
			{
				TextMesh component = gameObject.GetComponent<TextMesh>();
				bool flag2 = component == null;
				if (flag2)
				{
					result = null;
				}
				else
				{
					result = component;
				}
			}
			return result;
		}
		
		public string GetTranslatedText(string original)
		{
			string text;
			bool flag = LanguageFramework._translates.TryGetValue(StringExtensions.FormatUpperKey(original), out text);
			string result;
			if (flag)
			{
				result = text;
			}
			else
			{
				result = string.Empty;
			}
			return result;
		}
		
		public void SetTextMeshFont(TextMesh textMesh)
		{
			textMesh.font = LanguageFramework._font;
			textMesh.GetComponent<MeshRenderer>().material = LanguageFramework._font.material;
			textMesh.richText = false;
		}
		
		private void InitFont()
		{
			bool flag = LanguageFramework._font == null;
			if (flag)
			{
				try
				{
					AssetBundle assetBundle = LoadAssets.LoadBundle(this, _fontAssetName);
					LanguageFramework._font = assetBundle.LoadAsset<Font>(_fontName);
					ModConsole.Print("Font initialized!");
				}
				catch (Exception)
				{
					ModConsole.Error("Failed to load font! " + _fontAssetName + " " + _fontName);
				}
			}
		}
    }
}
