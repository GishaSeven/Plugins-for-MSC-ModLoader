﻿using MSCLoader;
using UnityEngine;

namespace RacingMuffler
{
    public class RacingMuffler : Mod
    {
        public override string ID => "RacingMuffler";
        public override string Name => "Racing muffler";
        public override string Author => "Roman266";
        public override string Version => "1.0.2";

        public override bool UseAssetsFolder => true;
		
		public override void OnLoad()
        {			
			if(GameObject.Find("racing muffler(Clone)") != null)
			{				
				Mesh new_mesh0 = LoadAssets.LoadOBJMesh(this, "racingmuffler.obj");
				GameObject.Find("racing muffler(Clone)").transform.GetComponent<MeshFilter>().mesh = new_mesh0;
			}
        }
    }
}
