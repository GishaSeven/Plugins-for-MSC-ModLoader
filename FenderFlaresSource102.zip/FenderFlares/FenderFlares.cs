﻿using MSCLoader;
using UnityEngine;
using System.Threading;

namespace FenderFlares
{
    public class FenderFlares : Mod
    {
        public override string ID => "FenderFlares";
        public override string Name => "Fender Flares";
        public override string Author => "Roman266";
        public override string Version => "1.0.2";

        public override bool UseAssetsFolder => true;
		
		private GameObject FLAREFL;
		private GameObject FLAREFR;
		private GameObject FLARERL;
		private GameObject FLARERR;

		public override void OnLoad()
        {			
			new Thread(waiting).Start();
        }
		
		private void waiting()
		{
			Thread.Sleep( 20 * 1000 );
						
			if(GameObject.Find("fender flare fl(Clone)").activeSelf == true)
			{
				FLAREFL = GameObject.Find("fender flare fl(Clone)");
				FLAREFR = GameObject.Find("fender flare fr(Clone)");
				FLARERL = GameObject.Find("fender flare rl(Clone)");
				FLARERR = GameObject.Find("fender flare rr(Clone)");
				
				Mesh new_mesh0 = LoadAssets.LoadOBJMesh(this, "fl_flare.obj");
				Mesh new_mesh1 = LoadAssets.LoadOBJMesh(this, "fr_flare.obj");
				Mesh new_mesh2 = LoadAssets.LoadOBJMesh(this, "rl_flare.obj");
				Mesh new_mesh3 = LoadAssets.LoadOBJMesh(this, "rr_flare.obj");
				
				FLAREFL.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				FLAREFR.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				FLARERL.transform.GetComponent<MeshFilter>().mesh = new_mesh2;
				FLARERR.transform.GetComponent<MeshFilter>().mesh = new_mesh3;
			}
		}
    }
}
