﻿using MSCLoader;
using UnityEngine;
using System;
using System.IO;
using System.Threading;
using HutongGames.PlayMaker;

namespace WheelsResizer
{
    public class WheelsResizer : Mod
    {
        public override string ID => "WheelsResizer";
        public override string Name => "Wheels Resizer";
        public override string Author => "Roman266";
        public override string Version => "2.0.2";

        public override bool UseAssetsFolder => true;

		private bool guiShow;
		private float StockRadius;
		private float RallyRadius;
		private float DragRadius;
		private float ScalePlus;
		private float ScaleMinus;
		private GameObject SATSUMA;
		private GameObject WHEELRR;
		private GameObject WHEELRL;
		private GameObject WHEELFR;
		private GameObject WHEELFL;
		private string path;
		private Rect guiBox = new Rect((Screen.width-360)/2, 10f, 360f, 465f);
		private Keybind ResizerGuiKey = new Keybind("ShowGUI", "Show GUI", KeyCode.F8);
		
		public override void OnLoad()
        {
            Keybind.Add(this, ResizerGuiKey);
			
			path = ModLoader.GetModAssetsFolder(this);
			
			this.SATSUMA = GameObject.Find("SATSUMA(557kg)");
			this.WHEELFL = this.SATSUMA.transform.FindChild("wheelFL").gameObject;
			this.WHEELFR = this.SATSUMA.transform.FindChild("wheelFR").gameObject;
			this.WHEELRL = this.SATSUMA.transform.FindChild("wheelRL").gameObject;
			this.WHEELRR = this.SATSUMA.transform.FindChild("wheelRR").gameObject;
			this.ScalePlus = 0.001f;
			this.ScaleMinus = -0.001f;
			this.StockRadius = 0.2715f;
			this.RallyRadius = 0.2875f;
			this.DragRadius = 0.255f;
			
			new Thread(waiting).Start();
        }
		
		public override void OnGUI()
		{
			if (guiShow)
			{
				GUI.ModalWindow(1, this.guiBox, new GUI.WindowFunction(this.Window), "Wheels Resizer");
			}
		}
		
        public override void Update()
        {			
			if (ResizerGuiKey.IsDown()) { GuiShow(); };
        }
		
		private void waiting()
		{
			Thread.Sleep( 20 * 1000 );
			loadsettings();
		}
		
		private void GuiShow()
		{
			this.guiShow = !this.guiShow;
			
			if(guiShow)
			{
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = true;
			}
			else
			{
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
			}
		}
				
		private void Window(int windowId)
		{
			bool flag0 = GUI.Button(new Rect(130f, 425f, 100f, 30f), "Close");
			if (flag0)
			{
				GuiShow();
			}
			GUI.Label(new Rect(15f, 25f, 120f, 30f), "Front left wheel");
			bool flag1 = GUI.RepeatButton(new Rect(15f, 50f, 60f, 30f), "Size -");
			if (flag1)
			{
				fl_size_minus();
			}
			bool flag2 = GUI.RepeatButton(new Rect(75f, 50f, 60f, 30f), "Size +");
			if (flag2)
			{
				fl_size_plus();
			}
			GUI.Label(new Rect(140f, 55f, 60f, 30f), this.WHEELFL.transform.localScale.y.ToString());
			bool flag3 = GUI.RepeatButton(new Rect(15f, 80f, 60f, 30f), "Width -");
			if (flag3)
			{
				fl_width_minus();
			}
			bool flag4 = GUI.RepeatButton(new Rect(75f, 80f, 60f, 30f), "Width +");
			if (flag4)
			{
				fl_width_plus();
			}
			GUI.Label(new Rect(140f, 85f, 60f, 30f), this.WHEELFL.transform.localScale.x.ToString());
			GUI.Label(new Rect(15f, 115f, 120f, 30f), "Front right wheel");
			bool flag5 = GUI.RepeatButton(new Rect(15f, 140f, 60f, 30f), "Size -");
			if (flag5)
			{
				fr_size_minus();
			}
			bool flag6 = GUI.RepeatButton(new Rect(75f, 140f, 60f, 30f), "Size +");
			if (flag6)
			{
				fr_size_plus();
			}
			GUI.Label(new Rect(140f, 145f, 60f, 30f), this.WHEELFR.transform.localScale.y.ToString());
			bool flag7 = GUI.RepeatButton(new Rect(15f, 170f, 60f, 30f), "Width -");
			if (flag7)
			{
				fr_width_minus();
			}
			bool flag8 = GUI.RepeatButton(new Rect(75f, 170f, 60f, 30f), "Width +");
			if (flag8)
			{
				fr_width_plus();
			}
			GUI.Label(new Rect(140f, 175f, 60f, 30f), this.WHEELFR.transform.localScale.x.ToString());
			GUI.Label(new Rect(15f, 210f, 120f, 30f), "Rear left wheel");
			bool flag9 = GUI.RepeatButton(new Rect(15f, 235f, 60f, 30f), "Size -");
			if (flag9)
			{
				rl_size_minus();
			}
			bool flag10 = GUI.RepeatButton(new Rect(75f, 235f, 60f, 30f), "Size +");
			if (flag10)
			{
				rl_size_plus();
			}
			GUI.Label(new Rect(140f, 240f, 60f, 30f), this.WHEELRL.transform.localScale.y.ToString());
			bool flag11 = GUI.RepeatButton(new Rect(15f, 265f, 60f, 30f), "Width -");
			if (flag11)
			{
				rl_width_minus();
			}
			bool flag12 = GUI.RepeatButton(new Rect(75f, 265f, 60f, 30f), "Width +");
			if (flag12)
			{
				rl_width_plus();
			}
			GUI.Label(new Rect(140f, 270f, 60f, 30f), this.WHEELRL.transform.localScale.x.ToString());
			GUI.Label(new Rect(15f, 300f, 120f, 30f), "Rear right wheel");
			bool flag13 = GUI.RepeatButton(new Rect(15f, 325f, 60f, 30f), "Size -");
			if (flag13)
			{
				rr_size_minus();
			}
			bool flag14 = GUI.RepeatButton(new Rect(75f, 325f, 60f, 30f), "Size +");
			if (flag14)
			{
				rr_size_plus();
			}
			GUI.Label(new Rect(140f, 330f, 60f, 30f), this.WHEELRR.transform.localScale.y.ToString());
			bool flag15 = GUI.RepeatButton(new Rect(15f, 355f, 60f, 30f), "Width -");
			if (flag15)
			{
				rr_width_minus();
			}
			bool flag16 = GUI.RepeatButton(new Rect(75f, 355f, 60f, 30f), "Width +");
			if (flag16)
			{
				rr_width_plus();
			}
			GUI.Label(new Rect(140f, 360f, 60f, 30f), this.WHEELRR.transform.localScale.x.ToString());
			GUI.Label(new Rect(225f, 25f, 120f, 30f), "Front wheels");
			bool flag17 = GUI.RepeatButton(new Rect(225f, 50f, 60f, 30f), "Size -");
			if (flag17)
			{
				fl_size_minus();
				fr_size_minus();
			}
			bool flag18 = GUI.RepeatButton(new Rect(285f, 50f, 60f, 30f), "Size +");
			if (flag18)
			{
				fl_size_plus();
				fr_size_plus();
			}
			bool flag19 = GUI.RepeatButton(new Rect(225f, 80f, 60f, 30f), "Width -");
			if (flag19)
			{
				fl_width_minus();
				fr_width_minus();
			}
			bool flag20 = GUI.RepeatButton(new Rect(285f, 80f, 60f, 30f), "Width +");
			if (flag20)
			{
				fl_width_plus();
				fr_width_plus();
			}
			GUI.Label(new Rect(225f, 115f, 120f, 30f), "Rear wheels");
			bool flag21 = GUI.RepeatButton(new Rect(225f, 140f, 60f, 30f), "Size -");
			if (flag21)
			{
				rl_size_minus();
				rr_size_minus();
			}
			bool flag22 = GUI.RepeatButton(new Rect(285f, 140f, 60f, 30f), "Size +");
			if (flag22)
			{
				rl_size_plus();
				rr_size_plus();
			}
			bool flag23 = GUI.RepeatButton(new Rect(225f, 170f, 60f, 30f), "Width -");
			if (flag23)
			{
				rl_width_minus();
				rr_width_minus();
			}
			bool flag24 = GUI.RepeatButton(new Rect(285f, 170f, 60f, 30f), "Width +");
			if (flag24)
			{
				rl_width_plus();
				rr_width_plus();
			}
			GUI.Label(new Rect(225f, 210f, 120f, 30f), "All wheels");
			bool flag25 = GUI.RepeatButton(new Rect(225f, 235f, 60f, 30f), "Size -");
			if (flag25)
			{
				fl_size_minus();
				fr_size_minus();
				rl_size_minus();
				rr_size_minus();
			}
			bool flag26 = GUI.RepeatButton(new Rect(285f, 235f, 60f, 30f), "Size +");
			if (flag26)
			{
				fl_size_plus();
				fr_size_plus();
				rl_size_plus();
				rr_size_plus();
			}
			bool flag27 = GUI.RepeatButton(new Rect(225f, 265f, 60f, 30f), "Width -");
			if (flag27)
			{
				fl_width_minus();
				fr_width_minus();
				rl_width_minus();
				rr_width_minus();
			}
			bool flag28 = GUI.RepeatButton(new Rect(285f, 265f, 60f, 30f), "Width +");
			if (flag28)
			{
				fl_width_plus();
				fr_width_plus();
				rl_width_plus();
				rr_width_plus();
			}
			bool flag29 = GUI.Button(new Rect(225f, 325f, 120f, 30f), "Reset to default");
			if (flag29)
			{
				resetsettings();
			}
			bool flag30 = GUI.Button(new Rect(225f, 355f, 120f, 30f), "Save settings");
			if (flag30)
			{
				savesettings();
			}
			bool flag31 = GUI.Button(new Rect(225f, 385f, 120f, 30f), "Load settings");
			if (flag31)
			{
				loadsettings();
			}
			GUI.DragWindow();
		}
		
		private void resetsettings()
		{
			this.WHEELFL.transform.localScale = new Vector3(1, 1, 1);
			this.WHEELFR.transform.localScale = new Vector3(1, 1, 1);
			this.WHEELRL.transform.localScale = new Vector3(1, 1, 1);
			this.WHEELRR.transform.localScale = new Vector3(1, 1, 1);

			if(GameObject.Find("wheel steel fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = this.StockRadius;
			}
				
			if(GameObject.Find("wheel spoke fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = this.StockRadius;
			}
				
			if(GameObject.Find("wheel hayosiko fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = this.StockRadius;
			}
				
			if(GameObject.Find("wheel rally fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = this.RallyRadius;
			}
				
			if(GameObject.Find("wheel racing fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = this.DragRadius;
			}

			if(GameObject.Find("wheel steel fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = this.StockRadius;
			}
				
			if(GameObject.Find("wheel spoke fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = this.StockRadius;
			}
				
			if(GameObject.Find("wheel hayosiko fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = this.StockRadius;
			}
				
			if(GameObject.Find("wheel rally fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = this.RallyRadius;
			}
				
			if(GameObject.Find("wheel racing fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = this.DragRadius;
			}

			if(GameObject.Find("wheel steel rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = this.StockRadius;
			}
				
			if(GameObject.Find("wheel spoke rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = this.StockRadius;
			}
				
			if(GameObject.Find("wheel hayosiko rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = this.StockRadius;
			}
				
			if(GameObject.Find("wheel rally rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = this.RallyRadius;
			}
				
			if(GameObject.Find("wheel racing rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = this.DragRadius;
			}

			if(GameObject.Find("wheel steel rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = this.StockRadius;
			}
				
			if(GameObject.Find("wheel spoke rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = this.StockRadius;
			}
				
			if(GameObject.Find("wheel hayosiko rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = this.StockRadius;
			}
				
			if(GameObject.Find("wheel rally rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = this.RallyRadius;
			}
				
			if(GameObject.Find("wheel racing rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = this.DragRadius;
			}
		}
		
		private void savesettings()
        {
			if(GameObject.Find("wheel steel fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELFL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELFL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius.ToString();
			
				File.WriteAllLines(path + "/fl_stock.txt", array);
			}
				
			if(GameObject.Find("wheel spoke fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELFL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELFL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius.ToString();
			
				File.WriteAllLines(path + "/fl_stock.txt", array);
			}
				
			if(GameObject.Find("wheel hayosiko fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELFL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELFL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius.ToString();
			
				File.WriteAllLines(path + "/fl_stock.txt", array);
			}
				
			if(GameObject.Find("wheel rally fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELFL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELFL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius.ToString();
			
				File.WriteAllLines(path + "/fl_rally.txt", array);
			}
				
			if(GameObject.Find("wheel racing fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELFL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELFL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius.ToString();

				File.WriteAllLines(path + "/fl_drag.txt", array);
			}

			if(GameObject.Find("wheel steel fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELFR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELFR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/fr_stock.txt", array);
			}
				
			if(GameObject.Find("wheel spoke fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELFR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELFR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/fr_stock.txt", array);
			}
				
			if(GameObject.Find("wheel hayosiko fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELFR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELFR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/fr_stock.txt", array);
			}
				
			if(GameObject.Find("wheel rally fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELFR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELFR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/fr_rally.txt", array);
			}
				
			if(GameObject.Find("wheel racing fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELFR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELFR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/fr_drag.txt", array);
			}

			if(GameObject.Find("wheel steel rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELRL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELRL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius.ToString();

				File.WriteAllLines(path + "/rl_stock.txt", array);
			}
				
			if(GameObject.Find("wheel spoke rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELRL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELRL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius.ToString();

				File.WriteAllLines(path + "/rl_stock.txt", array);
			}
				
			if(GameObject.Find("wheel hayosiko rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELRL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELRL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius.ToString();

				File.WriteAllLines(path + "/rl_stock.txt", array);
			}
				
			if(GameObject.Find("wheel rally rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELRL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELRL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius.ToString();

				File.WriteAllLines(path + "/rl_rally.txt", array);
			}
				
			if(GameObject.Find("wheel racing rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELRL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELRL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius.ToString();

				File.WriteAllLines(path + "/rl_drag.txt", array);
			}
			
			if(GameObject.Find("wheel steel rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELRR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELRR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/rr_stock.txt", array);
			}
				
			if(GameObject.Find("wheel spoke rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELRR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELRR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/rr_stock.txt", array);
			}
				
			if(GameObject.Find("wheel hayosiko rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELRR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELRR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/rr_stock.txt", array);
			}
				
			if(GameObject.Find("wheel rally rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELRR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELRR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/rr_rally.txt", array);
			}
				
			if(GameObject.Find("wheel racing rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = this.WHEELRR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = this.WHEELRR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/rr_drag.txt", array);
			}
        }
		
		private void loadsettings()
        {
			if(GameObject.Find("wheel steel fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fl_stock.txt"))
				{
					array = File.ReadAllLines(path + "/fl_stock.txt");
				
					this.WHEELFL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel spoke fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fl_stock.txt"))
				{
					array = File.ReadAllLines(path + "/fl_stock.txt");
				
					this.WHEELFL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel hayosiko fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fl_stock.txt"))
				{
					array = File.ReadAllLines(path + "/fl_stock.txt");
				
					this.WHEELFL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel rally fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fl_rally.txt"))
				{
					array = File.ReadAllLines(path + "/fl_rally.txt");
				
					this.WHEELFL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel racing fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fl_drag.txt"))
				{
					array = File.ReadAllLines(path + "/fl_drag.txt");
				
					this.WHEELFL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}

			if(GameObject.Find("wheel steel fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fr_stock.txt"))
				{
					array = File.ReadAllLines(path + "/fr_stock.txt");
				
					this.WHEELFR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel spoke fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fr_stock.txt"))
				{
					array = File.ReadAllLines(path + "/fr_stock.txt");
				
					this.WHEELFR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel hayosiko fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fr_stock.txt"))
				{
					array = File.ReadAllLines(path + "/fr_stock.txt");
				
					this.WHEELFR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel rally fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fr_rally.txt"))
				{
					array = File.ReadAllLines(path + "/fr_rally.txt");
				
					this.WHEELFR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel racing fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fr_drag.txt"))
				{
					array = File.ReadAllLines(path + "/fr_drag.txt");
				
					this.WHEELFR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}

			if(GameObject.Find("wheel steel rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rl_stock.txt"))
				{
					array = File.ReadAllLines(path + "/rl_stock.txt");
				
					this.WHEELRL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel spoke rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rl_stock.txt"))
				{
					array = File.ReadAllLines(path + "/rl_stock.txt");
				
					this.WHEELRL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel hayosiko rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rl_stock.txt"))
				{
					array = File.ReadAllLines(path + "/rl_stock.txt");
				
					this.WHEELRL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel rally rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rl_rally.txt"))
				{
					array = File.ReadAllLines(path + "/rl_rally.txt");
				
					this.WHEELRL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel racing rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rl_drag.txt"))
				{
					array = File.ReadAllLines(path + "/rl_drag.txt");
				
					this.WHEELRL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}

			if(GameObject.Find("wheel steel rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rr_stock.txt"))
				{
					array = File.ReadAllLines(path + "/rr_stock.txt");
				
					this.WHEELRR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel spoke rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rr_stock.txt"))
				{
					array = File.ReadAllLines(path + "/rr_stock.txt");
				
					this.WHEELRR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel hayosiko rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rr_stock.txt"))
				{
					array = File.ReadAllLines(path + "/rr_stock.txt");
				
					this.WHEELRR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel rally rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rr_rally.txt"))
				{
					array = File.ReadAllLines(path + "/rr_rally.txt");
				
					this.WHEELRR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(GameObject.Find("wheel racing rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rr_drag.txt"))
				{
					array = File.ReadAllLines(path + "/rr_drag.txt");
				
					this.WHEELRR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}
        }
		
		private void fl_size_minus()
		{
			this.WHEELFL.transform.localScale = new Vector3(this.WHEELFL.transform.localScale.x + this.ScaleMinus, this.WHEELFL.transform.localScale.y + this.ScaleMinus, this.WHEELFL.transform.localScale.z + this.ScaleMinus);
				
			if(GameObject.Find("wheel steel fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius -= this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel spoke fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius -= this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel hayosiko fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius -= this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel rally fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius -= this.RallyRadius/1000f;
			}
				
			if(GameObject.Find("wheel racing fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius -= this.DragRadius/1000f;
			}
		}
		
		private void fl_size_plus()
		{
			this.WHEELFL.transform.localScale = new Vector3(this.WHEELFL.transform.localScale.x + this.ScalePlus, this.WHEELFL.transform.localScale.y + this.ScalePlus, this.WHEELFL.transform.localScale.z + this.ScalePlus);
				
			if(GameObject.Find("wheel steel fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius += this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel spoke fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius += this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel hayosiko fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius += this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel rally fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius += this.RallyRadius/1000f;
			}
				
			if(GameObject.Find("wheel racing fl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius += this.DragRadius/1000f;
			}
		}
		
		private void fl_width_minus()
		{
			this.WHEELFL.transform.localScale = new Vector3(this.WHEELFL.transform.localScale.x + this.ScaleMinus, this.WHEELFL.transform.localScale.y, this.WHEELFL.transform.localScale.z);
		}
		
		private void fl_width_plus()
		{
			this.WHEELFL.transform.localScale = new Vector3(this.WHEELFL.transform.localScale.x + this.ScalePlus, this.WHEELFL.transform.localScale.y, this.WHEELFL.transform.localScale.z);
		}
		
		private void fr_size_minus()
		{
			this.WHEELFR.transform.localScale = new Vector3(this.WHEELFR.transform.localScale.x + this.ScaleMinus, this.WHEELFR.transform.localScale.y + this.ScaleMinus, this.WHEELFR.transform.localScale.z + this.ScaleMinus);
				
			if(GameObject.Find("wheel steel fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius -= this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel spoke fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius -= this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel hayosiko fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius -= this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel rally fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius -= this.RallyRadius/1000f;
			}
				
			if(GameObject.Find("wheel racing fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius -= this.DragRadius/1000f;
			}
		}
		
		private void fr_size_plus()
		{
			this.WHEELFR.transform.localScale = new Vector3(this.WHEELFR.transform.localScale.x + this.ScalePlus, this.WHEELFR.transform.localScale.y + this.ScalePlus, this.WHEELFR.transform.localScale.z + this.ScalePlus);
				
			if(GameObject.Find("wheel steel fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius += this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel spoke fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius += this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel hayosiko fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius += this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel rally fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius += this.RallyRadius/1000f;
			}
				
			if(GameObject.Find("wheel racing fr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius += this.DragRadius/1000f;
			}
		}
		
		private void fr_width_minus()
		{
			this.WHEELFR.transform.localScale = new Vector3(this.WHEELFR.transform.localScale.x + this.ScaleMinus, this.WHEELFR.transform.localScale.y, this.WHEELFR.transform.localScale.z);
		}
		
		private void fr_width_plus()
		{
			this.WHEELFR.transform.localScale = new Vector3(this.WHEELFR.transform.localScale.x + this.ScalePlus, this.WHEELFR.transform.localScale.y, this.WHEELFR.transform.localScale.z);
		}

		private void rl_size_minus()
		{
			this.WHEELRL.transform.localScale = new Vector3(this.WHEELRL.transform.localScale.x + this.ScaleMinus, this.WHEELRL.transform.localScale.y + this.ScaleMinus, this.WHEELRL.transform.localScale.z + this.ScaleMinus);
				
			if(GameObject.Find("wheel steel rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius -= this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel spoke rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius -= this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel hayosiko rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius -= this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel rally rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius -= this.RallyRadius/1000f;
			}
				
			if(GameObject.Find("wheel racing rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius -= this.DragRadius/1000f;
			}
		}
		
		private void rl_size_plus()
		{
			this.WHEELRL.transform.localScale = new Vector3(this.WHEELRL.transform.localScale.x + this.ScalePlus, this.WHEELRL.transform.localScale.y + this.ScalePlus, this.WHEELRL.transform.localScale.z + this.ScalePlus);
				
			if(GameObject.Find("wheel steel rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius += this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel spoke rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius += this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel hayosiko rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius += this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel rally rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius += this.RallyRadius/1000f;
			}
				
			if(GameObject.Find("wheel racing rl(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius += this.DragRadius/1000f;
			}
		}
		
		private void rl_width_minus()
		{
			this.WHEELRL.transform.localScale = new Vector3(this.WHEELRL.transform.localScale.x + this.ScaleMinus, this.WHEELRL.transform.localScale.y, this.WHEELRL.transform.localScale.z);
		}
		
		private void rl_width_plus()
		{
			this.WHEELRL.transform.localScale = new Vector3(this.WHEELRL.transform.localScale.x + this.ScalePlus, this.WHEELRL.transform.localScale.y, this.WHEELRL.transform.localScale.z);
		}
		
		private void rr_size_minus()
		{
			this.WHEELRR.transform.localScale = new Vector3(this.WHEELRR.transform.localScale.x + this.ScaleMinus, this.WHEELRR.transform.localScale.y + this.ScaleMinus, this.WHEELRR.transform.localScale.z + this.ScaleMinus);
				
			if(GameObject.Find("wheel steel rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius -= this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel spoke rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius -= this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel hayosiko rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius -= this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel rally rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius -= this.RallyRadius/1000f;
			}
				
			if(GameObject.Find("wheel racing rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius -= this.DragRadius/1000f;
			}
		}
		
		private void rr_size_plus()
		{
			this.WHEELRR.transform.localScale = new Vector3(this.WHEELRR.transform.localScale.x + this.ScalePlus, this.WHEELRR.transform.localScale.y + this.ScalePlus, this.WHEELRR.transform.localScale.z + this.ScalePlus);
				
			if(GameObject.Find("wheel steel rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius += this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel spoke rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius += this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel hayosiko rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius += this.StockRadius/1000f;
			}
				
			if(GameObject.Find("wheel rally rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius += this.RallyRadius/1000f;
			}
				
			if(GameObject.Find("wheel racing rr(Clone)").transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius += this.DragRadius/1000f;
			}
		}
		
		private void rr_width_minus()
		{
			this.WHEELRR.transform.localScale = new Vector3(this.WHEELRR.transform.localScale.x + this.ScaleMinus, this.WHEELRR.transform.localScale.y, this.WHEELRR.transform.localScale.z);
		}
		
		private void rr_width_plus()
		{
			this.WHEELRR.transform.localScale = new Vector3(this.WHEELRR.transform.localScale.x + this.ScalePlus, this.WHEELRR.transform.localScale.y, this.WHEELRR.transform.localScale.z);
		}
    }
}
