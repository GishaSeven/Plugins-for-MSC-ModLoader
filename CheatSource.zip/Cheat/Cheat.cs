﻿using HutongGames.PlayMaker;
using MSCLoader;
using UnityEngine;

namespace Cheat
{
    public class Cheat : Mod
    {
        public override string ID { get { return "Cheat"; } }
        public override string Name { get { return "Cheat"; } }
        public override string Author { get { return "Djoe45(Edit by Roman266)"; } }
        public override string Version { get { return "1.0.0"; } }

        public override void Update()
        {
            FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value = 0.0f;
            FsmVariables.GlobalVariables.FindFsmFloat("PlayerDirtiness").Value = 0.0f;
            FsmVariables.GlobalVariables.FindFsmFloat("PlayerDrunk").Value = 0.0f;
            FsmVariables.GlobalVariables.FindFsmFloat("PlayerHunger").Value = 0.0f;
            FsmVariables.GlobalVariables.FindFsmFloat("PlayerThirst").Value = 0.0f;
            FsmVariables.GlobalVariables.FindFsmFloat("PlayerUrine").Value = 0.0f;
        }
    }
}
