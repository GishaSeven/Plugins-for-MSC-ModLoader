﻿using MSCLoader;
using UnityEngine;

namespace FenderFlares
{
    public class FenderFlares : Mod
    {
        public override string ID => "FenderFlares";
        public override string Name => "Fender flares";
        public override string Author => "Roman266";
        public override string Version => "1.0.3";

        public override bool UseAssetsFolder => true;
		
		public override void OnLoad()
        {			
			if(GameObject.Find("fender flare fl(Clone)") != null)
			{
				Mesh new_mesh0 = LoadAssets.LoadOBJMesh(this, "fl_flare.obj");
				GameObject.Find("fender flare fl(Clone)").transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				
				UnityEngine.Object.Destroy(GameObject.Find("fender flare fl(Clone)").GetComponent<Collider>());
				BoxCollider FENDERCOLL1 = GameObject.Find("fender flare fl(Clone)").AddComponent<BoxCollider>();
				FENDERCOLL1.size = new Vector3(0.1f, 0.6f, 0.3f);
				FENDERCOLL1.center = new Vector3(0f, 0f, 0.12f);			
			}
			
			if(GameObject.Find("fender flare fr(Clone)") != null)
			{
				Mesh new_mesh1 = LoadAssets.LoadOBJMesh(this, "fr_flare.obj");
				GameObject.Find("fender flare fr(Clone)").transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				
				UnityEngine.Object.Destroy(GameObject.Find("fender flare fr(Clone)").GetComponent<Collider>());
				BoxCollider FENDERCOLL2 = GameObject.Find("fender flare fr(Clone)").AddComponent<BoxCollider>();
				FENDERCOLL2.size = new Vector3(0.1f, 0.6f, 0.3f);
				FENDERCOLL2.center = new Vector3(0f, 0f, 0.12f);
			}
			
			if(GameObject.Find("fender flare rl(Clone)") != null)
			{
				Mesh new_mesh2 = LoadAssets.LoadOBJMesh(this, "rl_flare.obj");
				GameObject.Find("fender flare rl(Clone)").transform.GetComponent<MeshFilter>().mesh = new_mesh2;
				
				UnityEngine.Object.Destroy(GameObject.Find("fender flare rl(Clone)").GetComponent<Collider>());
				BoxCollider FENDERCOLL3 = GameObject.Find("fender flare rl(Clone)").AddComponent<BoxCollider>();
				FENDERCOLL3.size = new Vector3(0.1f, 0.6f, 0.3f);
				FENDERCOLL3.center = new Vector3(0f, 0f, 0.12f);
			}
			
			if(GameObject.Find("fender flare rr(Clone)") != null)
			{
				Mesh new_mesh3 = LoadAssets.LoadOBJMesh(this, "rr_flare.obj");
				GameObject.Find("fender flare rr(Clone)").transform.GetComponent<MeshFilter>().mesh = new_mesh3;
				
				UnityEngine.Object.Destroy(GameObject.Find("fender flare rr(Clone)").GetComponent<Collider>());
				BoxCollider FENDERCOLL4 = GameObject.Find("fender flare rr(Clone)").AddComponent<BoxCollider>();
				FENDERCOLL4.size = new Vector3(0.1f, 0.6f, 0.3f);
				FENDERCOLL4.center = new Vector3(0f, 0f, 0.12f);
			}
        }
    }
}
