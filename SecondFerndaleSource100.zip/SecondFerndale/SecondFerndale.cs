﻿using System;
using MSCLoader;
using UnityEngine;
using System.Collections;
using HutongGames.PlayMaker;

namespace SecondFerndale
{
	public class SecondFerndale : Mod
    {
        public override string ID => "SecondFerndale";
        public override string Name => "SecondFerndale";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";
		
		private bool loaded;
		private Vector3 newpos;
		private Quaternion newang;
		private GameObject FERNDALE;
		private GameObject FERNCLONE;
        public override bool UseAssetsFolder => true;
		
        public override void OnLoad()
        {
			FsmVariables.GlobalVariables.FindFsmInt("PlayerKeyFerndale").Value = 1;
			FERNDALE = GameObject.Find("FERNDALE(1630kg)");
			newpos = new Vector3(-22.99983f, -0.3058776f, 33.48174f);
			newang = Quaternion.Euler(1.671524f, 122.8714f, 359.9451f);
			FERNCLONE = GameObject.Instantiate(FERNDALE, newpos, newang) as GameObject;
			FERNDALE.GetComponent<Rigidbody>().isKinematic = true;
        }
		
		public override void Update()
        {
			if(!loaded)
			{
				if(Camera.main != null)
				{
					SaveData data = SaveLoad.DeserializeSaveFile<SaveData>(this, "mySaveFile.save");
					if (data != null)
					{
						FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("FuelLevel").Value = data.save[0].fuel;
						FERNCLONE.GetComponent<Rigidbody>().isKinematic = true;
						FERNCLONE.transform.position = data.save[0].pos;
                    	FERNCLONE.transform.rotation = Quaternion.Euler(data.save[0].rotX, data.save[0].rotY, data.save[0].rotZ);
					}
					else
					{
						FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("FuelLevel").Value = 79;
						FERNCLONE.GetComponent<Rigidbody>().isKinematic = true;
						FERNCLONE.transform.position = newpos;
						FERNCLONE.transform.rotation = newang;
					}
					
					FERNCLONE.GetComponents<PlayMakerFSM>()[0].FsmVariables.GetFsmString("UniqueTagPosition").Value = "NewMuscleTransform";
					FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("UniqueTagFuelLevel").Value = "NewMuscleFuelLevel";
					FERNDALE.GetComponent<Rigidbody>().isKinematic = false;
					FERNCLONE.GetComponent<Rigidbody>().isKinematic = false;
					
					Texture2D texture1 = LoadAssets.LoadTexture(this, "muscle_dashboard.dds");
					Texture2D texture2 = LoadAssets.LoadTexture(this, "muscle_interior.dds");
					Texture2D texture3 = LoadAssets.LoadTexture(this, "muscle_paint.dds");
					Texture2D texture4 = LoadAssets.LoadTexture(this, "muscle_steering.dds");
					FERNCLONE.transform.FindChild("MESH/muscle_Scoop").gameObject.SetActive(false);
					FERNCLONE.transform.FindChild("LOD/MESH/muscle_interior").GetComponent<MeshRenderer>().material.mainTexture = texture2;
					FERNCLONE.transform.FindChild("LOD/MESH/muscle_dashboard").GetComponent<MeshRenderer>().material.mainTexture = texture1;
					FERNCLONE.transform.FindChild("LOD/MESH/muscle_chassis 1").GetComponent<MeshRenderer>().material.mainTexture = texture3;
					FERNCLONE.transform.FindChild("LOD/Dashboard/Steering/MuscleSteeringPivot/wheel_Stock").GetComponent<MeshRenderer>().material.mainTexture = texture4;
					FERNCLONE.transform.FindChild("MESH/panel").GetComponent<MeshRenderer>().material.mainTexture = texture2;
					FERNCLONE.transform.FindChild("MESH/panel 1").GetComponent<MeshRenderer>().material.mainTexture = texture2;
					FERNCLONE.transform.FindChild("MESH/muscle_body").GetComponent<MeshRenderer>().material.mainTexture = texture3;
					FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door").GetComponent<MeshRenderer>().material.mainTexture = texture3;
					FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/panel").GetComponent<MeshRenderer>().material.mainTexture = texture2;
					FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1").GetComponent<MeshRenderer>().material.mainTexture = texture3;
					FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/panel 1").GetComponent<MeshRenderer>().material.mainTexture = texture2;
					FERNCLONE.transform.FindChild("Bootlid/Bootlid/muscle_bootlid").GetComponent<MeshRenderer>().material.mainTexture = texture3;
					
					loaded = true;
				}
			}
		}
		
		public override void OnSave()
		{
			SaveData sd = new SaveData();
			SaveDataList sdl = new SaveDataList();
		    sdl.fuel = FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("FuelLevel").Value;
			sdl.pos = FERNCLONE.transform.position;
			sdl.rotX = FERNCLONE.transform.rotation.eulerAngles.x;
			sdl.rotY = FERNCLONE.transform.rotation.eulerAngles.y;
			sdl.rotZ = FERNCLONE.transform.rotation.eulerAngles.z;			
			sd.save.Add(sdl);
			SaveLoad.SerializeSaveFile(this, sd, "mySaveFile.save");		
		}
    }
}
