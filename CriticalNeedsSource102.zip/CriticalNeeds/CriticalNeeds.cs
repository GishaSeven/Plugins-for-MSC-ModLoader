﻿using HutongGames.PlayMaker;
using MSCLoader;
using UnityEngine;
using System.Collections;

namespace CriticalNeeds
{
    public class CriticalNeeds : Mod
    {
        public override string ID { get { return "CriticalNeeds"; } }
        public override string Name { get { return "Show critical needs"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.2"; } }

		public bool isUrine;
		public bool isHunger;
		public bool isThirst;
		public bool isFatigue;
		public bool isStress;
		
		public override void OnGUI()
		{
			GUIStyle myStyle = new GUIStyle();
			myStyle.fontSize = (int)(20.0f * (float)(Screen.width)/1000f);
			myStyle.normal.textColor = Color.red;
   
			if(isUrine)
			{
				GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-260)/1, Screen.width, Screen.height), "I really need to pee (" +Mathf.Round(FsmVariables.GlobalVariables.FindFsmFloat("PlayerUrine").Value - 100f) +"%)", myStyle);
			}
			
			if(isHunger)
			{
				GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-220)/1, Screen.width, Screen.height), "I really need to eat something (" +Mathf.Round(FsmVariables.GlobalVariables.FindFsmFloat("PlayerHunger").Value - 100f) +"%)", myStyle);
			}
			
			if(isThirst)
			{
				GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-180)/1, Screen.width, Screen.height), "I really need to drink something (" +Mathf.Round(FsmVariables.GlobalVariables.FindFsmFloat("PlayerThirst").Value - 100f) +"%)", myStyle);
			}
			
			if(isFatigue)
			{
				GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-140)/1, Screen.width, Screen.height), "I really need to sleep (" +Mathf.Round(FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value - 100f) +"%)", myStyle);
			}
			
			if(isStress)
			{
				GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-100)/1, Screen.width, Screen.height), "I really need to relax (" +Mathf.Round(FsmVariables.GlobalVariables.FindFsmFloat("PlayerStress").Value - 100f) +"%)", myStyle);
			}
		}
		
        public override void Update()
		{
			if(FsmVariables.GlobalVariables.FindFsmFloat("PlayerUrine").Value>180f)
			{
				isUrine = true;
			}
			else if (FsmVariables.GlobalVariables.FindFsmFloat("PlayerUrine").Value<180f)
			{
				isUrine = false;
			}
			
			if(FsmVariables.GlobalVariables.FindFsmFloat("PlayerHunger").Value>180f)
			{
				isHunger = true;
			}
			else if (FsmVariables.GlobalVariables.FindFsmFloat("PlayerHunger").Value<180f)
			{
				isHunger = false;
			}
			
			if(FsmVariables.GlobalVariables.FindFsmFloat("PlayerThirst").Value>180f)
			{
				isThirst = true;
			}
			else if (FsmVariables.GlobalVariables.FindFsmFloat("PlayerThirst").Value<180f)
			{
				isThirst = false;
			}
			
			if(FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value>180f)
			{
				isFatigue = true;
			}
			else if (FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value<180f)
			{
				isFatigue = false;
			}
			
			if(FsmVariables.GlobalVariables.FindFsmFloat("PlayerStress").Value>180f)
			{
				isStress = true;
			}
			else if (FsmVariables.GlobalVariables.FindFsmFloat("PlayerStress").Value<180f)
			{
				isStress = false;
			}
		}	
    }
}
