﻿using MSCLoader;
using UnityEngine;
using System.Threading;

namespace RacingMuffler
{
    public class RacingMuffler : Mod
    {
        public override string ID => "RacingMuffler";
        public override string Name => "Racing Muffler";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => true;
		
		private GameObject MUFFLER;

		public override void OnLoad()
        {			
			new Thread(waiting).Start();
        }
		
		private void waiting()
		{
			Thread.Sleep( 20 * 1000 );
			
			if(GameObject.Find("racing muffler(Clone)").activeSelf == true)
			{
				MUFFLER = GameObject.Find("racing muffler(Clone)");
				
				Mesh new_mesh0 = LoadAssets.LoadOBJMesh(this, "racingmuffler.obj");
				
				MUFFLER.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
			}
		}
    }
}
