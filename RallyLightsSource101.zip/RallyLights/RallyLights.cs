﻿using MSCLoader;
using UnityEngine;
using System.Collections;

namespace RallyLights
{
    public class RallyLights : Mod
    {
        public override string ID { get { return "RallyLights"; } }
        public override string Name { get { return "Rally Lights"; } }
        public override string Author { get { return "ajanhallinta, haverdaden"; } }
        public override string Version { get { return "1.0.1"; } }
		
		private bool isOff;
		private bool loaded;
		private bool ingame;
		private GameObject HandleTrigger;
		private GameObject on;
		private GameObject off;
		private GameObject lightGameObject;
		private CarDynamics CarDynam;
		private string path = ModLoader.ModsFolder+@"\RallyLights\";
		
		public override void OnLoad()
		{
			isOff = true;
		}
						
		public override void Update()
        {			
			if(Application.loadedLevelName == "GAME")
			{
				ingame = true;
			}
			else
			{
				ingame = false;
				loaded = false;
			}
			
			if (ingame && !loaded)
            {
				isOff = false;
				CreateNewObject("rallylights_on");
				CreateNewObject("rallylights_off");
				CarDynam = GameObject.Find("SATSUMA(557kg)").GetComponent<CarDynamics>();
                CreateTriggers();
				lightGameObject = new GameObject("The Light");
				Light lightComp = lightGameObject.AddComponent<Light>();
				lightComp.color = Color.white;
				lightComp.type = LightType.Spot;
				lightComp.spotAngle = 150;
				lightComp.intensity = 20;
				lightComp.range = 20;
				lightGameObject.transform.SetParent(CarDynam.transform);
				lightGameObject.transform.position = CarDynam.transform.position - new Vector3(0f, 0f, 4f);
				lightGameObject.transform.localEulerAngles= new Vector3(-40, 0, 0);
				loaded = true;
            }
						
			if(loaded)
			{
				RayCastTriggers();
			}
			
			if(isOff)
			{
				on = GameObject.Find("rallylights_on");
				on.GetComponent<MeshRenderer>().enabled = true;
				off = GameObject.Find("rallylights_off");
				off.GetComponent<MeshRenderer>().enabled = false;
				
				lightGameObject.SetActive(true);
			}
			else
			{
				on = GameObject.Find("rallylights_on");
				on.GetComponent<MeshRenderer>().enabled = false;
				off = GameObject.Find("rallylights_off");
				off.GetComponent<MeshRenderer>().enabled = true;
				
				lightGameObject.SetActive(false);
			}
        }
						
		private void RayCastTriggers()
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit, 1))
            {
                if (hit.collider.name == "Roman266")
                {
                    if (Input.GetMouseButtonDown(0))
                    {
                        isOff = !isOff;
                    }
                }
            }
        }
		
		private void CreateTriggers()
        {
            HandleTrigger = GameObject.CreatePrimitive(PrimitiveType.Cube);
            HandleTrigger.name = "Roman266";
            HandleTrigger.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);	
			HandleTrigger.transform.SetParent(CarDynam.transform);
            HandleTrigger.transform.position = CarDynam.transform.position - new Vector3(0f, -0.77f, 0.3f);			
            var col1 = HandleTrigger.GetComponent<Collider>();
            col1.isTrigger = true;
            HandleTrigger.GetComponent<MeshRenderer>().enabled = false;
        }
		
		void CreateNewObject(string ObjectName)
        {
            INIParser ini = new INIParser();
            ini.Open(path + ObjectName + ".txt");

            if (ini.ReadValue("Object", "ModelName", "") != "")
            {
                GameObject newObject = new GameObject();
                string parentName = ini.ReadValue("Object", "ParentName", "");
                string modelName = ini.ReadValue("Object", "ModelName", "");
                string textureName = ini.ReadValue("Object", "TextureName", "");
                string collisionModelName = ini.ReadValue("Object", "CollisionModelName", "");
                Vector3 localPos = StringToVector3(ini.ReadValue("Object", "localPosition", "(0, 0, 0)"));
                Vector3 localEulerAngles = StringToVector3(ini.ReadValue("Object", "localEulerAngles", "(0, 0, 0)"));
                Vector3 localScale = StringToVector3(ini.ReadValue("Object", "localScale", "(0, 0, 0)"));

                newObject.AddComponent<MeshFilter>();
                newObject.AddComponent<MeshRenderer>();
                newObject.GetComponent<MeshFilter>().mesh = LoadMesh(modelName);

                if (textureName != "")
                {
                    newObject.GetComponent<MeshRenderer>().material.mainTexture = LoadTexture(textureName).texture;
                }
                if (parentName != "")
                {
                    newObject.transform.parent = GameObject.Find(parentName).transform;
                }

                int i = 0;
                if (ini.ReadValue("Collision", "0","0") != "0")
                {
                    bool HasCollisionsLoaded = false;

                    while (!HasCollisionsLoaded)
                    {
                        string colName = ini.ReadValue("Collision", i.ToString(), "");
                        if (colName != "")
                            CreateCollision(newObject, colName);
                        else
                            HasCollisionsLoaded = true;
                        i++;
                    }
                }

                newObject.name = ObjectName;
                newObject.transform.localPosition = localPos;
                newObject.transform.localEulerAngles = localEulerAngles;
                newObject.transform.localScale = localScale;
            }
            else
            {
                ini.Close();
                return;
            }
            ini.Close();
        }

        void CreateCollision(GameObject Object, string CollisionName)
        {
            GameObject coll = new GameObject();
            coll.layer = 22;
            coll.name = CollisionName;
            coll.transform.parent = Object.transform;
            MeshCollider mc = coll.AddComponent<MeshCollider>();
            mc.sharedMesh = LoadMesh(CollisionName);
            mc.convex = true;
        }

        public Mesh LoadMesh(string modelname)
        {
            if (modelname.Contains(".obj"))
                modelname = modelname.Replace(".obj", "");

            if (!System.IO.File.Exists(path + modelname + ".obj")) { return null; }
            ObjImporter objimporter = new ObjImporter();
            Mesh holder_mesh = new Mesh();
            holder_mesh = objimporter.ImportFile(path + modelname + ".obj");
            holder_mesh.name = modelname;
            return holder_mesh;
        }

        public WWW LoadTexture(string texturename)
        {
            texturename = texturename.Replace(".png", "");
            WWW loadtexture1 = new WWW("");
            loadtexture1 = new WWW("file://" + @path + texturename + ".png");
            return loadtexture1;
        }

        public static Vector3 StringToVector3(string sVector)
        {
            if (sVector.StartsWith("(") && sVector.EndsWith(")"))
            {
                sVector = sVector.Substring(1, sVector.Length - 2);
            }

            string[] sArray = sVector.Split(',');

            Vector3 result = new Vector3(
                float.Parse(sArray[0]),
                float.Parse(sArray[1]),
                float.Parse(sArray[2]));

            return result;
        }
    }
}
