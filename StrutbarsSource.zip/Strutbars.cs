﻿using MSCLoader;
using UnityEngine;
using System.Collections;

namespace Strutbars
{
    public class Strutbars : Mod
	{
		// The ID of the mod - Should be unique
		public override string ID { get { return "Strutbars"; } }
		// The name of the mod that is displayed
		public override string Name { get { return "Strut bars"; } }
		
		// The name of the author
		public override string Author { get { return "ajanhallinta, haverdaden"; } }

		// The version of the mod
		public override string Version { get { return "1.0.0"; } }

		// Keybinds
        //private string path = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + @"\MySummerCar\Mods\";
        private string path = ModLoader.ModsFolder+@"\Strutbars\";
        // Called when the mod is loaded

        private bool loaded;
        
        void CreateNewObject(string ObjectName)
        {
            // Open INI
            INIParser ini = new INIParser();
            ini.Open(path + ObjectName + ".txt");

            if (ini.ReadValue("Object", "ModelName", "") != "")
            {
                // Init variables and get data from .txt
                GameObject newObject = new GameObject();
                string parentName = ini.ReadValue("Object", "ParentName", "");
                string modelName = ini.ReadValue("Object", "ModelName", "");
                string textureName = ini.ReadValue("Object", "TextureName", "");
                string collisionModelName = ini.ReadValue("Object", "CollisionModelName", "");
                Vector3 localPos = StringToVector3(ini.ReadValue("Object", "localPosition", "(0, 0, 0)"));
                Vector3 localEulerAngles = StringToVector3(ini.ReadValue("Object", "localEulerAngles", "(0, 0, 0)"));
                Vector3 localScale = StringToVector3(ini.ReadValue("Object", "localScale", "(0, 0, 0)"));

                // Add components to new GameObject
                newObject.AddComponent<MeshFilter>();
                newObject.AddComponent<MeshRenderer>();
                newObject.GetComponent<MeshFilter>().mesh = LoadMesh(modelName);

                // Load texture and set parent
                if (textureName != "")
                {
                    newObject.GetComponent<MeshRenderer>().material.mainTexture = LoadTexture(textureName).texture;
                }
                if (parentName != "")
                {
                    newObject.transform.parent = GameObject.Find(parentName).transform;
                }

                // Load Collisions
                int i = 0;
                if (ini.ReadValue("Collision", "0","0") != "0")
                {
                    bool HasCollisionsLoaded = false;

                    while (!HasCollisionsLoaded)
                    {
                        string colName = ini.ReadValue("Collision", i.ToString(), "");
                        if (colName != "")
                            CreateCollision(newObject, colName);
                        else
                            HasCollisionsLoaded = true;
                        i++;
                    }
                }

                // Assign newObject name and transform
                newObject.name = ObjectName;
                newObject.transform.localPosition = localPos;
                newObject.transform.localEulerAngles = localEulerAngles;
                newObject.transform.localScale = localScale;
            }
            else
            {
                ini.Close();
                return;
            }
            ini.Close();
        }

        void CreateCollision(GameObject Object, string CollisionName)
        {
            GameObject coll = new GameObject();
            coll.layer = 22;
            coll.name = CollisionName;
            coll.transform.parent = Object.transform;
            MeshCollider mc = coll.AddComponent<MeshCollider>();
            mc.sharedMesh = LoadMesh(CollisionName);
            mc.convex = true;
        }

        public Mesh LoadMesh(string modelname)
        {
            if (modelname.Contains(".obj"))
                modelname = modelname.Replace(".obj", "");

            if (!System.IO.File.Exists(path + modelname + ".obj")) { return null; }
            ObjImporter objimporter = new ObjImporter();
            Mesh holder_mesh = new Mesh();
            holder_mesh = objimporter.ImportFile(path + modelname + ".obj");
            holder_mesh.name = modelname;
            return holder_mesh;
        }

        public WWW LoadTexture(string texturename)
        {
            texturename = texturename.Replace(".png", "");
            WWW loadtexture1 = new WWW("");
            loadtexture1 = new WWW("file://" + @path + texturename + ".png");
            return loadtexture1;
        }

        public static Vector3 StringToVector3(string sVector)
        {
            // Remove the parentheses
            if (sVector.StartsWith("(") && sVector.EndsWith(")"))
            {
                sVector = sVector.Substring(1, sVector.Length - 2);
            }

            // split the items
            string[] sArray = sVector.Split(',');

            // store as a Vector3
            Vector3 result = new Vector3(
                float.Parse(sArray[0]),
                float.Parse(sArray[1]),
                float.Parse(sArray[2]));

            return result;
        }

        public override void Update()
        {
            if (Application.loadedLevelName == "GAME" && !loaded)
            {
                CreateNewObject("strutbars");
                loaded = true;

            }

            if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
    }
}
