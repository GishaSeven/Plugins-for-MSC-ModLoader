﻿using HutongGames.PlayMaker;
using MSCLoader;
using UnityEngine;

namespace Cheat
{
    public class Cheat : Mod
    {
        public override string ID { get { return "Cheat"; } }
        public override string Name { get { return "Cheat"; } }
        public override string Author { get { return "Djoe45(Edit by Roman266)"; } }
        public override string Version { get { return "1.0.2"; } }
		
		private bool loaded;
		private GameObject PLAYER;
		
        public override void Update()
        {
			if (Application.loadedLevelName == "GAME" && !loaded)
            {
				this.PLAYER = GameObject.Find("PLAYER");
			
				PlayMakerFSM[] componentsInChildren = this.PLAYER.GetComponentsInChildren<PlayMakerFSM>();
				for (int i = 0; i < componentsInChildren.Length; i++)
				{
				PlayMakerFSM playMakerFSM = componentsInChildren[i];
					if (playMakerFSM.name == "PlayerStress")
					{
						playMakerFSM.enabled = false;
					}
				
					if (playMakerFSM.name == "PlayerStressRate")
					{
						playMakerFSM.enabled = false;
					}
				}
                loaded = true;
            }
			
            if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
			
			FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value = 0.0f;
			FsmVariables.GlobalVariables.FindFsmFloat("PlayerDirtiness").Value = 0.0f;
			FsmVariables.GlobalVariables.FindFsmFloat("PlayerDrunk").Value = 0.0f;
			FsmVariables.GlobalVariables.FindFsmFloat("PlayerHunger").Value = 0.0f;
			FsmVariables.GlobalVariables.FindFsmFloat("PlayerThirst").Value = 0.0f;
			FsmVariables.GlobalVariables.FindFsmFloat("PlayerUrine").Value = 0.0f;
			FsmVariables.GlobalVariables.FindFsmFloat("PlayerStress").Value = 0.0f;
			FsmVariables.GlobalVariables.FindFsmFloat("PlayerStressRate").Value = 0.0f;
        }
    }
}
