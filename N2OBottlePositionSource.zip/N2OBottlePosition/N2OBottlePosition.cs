﻿using MSCLoader;
using UnityEngine;

namespace N2OBottlePosition
{
    public class N2OBottlePosition : Mod
    {
        public override string ID { get { return "N2OBottlePosition"; } }
        public override string Name { get { return "N2O Bottle Position"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject SATSUMA;
		private GameObject INTERIOR;
		private GameObject HOLDER;
		private GameObject TRIGGER;
		
        public override void Update()
        {
			if (Application.loadedLevelName == "GAME" && !loaded)
            {
                this.SATSUMA = GameObject.Find("SATSUMA(557kg)");
				this.INTERIOR = this.SATSUMA.transform.FindChild("Interior").gameObject;
				this.HOLDER = this.INTERIOR.transform.FindChild("n2o bottle holder(xxxxx)").gameObject;
				this.TRIGGER = this.INTERIOR.transform.FindChild("trigger_n2o_holder").gameObject;
			
				this.HOLDER.transform.localPosition = new Vector3(0.36f, -0.185f, 0.5f);
				this.HOLDER.transform.localRotation = new Quaternion(-0.119646f, -0.942f, -0.12f, 0.908800f);
				this.TRIGGER.transform.localPosition = new Vector3(0.36f, -0.185f, 0.5f);
                loaded = true;
            }

            if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
    }
}
