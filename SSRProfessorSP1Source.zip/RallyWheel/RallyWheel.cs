﻿using MSCLoader;
using UnityEngine;
using System.Threading;

namespace RallyWheel
{
    public class RallyWheel : Mod
    {
        public override string ID => "RallyWheel";
        public override string Name => "Rally Wheel";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";

        public override bool UseAssetsFolder => true;

		private GameObject FLRIM;
		private GameObject FRRIM;
		private GameObject RLRIM;
		private GameObject RRRIM;
		private GameObject SHOP;
		private GameObject SHOPLOD;
		private GameObject SHOPGFX;
		private GameObject SHOPSHELFS;
		private GameObject SHOPEQUIPM;
		private GameObject SHOPCHROME;
		
		public override void OnLoad()
        {				
			new Thread(waiting2r).Start();
        }
		
		private void waiting2r()
		{
			Thread.Sleep( 20 * 1000 );
			
			Mesh new_mesh1 = LoadAssets.LoadOBJMesh(this, "tire_rally.obj");
			
			Texture2D loadtexture2 = LoadAssets.LoadTexture(this, "tires_rally.dds");
			
			GameObject[] allObjects = UnityEngine.Object.FindObjectsOfType<GameObject>();
			foreach(GameObject findme in allObjects)
			{
				if(findme.name == "TireRally(Clone)")
				{
					findme.GetComponent<MeshFilter>().mesh = new_mesh1;
					findme.GetComponent<MeshRenderer>().material.mainTexture = loadtexture2;
				}
			}
			
			if(GameObject.Find("wheel rally fl(Clone)").activeSelf == true)
			{
				FLRIM = GameObject.Find("wheel rally fl(Clone)");
				FRRIM = GameObject.Find("wheel rally fr(Clone)");
				RLRIM = GameObject.Find("wheel rally rl(Clone)");
				RRRIM = GameObject.Find("wheel rally rr(Clone)");
				
				Mesh new_mesh0 = LoadAssets.LoadOBJMesh(this, "rim_rally.obj");
									
				FLRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				FRRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				RLRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				RRRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				
				GameObject Roman266FLRALLYCH = LoadAssets.LoadOBJ(this, "rim_rally_chrome.obj");
				Roman266FLRALLYCH.transform.parent = FLRIM.transform;
				Roman266FLRALLYCH.transform.localScale = new Vector3(1, 1, 1);
				Roman266FLRALLYCH.transform.localPosition = new Vector3(0, 0, 0);
				Roman266FLRALLYCH.transform.localEulerAngles= new Vector3(0, 0, 0);	
				GameObject Roman266FRRALLYCH = LoadAssets.LoadOBJ(this, "rim_rally_chrome.obj");
				Roman266FRRALLYCH.transform.parent = FRRIM.transform;
				Roman266FRRALLYCH.transform.localScale = new Vector3(1, 1, 1);
				Roman266FRRALLYCH.transform.localPosition = new Vector3(0, 0, 0);
				Roman266FRRALLYCH.transform.localEulerAngles= new Vector3(0, 0, 0);
				GameObject Roman266RLRALLYCH = LoadAssets.LoadOBJ(this, "rim_rally_chrome.obj");
				Roman266RLRALLYCH.transform.parent = RLRIM.transform;
				Roman266RLRALLYCH.transform.localScale = new Vector3(1, 1, 1);
				Roman266RLRALLYCH.transform.localPosition = new Vector3(0, 0, 0);
				Roman266RLRALLYCH.transform.localEulerAngles= new Vector3(0, 0, 0);
				GameObject Roman266RRRALLYCH = LoadAssets.LoadOBJ(this, "rim_rally_chrome.obj");
				Roman266RRRALLYCH.transform.parent = RRRIM.transform;
				Roman266RRRALLYCH.transform.localScale = new Vector3(1, 1, 1);
				Roman266RRRALLYCH.transform.localPosition = new Vector3(0, 0, 0);
				Roman266RRRALLYCH.transform.localEulerAngles= new Vector3(0, 0, 0);
			
				SHOP = GameObject.Find("STORE");
				SHOPLOD = SHOP.transform.FindChild("LOD").gameObject;
				SHOPGFX = SHOPLOD.transform.FindChild("GFX_Store").gameObject;
				SHOPSHELFS = SHOPGFX.transform.FindChild("StoreShelfs").gameObject;
				SHOPEQUIPM = SHOPSHELFS.transform.FindChild("store_equipment").gameObject;
				SHOPCHROME = SHOPEQUIPM.transform.FindChild("store_equipment_mirror").gameObject;
			
				Roman266FLRALLYCH.GetComponent<MeshRenderer>().material = SHOPCHROME.GetComponent<MeshRenderer>().material;
				Roman266FRRALLYCH.GetComponent<MeshRenderer>().material = SHOPCHROME.GetComponent<MeshRenderer>().material;
				Roman266RLRALLYCH.GetComponent<MeshRenderer>().material = SHOPCHROME.GetComponent<MeshRenderer>().material;
				Roman266RRRALLYCH.GetComponent<MeshRenderer>().material = SHOPCHROME.GetComponent<MeshRenderer>().material;
			}
		}
    }
}
