﻿using MSCLoader;
using UnityEngine;

namespace LowRide
{
    public class LowRide : Mod
    {
        public override string ID { get { return "LowRide"; } }
        public override string Name { get { return "Low Ride"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private GameObject SATSUMA;
		private GameObject MISCPARTS;
		private GameObject PIPE;
		private GameObject MUFFLER;
		private GameObject FUELTANK;
		private GameObject FUELTANKTR;
		private GameObject CHASSIS;
		private GameObject SUBFRAME;
		
        public override void Update()
        {
            this.SATSUMA = GameObject.Find("SATSUMA(557kg)");
			this.MISCPARTS = this.SATSUMA.transform.FindChild("MiscParts").gameObject;
			this.PIPE = this.MISCPARTS.transform.FindChild("pivot_exhaust pipe").gameObject;
			this.MUFFLER = this.MISCPARTS.transform.FindChild("pivot_exhaust_muffler").gameObject;
			this.FUELTANK = this.MISCPARTS.transform.FindChild("pivot_fuel_tank").gameObject;
			this.FUELTANKTR = this.MISCPARTS.transform.FindChild("trigger_fuel_tank").gameObject;
			this.CHASSIS = this.SATSUMA.transform.FindChild("Chassis").gameObject;
			this.SUBFRAME = this.CHASSIS.transform.FindChild("sub frame(xxxxx)").gameObject;
			
			this.PIPE.transform.localPosition = new Vector3(this.PIPE.transform.localPosition.x, 0.292f, this.PIPE.transform.localPosition.z);
			this.MUFFLER.transform.localPosition = new Vector3(this.MUFFLER.transform.localPosition.x, 0.352521f, 1.3f);
			this.FUELTANK.transform.localPosition = new Vector3(this.FUELTANK.transform.localPosition.x, 0.6f, 1.4f);
			this.FUELTANKTR.transform.localPosition = new Vector3(this.FUELTANKTR.transform.localPosition.x, 0.6f, 1.4f);
			this.SUBFRAME.transform.localPosition = new Vector3(this.SUBFRAME.transform.localPosition.x, -0.15f, this.SUBFRAME.transform.localPosition.z);
			
			GameObject.Find("SATSUMA(557kg)").GetComponent<Axles>().frontAxle.leftWheel.bumpRate = 10000f;
			GameObject.Find("SATSUMA(557kg)").GetComponent<Axles>().frontAxle.rightWheel.bumpRate = 10000f;
			GameObject.Find("SATSUMA(557kg)").GetComponent<Axles>().rearAxle.leftWheel.bumpRate = 10000f;
			GameObject.Find("SATSUMA(557kg)").GetComponent<Axles>().rearAxle.rightWheel.bumpRate = 10000f;
        }
    }
}
