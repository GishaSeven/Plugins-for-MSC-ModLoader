﻿using MSCLoader;
using System.Linq;
using UnityEngine;

namespace GearSticks
{
    public class GearSticks : Mod
    {
        public override string ID => "GearSticks";
        public override string Name => "Gear Sticks";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";
        public override string Description => "Basis for easy Satsuma gear sticks replace";

        public override void ModSetup()
        {
            SetupFunction(Setup.OnLoad, Mod_OnLoad);
        }

        private void Mod_OnLoad()
        {
            //Chrome material
			AssetBundle bundle = LoadAssets.LoadBundle(this,"material.unity3d");
			Material metallic = bundle.LoadAsset<Material>("MyMetallicMaterial.mat");
			bundle.Unload(false);
			
			//Stock stick installed
			Mesh stockmesh1 = LoadAssets.LoadOBJMesh(this, "gear_shifter.obj");
			Texture2D atlasmotor1 = LoadAssets.LoadTexture(this, "gear_shifter.dds");
			Material atlasdifuse = new Material(Shader.Find("Specular"));
			GameObject stockshiftergo = Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "gear stick(xxxxx)").transform.gameObject;
			stockshiftergo.GetComponent<MeshFilter>().sharedMesh = stockmesh1;
			stockshiftergo.GetComponent<MeshRenderer>().material = atlasdifuse;
			stockshiftergo.GetComponent<MeshRenderer>().material.mainTexture = atlasmotor1;
			
			GameObject stockshifterchrgo = LoadAssets.LoadOBJ(this, "gear_shifter_chrome.obj");
			Object.Destroy(stockshifterchrgo.GetComponent<MeshCollider>());
			stockshifterchrgo.transform.parent = stockshiftergo.transform;
			stockshifterchrgo.transform.localPosition = Vector3.zero;
			stockshifterchrgo.transform.localEulerAngles = Vector3.zero;
			stockshifterchrgo.transform.localScale = Vector3.one;
			stockshifterchrgo.GetComponent<MeshRenderer>().material = metallic;
			
			Mesh stockmesh2 = LoadAssets.LoadOBJMesh(this, "gear_shifter_001.obj");
			Texture2D atlasmotor2 = LoadAssets.LoadTexture(this, "gear_shifter_001.dds");
			GameObject stockshifter001go = Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "gear stick(xxxxx)").transform.Find("GearLever/Pivot/Lever/gear_stick").gameObject;
			stockshifter001go.GetComponent<MeshFilter>().sharedMesh = stockmesh2;
			stockshifter001go.GetComponent<MeshRenderer>().material = atlasdifuse;
			stockshifter001go.GetComponent<MeshRenderer>().material.mainTexture = atlasmotor2;
			
			GameObject stockshifter001chrgo = LoadAssets.LoadOBJ(this, "gear_shifter_001_chrome.obj");
			Object.Destroy(stockshifter001chrgo.GetComponent<MeshCollider>());
			stockshifter001chrgo.transform.parent = stockshifter001go.transform;
			stockshifter001chrgo.transform.localPosition = Vector3.zero;
			stockshifter001chrgo.transform.localEulerAngles = Vector3.zero;
			stockshifter001chrgo.transform.localScale = Vector3.one;
			stockshifter001chrgo.GetComponent<MeshRenderer>().material = metallic;
			
			//GT console installed
			Mesh gtmesh1 = LoadAssets.LoadOBJMesh(this, "center_console_gt.obj");
			Texture2D atlasmotor3 = LoadAssets.LoadTexture(this, "center_console_gt.dds");
			GameObject gtshiftergo = Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "center console gt(xxxxx)").transform.gameObject;
			gtshiftergo.GetComponent<MeshFilter>().sharedMesh = gtmesh1;
			gtshiftergo.GetComponent<MeshRenderer>().material = atlasdifuse;
			gtshiftergo.GetComponent<MeshRenderer>().material.mainTexture = atlasmotor3;
			
			GameObject gtshifterchrgo = LoadAssets.LoadOBJ(this, "center_console_gt_chrome.obj");
			Object.Destroy(gtshifterchrgo.GetComponent<MeshCollider>());
			gtshifterchrgo.transform.parent = gtshiftergo.transform;
			gtshifterchrgo.transform.localPosition = Vector3.zero;
			gtshifterchrgo.transform.localEulerAngles = Vector3.zero;
			gtshifterchrgo.transform.localScale = Vector3.one;
			gtshifterchrgo.GetComponent<MeshRenderer>().material = metallic;
			
			Mesh gtmesh2 = LoadAssets.LoadOBJMesh(this, "gear_stick_gt.obj");
			Texture2D atlasmotor4 = LoadAssets.LoadTexture(this, "gear_stick_gt.dds");
			GameObject gtshifter001go = Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "center console gt(xxxxx)").transform.Find("GearLever/Pivot/Lever/gear_stick").gameObject;
			gtshifter001go.GetComponent<MeshFilter>().sharedMesh = gtmesh2;
			gtshifter001go.GetComponent<MeshRenderer>().material = atlasdifuse;
			gtshifter001go.GetComponent<MeshRenderer>().material.mainTexture = atlasmotor4;
			
			GameObject gtshifter001chrgo = LoadAssets.LoadOBJ(this, "gear_stick_gt_chrome.obj");
			Object.Destroy(gtshifter001chrgo.GetComponent<MeshCollider>());
			gtshifter001chrgo.transform.parent = gtshifter001go.transform;
			gtshifter001chrgo.transform.localPosition = Vector3.zero;
			gtshifter001chrgo.transform.localEulerAngles = Vector3.zero;
			gtshifter001chrgo.transform.localScale = Vector3.one;
			gtshifter001chrgo.GetComponent<MeshRenderer>().material = metallic;
			
			//Stock stick uninstalled
			foreach (GameObject stockshiftergo2 in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "gear stick(Clone)"))
			{
				stockshiftergo2.GetComponent<MeshFilter>().sharedMesh = stockmesh1;
				stockshiftergo2.GetComponent<MeshRenderer>().material = atlasdifuse;
				stockshiftergo2.GetComponent<MeshRenderer>().material.mainTexture = atlasmotor1;
				
				GameObject stockshifterchrgo2 = LoadAssets.LoadOBJ(this, "gear_shifter_chrome.obj");
				Object.Destroy(stockshifterchrgo2.GetComponent<MeshCollider>());
				stockshifterchrgo2.transform.parent = stockshiftergo2.transform;
				stockshifterchrgo2.transform.localPosition = Vector3.zero;
				stockshifterchrgo2.transform.localEulerAngles = Vector3.zero;
				stockshifterchrgo2.transform.localScale = Vector3.one;
				stockshifterchrgo2.GetComponent<MeshRenderer>().material = metallic;
				
				GameObject stockshifter001go2 = stockshiftergo2.transform.Find("gear_stick").gameObject;
				stockshifter001go2.GetComponent<MeshFilter>().sharedMesh = stockmesh2;
				stockshifter001go2.GetComponent<MeshRenderer>().material = atlasdifuse;
				stockshifter001go2.GetComponent<MeshRenderer>().material.mainTexture = atlasmotor2;
			
				GameObject stockshifter001chrgo2 = LoadAssets.LoadOBJ(this, "gear_shifter_001_chrome.obj");
				Object.Destroy(stockshifter001chrgo2.GetComponent<MeshCollider>());
				stockshifter001chrgo2.transform.parent = stockshifter001go2.transform;
				stockshifter001chrgo2.transform.localPosition = Vector3.zero;
				stockshifter001chrgo2.transform.localEulerAngles = Vector3.zero;
				stockshifter001chrgo2.transform.localScale = Vector3.one;
				stockshifter001chrgo2.GetComponent<MeshRenderer>().material = metallic;
			}
			
			foreach (GameObject stockshiftergo2 in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "gear stick"))
			{
				stockshiftergo2.GetComponent<MeshFilter>().sharedMesh = stockmesh1;
				stockshiftergo2.GetComponent<MeshRenderer>().material = atlasdifuse;
				stockshiftergo2.GetComponent<MeshRenderer>().material.mainTexture = atlasmotor1;
				
				GameObject stockshifterchrgo2 = LoadAssets.LoadOBJ(this, "gear_shifter_chrome.obj");
				Object.Destroy(stockshifterchrgo2.GetComponent<MeshCollider>());
				stockshifterchrgo2.transform.parent = stockshiftergo2.transform;
				stockshifterchrgo2.transform.localPosition = Vector3.zero;
				stockshifterchrgo2.transform.localEulerAngles = Vector3.zero;
				stockshifterchrgo2.transform.localScale = Vector3.one;
				stockshifterchrgo2.GetComponent<MeshRenderer>().material = metallic;
				
				GameObject stockshifter001go2 = stockshiftergo2.transform.Find("gear_stick").gameObject;
				stockshifter001go2.GetComponent<MeshFilter>().sharedMesh = stockmesh2;
				stockshifter001go2.GetComponent<MeshRenderer>().material = atlasdifuse;
				stockshifter001go2.GetComponent<MeshRenderer>().material.mainTexture = atlasmotor2;
			
				GameObject stockshifter001chrgo2 = LoadAssets.LoadOBJ(this, "gear_shifter_001_chrome.obj");
				Object.Destroy(stockshifter001chrgo2.GetComponent<MeshCollider>());
				stockshifter001chrgo2.transform.parent = stockshifter001go2.transform;
				stockshifter001chrgo2.transform.localPosition = Vector3.zero;
				stockshifter001chrgo2.transform.localEulerAngles = Vector3.zero;
				stockshifter001chrgo2.transform.localScale = Vector3.one;
				stockshifter001chrgo2.GetComponent<MeshRenderer>().material = metallic;
			}
			
			//GT console uninstalled
			foreach (GameObject gtshiftergo2 in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "center console gt(Clone)"))
			{
				gtshiftergo2.GetComponent<MeshFilter>().sharedMesh = gtmesh1;
				gtshiftergo2.GetComponent<MeshRenderer>().material = atlasdifuse;
				gtshiftergo2.GetComponent<MeshRenderer>().material.mainTexture = atlasmotor3;
				
				GameObject gtshifterchrgo2 = LoadAssets.LoadOBJ(this, "center_console_gt_chrome.obj");
				Object.Destroy(gtshifterchrgo2.GetComponent<MeshCollider>());
				gtshifterchrgo2.transform.parent = gtshiftergo2.transform;
				gtshifterchrgo2.transform.localPosition = Vector3.zero;
				gtshifterchrgo2.transform.localEulerAngles = Vector3.zero;
				gtshifterchrgo2.transform.localScale = Vector3.one;
				gtshifterchrgo2.GetComponent<MeshRenderer>().material = metallic;
				
				GameObject gtshifter001go2 = gtshiftergo2.transform.Find("gear_stick").gameObject;
				gtshifter001go2.GetComponent<MeshFilter>().sharedMesh = gtmesh2;
				gtshifter001go2.GetComponent<MeshRenderer>().material = atlasdifuse;
				gtshifter001go2.GetComponent<MeshRenderer>().material.mainTexture = atlasmotor4;
				
				GameObject gtshifter001chrgo2 = LoadAssets.LoadOBJ(this, "gear_stick_gt_chrome.obj");
				Object.Destroy(gtshifter001chrgo2.GetComponent<MeshCollider>());
				gtshifter001chrgo2.transform.parent = gtshifter001go2.transform;
				gtshifter001chrgo2.transform.localPosition = Vector3.zero;
				gtshifter001chrgo2.transform.localEulerAngles = Vector3.zero;
				gtshifter001chrgo2.transform.localScale = Vector3.one;
				gtshifter001chrgo2.GetComponent<MeshRenderer>().material = metallic;
			}
			
			foreach (GameObject gtshiftergo2 in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "center console gt"))
			{
				gtshiftergo2.GetComponent<MeshFilter>().sharedMesh = gtmesh1;
				gtshiftergo2.GetComponent<MeshRenderer>().material = atlasdifuse;
				gtshiftergo2.GetComponent<MeshRenderer>().material.mainTexture = atlasmotor3;
				
				GameObject gtshifterchrgo2 = LoadAssets.LoadOBJ(this, "center_console_gt_chrome.obj");
				Object.Destroy(gtshifterchrgo2.GetComponent<MeshCollider>());
				gtshifterchrgo2.transform.parent = gtshiftergo2.transform;
				gtshifterchrgo2.transform.localPosition = Vector3.zero;
				gtshifterchrgo2.transform.localEulerAngles = Vector3.zero;
				gtshifterchrgo2.transform.localScale = Vector3.one;
				gtshifterchrgo2.GetComponent<MeshRenderer>().material = metallic;
				
				GameObject gtshifter001go2 = gtshiftergo2.transform.Find("gear_stick").gameObject;
				gtshifter001go2.GetComponent<MeshFilter>().sharedMesh = gtmesh2;
				gtshifter001go2.GetComponent<MeshRenderer>().material = atlasdifuse;
				gtshifter001go2.GetComponent<MeshRenderer>().material.mainTexture = atlasmotor4;
				
				GameObject gtshifter001chrgo2 = LoadAssets.LoadOBJ(this, "gear_stick_gt_chrome.obj");
				Object.Destroy(gtshifter001chrgo2.GetComponent<MeshCollider>());
				gtshifter001chrgo2.transform.parent = gtshifter001go2.transform;
				gtshifter001chrgo2.transform.localPosition = Vector3.zero;
				gtshifter001chrgo2.transform.localEulerAngles = Vector3.zero;
				gtshifter001chrgo2.transform.localScale = Vector3.one;
				gtshifter001chrgo2.GetComponent<MeshRenderer>().material = metallic;
			}
        }
    }
}
