﻿using System;

namespace LanguageFramework
{		
	public enum SceneType
	{
		None,
		MainMenu,
		Game
	}
}
