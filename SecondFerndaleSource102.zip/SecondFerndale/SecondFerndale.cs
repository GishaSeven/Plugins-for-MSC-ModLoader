﻿using MSCLoader;
using UnityEngine;
using HutongGames.PlayMaker;
using System.Linq;
using System.Collections.Generic;
using HutongGames.PlayMaker.Actions;

namespace SecondFerndale
{
	public class SecondFerndale : Mod
    {
        public override string ID => "SecondFerndale";
        public override string Name => "SecondFerndale";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";
		
		private Vector3 newpos;
		private Quaternion newang;
		private GameObject FERNCLONE;
		private GameObject MUSCLECOLLIDERS;
		public override bool LoadInMenu => true;
        public override bool UseAssetsFolder => true;
		
		public override void OnMenuLoad() 
		{
			SaveData data = SaveLoad.DeserializeSaveFile<SaveData>(this, "mySaveFile.save");
            if (data != null)
            {
                AssetBundle colliders = LoadAssets.LoadBundle(this,"colliders.unity3d");
				GameObject musclecolliders0 = colliders.LoadAsset("muscle_colliders.prefab") as GameObject;
				MUSCLECOLLIDERS = GameObject.Instantiate<GameObject>(musclecolliders0);
				colliders.Unload(false);
				Object.Destroy(musclecolliders0);
				
                MUSCLECOLLIDERS.transform.position = data.save[0].pos;
                MUSCLECOLLIDERS.transform.rotation = Quaternion.Euler(data.save[0].rotX, data.save[0].rotY, data.save[0].rotZ);
				
				Object.DontDestroyOnLoad(MUSCLECOLLIDERS);
            }
		}
		
        public override void OnLoad()
        {
			FsmVariables.GlobalVariables.FindFsmInt("PlayerKeyFerndale").Value = 1;

            newpos = new Vector3(-22.99983f, -0.3058776f, 33.48174f);
            newang = Quaternion.Euler(1.671524f, 122.8714f, 359.9451f);
            FERNCLONE = Object.Instantiate(GameObject.Find("FERNDALE(1630kg)"));

            // FRED TWEAK
            FERNCLONE.name = "SECONDFERNDALE(1630kg)";
            foreach (PlayMakerFSM playmaker in FERNCLONE.GetComponentsInChildren<PlayMakerFSM>().Where(fsm => fsm.FsmStates.Any(state => state.Name != null && (state.Name == "Load game" || state.Name == "Save game"))))
                foreach (FsmState state in playmaker.FsmStates.Where(state => state.Name == "Load game" || state.Name == "Save game"))
                    state.Actions = new FsmStateAction[0];

            // GASOLINE INDICATOR
            Transform indicators = GameObject.Find("GUI/Indicators/Fluids").transform;
            GameObject gasolineIndicator = Object.Instantiate(indicators.Find("GasolineMuscle").gameObject);
            gasolineIndicator.name = "GasolineSecondFerndaleMOD";
            gasolineIndicator.transform.GetChild(1).GetComponent<PlayMakerFSM>().FsmVariables.FindFsmGameObject("Tank").Value = FERNCLONE.transform.Find("FuelTank").gameObject;
            gasolineIndicator.SetActive(false);
            gasolineIndicator.transform.parent = indicators;
            gasolineIndicator.transform.localPosition = Vector3.zero;
            gasolineIndicator.transform.localEulerAngles = Vector3.zero;

            FERNCLONE.transform.Find("LOD/FuelFiller 1/OpenCap/CapTrigger_FuelFerndale").GetComponent<PlayMakerFSM>().FsmVariables.FindFsmGameObject("VehicleGUI").Value = gasolineIndicator;
			
            // FIX DUAL SHIFTING AND INPUT
            string playerCarName = "SecondFerndale";
            bool lodActive = FERNCLONE.transform.Find("LOD").gameObject.activeSelf;
            FERNCLONE.transform.Find("LOD").gameObject.SetActive(true);
			
            (FERNCLONE.transform.Find("LOD/PlayerTrigger/DriveTrigger").GetComponent<PlayMakerFSM>().FsmStates.First(state => state.Name == "Player in car").Actions[15] as SetStringValue).stringValue = playerCarName;
			
            // GEAR
            foreach (FsmState state in FERNCLONE.transform.Find("LOD/Dashboard/GearShifter/Pivot").GetComponent<PlayMakerFSM>().FsmStates.Where(state => state.Name.Contains("In car")))
                (state.Actions[0] as StringCompare).compareTo = playerCarName;

            // LIGHTS
            (FERNCLONE.transform.Find("LOD/Dashboard/Knobs/Lights").GetComponent<PlayMakerFSM>().FsmStates.First(state => state.Name == "Check down").Actions[0] as StringCompare).compareTo = playerCarName;

            // WIPERS
            (FERNCLONE.transform.Find("LOD/Dashboard/Knobs/ButtonWipers").GetComponent<PlayMakerFSM>().FsmStates.First(state => state.Name == "Check car").Actions[0] as StringCompare).compareTo = playerCarName;

            // INDICATORS
            (FERNCLONE.transform.Find("LOD/Dashboard/TurnSignals").GetComponent<PlayMakerFSM>().FsmStates.First(state => state.Name == "State 2").Actions[2] as StringCompare).compareTo = playerCarName;

            FERNCLONE.transform.Find("LOD").gameObject.SetActive(lodActive);
            // FRED TWEAK
			
            SaveData data = SaveLoad.DeserializeSaveFile<SaveData>(this, "mySaveFile.save");
            if (data != null)
            {
                FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("FuelLevel").Value = data.save[0].fuel;
                
				Object.Destroy(MUSCLECOLLIDERS);
				
				FERNCLONE.transform.position = data.save[0].pos;
                FERNCLONE.transform.rotation = Quaternion.Euler(data.save[0].rotX, data.save[0].rotY, data.save[0].rotZ);
            }
            else
            {
                FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("FuelLevel").Value = 79;
                FERNCLONE.transform.position = newpos;
                FERNCLONE.transform.rotation = newang;
            }

            FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("UniqueTagFuelLevel").Value = "NewMuscleFuelLevel";

            Texture2D texture1 = LoadAssets.LoadTexture(this, "muscle_dashboard.dds");
            Texture2D texture2 = LoadAssets.LoadTexture(this, "muscle_interior.dds");
            Texture2D texture3 = LoadAssets.LoadTexture(this, "muscle_paint.dds");
            Texture2D texture4 = LoadAssets.LoadTexture(this, "muscle_steering.dds");
            FERNCLONE.transform.FindChild("MESH/muscle_Scoop").gameObject.SetActive(false);
            FERNCLONE.transform.FindChild("LOD/MESH/muscle_interior").GetComponent<MeshRenderer>().material.mainTexture = texture2;
            FERNCLONE.transform.FindChild("LOD/MESH/muscle_dashboard").GetComponent<MeshRenderer>().material.mainTexture = texture1;
            FERNCLONE.transform.FindChild("LOD/MESH/muscle_chassis 1").GetComponent<MeshRenderer>().material.mainTexture = texture3;
            FERNCLONE.transform.FindChild("LOD/Dashboard/Steering/MuscleSteeringPivot/wheel_Stock").GetComponent<MeshRenderer>().material.mainTexture = texture4;
            FERNCLONE.transform.FindChild("MESH/panel").GetComponent<MeshRenderer>().material.mainTexture = texture2;
            FERNCLONE.transform.FindChild("MESH/panel 1").GetComponent<MeshRenderer>().material.mainTexture = texture2;
            FERNCLONE.transform.FindChild("MESH/muscle_body").GetComponent<MeshRenderer>().material.mainTexture = texture3;
            FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door").GetComponent<MeshRenderer>().material.mainTexture = texture3;
            FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/panel").GetComponent<MeshRenderer>().material.mainTexture = texture2;
            FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1").GetComponent<MeshRenderer>().material.mainTexture = texture3;
            FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/panel 1").GetComponent<MeshRenderer>().material.mainTexture = texture2;
            FERNCLONE.transform.FindChild("Bootlid/Bootlid/muscle_bootlid").GetComponent<MeshRenderer>().material.mainTexture = texture3;
        }
	
		public override void OnSave()
		{
			SaveData sd = new SaveData();
			SaveDataList sdl = new SaveDataList();
		    sdl.fuel = FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("FuelLevel").Value;
			sdl.pos = FERNCLONE.transform.position;
			sdl.rotX = FERNCLONE.transform.rotation.eulerAngles.x;
			sdl.rotY = FERNCLONE.transform.rotation.eulerAngles.y;
			sdl.rotZ = FERNCLONE.transform.rotation.eulerAngles.z;			
			sd.save.Add(sdl);
			SaveLoad.SerializeSaveFile(this, sd, "mySaveFile.save");		
		}
    }
}
