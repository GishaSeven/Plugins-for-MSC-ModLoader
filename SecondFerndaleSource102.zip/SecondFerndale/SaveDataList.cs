﻿using System;
using UnityEngine;

namespace SecondFerndale
{
    public class SaveDataList
    {
		public float fuel;
		public Vector3 pos;
		public float rotX, rotY, rotZ;
    }
}
