﻿using MSCLoader;
using UnityEngine;

namespace Grille
{
    public class Grille : Mod
    {
        public override string ID => "Grille";
        public override string Name => "Grille";
        public override string Author => "Roman266";
        public override string Version => "1.0.2";

        public override bool UseAssetsFolder => true;
		
		public override void OnLoad()
        {										
			Mesh new_mesh0 = LoadAssets.LoadOBJMesh(this, "grille.obj");	
			GameObject.Find("grille(Clone)").transform.GetComponent<MeshFilter>().mesh = new_mesh0;	
			GameObject.Find("grille(Clone)").transform.GetComponent<Renderer>().materials[1].color = new Color(0f, 0f, 0f, 0f);
        }
    }
}
