﻿using System;
using UnityEngine;
using System.Collections.Generic;

namespace GAZ24
{
    public class SaveData
    {
		public List<SaveDataList> save = new List<SaveDataList>();
    }
}
