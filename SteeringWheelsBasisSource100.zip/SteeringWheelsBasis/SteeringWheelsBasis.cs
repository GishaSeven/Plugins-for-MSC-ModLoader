﻿using MSCLoader;
using System.Linq;
using UnityEngine;

namespace SteeringWheelsBasis
{
    public class SteeringWheelsBasis : Mod
    {
        public override string ID => "SteeringWheelsBasis";
        public override string Name => "Steering Wheels Basis";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";

        public override bool UseAssetsFolder => true;
		
		public override void OnLoad()
        {			
			//Chrome material
			AssetBundle bundle = LoadAssets.LoadBundle(this,"material.unity3d");
			Material metallic = bundle.LoadAsset<Material>("MyMetallicMaterial.mat");
			bundle.Unload(false); 
			
			//Stock steering wheel
			Mesh stockmesh = LoadAssets.LoadOBJMesh(this, "stock.obj");
			Texture2D stocktexture = LoadAssets.LoadTexture(this, "stock.dds");
			GameObject stockgo = GameObject.Find("stock steering wheel(Clone)").gameObject;
			stockgo.GetComponent<MeshFilter>().sharedMesh = stockmesh;
			stockgo.GetComponent<MeshRenderer>().material.mainTexture = stocktexture;
			
			GameObject stockchromego = LoadAssets.LoadOBJ(this, "stock_chrome.obj");
			Object.Destroy(stockchromego.GetComponent<MeshCollider>());
			stockchromego.transform.parent = stockgo.transform;
			stockchromego.transform.localPosition = Vector3.zero;
			stockchromego.transform.localEulerAngles = Vector3.zero;
			stockchromego.transform.localScale = Vector3.one;
			stockchromego.GetComponent<MeshRenderer>().material = metallic;
			
			//GT steering wheel
			GameObject gtgonew = LoadAssets.LoadOBJ(this, "gt.obj");
			Object.Destroy(gtgonew.GetComponent<MeshCollider>());
			Texture2D gttexture = LoadAssets.LoadTexture(this, "gt.dds");
			GameObject gtgo = GameObject.Find("gt steering wheel(Clone)").gameObject;
			gtgonew.GetComponent<MeshRenderer>().material = gtgo.GetComponent<MeshRenderer>().materials[1];
			gtgonew.GetComponent<MeshRenderer>().material.mainTexture = gttexture;
			Object.Destroy(gtgo.GetComponent<MeshRenderer>());
			gtgonew.transform.parent = gtgo.transform;
			gtgonew.transform.localPosition = Vector3.zero;
			gtgonew.transform.localEulerAngles = Vector3.zero;
			gtgonew.transform.localScale = Vector3.one;
			
			GameObject gtchromego = LoadAssets.LoadOBJ(this, "gt_chrome.obj");
			Object.Destroy(gtchromego.GetComponent<MeshCollider>());
			gtchromego.transform.parent = gtgo.transform;
			gtchromego.transform.localPosition = Vector3.zero;
			gtchromego.transform.localEulerAngles = Vector3.zero;
			gtchromego.transform.localScale = Vector3.one;
			gtchromego.GetComponent<MeshRenderer>().material = metallic;
			
			//Sport steering wheel
			Mesh sportmesh = LoadAssets.LoadOBJMesh(this, "sport.obj");
			Texture2D sporttexture = LoadAssets.LoadTexture(this, "sport.dds");

			foreach (GameObject steeringwheel in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "sport steering wheel(Clone)" && g.GetComponent<MeshFilter>() !=null))
            {
				steeringwheel.GetComponent<MeshFilter>().sharedMesh = sportmesh;
				steeringwheel.GetComponent<MeshRenderer>().material = stockgo.GetComponent<MeshRenderer>().material;
				steeringwheel.GetComponent<MeshRenderer>().material.mainTexture = sporttexture;
					
				GameObject sportchromego = LoadAssets.LoadOBJ(this, "sport_chrome.obj");
				Object.Destroy(sportchromego.GetComponent<MeshCollider>());
				sportchromego.transform.parent = steeringwheel.transform;
				sportchromego.transform.localPosition = Vector3.zero;
				sportchromego.transform.localEulerAngles = Vector3.zero;
				sportchromego.transform.localScale = Vector3.one;
				sportchromego.GetComponent<MeshRenderer>().material = metallic;
            }
			
			//Rally steering wheel
			Mesh rallymesh = LoadAssets.LoadOBJMesh(this, "rally.obj");
			Texture2D rallytexture = LoadAssets.LoadTexture(this, "rally.dds");
			Texture2D rallystexture = LoadAssets.LoadTexture(this, "rally_s.dds");
			
			foreach (GameObject steeringwheel in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "rally steering wheel(Clone)" && g.GetComponent<MeshFilter>() !=null))
			{
				steeringwheel.GetComponent<MeshFilter>().sharedMesh = rallymesh;
				steeringwheel.GetComponent<MeshRenderer>().material.mainTexture = rallytexture;
				steeringwheel.GetComponent<MeshRenderer>().material.SetTexture("_SpecGlossMap", rallystexture);
				
				GameObject rallychromego = LoadAssets.LoadOBJ(this, "rally_chrome.obj");
				Object.Destroy(rallychromego.GetComponent<MeshCollider>());
				rallychromego.transform.parent = steeringwheel.transform;
				rallychromego.transform.localPosition = Vector3.zero;
				rallychromego.transform.localEulerAngles = Vector3.zero;
				rallychromego.transform.localScale = Vector3.one;
				rallychromego.GetComponent<MeshRenderer>().material = metallic;
			}
        }
    }
}
