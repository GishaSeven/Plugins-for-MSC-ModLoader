﻿using MSCLoader;
using UnityEngine;
using System.Linq;

namespace Textures
{
    public class Textures : Mod
    {
        public override string ID => "Textures";
        public override string Name => "Textures";
        public override string Author => "Roman266";
        public override string Version => "1.0.3";

		public override bool LoadInMenu => true;
		public override bool UseAssetsFolder => true;
		private Keybind ReloadTexturesKey = new Keybind("Reload Textures", "Reload Textures", KeyCode.F5);
		
		public override void OnMenuLoad() 
		{
			LoadTextures();
        }
		
		public override void OnLoad()
		{
			Keybind.Add(this, ReloadTexturesKey);
			
			LoadTextures();
        }
		
		public override void Update()
        {
			if (ReloadTexturesKey.IsDown()) 
			{ 
				LoadTextures();
			}
		}
		
		private void LoadTextures()
		{	
			if(Application.loadedLevelName == "MainMenu")
			{
				Texture2D texture1 = LoadAssets.LoadTexture(this, "drivers_lincence.dds");
			
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Licence") >= 0).FirstOrDefault().transform.Find("Card/mesh").GetComponent<MeshRenderer>().material.mainTexture = texture1;
			}

			if(Application.loadedLevelName == "GAME")
			{
				Texture2D texture2 = LoadAssets.LoadTexture(this, "repairshop_01.dds");
				Texture2D texture3 = LoadAssets.LoadTexture(this, "repairshop_02.dds");
				Texture2D texture4 = LoadAssets.LoadTexture(this, "repairshop_03.dds");
				Texture2D texture5 = LoadAssets.LoadTexture(this, "repairshop_04.dds");
				Texture2D texture6 = LoadAssets.LoadTexture(this, "repairshop_05.dds");
				Texture2D texture7 = LoadAssets.LoadTexture(this, "repairshop_06.dds");
				Texture2D texture8 = LoadAssets.LoadTexture(this, "repairshop_07.dds");
				Texture2D texture9 = LoadAssets.LoadTexture(this, "repairshop_08.dds");
			
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/PageFront/bg").GetComponent<MeshRenderer>().material.mainTexture = texture2;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/PageMisc/bg").GetComponent<MeshRenderer>().material.mainTexture = texture3;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/PageGearing/bg").GetComponent<MeshRenderer>().material.mainTexture = texture4;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/PageMetalwork/bg").GetComponent<MeshRenderer>().material.mainTexture = texture5;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/PagePaintCar/bg").GetComponent<MeshRenderer>().material.mainTexture = texture6;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/PagePaintRims/bg").GetComponent<MeshRenderer>().material.mainTexture = texture7;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/Background").GetComponent<MeshRenderer>().material.mainTexture = texture8;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/PageTirejob/bg").GetComponent<MeshRenderer>().material.mainTexture = texture9;
				
				if(GameObject.Find("register plate(Clone)") == null)
				{
					Texture2D texture10 = LoadAssets.LoadTexture(this, "inspection_recipiet_fi.dds");
					Texture2D texture11 = LoadAssets.LoadTexture(this, "inspection_recipiet_en.dds");
					Texture2D texture12 = LoadAssets.LoadTexture(this, "inspection_fail.dds");
					Texture2D texture13 = LoadAssets.LoadTexture(this, "inspection_pass.dds");
				
					Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("InspectionRecipiet/Background_FI").GetComponent<MeshRenderer>().material.mainTexture = texture10;
					Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("InspectionRecipiet/Background_EN").GetComponent<MeshRenderer>().material.mainTexture = texture11;
					Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("InspectionRecipiet/Checkmarks/ResultFail").GetComponent<MeshRenderer>().material.mainTexture = texture12;
					Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("InspectionRecipiet/Checkmarks/ResultPass").GetComponent<MeshRenderer>().material.mainTexture = texture13;
				}
			}
		}
    }
}
