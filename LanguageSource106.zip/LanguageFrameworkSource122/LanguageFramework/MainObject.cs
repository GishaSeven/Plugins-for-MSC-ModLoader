﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace LanguageFramework
{
    public class MainObject : MonoBehaviour
    {		
		private LanguageFramework _lang;
		private TextMesh _dayTextMesh;
		private TextMesh _subtitleMesh;
		private TextMesh _subtitleShadow;
		private TextMesh _subtitleParts;
		private TextMesh _subtitlePartsShadow;
		private TextMesh _interaction;
		private TextMesh _interactionShadow;
		private TextMesh _gear;
		private TextMesh _gearShadow;
		private TextMesh _rally;
		private TextMesh _rallyShadow;
		private Dictionary<string, string> _pairs = new Dictionary<string, string>();
		private bool _isLoaded;
		
		public void SetMod(LanguageFramework lang)
		{
			this._lang = lang;
			this._dayTextMesh = lang.GetTextMesh("GUI/HUD/Day/HUDValue");
			this._subtitleMesh = lang.GetTextMesh("GUI/Indicators/Subtitles");
			this._subtitleShadow = lang.GetTextMesh("GUI/Indicators/Subtitles/Shadow");
			this._subtitleParts = lang.GetTextMesh("GUI/Indicators/Partname");
			this._subtitlePartsShadow = lang.GetTextMesh("GUI/Indicators/Partname/Shadow");
			this._interaction = lang.GetTextMesh("GUI/Indicators/Interaction");
			this._interactionShadow = lang.GetTextMesh("GUI/Indicators/Interaction/Shadow");
			this._subtitleParts = lang.GetTextMesh("GUI/Indicators/Partname");
			this._subtitlePartsShadow = lang.GetTextMesh("GUI/Indicators/Partname/Shadow");
			this._gear = lang.GetTextMesh("GUI/Indicators/Gear");
			this._gearShadow = lang.GetTextMesh("GUI/Indicators/Gear/Shadow");
			this._rally = lang.GetTextMesh("GUI/Indicators/RallyCountdown");
			this._rallyShadow = lang.GetTextMesh("GUI/Indicators/RallyCountdown/Shadow");
			this._isLoaded = true;
		}
		
		private void LateUpdate()
		{
			bool flag = !this._isLoaded;
			if (!flag)
			{
				this.UpdateTextMeshes(new TextMesh[]
				{
					this._dayTextMesh
				});
				this.UpdateTextMeshes(new TextMesh[]
				{
					this._subtitleMesh,
					this._subtitleShadow
				});
				this.UpdateTextMeshes(new TextMesh[]
				{
					this._subtitleParts,
					this._subtitlePartsShadow
				});
				this.UpdateTextMeshes(new TextMesh[]
				{
					this._interaction,
					this._interactionShadow
				});
				this.UpdateTextMeshes(new TextMesh[]
				{
					this._gear,
					this._gearShadow
				});
				this.UpdateTextMeshes(new TextMesh[]
				{
					this._rally,
					this._rallyShadow
				});
			}
		}
		
		private void UpdateTextMeshes(params TextMesh[] textMeshes)
		{
			string text = textMeshes[0].text;
			bool flag = string.IsNullOrEmpty(text);
			if (!flag)
			{
				bool flag2 = !text.Equals(this.GetPairsOldText(text));
				if (flag2)
				{
					string translatedText = this._lang.GetTranslatedText(text);
					bool flag3 = !string.IsNullOrEmpty(translatedText);
					if (flag3)
					{
						this._pairs[text] = translatedText;
						int num = textMeshes.Length;
						for (int i = 0; i < num; i++)
						{
							textMeshes[i].text = translatedText;
						}
					}
				}
			}
		}
		
		private string GetPairsOldText(string original)
		{
			string text;
			bool flag = this._pairs.TryGetValue(StringExtensions.FormatUpperKey(original), out text);
			string result;
			if (flag)
			{
				result = text;
			}
			else
			{
				result = string.Empty;
			}
			return result;
		}
    }
}
