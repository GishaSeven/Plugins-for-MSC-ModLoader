﻿using System;

namespace LanguageFramework
{
    public static class StringExtensions
    {
		private static readonly char[] _trims = new char[]
		{
			' ',
			'\t',
			'\n',
			'\r'
		};

		public static string TrimStartEnd(this string original)
		{
			original = original.TrimStart(StringExtensions._trims).TrimEnd(StringExtensions._trims);
			return original;
		}

		public static string FormatUpperKey(this string original)
		{
			original = original.TrimStart(StringExtensions._trims).TrimEnd(StringExtensions._trims);
			original = original.Replace(" ", string.Empty).Replace("\n", string.Empty).Replace("\r", string.Empty);
			original = original.ToUpper();
			return original;
		}
	}
}
