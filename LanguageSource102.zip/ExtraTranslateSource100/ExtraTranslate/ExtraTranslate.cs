﻿using MSCLoader;
using UnityEngine;
using System;
using System.IO;
using HutongGames.PlayMaker;

namespace ExtraTranslate
{
    public class ExtraTranslate : Mod
    {
        public override string ID => "ExtraTranslate";
        public override string Name => "ExtraTranslate";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";

		public override bool UseAssetsFolder => true;
		
		private string path;
		private string cashreg;
		private string mk;
		
		public override void OnLoad()
		{
			path = ModLoader.GetModAssetsFolder(this);
			
			string[] array = new string[2];
			{
				array = File.ReadAllLines(path + "/translate.txt");
				cashreg = array[0];
				mk = array[1];
			}
		}
		
		public override void Update()
        {
			if(GameObject.Find("STORE/StoreCashRegister/Register") != null)
			{
				GameObject.Find("STORE/StoreCashRegister/Register").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("Notification").Value = cashreg + GameObject.Find("STORE/StoreCashRegister/Register").GetComponent<TextMesh>().text + mk;
			}
			
			if(GameObject.Find("REPAIRSHOP/LOD/Store/ShopCashRegister/Register") != null)
			{
				GameObject.Find("REPAIRSHOP/LOD/Store/ShopCashRegister/Register").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("Notification").Value = cashreg + GameObject.Find("REPAIRSHOP/LOD/Store/ShopCashRegister/Register").GetComponent<TextMesh>().text + mk;
			}
		}
    }
}
