﻿using MSCLoader;
using System.IO;
using UnityEngine;

namespace Autoload
{
	public class Autoload : Mod
    {
        public override string ID => "Autoload";
        public override string Name => "Autoload";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";
		
		private bool Disabled;	
		private string path;		
		public override bool LoadInMenu => true;
		public override bool UseAssetsFolder => true;
		private Keybind testKey = new Keybind("Exit", "Exit to menu", KeyCode.Q, KeyCode.LeftAlt);
		
        public override void OnMenuLoad()
        {
			path = ModLoader.GetModAssetsFolder(this);
			LoadSettings();
        }
		
		public override void OnLoad()
		{
			Keybind.Add(this, testKey);
			path = ModLoader.GetModAssetsFolder(this);
		}
		
		public override void Update()
		{
			if (testKey.IsDown())
			{
				Disabled = true;
				SaveSettings();
				Application.LoadLevel("MainMenu");
			}
		}
		
		private void LoadSettings()
		{
			string[] array = new string[1];
			if(File.Exists(path + "/disabled.txt"))
			{
				array = File.ReadAllLines(path + "/disabled.txt");
				
				Disabled = bool.Parse(array[0]);
			}
			else
			{
				SaveSettings();
			}
			
			if(Disabled)
			{
				Disabled = false;
				SaveSettings();
			}
			else
			{
				Application.LoadLevel("Game");
			}
		}
		
		private void SaveSettings()
		{
			string[] array = new string[1];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			bool num1 = Disabled;
			arg_11_0[arg_11_1] = num1.ToString();
			
			File.WriteAllLines(path + "/disabled.txt", array);
		}
    }
}
