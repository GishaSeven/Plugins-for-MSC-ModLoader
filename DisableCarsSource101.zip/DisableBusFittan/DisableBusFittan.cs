﻿using MSCLoader;
using UnityEngine;
using System.Threading;

namespace DisableBusFittan
{
    public class DisableBusFittan : Mod
    {
        public override string ID => "DisableBusFittan";
        public override string Name => "Disable Bus and Fittan";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => false;

		public override void OnLoad()
        {			
			new Thread(waiting).Start();
        }
		
		private void waiting()
		{
			Thread.Sleep( 20 * 1000 );
			
			GameObject.Find("BUS").SetActive(false);
			GameObject.Find("FITTAN").SetActive(false);
		}
    }
}
