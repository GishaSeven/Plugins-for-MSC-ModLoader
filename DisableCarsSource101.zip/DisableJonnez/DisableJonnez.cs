﻿using MSCLoader;
using UnityEngine;

namespace DisableJonnez
{
    public class DisableJonnez : Mod
    {
        public override string ID => "DisableJonnez";
        public override string Name => "Disable Jonnez";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => false;
		
		public override void OnLoad()
        {				
			GameObject.Find("JONNEZ ES(Clone)").SetActive(false);
        }
    }
}
