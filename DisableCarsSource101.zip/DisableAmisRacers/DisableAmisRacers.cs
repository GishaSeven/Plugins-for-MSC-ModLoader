﻿using MSCLoader;
using UnityEngine;

namespace DisableAmisRacers
{
    public class DisableAmisRacers : Mod
    {
        public override string ID => "DisableAmisRacers";
        public override string Name => "Disable Amis Racers";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => false;

		public override void OnLoad()
        {			
			GameObject.Find("KYLAJANI").SetActive(false);
			GameObject.Find("AMIS2").SetActive(false);
        }
    }
}
