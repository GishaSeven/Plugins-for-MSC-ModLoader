﻿using MSCLoader;
using UnityEngine;

namespace DisableFerndale
{
    public class DisableFerndale : Mod
    {
        public override string ID => "DisableFerndale";
        public override string Name => "Disable Ferndale";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => false;
		
		public override void OnLoad()
        {				
			GameObject.Find("FERNDALE(1630kg)").SetActive(false);
        }
    }
}
