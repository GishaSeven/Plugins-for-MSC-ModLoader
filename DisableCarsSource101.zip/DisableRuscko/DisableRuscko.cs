﻿using MSCLoader;
using UnityEngine;

namespace DisableRuscko
{
    public class DisableRuscko : Mod
    {
        public override string ID => "DisableRuscko";
        public override string Name => "Disable Ruscko";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => false;

		public override void OnLoad()
        {			
			GameObject.Find("RCO_RUSCKO12(270)").SetActive(false);
        }
    }
}
