﻿using MSCLoader;
using UnityEngine;

namespace DisableHayosiko
{
    public class DisableHayosiko : Mod
    {
        public override string ID => "DisableHayosiko";
        public override string Name => "Disable Hayosiko";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => false;
		
		public override void OnLoad()
        {				
			GameObject.Find("HAYOSIKO(1500kg, 250)").SetActive(false);
        }
    }
}
