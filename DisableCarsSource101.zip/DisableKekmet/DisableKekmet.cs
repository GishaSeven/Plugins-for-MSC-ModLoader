﻿using MSCLoader;
using UnityEngine;

namespace DisableKekmet
{
    public class DisableKekmet : Mod
    {
        public override string ID => "DisableKekmet";
        public override string Name => "Disable Kekmet";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => false;

		public override void OnLoad()
        {				
			GameObject.Find("KEKMET(350-400psi)").SetActive(false);
			GameObject.Find("FLATBED").SetActive(false);
        }
    }
}
