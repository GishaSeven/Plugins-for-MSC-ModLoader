﻿using HutongGames.PlayMaker;
using MSCLoader;
using UnityEngine;
using System;

namespace SpeedPower
{
    public class SpeedPower : Mod
    {
        public override string ID { get { return "SpeedPower"; } }
        public override string Name { get { return "SpeedPower"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }
		
		public bool isShow;
		public bool isDrag;
		public bool isStock;
		public bool isRally;
		
		public override void OnGUI()
		{
			GUIStyle myStyle = new GUIStyle();
			myStyle.fontSize = (int)(12.0f * (float)(Screen.width)/1000f);
			myStyle.normal.textColor = Color.white;
			
			if(isShow)
			{
			GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-160)/1, Screen.width, Screen.height), "RPM: " + FsmVariables.GlobalVariables.FindFsmFloat("RPM"), myStyle);
			
			if(isStock)
			{
			GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-140)/1, Screen.width, Screen.height), "Speed: " + GameObject.Find("SATSUMA(557kg)").GetComponent<Drivetrain>().velo*3.9f, myStyle);
			}
			if(isRally)
			{
			GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-140)/1, Screen.width, Screen.height), "Speed: " + GameObject.Find("SATSUMA(557kg)").GetComponent<Drivetrain>().velo*3.7f, myStyle);
			}
			if(isDrag)
			{
			GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-140)/1, Screen.width, Screen.height), "Speed: " + GameObject.Find("SATSUMA(557kg)").GetComponent<Drivetrain>().velo*4.2f, myStyle);
			}
			
			GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-120)/1, Screen.width, Screen.height), "Max Power: " + GameObject.Find("SATSUMA(557kg)").GetComponent<Drivetrain>().maxPower, myStyle);
			GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-100)/1, Screen.width, Screen.height), "Max Torque: " + GameObject.Find("SATSUMA(557kg)").GetComponent<Drivetrain>().maxTorque, myStyle);
			}
		}

        public override void Update()
        {
			if(Input.GetKeyDown(KeyCode.F6) && isShow == false)
			{
				isShow = true;
			}
			else if (Input.GetKeyDown(KeyCode.F6) && isShow == true)
			{
				isShow = false;
			}
			
			if(GameObject.Find("SATSUMA(557kg)").GetComponent<Axles>().frontAxle.leftWheel.radius<=0.26f && GameObject.Find("SATSUMA(557kg)").GetComponent<Axles>().frontAxle.leftWheel.radius>=0.25f)
			{
				isDrag = true;
			}
			else if (Input.GetKeyDown(KeyCode.F6) && isShow == true)
			{
				isDrag = false;
			}
			
			if(GameObject.Find("SATSUMA(557kg)").GetComponent<Axles>().frontAxle.leftWheel.radius<=0.28f && GameObject.Find("SATSUMA(557kg)").GetComponent<Axles>().frontAxle.leftWheel.radius>=0.27f)
			{
				isStock = true;
			}
			else if (Input.GetKeyDown(KeyCode.F6) && isShow == true)
			{
				isStock = false;
			}
			
			if(GameObject.Find("SATSUMA(557kg)").GetComponent<Axles>().frontAxle.leftWheel.radius<=0.29f && GameObject.Find("SATSUMA(557kg)").GetComponent<Axles>().frontAxle.leftWheel.radius>=0.28f)
			{
				isRally = true;
			}
			else if (Input.GetKeyDown(KeyCode.F6) && isShow == true)
			{
				isRally = false;
			}
        }
    }
}
