﻿using MSCLoader;
using UnityEngine;

namespace Pause
{
    public class Pause : Mod
    {
        public override string ID { get { return "Pause"; } }
        public override string Name { get { return "Pause"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.1"; } }

        public float timing;
		public bool isPaused;
		
		private Keybind pauseKey = new Keybind("PauseKey", "Pause", KeyCode.Pause);
		
		public override void OnLoad()
        {
            Keybind.Add(this, pauseKey);
        }
		
        public override void Update()
		{
			if (pauseKey.IsDown()) { Pause1(); };
			
			Time.timeScale = timing;
			
			if(isPaused == true)
			{
				timing = 0;
			}
			else if(isPaused == false)
			{
				timing = 1;
			}
		}
		
		private void Pause1()
        {
            this.isPaused = !this.isPaused;
        }

		public override void OnGUI()
		{
			GUIStyle myStyle = new GUIStyle();
			myStyle.fontSize = (int)(40.0f * (float)(Screen.width)/1000f);
			myStyle.normal.textColor = Color.red;
   
			if(isPaused)
			{
				GUI.Label(new Rect((Screen.width-190)/2, (Screen.height-100)/2, Screen.width, Screen.height), "PAUSE", myStyle);
			}
		}
    }
}
