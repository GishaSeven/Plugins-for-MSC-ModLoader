﻿using MSCLoader;
using System.Linq;
using UnityEngine;

namespace RacingMuffler
{
    public class RacingMuffler : Mod
    {
        public override string ID => "RacingMuffler";
        public override string Name => "Racing muffler";
        public override string Author => "Roman266";
        public override string Version => "1.0.3";

        public override bool UseAssetsFolder => true;
		
		public override void OnLoad()
        {			
			foreach (GameObject muffler in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "racing muffler(Clone)" && g.GetComponent<MeshFilter>() !=null))
            {
                Mesh new_mesh0 = LoadAssets.LoadOBJMesh(this, "racingmuffler.obj");
				
				muffler.GetComponent<MeshFilter>().mesh = new_mesh0;				
            }
        }
    }
}
