﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace LanguageFramework
{
    public class MainObject : MonoBehaviour
    {		
		private LanguageFramework _lang;
		private TextMesh _dayTextMesh;
		private TextMesh _subtitleMesh;
		private TextMesh _subtitleShadow;
		private TextMesh _subtitleParts;
		private TextMesh _subtitlePartsShadow;
		private TextMesh _interaction;
		private TextMesh _interactionShadow;
		private TextMesh _gear;
		private TextMesh _gearShadow;
		private TextMesh _rally;
		private TextMesh _rallyShadow;
		private Dictionary<string, string> _pairs = new Dictionary<string, string>();
		private bool _isLoaded;
		
		public void SetMod(LanguageFramework lang)
		{
			_lang = lang;
			_dayTextMesh = lang.GetTextMesh("GUI/HUD/Day/HUDValue");
			_subtitleMesh = lang.GetTextMesh("GUI/Indicators/Subtitles");
			_subtitleShadow = lang.GetTextMesh("GUI/Indicators/Subtitles/Shadow");
			_subtitleParts = lang.GetTextMesh("GUI/Indicators/Partname");
			_subtitlePartsShadow = lang.GetTextMesh("GUI/Indicators/Partname/Shadow");
			_interaction = lang.GetTextMesh("GUI/Indicators/Interaction");
			_interactionShadow = lang.GetTextMesh("GUI/Indicators/Interaction/Shadow");
			_subtitleParts = lang.GetTextMesh("GUI/Indicators/Partname");
			_subtitlePartsShadow = lang.GetTextMesh("GUI/Indicators/Partname/Shadow");
			_gear = lang.GetTextMesh("GUI/Indicators/Gear");
			_gearShadow = lang.GetTextMesh("GUI/Indicators/Gear/Shadow");
			_rally = lang.GetTextMesh("GUI/Indicators/RallyCountdown");
			_rallyShadow = lang.GetTextMesh("GUI/Indicators/RallyCountdown/Shadow");
			_isLoaded = true;
		}
		
		private void LateUpdate()
		{
			bool flag = !_isLoaded;
			if (!flag)
			{
				UpdateTextMeshes(new TextMesh[]
				{
					_dayTextMesh
				});
				UpdateTextMeshes(new TextMesh[]
				{
					_subtitleMesh,
					_subtitleShadow
				});
				UpdateTextMeshes(new TextMesh[]
				{
					_subtitleParts,
					_subtitlePartsShadow
				});
				UpdateTextMeshes(new TextMesh[]
				{
					_interaction,
					_interactionShadow
				});
				UpdateTextMeshes(new TextMesh[]
				{
					_gear,
					_gearShadow
				});
				UpdateTextMeshes(new TextMesh[]
				{
					_rally,
					_rallyShadow
				});
			}
		}
		
		private void UpdateTextMeshes(params TextMesh[] textMeshes)
		{
			string text = textMeshes[0].text;
			bool flag = string.IsNullOrEmpty(text);
			if (!flag)
			{
				bool flag2 = !text.Equals(GetPairsOldText(text));
				if (flag2)
				{
					string translatedText = _lang.GetTranslatedText(text);
					bool flag3 = !string.IsNullOrEmpty(translatedText);
					if (flag3)
					{
						_pairs[text] = translatedText;
						int num = textMeshes.Length;
						for (int i = 0; i < num; i++)
						{
							textMeshes[i].text = translatedText;
						}
					}
				}
			}
		}
		
		private string GetPairsOldText(string original)
		{
			string text;
			bool flag = _pairs.TryGetValue(StringExtensions.FormatUpperKey(original), out text);
			string result;
			if (flag)
			{
				result = text;
			}
			else
			{
				result = string.Empty;
			}
			return result;
		}
    }
}
