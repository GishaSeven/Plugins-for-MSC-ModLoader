﻿using MSCLoader;
using UnityEngine;

namespace SpeedPower
{
    public class SpeedPower : Mod
    {
        public override string ID => "SpeedPower";
        public override string Name => "Speed Power";
        public override string Author => "Roman266";
        public override string Version => "1.0.4";

        public override bool UseAssetsFolder => false;

        public bool isShow;
		public bool isPower;
		
		private Keybind show2Key = new Keybind("ShowSpeed", "Show Satsuma speed", KeyCode.F6);
		private Keybind show3Key = new Keybind("ShowPower", "Show Satsuma power", KeyCode.F5);
		
		public override void OnLoad()
        {
            Keybind.Add(this, show2Key);
			Keybind.Add(this, show3Key);
        }
		
        public override void Update()
        {
			if (show2Key.IsDown()) { ShowStat(); };
			if (show3Key.IsDown()) { ShowStat2(); };
        }
		
		private void ShowStat()
        {
            this.isShow = !this.isShow;
        }
		
		private void ShowStat2()
        {
            this.isPower = !this.isPower;
        }
		
		public override void OnGUI()
		{
			GUIStyle myStyle = new GUIStyle();
			myStyle.fontSize = (int)(12.0f * (float)(Screen.width)/1000f);
			myStyle.normal.textColor = Color.white;
			
			if(isShow)
			{
				GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-120)/1, Screen.width, Screen.height), "RPM: " + Mathf.Round(GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Drivetrain>().rpm), myStyle);			
				GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-100)/1, Screen.width, Screen.height), "Speed: " + Mathf.Round(GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Drivetrain>().differentialSpeed), myStyle);
				if(isPower)
				{	
					GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-180)/1, Screen.width, Screen.height), "Max Power: " + Mathf.Round(GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Drivetrain>().maxPower), myStyle);
					GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-160)/1, Screen.width, Screen.height), "Max Torque: " + Mathf.Round(GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Drivetrain>().maxTorque), myStyle);
					GUI.Label(new Rect((Screen.width-300)/15, (Screen.height-140)/1, Screen.width, Screen.height), "Mass: " + GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Rigidbody>().mass, myStyle);
				}
			}
		}
    }
}
