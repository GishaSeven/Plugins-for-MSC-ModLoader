﻿using MSCLoader;
using UnityEngine;

namespace LFTTFix
{
    public class LFTTFix : Mod
    {
        public override string ID => "LFTTFix";
        public override string Name => "LFTTFix";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";

		public override bool UseAssetsFolder => false;
		
		public override void OnLoad()
		{
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(3).GetChild(0).transform.localPosition = new Vector3(0.2f, -0.4f, 0f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(3).GetChild(0).GetChild(2).gameObject.GetComponent<MeshRenderer>().enabled = false;
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(3).GetChild(0).GetChild(3).transform.localPosition = new Vector3(-7.75f, 1f, 0f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(3).GetChild(0).GetChild(4).transform.localPosition = new Vector3(-14f, 1f, 0f);
						
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(0).GetChild(1).GetChild(0).transform.localPosition = new Vector3(-2.5f, 5f, 0f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(1).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(1).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(2).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(2).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(2).GetChild(1).GetChild(1).transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(2).GetChild(1).GetChild(1).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(2).GetChild(1).GetChild(3).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(2).GetChild(1).GetChild(3).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(3).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(3).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(3).GetChild(1).GetChild(1).transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(3).GetChild(1).GetChild(1).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(3).GetChild(1).GetChild(3).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(3).GetChild(1).GetChild(3).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(4).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(4).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(4).GetChild(1).GetChild(1).transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(4).GetChild(1).GetChild(1).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(4).GetChild(1).GetChild(3).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(4).GetChild(1).GetChild(3).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(5).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(5).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(6).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(6).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(6).GetChild(1).GetChild(1).transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(6).GetChild(1).GetChild(1).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(6).GetChild(1).GetChild(6).transform.localPosition = new Vector3(-0.15f, -0.22f, 0f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(6).GetChild(1).GetChild(5).transform.localPosition = new Vector3(0.9f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(6).GetChild(1).GetChild(5).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(7).GetChild(2).GetChild(0).transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(7).GetChild(2).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(7).GetChild(2).GetChild(1).transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(7).GetChild(2).GetChild(1).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(7).GetChild(2).GetChild(6).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(7).GetChild(2).GetChild(6).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(8).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(8).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(8).GetChild(1).GetChild(1).transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(8).GetChild(1).GetChild(1).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(8).GetChild(1).GetChild(3).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(8).GetChild(1).GetChild(3).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(9).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(9).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(10).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(10).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(10).GetChild(1).GetChild(1).transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(10).GetChild(1).GetChild(1).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(10).GetChild(1).GetChild(3).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(10).GetChild(1).GetChild(3).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(11).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(11).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(11).GetChild(1).GetChild(1).transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(11).GetChild(1).GetChild(1).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(11).GetChild(1).GetChild(2).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(11).GetChild(1).GetChild(2).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(12).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(12).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(12).GetChild(1).GetChild(1).transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(12).GetChild(1).GetChild(1).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(12).GetChild(1).GetChild(2).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(12).GetChild(1).GetChild(2).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(13).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(13).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(13).GetChild(1).GetChild(1).transform.localPosition = new Vector3(-8.9f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(13).GetChild(1).GetChild(1).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(13).GetChild(1).GetChild(2).transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(13).GetChild(1).GetChild(2).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(13).GetChild(1).GetChild(8).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(13).GetChild(1).GetChild(8).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(13).GetChild(1).GetChild(3).transform.localPosition = new Vector3(-5.7f, 4f, 0f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(13).GetChild(1).GetChild(5).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0.4f, 0f, 0f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(13).GetChild(1).GetChild(9).transform.localPosition = new Vector3(1f, 14f, 0f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(14).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(14).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(15).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(15).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(15).GetChild(1).GetChild(1).transform.localPosition = new Vector3(-18.28f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(15).GetChild(1).GetChild(1).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(15).GetChild(1).GetChild(3).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(15).GetChild(1).GetChild(3).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(16).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(16).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(17).GetChild(1).GetChild(1).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(17).GetChild(1).GetChild(1).transform.localScale = new Vector3(1f, 0.9f, 1f);
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(17).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0f, 5.55f, 0f);;
			
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(18).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0f, 1.87f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(18).GetChild(1).GetChild(0).transform.localScale = new Vector3(1f, 0.9f, 1f);

			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(18).GetChild(1).GetChild(2).transform.localPosition = new Vector3(0.85f, 15.85f, 0f);
			GameObject.Find("Systems").transform.GetChild(18).GetChild(0).GetChild(4).GetChild(18).GetChild(1).GetChild(2).transform.localScale = new Vector3(1f, 0.9f, 1f);
        }
    }
}
