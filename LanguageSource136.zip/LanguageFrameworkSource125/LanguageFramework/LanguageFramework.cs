﻿using MSCLoader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

namespace LanguageFramework
{
    public class LanguageFramework : Mod
    {
        public override string ID => "LanguageFramework";
        public override string Name => "LanguageFramework";
        public override string Author => "jinnin0105";
        public override string Version => "1.2.5";
		public override string Description => "Part of translation.";
		
		public override void ModSetup()
        {
            SetupFunction(Setup.OnMenuLoad, Mod_OnMenuLoad);
            SetupFunction(Setup.OnNewGame, Mod_OnNewGame);
            SetupFunction(Setup.FixedUpdate, Mod_FixedUpdate);
        }
		
		private SceneType _currentScene;
		private string _assetsPath;
		private static Dictionary<string, string> _translates = new Dictionary<string, string>();
		private bool endingtranslated;
		
		public bool isAssetsLoaded
		{
			get;
			set;
		}
		
		private void Mod_OnMenuLoad() 
		{
			_assetsPath = ModLoader.GetModAssetsFolder(this);
			ParseCurrentLanguage();
			TranslateAll();
		}
		
		private void Mod_OnNewGame()
		{
			TranslateAll();
		}
		
		private void TranslateAll()
		{
			TextMesh[] array = Resources.FindObjectsOfTypeAll<TextMesh>();
			List<Transform> list = new List<Transform>();
			StringBuilder stringBuilder = new StringBuilder();
			int num = array.Length;
			for (int i = 0; i < num; i++)
			{
				TextMesh textMesh = array[i];
				list.Clear();
				Transform transform = textMesh.transform;
				while (transform != null)
				{
					list.Add(transform);
					transform = transform.parent;
				}
				stringBuilder.Length = 0;
				int count = list.Count;
				while (count-- > 0)
				{
					string text = list[count].name;
					text = text.Replace(" ", string.Empty);
					stringBuilder.Append(text);
					bool flag = count != 0;
					if (flag)
					{
						stringBuilder.Append("/");
					}
				}
				string text2 = stringBuilder.ToString();
				bool flag2 = text2.StartsWith("Licence/") || text2.StartsWith("Interface/") || text2.StartsWith("Loading/") || text2.StartsWith("GUI/") || text2.StartsWith("Systems/") || text2.StartsWith("Sheets/") || text2.StartsWith("RALLY/RallyTV/") || text2.StartsWith("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/") || text2.StartsWith("Intro/") || text2.StartsWith("YARD/PlayerMailBox/mailbox_bottom_player/") || text2.StartsWith("BUTTONS/") || text2.StartsWith("INSPECTION/LOD/Floor/");
				if (flag2)
				{
					Translate(textMesh);
				}
			}
		}
		
		private void OnPreGameSceneLoaded()
		{
			TranslateAll();
			GameObject gameObject = new GameObject("MainObject", new Type[]
			{
				typeof(MainObject)
			});
			MainObject component = gameObject.GetComponent<MainObject>();
			component.SetMod(this);
		}
		
		private SceneType GetSceneType()
		{
			string loadedLevelName = Application.loadedLevelName;
			SceneType result;
			if (!(loadedLevelName == "MainMenu"))
			{
				if (!(loadedLevelName == "GAME"))
				{
					result = SceneType.None;
				}
				else
				{
					result = SceneType.Game;
				}
			}
			else
			{
				result = SceneType.MainMenu;
			}
			return result;
		}
		
		private void Mod_FixedUpdate()
        {
			SceneType sceneType = GetSceneType();
			bool flag = GetSceneType() == SceneType.Game;
			if (flag)
			{
				bool flag2 = _currentScene != sceneType;
				if (flag2)
				{
					_currentScene = sceneType;
					SceneType sceneType2 = GetSceneType();
					if (sceneType2 == SceneType.Game)
					{
						OnPreGameSceneLoaded();
					}
				}
			}
			
			if(Application.loadedLevelName == "Ending")
			{
				if(!endingtranslated)
				{
					TranslateAll();
					endingtranslated = true;
				}
			}
		}
		
		public void ParseCurrentLanguage()
		{
			LanguageFramework._translates.Clear();
			LanguageFramework._translates = ParseStringKeyValue(_assetsPath, "translate");
		}
		
		public Dictionary<string, string> ParseStringKeyValue(string assetPath, string fileName)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			try
			{
				string[] array = File.ReadAllLines(string.Format("{0}/{1}.txt", assetPath, fileName), Encoding.UTF8);
				int num = array.Length;
				for (int i = 0; i < num; i++)
				{
					string text = array[i];
					bool flag = string.IsNullOrEmpty(text);
					if (!flag)
					{
						bool flag2 = text.Contains("//");
						if (!flag2)
						{
							string[] array2 = array[i].Split(new char[]
							{
								'='
							});
							bool flag3 = array2.Length < 2;
							if (!flag3)
							{
								string text2 = StringExtensions.FormatUpperKey(array2[0]);
								string text3 = StringExtensions.TrimStartEnd(array2[1]);
								text3 = text3.Replace("\\n", "\n");
								bool flag4 = !dictionary.ContainsKey(text2);
								if (flag4)
								{
									dictionary.Add(text2, text3);
								}
								else
								{
									ModConsole.Error(string.Concat(new object[]
									{
										text2,
										" key is already! delete this line (",
										i + 1,
										" line)"
									}));
								}
							}
						}
					}
				}
			}
			catch (Exception)
			{
				ModConsole.Error(fileName + ".txt not found! " + dictionary.Count);
			}
			return dictionary;
		}
		
		public void Translate(TextMesh textMesh)
		{
			string text;
			bool flag = !LanguageFramework._translates.TryGetValue(StringExtensions.FormatUpperKey(textMesh.text), out text);
			if (!flag)
			{
				textMesh.text = text;
			}
		}
		
		public TextMesh GetTextMesh(string path)
		{
			GameObject gameObject = GameObject.Find(path);
			bool flag = gameObject == null;
			TextMesh result;
			if (flag)
			{
				result = null;
			}
			else
			{
				TextMesh component = gameObject.GetComponent<TextMesh>();
				bool flag2 = component == null;
				if (flag2)
				{
					result = null;
				}
				else
				{
					result = component;
				}
			}
			return result;
		}
		
		public string GetTranslatedText(string original)
		{
			string text;
			bool flag = LanguageFramework._translates.TryGetValue(StringExtensions.FormatUpperKey(original), out text);
			string result;
			if (flag)
			{
				result = text;
			}
			else
			{
				result = string.Empty;
			}
			return result;
		}
    }
}
