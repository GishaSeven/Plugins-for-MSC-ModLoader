﻿using MSCLoader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

namespace NewFonts
{
    public class NewFonts : Mod
    {
        public override string ID => "NewFonts";
        public override string Name => "New Fonts";
        public override string Author => "Roman266";
        public override string Version => "1.0.2";
		public override string Description => "Part of translation.";
		
		public override void ModSetup()
        {
            SetupFunction(Setup.OnMenuLoad, Mod_OnMenuLoad);
            SetupFunction(Setup.OnNewGame, Mod_OnNewGame);
            SetupFunction(Setup.FixedUpdate, Mod_FixedUpdate);
        }

		private string assetsfolderpath;
		private string font1name;
		private string font2name;
		private string font3name;
		private string font4name;
		private string font5name;
		private string font6name;
		private string font7name;
		private string font8name;
		private string font9name;
		private string font10name;
		private string font11name;
		private string fontsearchname;
		private Font NewFont1;
		private Font NewFont2;
		private Font NewFont3;
		private Font NewFont4;
		private Font NewFont5;
		private Font NewFont6;
		private Font NewFont7;
		private Font NewFont8;
		private Font NewFont9;
		private Font NewFont10;
		private Font NewFont11;
		private bool gametranslated;
		private bool endingtranslated;
		private bool searchgameobjects;
		
		private void Mod_OnMenuLoad() 
		{
			LoadFonts();
		}
		
		private void LoadFonts()
		{
			assetsfolderpath = ModLoader.GetModAssetsFolder(this);
			
			string[] array = new string[26];
			array = File.ReadAllLines(assetsfolderpath + "/fonts.txt");
			font1name = array[1];
			font2name = array[3];
			font3name = array[5];
			font4name = array[7];
			font5name = array[9];
			font6name = array[11];
			font7name = array[13];
			font8name = array[15];
			font9name = array[17];
			font10name = array[19];
			font11name = array[21];
			searchgameobjects = bool.Parse(array[23]);
			fontsearchname = array[25];
			
			AssetBundle fontsassetbundle = LoadAssets.LoadBundle(this,"fonts.unity3d");
			if(font1name != "")
			{
				NewFont1 = fontsassetbundle.LoadAsset<Font>(font1name);
			}
			if(font2name != "")
			{
				NewFont2 = fontsassetbundle.LoadAsset<Font>(font2name);
			}
			if(font3name != "")
			{
				NewFont3 = fontsassetbundle.LoadAsset<Font>(font3name);
			}
			if(font4name != "")
			{
				NewFont4 = fontsassetbundle.LoadAsset<Font>(font4name);
			}
			if(font5name != "")
			{
				NewFont5 = fontsassetbundle.LoadAsset<Font>(font5name);
			}
			if(font6name != "")
			{
				NewFont6 = fontsassetbundle.LoadAsset<Font>(font6name);
			}
			if(font7name != "")
			{
				NewFont7 = fontsassetbundle.LoadAsset<Font>(font7name);
			}
			if(font8name != "")
			{
				NewFont8 = fontsassetbundle.LoadAsset<Font>(font8name);
			}
			if(font9name != "")
			{
				NewFont9 = fontsassetbundle.LoadAsset<Font>(font9name);
			}
			if(font10name != "")
			{
				NewFont10 = fontsassetbundle.LoadAsset<Font>(font10name);
			}
			if(font11name != "")
			{
				NewFont11 = fontsassetbundle.LoadAsset<Font>(font11name);
			}
			fontsassetbundle.Unload(false);
			
			ReplaceFonts();
		}
		
		private void ReplaceFonts()
		{
			if(searchgameobjects)
			{
				GameObject[] allObjects = Resources.FindObjectsOfTypeAll<GameObject>();
				
				foreach(GameObject findfontstest in allObjects)
				{
					if(findfontstest.GetComponent<TextMesh>() != null)
					{
						if(findfontstest.GetComponent<TextMesh>().font.name == fontsearchname)
						{
							ModConsole.Print("FONTS: " + findfontstest.transform.parent.name + "/" + findfontstest.name);
						}
					}
				}
			}
			
			GameObject[] arraygolist = Resources.FindObjectsOfTypeAll<GameObject>();
			List<Transform> transformlist = new List<Transform>();
			StringBuilder gostringbuilder = new StringBuilder();
			int gonum = arraygolist.Length;
			for (int i = 0; i < gonum; i++)
			{
				GameObject gameobjectslist = arraygolist[i];
				transformlist.Clear();
				Transform gotransform = gameobjectslist.transform;
				while(gotransform != null)
				{
					transformlist.Add(gotransform);
					gotransform = gotransform.parent;
				}
				gostringbuilder.Length = 0;
				int gocount = transformlist.Count;
				while(gocount-- > 0)
				{
					string text = transformlist[gocount].name;
					text = text.Replace(" ", string.Empty);
					gostringbuilder.Append(text);
					bool flag = gocount != 0;
					if(flag)
					{
						gostringbuilder.Append("/");
					}
				}
				string text2 = gostringbuilder.ToString();
				bool flag2 = text2.StartsWith("Licence/") || text2.StartsWith("Interface/") || text2.StartsWith("Loading/") || text2.StartsWith("GUI/") || text2.StartsWith("Systems/") || text2.StartsWith("Sheets/") || text2.StartsWith("RALLY/RallyTV/") || text2.StartsWith("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/") || text2.StartsWith("Intro/") || text2.StartsWith("YARD/PlayerMailBox/mailbox_bottom_player/") || text2.StartsWith("BUTTONS/") || text2.StartsWith("PERAJARVI/CHURCH/") || text2.StartsWith("INSPECTION/LOD/Floor/");
				if(flag2)
				{
					if(gameobjectslist.GetComponent<TextMesh>() != null)
					{
						if(NewFont1 != null)
						{
							if(gameobjectslist.GetComponent<TextMesh>().font.name == "FugazOne-Regular")
							{
								gameobjectslist.GetComponent<TextMesh>().font = NewFont1;
								gameobjectslist.GetComponent<MeshRenderer>().material.mainTexture = NewFont1.material.mainTexture;
							}
						}
						
						if(NewFont2 != null)
						{
							if(gameobjectslist.GetComponent<TextMesh>().font.name == "Heebo-Black")
							{
								gameobjectslist.GetComponent<TextMesh>().font = NewFont2;
								gameobjectslist.GetComponent<MeshRenderer>().material.mainTexture = NewFont2.material.mainTexture;
							}
						}
						
						if(NewFont3 != null)
						{
							if(gameobjectslist.GetComponent<TextMesh>().font.name == "AlfaSlabOne-Regular")
							{
								gameobjectslist.GetComponent<TextMesh>().font = NewFont3;
								gameobjectslist.GetComponent<MeshRenderer>().material.mainTexture = NewFont3.material.mainTexture;
							}
						}
						
						if(NewFont4 != null)
						{
							if(gameobjectslist.GetComponent<TextMesh>().font.name == "Cour10Bd")
							{
								gameobjectslist.GetComponent<TextMesh>().font = NewFont4;
								gameobjectslist.GetComponent<MeshRenderer>().material.mainTexture = NewFont4.material.mainTexture;
							}
						}
						
						if(NewFont5 != null)
						{
							if(gameobjectslist.GetComponent<TextMesh>().font.name == "RAGE")
							{
								gameobjectslist.GetComponent<TextMesh>().font = NewFont5;
								gameobjectslist.GetComponent<MeshRenderer>().material.mainTexture = NewFont5.material.mainTexture;
							}
						}
						
						if(NewFont6 != null)
						{
							if(gameobjectslist.GetComponent<TextMesh>().font.name == "Dosis-SemiBold LowCase")
							{
								gameobjectslist.GetComponent<TextMesh>().font = NewFont6;
								gameobjectslist.GetComponent<MeshRenderer>().material.mainTexture = NewFont6.material.mainTexture;
							}
						}
						
						if(NewFont7 != null)
						{
							if(gameobjectslist.GetComponent<TextMesh>().font.name == "VT323-Regular")
							{
								gameobjectslist.GetComponent<TextMesh>().font = NewFont7;
								gameobjectslist.GetComponent<MeshRenderer>().material.mainTexture = NewFont7.material.mainTexture;
								gameobjectslist.GetComponent<TextMesh>().fontStyle = FontStyle.Normal;
							}
						}
						
						if(NewFont8 != null)
						{
							if(gameobjectslist.GetComponent<TextMesh>().font.name == "Dosis-SemiBold")
							{
								gameobjectslist.GetComponent<TextMesh>().font = NewFont8;
								gameobjectslist.GetComponent<MeshRenderer>().material.mainTexture = NewFont8.material.mainTexture;
							}
						}
						
						if(NewFont9 != null)
						{
							if(gameobjectslist.GetComponent<TextMesh>().font.name == "DroidSerif-Bold")
							{
								gameobjectslist.GetComponent<TextMesh>().font = NewFont9;
								gameobjectslist.GetComponent<MeshRenderer>().material.mainTexture = NewFont9.material.mainTexture;
							}
						}
						
						if(NewFont10 != null)
						{
							if(gameobjectslist.GetComponent<TextMesh>().font.name == "PlayfairDisplay-Bold")
							{
								gameobjectslist.GetComponent<TextMesh>().font = NewFont10;
								gameobjectslist.GetComponent<MeshRenderer>().material.mainTexture = NewFont10.material.mainTexture;
							}
						}
						
						if(NewFont11 != null)
						{
							if(gameobjectslist.GetComponent<TextMesh>().font.name == "WalterTurncoat-Regular")
							{
								gameobjectslist.GetComponent<TextMesh>().font = NewFont11;
								gameobjectslist.GetComponent<MeshRenderer>().material.mainTexture = NewFont11.material.mainTexture;
							}
						}
					}
				}
			}
		}
		
		private void Mod_OnNewGame()
		{
			ReplaceFonts();
		}
		
		private void Mod_FixedUpdate()
		{
			if(Application.loadedLevelName == "Ending")
			{
				if(!endingtranslated)
				{
					ReplaceFonts();
					endingtranslated = true;
				}
			}
			
			if(!gametranslated)
			{
				if(GameObject.Find("GUI/HUD") != null)
				{
					ReplaceFonts();
					gametranslated = true;
				}
			}
		}
    }
}
