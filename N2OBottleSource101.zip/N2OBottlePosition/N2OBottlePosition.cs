﻿using MSCLoader;
using System.Linq;
using UnityEngine;

namespace N2OBottlePosition
{
    public class N2OBottlePosition : Mod
    {
        public override string ID => "N2OBottlePosition";
        public override string Name => "N2O Bottle Position";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";
        public override string Description => "Change N2O bottle position.";
		
		private GameObject bottle;
		private GameObject holder;
		
        public override void OnLoad()
        {
			if(GameObject.Find("n2o bottle(Clone)") != null)
			{
				bottle = Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("n2o bottle(Clone)") >= 0).Last().transform.gameObject;
				bottle.gameObject.SetActive(false);
				holder = GameObject.Find("SATSUMA(557kg, 248)").transform.Find("Interior").transform.Find("n2o bottle holder(xxxxx)").gameObject;
				holder.transform.localPosition = new Vector3(0.36f, -0.185f, 0.5f);
				holder.transform.localRotation = new Quaternion(-0.119646f, -0.942f, -0.12f, 0.908800f);
				holder.transform.localPosition = new Vector3(0.36f, -0.185f, 0.5f);
				bottle.gameObject.SetActive(true);
				GameObject.Find("SATSUMA(557kg, 248)").transform.Find("Interior").transform.Find("trigger_n2o_holder").transform.localPosition = new Vector3(0.36f, -0.185f, 0.5f);
			}
        }
    }
}
