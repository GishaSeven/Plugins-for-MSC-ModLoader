﻿using MSCLoader;
using UnityEngine;

namespace TachometerPosition
{
    public class TachometerPosition : Mod
    {
        public override string ID => "TachometerPosition";
        public override string Name => "Tachometer Position";
        public override string Author => "Roman266";
        public override string Version => "1.0.5";

        public override bool UseAssetsFolder => false;

		public override void OnLoad()
        {			
			//Tachometer position
			GameObject TACHOMETER = GameObject.Find("SATSUMA(557kg, 248)/Dashboard/Steering/steering_column2/tachometer(xxxxx)");
			TACHOMETER.transform.localPosition = new Vector3(0.25f, -0.35f, 0.21f);
			TACHOMETER.transform.localRotation = new Quaternion(1f, 0.5f, -1f, 7f);
			//Tachometer trigger
			GameObject TRIGGER = GameObject.Find("SATSUMA(557kg, 248)/Dashboard/Steering/steering_column2/trigger_tachometer");
			TRIGGER.transform.localPosition = new Vector3(0.25f, -0.35f, 0.21f);
			//FuelGauge position
			if(GameObject.Find("fuel mixture gauge(xxxxx)") != null)
			{
				GameObject FUELMIXTURE = GameObject.Find("dashboard(Clone)/fuel mixture gauge(xxxxx)");
				FUELMIXTURE.transform.localPosition = new Vector3(0.11f, -0.02f, 0.15f);
				FUELMIXTURE.transform.localRotation = new Quaternion(1f, 0f, 25f, 90f);
			}
			//FuelGauge trigger
			if(GameObject.Find("SATSUMA(557kg, 248)/Dashboard/pivot_dashboard/dashboard(Clone)/trigger_fuel_mix_gauge") != null)
			{
				GameObject TRIGGERFUEL = GameObject.Find("SATSUMA(557kg, 248)/Dashboard/pivot_dashboard/dashboard(Clone)/trigger_fuel_mix_gauge");
				TRIGGERFUEL.transform.localPosition = new Vector3(0.11f, -0.02f, 0.15f);
			}
			//Panel position
			if(GameObject.Find("n2o button panel(xxxxx)") != null)
			{
				GameObject PANEL = GameObject.Find("dashboard meters(Clone)/n2o button panel(xxxxx)");
				PANEL.transform.localPosition = new Vector3(0.259200f, -0.028f, 0.03f);
			}
			//Panel trigger
			if(GameObject.Find("SATSUMA(557kg, 248)/Dashboard/pivot_dashboard/dashboard(Clone)/pivot_meters/dashboard meters(Clone)/trigger_n2o_button_panel") != null)
			{
				GameObject PANELTRIGGER = GameObject.Find("SATSUMA(557kg, 248)/Dashboard/pivot_dashboard/dashboard(Clone)/pivot_meters/dashboard meters(Clone)/trigger_n2o_button_panel");
				PANELTRIGGER.transform.localPosition = new Vector3(0.259200f, -0.028f, 0.03f);
			}
        }
    }
}
