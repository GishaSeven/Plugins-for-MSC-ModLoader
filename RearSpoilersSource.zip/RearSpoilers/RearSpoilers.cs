﻿using MSCLoader;
using UnityEngine;
using System.Collections;

namespace RearSpoilers
{
    public class RearSpoilers : Mod
    {
        public override string ID { get { return "RearSpoilers"; } }
        public override string Name { get { return "Rear Spoilers"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject SPOILER;
		private GameObject SPOILER2;
		private string path = ModLoader.ModsFolder+@"\RearSpoilers\";
		
        public override void Update()
        {
            if (Application.loadedLevelName == "GAME" && !loaded)
            {
				if(GameObject.Find("rear spoiler(Clone)").activeSelf == true)
				{
					SPOILER = GameObject.Find("rear spoiler(Clone)");
							
					ObjImporter objimporter = new ObjImporter();
					Mesh new_mesh0 = new Mesh();
					new_mesh0 = objimporter.ImportFile(path + "spoiler_rear.obj");
				
					SPOILER.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				}
				
				if(GameObject.Find("rear spoiler2(Clone)").activeSelf == true)
				{
					SPOILER2 = GameObject.Find("rear spoiler2(Clone)");
							
					ObjImporter objimporter = new ObjImporter();
					Mesh new_mesh1 = new Mesh();
					new_mesh1 = objimporter.ImportFile(path + "spoiler2_rear.obj");
				
					SPOILER2.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				}
														
				loaded = true;
            }
			
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
    }
}
