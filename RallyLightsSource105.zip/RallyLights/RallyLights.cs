﻿using MSCLoader;
using UnityEngine;

namespace RallyLights
{
    public class RallyLights : Mod
    {
        public override string ID => "RallyLights";
        public override string Name => "Rally Lights";
        public override string Author => "Roman266";
        public override string Version => "1.0.5";

        public override bool UseAssetsFolder => true;
		
		private bool isOff;
		private GameObject SATSUMA;
		private GameObject HandleTrigger;
		private GameObject lightGameObject;
		private GameObject lightGameObject2;
		private GameObject lightGameObject3;
		private GameObject lightGameObject4;
		private GameObject lightGameObject5;
		private GameObject Roman266RALLYON;
		private GameObject Roman266RALLYOFF;

		public override void OnLoad()
        {
			SATSUMA = GameObject.Find("SATSUMA(557kg, 248)");
			
			Roman266RALLYOFF = LoadAssets.LoadOBJ(this, "rallylights_off.obj");
			Roman266RALLYOFF.transform.parent = SATSUMA.transform;
			Roman266RALLYOFF.transform.localScale = new Vector3(1, 1, 1);
			Roman266RALLYOFF.transform.localPosition = new Vector3(0, 0, 0);
			Roman266RALLYOFF.transform.localEulerAngles= new Vector3(0, 0, 0);
			Texture2D loadtexture1 = LoadAssets.LoadTexture(this, "rallylights_off.dds");
			Roman266RALLYOFF.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1;
			
			Roman266RALLYON = LoadAssets.LoadOBJ(this, "rallylights_on.obj");
			Roman266RALLYON.transform.parent = SATSUMA.transform;
			Roman266RALLYON.transform.localScale = new Vector3(1, 1, 1);
			Roman266RALLYON.transform.localPosition = new Vector3(0, 0, 0);
			Roman266RALLYON.transform.localEulerAngles= new Vector3(0, 0, 0);
			Texture2D loadtexture2 = LoadAssets.LoadTexture(this, "rallylights_on.dds");
			Roman266RALLYON.GetComponent<MeshRenderer>().material.mainTexture = loadtexture2;
			
			lightGameObject = new GameObject("Roman266Light");
			Light lightComp = lightGameObject.AddComponent<Light>();
			lightComp.color = Color.white;
			lightComp.type = LightType.Spot;
			lightComp.spotAngle = 150;
			lightComp.intensity = 30;
			lightComp.range = 80;
			lightGameObject.transform.parent = SATSUMA.transform;
			lightGameObject.transform.localPosition = new Vector3(0, 0, 2);
			lightGameObject.transform.localEulerAngles= new Vector3(0, 0, 0);
				
			lightGameObject2 = new GameObject("Roman266Light2");
			Light lightComp2 = lightGameObject2.AddComponent<Light>();
			lightComp2.color = Color.white;
			lightComp2.type = LightType.Point;
			lightComp2.intensity = 30;
			lightComp2.range = 0.14f;
			lightGameObject2.transform.parent = SATSUMA.transform;
			lightGameObject2.transform.localPosition = new Vector3(0.24f, 0.13f, 1.84f);
			lightGameObject2.transform.localEulerAngles= new Vector3(0, 0, 0);
				
			lightGameObject3 = new GameObject("Roman266Light3");
			Light lightComp3 = lightGameObject3.AddComponent<Light>();
			lightComp3.color = Color.white;
			lightComp3.type = LightType.Point;
			lightComp3.intensity = 30;
			lightComp3.range = 0.14f;
			lightGameObject3.transform.parent = SATSUMA.transform;
			lightGameObject3.transform.localPosition = new Vector3(0.08f, 0.13f, 1.84f);
			lightGameObject3.transform.localEulerAngles= new Vector3(0, 0, 0);
				
			lightGameObject4 = new GameObject("Roman266Light4");
			Light lightComp4 = lightGameObject4.AddComponent<Light>();
			lightComp4.color = Color.white;
			lightComp4.type = LightType.Point;
			lightComp4.intensity = 30;
			lightComp4.range = 0.14f;
			lightGameObject4.transform.parent = SATSUMA.transform;
			lightGameObject4.transform.localPosition = new Vector3(-0.08f, 0.13f, 1.84f);
			lightGameObject4.transform.localEulerAngles= new Vector3(0, 0, 0);
				
			lightGameObject5 = new GameObject("Roman266Light5");
			Light lightComp5 = lightGameObject5.AddComponent<Light>();
			lightComp5.color = Color.white;
			lightComp5.type = LightType.Point;
			lightComp5.intensity = 30;
			lightComp5.range = 0.14f;
			lightGameObject5.transform.parent = SATSUMA.transform;
			lightGameObject5.transform.localPosition = new Vector3(-0.24f, 0.13f, 1.84f);
			lightGameObject5.transform.localEulerAngles= new Vector3(0, 0, 0);
			
			HandleTrigger = GameObject.CreatePrimitive(PrimitiveType.Cube);
            HandleTrigger.name = "Roman266";
            HandleTrigger.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
			HandleTrigger.transform.parent = SATSUMA.transform;
			HandleTrigger.transform.localPosition = new Vector3(0f, 0.77f, 0.3f);
			HandleTrigger.transform.localEulerAngles= new Vector3(0, 0, 0);
            var col1 = HandleTrigger.GetComponent<Collider>();
            col1.isTrigger = true;
            HandleTrigger.GetComponent<MeshRenderer>().enabled = false;
			
			isOff = false;
        }
		
		public override void Update()
        {	
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			RaycastHit Roman266hit;

            if (Physics.Raycast(ray, out Roman266hit, 1))
            {
                if (Roman266hit.collider.name == "Roman266")
                {
                    if (Input.GetMouseButtonDown(0))
                    {
                        isOff = !isOff;
                    }
                }
            }
			
			if(isOff)
			{
				Roman266RALLYON.GetComponent<MeshRenderer>().enabled = true;
				Roman266RALLYOFF.GetComponent<MeshRenderer>().enabled = false;
				
				lightGameObject.SetActive(true);
				lightGameObject2.SetActive(true);
				lightGameObject3.SetActive(true);
				lightGameObject4.SetActive(true);
				lightGameObject5.SetActive(true);
			}
			else
			{
				Roman266RALLYON.GetComponent<MeshRenderer>().enabled = false;
				Roman266RALLYOFF.GetComponent<MeshRenderer>().enabled = true;
				
				lightGameObject.SetActive(false);
				lightGameObject2.SetActive(false);
				lightGameObject3.SetActive(false);
				lightGameObject4.SetActive(false);
				lightGameObject5.SetActive(false);
			}
		}
    }
}
