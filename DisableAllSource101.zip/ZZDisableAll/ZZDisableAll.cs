﻿using System;
using System.IO;
using MSCLoader;
using UnityEngine;
using HutongGames.PlayMaker;

namespace ZZDisableAll
{
    public class ZZDisableAll : Mod
    {
        public override string ID => "ZZDisableAll";
        public override string Name => "DisableAll";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => true;
		
		private bool GUISHOWB;
		private bool BOATB;
		private bool FERNDALEB;
		private bool FLATBEDB;
		private bool GIFUB;
		private bool HAYOSIKOB;
		private bool JONNEZB;
		private bool KEKMETB;
		private bool RCOB;
		private bool SATSUMAB;
		private bool CABINB;
		private bool COTTAGEB;
		private bool DANCEHALLB;
		private bool DRAGRACEB;
		private bool INSPECTIONB;
		private bool LANDFILLB;
		private bool PERAJARVIB;
		private bool REPAIRSHOPB;
		private bool RYKIPOHJAB;
		private bool SOCCERB;
		private bool STOREB;
		private bool WATERFACILITYB;
		private bool YARDB;
		private bool CARPARTSB;
		private bool DatabaseB;
		private bool HUMANSB;
		private bool ITEMSB;
		private bool JOBSB;
		private bool KILJUGUYB;
		private bool MISCB;
		private bool NPC_CARSB;
		private bool RALLYB;
		private bool SystemsB;
		private bool TRAFFICB;
		private bool TRAINB;
		private bool MAPHALFB;
		private bool MAPFULLB;
		private bool BoltPMB;
		private bool timer1;
		private bool timer2;
		private string path;
		private GameObject BOATG;
		private GameObject FERNDALEG;
		private GameObject FLATBEDG;
		private GameObject GIFUG;
		private GameObject HAYOSIKOG;
		private GameObject JONNEZG;
		private GameObject KEKMETG;
		private GameObject RCOG;
		private GameObject SATSUMAG;
		private GameObject CABING;
		private GameObject COTTAGEG;
		private GameObject DANCEHALLG;
		private GameObject DRAGRACEG;
		private GameObject INSPECTIONG;
		private GameObject LANDFILLG;
		private GameObject PERAJARVIG;
		private GameObject REPAIRSHOPG;
		private GameObject RYKIPOHJAG;
		private GameObject SOCCERG;
		private GameObject STOREG;
		private GameObject WATERFACILITYG;
		private GameObject YARDG;
		private GameObject CARPARTSG;
		private GameObject DatabaseG;
		private GameObject HUMANSG;
		private GameObject ITEMSG;
		private GameObject JOBSG;
		private GameObject KILJUGUYG;
		private GameObject MISCG;
		private GameObject NPC_CARSG;
		private GameObject RALLYG;
		private GameObject SystemsG;
		private GameObject TRAFFICG;
		private GameObject TRAING;
		private GameObject MAPG;
		private GameObject BuildingsG;
		private GameObject TrafficSignsG;
		private GameObject StreetLightsG;
		private GameObject ELEC_POLESG;
		private GameObject ELEC_POLES_COLLG;
		private GameObject CHURCHWALLG;
		private GameObject TREES1_COLLG;
		private GameObject TREES2_COLLG;
		private GameObject TREES3_COLLG;
		private GameObject FOLIAGEG;
		private GameObject TERRAINOUTG;
		private GameObject ROCKSG;
		private GameObject BirdTowerG;
		private GameObject BusStopG;
		private GameObject BusStop1G;
		private GameObject HayBalesG;
		private Rect windowRect = new Rect((Screen.width-450)/2, (Screen.height-330)/2, 450, 330);
		private Keybind showguikey = new Keybind("ShowGUI", "Show GUI", KeyCode.D, KeyCode.RightControl);
		
		public override void OnLoad()
		{
			Keybind.Add(this, showguikey);
			
			path = ModLoader.GetModAssetsFolder(this);
			
			BOATG = GameObject.Find("BOAT");
			FERNDALEG = GameObject.Find("FERNDALE(1630kg)");
			FLATBEDG = GameObject.Find("FLATBED");
			GIFUG = GameObject.Find("GIFU(750/450psi)");
			HAYOSIKOG = GameObject.Find("HAYOSIKO(1500kg, 250)");
			JONNEZG = GameObject.Find("JONNEZ ES(Clone)");
			KEKMETG = GameObject.Find("KEKMET(350-400psi)");
			RCOG = GameObject.Find("RCO_RUSCKO12(270)");
			SATSUMAG = GameObject.Find("SATSUMA(557kg, 248)");
			CABING = GameObject.Find("CABIN");
			COTTAGEG = GameObject.Find("COTTAGE");
			DANCEHALLG = GameObject.Find("DANCEHALL");
			DRAGRACEG = GameObject.Find("DRAGRACE");
			INSPECTIONG = GameObject.Find("INSPECTION");
			LANDFILLG = GameObject.Find("LANDFILL");
			PERAJARVIG = GameObject.Find("PERAJARVI");
			REPAIRSHOPG = GameObject.Find("REPAIRSHOP");
			RYKIPOHJAG = GameObject.Find("RYKIPOHJA");
			SOCCERG = GameObject.Find("SOCCER");
			STOREG = GameObject.Find("STORE");
			WATERFACILITYG = GameObject.Find("WATERFACILITY");
			YARDG = GameObject.Find("YARD");
			CARPARTSG = GameObject.Find("CARPARTS");
			DatabaseG = GameObject.Find("Database");
			HUMANSG = GameObject.Find("HUMANS");
			ITEMSG = GameObject.Find("ITEMS");
			JOBSG = GameObject.Find("JOBS");
			KILJUGUYG = GameObject.Find("KILJUGUY");
			MISCG = GameObject.Find("MISC");
			NPC_CARSG = GameObject.Find("NPC_CARS");
			RALLYG = GameObject.Find("RALLY");
			SystemsG = GameObject.Find("Systems");
			TRAFFICG = GameObject.Find("TRAFFIC");
			TRAING = GameObject.Find("TRAIN");
			MAPG = GameObject.Find("MAP");
			BuildingsG = GameObject.Find("Buildings");
			TrafficSignsG = GameObject.Find("TrafficSigns");
			StreetLightsG = GameObject.Find("StreetLights");
			ELEC_POLESG = GameObject.Find("ELEC_POLES");
			ELEC_POLES_COLLG = GameObject.Find("ELEC_POLES_COLL");
			CHURCHWALLG = GameObject.Find("CHURCHWALL");
			TREES1_COLLG = GameObject.Find("TREES1_COLL");
			TREES2_COLLG = GameObject.Find("TREES2_COLL");
			TREES3_COLLG = GameObject.Find("TREES3_COLL");
			FOLIAGEG = GameObject.Find("FOLIAGE");
			TERRAINOUTG = GameObject.Find("TERRAINOUT");
			ROCKSG = GameObject.Find("ROCKS");
			BirdTowerG = GameObject.Find("BirdTower");
			BusStopG = GameObject.Find("BusStop");
			BusStop1G = GameObject.Find("BusStop 1");
			HayBalesG = GameObject.Find("HayBales");
						
			ModConsole.Print("[DisableAll]: GameObjects found!");
			
			loadsettings();
		}

		public override void Update()
		{
			if (showguikey.IsDown()) { GuiShow(); };
			
			if(timer1)
			{
				if(Camera.main != null)
				{
					ITEMSG.SetActive(false);
					
					timer1 = false;
				}
			}
			
			if(timer2)
			{
				if(Camera.main != null)
				{
					GameObject[] allObjects = UnityEngine.Object.FindObjectsOfType<GameObject>();
					foreach(GameObject BoltPMG in allObjects)
					{
						if(BoltPMG.name == "BoltPM")
						{
							BoltPMG.SetActive(false);
						}
					}
					
					timer2 = false;
				}
			}
		}
		
		private void GuiShow()
		{
			GUISHOWB = !GUISHOWB;
			
			if(GUISHOWB)
			{
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = true;
			}
			else
			{
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
			}
		}
		
		public override void OnGUI()
		{
			if(GUISHOWB)
			{
				GUI.ModalWindow(0, windowRect, DoMyWindow, "Disable All");
			}
		}
		
		void DoMyWindow(int windowID)
		{
			var styleRed = new GUIStyle(GUI.skin.button);
			styleRed.normal.textColor = Color.red;
			
			var styleGreen = new GUIStyle(GUI.skin.button);
			styleGreen.normal.textColor = Color.green;
			
			if (GUI.Button(new Rect(225, 300, 100, 20), "Close"))
			{
				GUISHOWB = false;
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
			}
			
			if (GUI.Button(new Rect(125, 300, 100, 20), "Save"))
			{
				savesettings();
			}
			
			if(BOATB)
			{
				if (GUI.Button(new Rect(10, 20, 100, 20), "Boat", styleRed))
				{
					BOATD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(10, 20, 100, 20), "Boat", styleGreen))
				{
					BOATD();
				}
			}
			
			if(FERNDALEB)
			{
				if (GUI.Button(new Rect(10, 40, 100, 20), "Ferndale", styleRed))
				{
					FERNDALED();
				}
			}
			else
			{
				if (GUI.Button(new Rect(10, 40, 100, 20), "Ferndale", styleGreen))
				{
					FERNDALED();
				}
			}
			
			if(FLATBEDB)
			{
				if (GUI.Button(new Rect(10, 60, 100, 20), "Flatbed", styleRed))
				{
					FLATBEDD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(10, 60, 100, 20), "Flatbed", styleGreen))
				{
					FLATBEDD();
				}
			}
			
			if(GIFUB)
			{
				if (GUI.Button(new Rect(10, 80, 100, 20), "Gifu", styleRed))
				{
					GIFUD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(10, 80, 100, 20), "Gifu", styleGreen))
				{
					GIFUD();
				}
			}
		
			if(HAYOSIKOB)
			{
				if (GUI.Button(new Rect(10, 100, 100, 20), "Hayosiko", styleRed))
				{
					HAYOSIKOD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(10, 100, 100, 20), "Hayosiko", styleGreen))
				{
					HAYOSIKOD();
				}
			}
			
			if(JONNEZB)
			{
				if (GUI.Button(new Rect(10, 120, 100, 20), "Jonnez ES", styleRed))
				{
					JONNEZD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(10, 120, 100, 20), "Jonnez ES", styleGreen))
				{
					JONNEZD();
				}
			}
		
			if(KEKMETB)
			{
				if (GUI.Button(new Rect(10, 140, 100, 20), "Kekmet", styleRed))
				{
					KEKMETD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(10, 140, 100, 20), "Kekmet", styleGreen))
				{
					KEKMETD();
				}
			}
		
			if(RCOB)
			{
				if (GUI.Button(new Rect(10, 160, 100, 20), "RCO Ruscko", styleRed))
				{
					RCOD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(10, 160, 100, 20), "RCO Ruscko", styleGreen))
				{
					RCOD();
				}
			}
			
			if(SATSUMAB)
			{
				if (GUI.Button(new Rect(10, 180, 100, 20), "Satsuma", styleRed))
				{
					SATSUMAD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(10, 180, 100, 20), "Satsuma", styleGreen))
				{
					SATSUMAD();
				}
			}
			
			if(CABINB)
			{
				if (GUI.Button(new Rect(120, 20, 100, 20), "Cabin", styleRed))
				{
					CABIND();
				}
			}
			else
			{
				if (GUI.Button(new Rect(120, 20, 100, 20), "Cabin", styleGreen))
				{
					CABIND();
				}
			}
			
			if(COTTAGEB)
			{
				if (GUI.Button(new Rect(120, 40, 100, 20), "Cottage", styleRed))
				{
					COTTAGED();
				}
			}
			else
			{
				if (GUI.Button(new Rect(120, 40, 100, 20), "Cottage", styleGreen))
				{
					COTTAGED();
				}
			}
			
			if(DANCEHALLB)
			{
				if (GUI.Button(new Rect(120, 60, 100, 20), "Dance hall", styleRed))
				{
					DANCEHALLD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(120, 60, 100, 20), "Dance hall", styleGreen))
				{
					DANCEHALLD();
				}
			}
			
			if(DRAGRACEB)
			{
				if (GUI.Button(new Rect(120, 80, 100, 20), "Drag race", styleRed))
				{
					DRAGRACED();
				}
			}
			else
			{
				if (GUI.Button(new Rect(120, 80, 100, 20), "Drag race", styleGreen))
				{
					DRAGRACED();
				}
			}
			
			if(INSPECTIONB)
			{
				if (GUI.Button(new Rect(120, 100, 100, 20), "Inspection", styleRed))
				{
					INSPECTIOND();
				}
			}
			else
			{
				if (GUI.Button(new Rect(120, 100, 100, 20), "Inspection", styleGreen))
				{
					INSPECTIOND();
				}
			}
			
			if(LANDFILLB)
			{
				if (GUI.Button(new Rect(120, 120, 100, 20), "Landfill", styleRed))
				{
					LANDFILLD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(120, 120, 100, 20), "Landfill", styleGreen))
				{
					LANDFILLD();
				}
			}
			
			if(PERAJARVIB)
			{
				if (GUI.Button(new Rect(120, 140, 100, 20), "Perajarvi", styleRed))
				{
					PERAJARVID();
				}
			}
			else
			{
				if (GUI.Button(new Rect(120, 140, 100, 20), "Perajarvi", styleGreen))
				{
					PERAJARVID();
				}
			}
			
			if(REPAIRSHOPB)
			{
				if (GUI.Button(new Rect(120, 160, 100, 20), "Repair shop", styleRed))
				{
					REPAIRSHOPD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(120, 160, 100, 20), "Repair shop", styleGreen))
				{
					REPAIRSHOPD();
				}
			}
			
			if(RYKIPOHJAB)
			{
				if (GUI.Button(new Rect(120, 180, 100, 20), "Rykipohja", styleRed))
				{
					RYKIPOHJAD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(120, 180, 100, 20), "Rykipohja", styleGreen))
				{
					RYKIPOHJAD();
				}
			}
			
			if(SOCCERB)
			{
				if (GUI.Button(new Rect(120, 200, 100, 20), "Soccer", styleRed))
				{
					SOCCERD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(120, 200, 100, 20), "Soccer", styleGreen))
				{
					SOCCERD();
				}
			}
			
			if(STOREB)
			{
				if (GUI.Button(new Rect(120, 220, 100, 20), "Store", styleRed))
				{
					STORED();
				}
			}
			else
			{
				if (GUI.Button(new Rect(120, 220, 100, 20), "Store", styleGreen))
				{
					STORED();
				}
			}
			
			if(WATERFACILITYB)
			{
				if (GUI.Button(new Rect(120, 240, 100, 20), "Water facility", styleRed))
				{
					WATERFACILITYD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(120, 240, 100, 20), "Water facility", styleGreen))
				{
					WATERFACILITYD();
				}
			}
			
			if(YARDB)
			{
				if (GUI.Button(new Rect(120, 260, 100, 20), "Yard", styleRed))
				{
					YARDD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(120, 260, 100, 20), "Yard", styleGreen))
				{
					YARDD();
				}
			}
			
			if(CARPARTSB)
			{
				if (GUI.Button(new Rect(230, 20, 100, 20), "Car parts", styleRed))
				{
					CARPARTSD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(230, 20, 100, 20), "Car parts", styleGreen))
				{
					CARPARTSD();
				}
			}
			
			if(DatabaseB)
			{
				if (GUI.Button(new Rect(230, 40, 100, 20), "Database", styleRed))
				{
					DatabaseD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(230, 40, 100, 20), "Database", styleGreen))
				{
					DatabaseD();
				}
			}
			
			if(HUMANSB)
			{
				if (GUI.Button(new Rect(230, 60, 100, 20), "Humans", styleRed))
				{
					HUMANSD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(230, 60, 100, 20), "Humans", styleGreen))
				{
					HUMANSD();
				}
			}
			
			if(ITEMSB)
			{
				if (GUI.Button(new Rect(230, 80, 100, 20), "Items", styleRed))
				{
					ITEMSD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(230, 80, 100, 20), "Items", styleGreen))
				{
					ITEMSD();
				}
			}
			
			if(JOBSB)
			{
				if (GUI.Button(new Rect(230, 100, 100, 20), "Jobs", styleRed))
				{
					JOBSD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(230, 100, 100, 20), "Jobs", styleGreen))
				{
					JOBSD();
				}
			}
			
			if(KILJUGUYB)
			{
				if (GUI.Button(new Rect(230, 120, 100, 20), "Kilju guy", styleRed))
				{
					KILJUGUYD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(230, 120, 100, 20), "Kilju guy", styleGreen))
				{
					KILJUGUYD();
				}
			}
			
			if(MISCB)
			{
				if (GUI.Button(new Rect(230, 140, 100, 20), "Misc", styleRed))
				{
					MISCD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(230, 140, 100, 20), "Misc", styleGreen))
				{
					MISCD();
				}
			}
			
			if(NPC_CARSB)
			{
				if (GUI.Button(new Rect(230, 160, 100, 20), "NPC cars", styleRed))
				{
					NPC_CARSD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(230, 160, 100, 20), "NPC cars", styleGreen))
				{
					NPC_CARSD();
				}
			}
			
			if(RALLYB)
			{
				if (GUI.Button(new Rect(230, 180, 100, 20), "Rally", styleRed))
				{
					RALLYD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(230, 180, 100, 20), "Rally", styleGreen))
				{
					RALLYD();
				}
			}
			
			if(SystemsB)
			{
				if (GUI.Button(new Rect(230, 200, 100, 20), "Systems", styleRed))
				{
					SystemsD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(230, 200, 100, 20), "Systems", styleGreen))
				{
					SystemsD();
				}
			}
			
			if(TRAFFICB)
			{
				if (GUI.Button(new Rect(230, 220, 100, 20), "Traffic", styleRed))
				{
					TRAFFICD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(230, 220, 100, 20), "Traffic", styleGreen))
				{
					TRAFFICD();
				}
			}
			
			if(TRAINB)
			{
				if (GUI.Button(new Rect(230, 240, 100, 20), "Train", styleRed))
				{
					TRAIND();
				}
			}
			else
			{
				if (GUI.Button(new Rect(230, 240, 100, 20), "Train", styleGreen))
				{
					TRAIND();
				}
			}
			
			if(MAPHALFB)
			{
				if (GUI.Button(new Rect(340, 20, 100, 20), "Map: half", styleRed))
				{
					MAPHALFD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(340, 20, 100, 20), "Map: half", styleGreen))
				{
					MAPHALFD();
				}
			}
			
			if(MAPFULLB)
			{
				if (GUI.Button(new Rect(340, 40, 100, 20), "Map: full", styleRed))
				{
					MAPFULLD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(340, 40, 100, 20), "Map: full", styleGreen))
				{
					MAPFULLD();
				}
			}
			
			if(BoltPMB)
			{
				if (GUI.Button(new Rect(340, 80, 100, 20), "All bolts", styleRed))
				{
					BoltPMD();
				}
			}
			else
			{
				if (GUI.Button(new Rect(340, 80, 100, 20), "All bolts", styleGreen))
				{
					BoltPMD();
				}
			}
		}
		
		private void BOATD()
		{
			BOATB = !BOATB;
			
			if(BOATB)
			{
				BOATG.SetActive(false);
			}
			else
			{
				BOATG.SetActive(true);
			}
		}
		
		private void FERNDALED()
		{
			FERNDALEB = !FERNDALEB;
			
			if(FERNDALEB)
			{
				FERNDALEG.SetActive(false);
			}
			else
			{
				FERNDALEG.SetActive(true);
			}
		}
		
		private void FLATBEDD()
		{
			FLATBEDB = !FLATBEDB;
			
			if(FLATBEDB)
			{
				FLATBEDG.SetActive(false);
			}
			else
			{
				FLATBEDG.SetActive(true);
			}
		}
		
		private void GIFUD()
		{
			GIFUB = !GIFUB;
			
			if(GIFUB)
			{
				GIFUG.SetActive(false);
			}
			else
			{
				GIFUG.SetActive(true);
			}
		}
		
		private void HAYOSIKOD()
		{
			HAYOSIKOB = !HAYOSIKOB;
			
			if(HAYOSIKOB)
			{
				HAYOSIKOG.SetActive(false);
			}
			else
			{
				HAYOSIKOG.SetActive(true);
			}
		}
		
		private void JONNEZD()
		{
			JONNEZB = !JONNEZB;
			
			if(JONNEZB)
			{
				JONNEZG.SetActive(false);
			}
			else
			{
				JONNEZG.SetActive(true);
			}
		}
		
		private void KEKMETD()
		{
			KEKMETB = !KEKMETB;
			
			if(KEKMETB)
			{
				KEKMETG.SetActive(false);
			}
			else
			{
				KEKMETG.SetActive(true);
			}
		}
		
		private void RCOD()
		{
			RCOB = !RCOB;
			
			if(RCOB)
			{
				RCOG.SetActive(false);
			}
			else
			{
				RCOG.SetActive(true);
			}
		}
		
		private void SATSUMAD()
		{
			SATSUMAB = !SATSUMAB;
			
			if(SATSUMAB)
			{
				SATSUMAG.SetActive(false);
			}
			else
			{
				SATSUMAG.SetActive(true);
			}
		}
		
		private void CABIND()
		{
			CABINB = !CABINB;
			
			if(CABINB)
			{
				CABING.SetActive(false);
			}
			else
			{
				CABING.SetActive(true);
			}
		}
		
		private void COTTAGED()
		{
			COTTAGEB = !COTTAGEB;
			
			if(COTTAGEB)
			{
				COTTAGEG.SetActive(false);
			}
			else
			{
				COTTAGEG.SetActive(true);
			}
		}
		
		private void DANCEHALLD()
		{
			DANCEHALLB = !DANCEHALLB;
			
			if(DANCEHALLB)
			{
				DANCEHALLG.SetActive(false);
			}
			else
			{
				DANCEHALLG.SetActive(true);
			}
		}
		
		private void DRAGRACED()
		{
			DRAGRACEB = !DRAGRACEB;
			
			if(DRAGRACEB)
			{
				DRAGRACEG.SetActive(false);
			}
			else
			{
				DRAGRACEG.SetActive(true);
			}
		}
		
		private void INSPECTIOND()
		{
			INSPECTIONB = !INSPECTIONB;
			
			if(INSPECTIONB)
			{
				INSPECTIONG.SetActive(false);
			}
			else
			{
				INSPECTIONG.SetActive(true);
			}
		}
		
		private void LANDFILLD()
		{
			LANDFILLB = !LANDFILLB;
			
			if(LANDFILLB)
			{
				LANDFILLG.SetActive(false);
			}
			else
			{
				LANDFILLG.SetActive(true);
			}
		}
		
		private void PERAJARVID()
		{
			PERAJARVIB = !PERAJARVIB;
			
			if(PERAJARVIB)
			{
				PERAJARVIG.SetActive(false);
			}
			else
			{
				PERAJARVIG.SetActive(true);
			}
		}
		
		private void REPAIRSHOPD()
		{
			REPAIRSHOPB = !REPAIRSHOPB;
			
			if(REPAIRSHOPB)
			{
				REPAIRSHOPG.SetActive(false);
			}
			else
			{
				REPAIRSHOPG.SetActive(true);
			}
		}
		
		private void RYKIPOHJAD()
		{
			RYKIPOHJAB = !RYKIPOHJAB;
			
			if(RYKIPOHJAB)
			{
				RYKIPOHJAG.SetActive(false);
			}
			else
			{
				RYKIPOHJAG.SetActive(true);
			}
		}
		
		private void SOCCERD()
		{
			SOCCERB = !SOCCERB;
			
			if(SOCCERB)
			{
				SOCCERG.SetActive(false);
			}
			else
			{
				SOCCERG.SetActive(true);
			}
		}
		
		private void STORED()
		{
			STOREB = !STOREB;
			
			if(STOREB)
			{
				STOREG.SetActive(false);
			}
			else
			{
				STOREG.SetActive(true);
			}
		}
		
		private void WATERFACILITYD()
		{
			WATERFACILITYB = !WATERFACILITYB;
			
			if(WATERFACILITYB)
			{
				WATERFACILITYG.SetActive(false);
			}
			else
			{
				WATERFACILITYG.SetActive(true);
			}
		}
		
		private void YARDD()
		{
			YARDB = !YARDB;
			
			if(YARDB)
			{
				YARDG.SetActive(false);
			}
			else
			{
				YARDG.SetActive(true);
			}
		}
		
		private void CARPARTSD()
		{
			CARPARTSB = !CARPARTSB;
			
			if(CARPARTSB)
			{
				CARPARTSG.SetActive(false);
			}
			else
			{
				CARPARTSG.SetActive(true);
			}
		}
		
		private void DatabaseD()
		{
			DatabaseB = !DatabaseB;
			
			if(DatabaseB)
			{
				DatabaseG.SetActive(false);
			}
			else
			{
				DatabaseG.SetActive(true);
			}
		}
		
		private void HUMANSD()
		{
			HUMANSB = !HUMANSB;
			
			if(HUMANSB)
			{
				HUMANSG.SetActive(false);
			}
			else
			{
				HUMANSG.SetActive(true);
			}
		}
		
		private void ITEMSD()
		{
			ITEMSB = !ITEMSB;
			
			if(ITEMSB)
			{
				ITEMSG.SetActive(false);
			}
			else
			{
				ITEMSG.SetActive(true);
			}
		}
		
		private void JOBSD()
		{
			JOBSB = !JOBSB;
			
			if(JOBSB)
			{
				JOBSG.SetActive(false);
			}
			else
			{
				JOBSG.SetActive(true);
			}
		}
		
		private void KILJUGUYD()
		{
			KILJUGUYB = !KILJUGUYB;
			
			if(KILJUGUYB)
			{
				KILJUGUYG.SetActive(false);
			}
			else
			{
				KILJUGUYG.SetActive(true);
			}
		}
		
		private void MISCD()
		{
			MISCB = !MISCB;
			
			if(MISCB)
			{
				MISCG.SetActive(false);
			}
			else
			{
				MISCG.SetActive(true);
			}
		}
		
		private void NPC_CARSD()
		{
			NPC_CARSB = !NPC_CARSB;
			
			if(NPC_CARSB)
			{
				NPC_CARSG.SetActive(false);
			}
			else
			{
				NPC_CARSG.SetActive(true);
			}
		}
		
		private void RALLYD()
		{
			RALLYB = !RALLYB;
			
			if(RALLYB)
			{
				RALLYG.SetActive(false);
			}
			else
			{
				RALLYG.SetActive(true);
			}
		}
		
		private void SystemsD()
		{
			SystemsB = !SystemsB;
			
			if(SystemsB)
			{
				SystemsG.SetActive(false);
			}
			else
			{
				SystemsG.SetActive(true);
			}
		}
		
		private void TRAFFICD()
		{
			TRAFFICB = !TRAFFICB;
			
			if(TRAFFICB)
			{
				TRAFFICG.SetActive(false);
			}
			else
			{
				TRAFFICG.SetActive(true);
			}
		}
		
		private void TRAIND()
		{
			TRAINB = !TRAINB;
			
			if(TRAINB)
			{
				TRAING.SetActive(false);
			}
			else
			{
				TRAING.SetActive(true);
			}
		}
		
		private void MAPHALFD()
		{
			if(MAPFULLB)
			{
				MAPFULLD();
			}
			
			MAPHALFB = !MAPHALFB;
			
			if(MAPHALFB)
			{
				BuildingsG.SetActive(false);
				TrafficSignsG.SetActive(false);
				StreetLightsG.SetActive(false);
				ELEC_POLESG.SetActive(false);
				ELEC_POLES_COLLG.SetActive(false);
				CHURCHWALLG.SetActive(false);
				TREES1_COLLG.SetActive(false);
				TREES2_COLLG.SetActive(false);
				TREES3_COLLG.SetActive(false);
				FOLIAGEG.SetActive(false);
				TERRAINOUTG.SetActive(false);
				ROCKSG.SetActive(false);
				BirdTowerG.SetActive(false);
				BusStopG.SetActive(false);
				BusStop1G.SetActive(false);
				HayBalesG.SetActive(false);
			}
			else
			{
				BuildingsG.SetActive(true);
				TrafficSignsG.SetActive(true);
				StreetLightsG.SetActive(true);
				ELEC_POLESG.SetActive(true);
				ELEC_POLES_COLLG.SetActive(true);
				CHURCHWALLG.SetActive(true);
				TREES1_COLLG.SetActive(true);
				TREES2_COLLG.SetActive(true);
				TREES3_COLLG.SetActive(true);
				FOLIAGEG.SetActive(true);
				TERRAINOUTG.SetActive(true);
				ROCKSG.SetActive(true);
				BirdTowerG.SetActive(true);
				BusStopG.SetActive(true);
				BusStop1G.SetActive(true);
				HayBalesG.SetActive(true);
			}
		}
		
		private void MAPFULLD()
		{
			if(MAPHALFB)
			{
				MAPHALFD();
			}
			
			MAPFULLB = !MAPFULLB;
			
			if(MAPFULLB)
			{
				MAPG.SetActive(false);
			}
			else
			{
				MAPG.SetActive(true);
			}
		}
		
		private void BoltPMD()
		{
			BoltPMB = !BoltPMB;
			
			if(BoltPMB)
			{
				GameObject[] allObjects = UnityEngine.Object.FindObjectsOfType<GameObject>();
				foreach(GameObject BoltPMG in allObjects)
				{
					if(BoltPMG.name == "BoltPM")
					{
						BoltPMG.SetActive(false);
					}
				}
			}
		}
		
		private void savesettings()
		{
			string[] array = new string[37];
			
			string[] arg0a = array;
			int arg0b = 0;
			bool num0 = BOATB;
			arg0a[arg0b] = num0.ToString();
			
			string[] arg1a = array;
			int arg1b = 1;
			bool num1 = FERNDALEB;
			arg1a[arg1b] = num1.ToString();
			
			string[] arg2a = array;
			int arg2b = 2;
			bool num2 = FLATBEDB;
			arg2a[arg2b] = num2.ToString();
			
			string[] arg3a = array;
			int arg3b = 3;
			bool num3 = GIFUB;
			arg3a[arg3b] = num3.ToString();
			
			string[] arg4a = array;
			int arg4b = 4;
			bool num4 = HAYOSIKOB;
			arg4a[arg4b] = num4.ToString();
			
			string[] arg5a = array;
			int arg5b = 5;
			bool num5 = JONNEZB;
			arg5a[arg5b] = num5.ToString();
			
			string[] arg6a = array;
			int arg6b = 6;
			bool num6 = KEKMETB;
			arg6a[arg6b] = num6.ToString();
			
			string[] arg7a = array;
			int arg7b = 7;
			bool num7 = RCOB;
			arg7a[arg7b] = num7.ToString();
			
			string[] arg8a = array;
			int arg8b = 8;
			bool num8 = SATSUMAB;
			arg8a[arg8b] = num8.ToString();
			
			string[] arg9a = array;
			int arg9b = 9;
			bool num9 = CABINB;
			arg9a[arg9b] = num9.ToString();
			
			string[] arg10a = array;
			int arg10b = 10;
			bool num10 = COTTAGEB;
			arg10a[arg10b] = num10.ToString();
			
			string[] arg11a = array;
			int arg11b = 11;
			bool num11 = DANCEHALLB;
			arg11a[arg11b] = num11.ToString();
			
			string[] arg12a = array;
			int arg12b = 12;
			bool num12 = DRAGRACEB;
			arg12a[arg12b] = num12.ToString();
			
			string[] arg13a = array;
			int arg13b = 13;
			bool num13 = INSPECTIONB;
			arg13a[arg13b] = num13.ToString();
			
			string[] arg14a = array;
			int arg14b = 14;
			bool num14 = LANDFILLB;
			arg14a[arg14b] = num14.ToString();
			
			string[] arg15a = array;
			int arg15b = 15;
			bool num15 = PERAJARVIB;
			arg15a[arg15b] = num15.ToString();
			
			string[] arg16a = array;
			int arg16b = 16;
			bool num16 = REPAIRSHOPB;
			arg16a[arg16b] = num16.ToString();
			
			string[] arg17a = array;
			int arg17b = 17;
			bool num17 = RYKIPOHJAB;
			arg17a[arg17b] = num17.ToString();
			
			string[] arg18a = array;
			int arg18b = 18;
			bool num18 = SOCCERB;
			arg18a[arg18b] = num18.ToString();
			
			string[] arg19a = array;
			int arg19b = 19;
			bool num19 = STOREB;
			arg19a[arg19b] = num19.ToString();
			
			string[] arg20a = array;
			int arg20b = 20;
			bool num20 = WATERFACILITYB;
			arg20a[arg20b] = num20.ToString();
			
			string[] arg21a = array;
			int arg21b = 21;
			bool num21 = YARDB;
			arg21a[arg21b] = num21.ToString();
			
			string[] arg22a = array;
			int arg22b = 22;
			bool num22 = CARPARTSB;
			arg22a[arg22b] = num22.ToString();
			
			string[] arg23a = array;
			int arg23b = 23;
			bool num23 = DatabaseB;
			arg23a[arg23b] = num23.ToString();
			
			string[] arg24a = array;
			int arg24b = 24;
			bool num24 = HUMANSB;
			arg24a[arg24b] = num24.ToString();
			
			string[] arg25a = array;
			int arg25b = 25;
			bool num25 = ITEMSB;
			arg25a[arg25b] = num25.ToString();
			
			string[] arg26a = array;
			int arg26b = 26;
			bool num26 = JOBSB;
			arg26a[arg26b] = num26.ToString();
			
			string[] arg27a = array;
			int arg27b = 27;
			bool num27 = KILJUGUYB;
			arg27a[arg27b] = num27.ToString();
			
			string[] arg28a = array;
			int arg28b = 28;
			bool num28 = MISCB;
			arg28a[arg28b] = num28.ToString();
			
			string[] arg29a = array;
			int arg29b = 29;
			bool num29 = NPC_CARSB;
			arg29a[arg29b] = num29.ToString();
			
			string[] arg30a = array;
			int arg30b = 30;
			bool num30 = RALLYB;
			arg30a[arg30b] = num30.ToString();
			
			string[] arg31a = array;
			int arg31b = 31;
			bool num31 = SystemsB;
			arg31a[arg31b] = num31.ToString();
			
			string[] arg32a = array;
			int arg32b = 32;
			bool num32 = TRAFFICB;
			arg32a[arg32b] = num32.ToString();
			
			string[] arg33a = array;
			int arg33b = 33;
			bool num33 = TRAINB;
			arg33a[arg33b] = num33.ToString();
			
			string[] arg34a = array;
			int arg34b = 34;
			bool num34 = MAPHALFB;
			arg34a[arg34b] = num34.ToString();
			
			string[] arg35a = array;
			int arg35b = 35;
			bool num35 = MAPFULLB;
			arg35a[arg35b] = num35.ToString();
			
			string[] arg36a = array;
			int arg36b = 36;
			bool num36 = BoltPMB;
			arg36a[arg36b] = num36.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void loadsettings()
		{
			string[] array = new string[37];
			if (File.Exists(path + "/save.txt"))
			{
				array = File.ReadAllLines(path + "/save.txt");
				
				BOATB = bool.Parse(array[0]);
				FERNDALEB = bool.Parse(array[1]);
				FLATBEDB = bool.Parse(array[2]);
				GIFUB = bool.Parse(array[3]);
				HAYOSIKOB = bool.Parse(array[4]);
				JONNEZB = bool.Parse(array[5]);
				KEKMETB = bool.Parse(array[6]);
				RCOB = bool.Parse(array[7]);
				SATSUMAB = bool.Parse(array[8]);
				CABINB = bool.Parse(array[9]);
				COTTAGEB = bool.Parse(array[10]);
				DANCEHALLB = bool.Parse(array[11]);
				DRAGRACEB = bool.Parse(array[12]);
				INSPECTIONB = bool.Parse(array[13]);
				LANDFILLB = bool.Parse(array[14]);
				PERAJARVIB = bool.Parse(array[15]);
				REPAIRSHOPB = bool.Parse(array[16]);
				RYKIPOHJAB = bool.Parse(array[17]);
				SOCCERB = bool.Parse(array[18]);
				STOREB = bool.Parse(array[19]);
				WATERFACILITYB = bool.Parse(array[20]);
				YARDB = bool.Parse(array[21]);
				CARPARTSB = bool.Parse(array[22]);
				DatabaseB = bool.Parse(array[23]);
				HUMANSB = bool.Parse(array[24]);
				ITEMSB = bool.Parse(array[25]);
				JOBSB = bool.Parse(array[26]);
				KILJUGUYB = bool.Parse(array[27]);
				MISCB = bool.Parse(array[28]);
				NPC_CARSB = bool.Parse(array[29]);
				RALLYB = bool.Parse(array[30]);
				SystemsB = bool.Parse(array[31]);
				TRAFFICB = bool.Parse(array[32]);
				TRAINB = bool.Parse(array[33]);
				MAPHALFB = bool.Parse(array[34]);
				MAPFULLB = bool.Parse(array[35]);
				BoltPMB = bool.Parse(array[36]);
			}
			
			if(BOATB)
			{
				BOATG.SetActive(false);
			}
			
			if(FERNDALEB)
			{
				FERNDALEG.SetActive(false);
			}
			
			if(FLATBEDB)
			{
				FLATBEDG.SetActive(false);
			}
			
			if(GIFUB)
			{
				GIFUG.SetActive(false);
			}
			
			if(HAYOSIKOB)
			{
				HAYOSIKOG.SetActive(false);
			}
			
			if(JONNEZB)
			{
				JONNEZG.SetActive(false);
			}
			
			if(KEKMETB)
			{
				KEKMETG.SetActive(false);
			}
			
			if(RCOB)
			{
				RCOG.SetActive(false);
			}
			
			if(SATSUMAB)
			{
				SATSUMAG.SetActive(false);
			}
			
			if(CABINB)
			{
				CABING.SetActive(false);
			}
			
			if(COTTAGEB)
			{
				COTTAGEG.SetActive(false);
			}
			
			if(DANCEHALLB)
			{
				DANCEHALLG.SetActive(false);
			}
			
			if(DRAGRACEB)
			{
				DRAGRACEG.SetActive(false);
			}
			
			if(INSPECTIONB)
			{
				INSPECTIONG.SetActive(false);
			}
			
			if(LANDFILLB)
			{
				LANDFILLG.SetActive(false);
			}
			
			if(PERAJARVIB)
			{
				PERAJARVIG.SetActive(false);
			}
			
			if(REPAIRSHOPB)
			{
				REPAIRSHOPG.SetActive(false);
			}
			
			if(RYKIPOHJAB)
			{
				RYKIPOHJAG.SetActive(false);
			}
			
			if(SOCCERB)
			{
				SOCCERG.SetActive(false);
			}
			
			if(STOREB)
			{
				STOREG.SetActive(false);
			}
			
			if(WATERFACILITYB)
			{
				WATERFACILITYG.SetActive(false);
			}
			
			if(YARDB)
			{
				YARDG.SetActive(false);
			}
			
			if(CARPARTSB)
			{
				CARPARTSG.SetActive(false);
			}
			
			if(DatabaseB)
			{
				DatabaseG.SetActive(false);
			}
			
			if(HUMANSB)
			{
				HUMANSG.SetActive(false);
			}
			
			if(JOBSB)
			{
				JOBSG.SetActive(false);
			}
			
			if(KILJUGUYB)
			{
				KILJUGUYG.SetActive(false);
			}
			
			if(MISCB)
			{
				MISCG.SetActive(false);
			}
			
			if(NPC_CARSB)
			{
				NPC_CARSG.SetActive(false);
			}
			
			if(RALLYB)
			{
				RALLYG.SetActive(false);
			}
			
			if(SystemsB)
			{
				SystemsG.SetActive(false);
			}
			
			if(TRAFFICB)
			{
				TRAFFICG.SetActive(false);
			}
			
			if(TRAINB)
			{
				TRAING.SetActive(false);
			}
			
			if(MAPHALFB)
			{
				BuildingsG.SetActive(false);
				TrafficSignsG.SetActive(false);
				StreetLightsG.SetActive(false);
				ELEC_POLESG.SetActive(false);
				ELEC_POLES_COLLG.SetActive(false);
				CHURCHWALLG.SetActive(false);
				TREES1_COLLG.SetActive(false);
				TREES2_COLLG.SetActive(false);
				TREES3_COLLG.SetActive(false);
				FOLIAGEG.SetActive(false);
				TERRAINOUTG.SetActive(false);
				ROCKSG.SetActive(false);
				BirdTowerG.SetActive(false);
				BusStopG.SetActive(false);
				BusStop1G.SetActive(false);
				HayBalesG.SetActive(false);
			}
			
			if(MAPFULLB)
			{
				MAPG.SetActive(false);
			}
			
			if(ITEMSB)
			{
				timer1 = true;
			}
			
			if(BoltPMB)
			{
				timer2 = true;
			}
		}
    }
}