﻿using HutongGames.PlayMaker;
using MSCLoader;
using UnityEngine;

namespace RallyWheel
{
    public class RallyWheel : Mod
    {
        public override string ID { get { return "RallyWheel"; } }
        public override string Name { get { return "RallyWheel"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }
		
        public override void Update()
		{
			GameObject.Find("wheel rally fl(Clone)").transform.localScale = new Vector3(0.9f, 0.9f, 0.9f);
			GameObject.Find("wheel rally fr(Clone)").transform.localScale = new Vector3(0.9f, 0.9f, 0.9f);
			GameObject.Find("wheel rally rl(Clone)").transform.localScale = new Vector3(0.9f, 0.9f, 0.9f);
			GameObject.Find("wheel rally rr(Clone)").transform.localScale = new Vector3(0.9f, 0.9f, 0.9f);
			
			GameObject.Find("SATSUMA(557kg)").GetComponent<Axles>().frontAxle.leftWheel.radius = 0.27f;
			GameObject.Find("SATSUMA(557kg)").GetComponent<Axles>().frontAxle.rightWheel.radius = 0.27f;
			GameObject.Find("SATSUMA(557kg)").GetComponent<Axles>().rearAxle.leftWheel.radius = 0.27f;
			GameObject.Find("SATSUMA(557kg)").GetComponent<Axles>().rearAxle.rightWheel.radius = 0.27f;
			
			GameObject.Find("discbrake(flxxx)").transform.localScale = new Vector3(0.9f, 0.9f, 0.9f);
			GameObject.Find("discbrake(frxxx)").transform.localScale = new Vector3(0.9f, 0.9f, 0.9f);
			GameObject.Find("drumbrake rl(xxxxx)").transform.localScale = new Vector3(0.9f, 0.9f, 0.9f);
			GameObject.Find("drumbrake rr(xxxxx)").transform.localScale = new Vector3(0.9f, 0.9f, 0.9f);
		}	
    }
}
