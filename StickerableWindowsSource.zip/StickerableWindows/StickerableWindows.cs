﻿using MSCLoader;
using UnityEngine;
using System.Collections;

namespace StickerableWindows
{
    public class StickerableWindows : Mod
    {
        public override string ID { get { return "StickerableWindows"; } }
        public override string Name { get { return "Stickerable Windows"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject WINDOWS;
		private string path = ModLoader.ModsFolder+@"\StickerableWindows\";
		
        public override void Update()
        {
            if (Application.loadedLevelName == "GAME" && !loaded)
            {
				WINDOWS = GameObject.Find("Sticker");
							
				ObjImporter objimporter = new ObjImporter();
				Mesh new_mesh0 = new Mesh();
				new_mesh0 = objimporter.ImportFile(path + "windows.obj");
				
				WINDOWS.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
									
				loaded = true;
            }
			
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
    }
}
