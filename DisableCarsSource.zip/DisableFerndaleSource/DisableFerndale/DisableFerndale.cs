﻿using MSCLoader;
using UnityEngine;

namespace DisableFerndale
{
    public class DisableFerndale : Mod
    {
        public override string ID { get { return "DisableFerndale"; } }
        public override string Name { get { return "Disable Ferndale"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject FERNDALE;
		
        public override void Update()
        {
			if (Application.loadedLevelName == "GAME" && !loaded)
            {
				FERNDALE = GameObject.Find("FERNDALE(1630kg)");
				FERNDALE.SetActive(false);
				loaded = true;
            }
			
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
    }
}
