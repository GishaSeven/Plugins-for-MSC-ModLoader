﻿using MSCLoader;
using UnityEngine;

namespace DisableGifu
{
    public class DisableGifu : Mod
    {
        public override string ID { get { return "DisableGifu"; } }
        public override string Name { get { return "Disable Gifu"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject GIFU;
		
        public override void Update()
        {
			if (Application.loadedLevelName == "GAME" && !loaded)
            {
				GIFU = GameObject.Find("GIFU(750/450psi)");
				GIFU.SetActive(false);
				loaded = true;
            }
			
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
    }
}
