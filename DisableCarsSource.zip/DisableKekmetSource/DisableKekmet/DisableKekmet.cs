﻿using MSCLoader;
using UnityEngine;

namespace DisableKekmet
{
    public class DisableKekmet : Mod
    {
        public override string ID { get { return "DisableKekmet"; } }
        public override string Name { get { return "Disable Kekmet"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject KEKMET;
		private GameObject FLATBED;
		
        public override void Update()
        {
			if (Application.loadedLevelName == "GAME" && !loaded)
            {
				KEKMET = GameObject.Find("KEKMET(350-400psi)");
				FLATBED = GameObject.Find("FLATBED");
				KEKMET.SetActive(false);
				FLATBED.SetActive(false);
				loaded = true;
            }
			
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
    }
}
