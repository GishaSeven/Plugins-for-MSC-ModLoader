﻿using MSCLoader;
using UnityEngine;

namespace DisableHayosiko
{
    public class DisableHayosiko : Mod
    {
        public override string ID { get { return "DisableHayosiko"; } }
        public override string Name { get { return "Disable Hayosiko"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject HAYOSIKO;
		
        public override void Update()
        {
			if (Application.loadedLevelName == "GAME" && !loaded)
            {
				HAYOSIKO = GameObject.Find("HAYOSIKO(1500kg)");
				HAYOSIKO.SetActive(false);
				loaded = true;
            }
			
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
    }
}
