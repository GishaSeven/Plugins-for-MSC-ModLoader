﻿using MSCLoader;
using UnityEngine;

namespace DisableJonnez
{
    public class DisableJonnez : Mod
    {
        public override string ID { get { return "DisableJonnez"; } }
        public override string Name { get { return "Disable Jonnez"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject JONNEZ;
		
        public override void Update()
        {
			if (Application.loadedLevelName == "GAME" && !loaded)
            {
				JONNEZ = GameObject.Find("JONNEZ ES(Clone)");
				JONNEZ.SetActive(false);
				loaded = true;
            }
			
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
    }
}
