﻿using MSCLoader;
using UnityEngine;

namespace Mirrors
{
    public class Mirrors : Mod
    {
        public override string ID { get { return "Mirrors"; } }
        public override string Name { get { return "Mirrors"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject LDOOR;
		private GameObject MIRRORMESH;
		private GameObject MIRRORCAMERA;
		private GameObject LFENDER;
		private GameObject RFENDER;
		
        public override void Update()
        {
			if (Application.loadedLevelName == "GAME" && !loaded)
            {
				LDOOR = GameObject.Find("door left(Clone)");		
				MIRRORMESH = LDOOR.transform.FindChild("mirror").gameObject;
				MIRRORCAMERA = LDOOR.transform.FindChild("CarSideMirrorPivot").gameObject;
				LFENDER = GameObject.Find("fender left(Clone)");
				RFENDER = GameObject.Find("fender right(Clone)");
				
				MIRRORMESH.transform.parent = LFENDER.transform;
				MIRRORMESH.transform.localPosition = new Vector3(-0.06f, 0.5f, 0.08f);
				MIRRORMESH.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
				MIRRORMESH.transform.localEulerAngles = new Vector3(0f, 0f, 0f);
				
				GameObject MirrorClone = GameObject.Instantiate(MIRRORMESH, MIRRORMESH.transform.position, MIRRORMESH.transform.rotation) as GameObject;
				
				MirrorClone.transform.parent = RFENDER.transform;
				MirrorClone.transform.localScale = new Vector3(1.2f, 1.2f, -1.2f);
				MirrorClone.transform.localPosition = new Vector3(0.078f, 0.5f, 0.08f);
				
				MIRRORCAMERA.transform.parent = LFENDER.transform;
				MIRRORCAMERA.transform.localPosition = new Vector3(0.5f, 0f, 0.5f);
				MIRRORCAMERA.transform.localEulerAngles = new Vector3(90f, 0f, 0f);
				
				loaded = true;
            }
			
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
    }
}
