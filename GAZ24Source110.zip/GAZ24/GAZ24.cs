﻿using System.IO;
using MSCLoader;
using System.Linq;
using UnityEngine;
using HutongGames.PlayMaker;
using HutongGames.PlayMaker.Actions;

namespace GAZ24
{
	public class GAZ24 : Mod
    {
        public override string ID => "GAZ24";
        public override string Name => "GAZ 24";
        public override string Author => "Roman266";
        public override string Version => "1.1.0";

		private bool loaded;
		private static Vector3 newpos;
		private static Quaternion newang;
		private GameObject MUSCLECOLLIDERS;
		private GameObject FERNDALE;
		private static GameObject FERNCLONE;
		private GameObject MESH1;
		private GameObject MESH2;
		private GameObject MESH3;
		private GameObject MESH4;
		private GameObject MESH5;
		private GameObject MESH6;
		private GameObject MESH7;
		private GameObject MESH8;
		private GameObject MESH9;
		private GameObject MESH10;
		private GameObject MESH11;
		private GameObject MESH12;
		private GameObject MESH13;
		private GameObject MESH14;
		private GameObject MESH15;
		private GameObject MESH16;
		private GameObject MESH17;
		private GameObject MESH18;
		private GameObject MESH19;
		private GameObject MESH20;
		private GameObject MESH21;
		private GameObject MESH22;
		private GameObject MESH23;
		private GameObject MESH23A;
		private GameObject MESH24;
		private GameObject MESH25;
		private GameObject MESH26;
		private GameObject MESH27;
		private GameObject MESH28;
		private GameObject MESH29;
		private GameObject MESH30;
		private GameObject MESH31;
		private GameObject MESH32;
		private GameObject MESH33;
		private GameObject MESH34;
		private GameObject MESH35;
		private GameObject MESH36;
		private GameObject MESH37;
		private GameObject MESH38;
		private GameObject MESH39;
		private GameObject MESH40;
		private GameObject MESH40A;
		private GameObject MESH41;
		private GameObject MESH42;
		private GameObject MESH43;
		private GameObject MESH44;
		private GameObject MESH45;
		private GameObject MESH46;
		private GameObject MESH47;
		private GameObject MESH48;
		private GameObject MESH49;
		private GameObject MESH50;
		private GameObject MESH51;
		private GameObject MESH52;
		private GameObject MESH53;
		private GameObject MESH54;
		private Texture2D TEXTURE1;
		private Texture2D TEXTURE2;
		private Texture2D TEXTURE3;
		private Texture2D TEXTURE4;
		private Material DASHMAT1;
		private Material DASHMAT2;
		private Material[] BODYCOLORMAT;
		private Material[] INTERIORCOLORMAT;
		private Material[] INTERIOR1COLORMAT;
		private Material[] INTERIOR2COLORMAT;
		private AudioClip IDLE;
		private AudioClip REV2;
		private AudioClip REV;
		public override bool LoadInMenu => true;
        public override bool UseAssetsFolder => true;
		
		Settings SettingsBool1 = new Settings("Doors", "Crutch doors fix (after change restart game)", false);
		Settings SettingsBool2 = new Settings("Sounds", "Ferndale sounds (after change restart game)", false);
		Settings SettingsBool3 = new Settings("Handling", "Ferndale handling (after change restart game)", false);
		Settings ResetButton = new Settings("Button", "Reset car", resetcar);
		
		public override void OnMenuLoad() 
		{
			SaveData data = SaveLoad.DeserializeSaveFile<SaveData>(this, "mySaveFile.save");
            if (data != null)
            {
                AssetBundle colliders = LoadAssets.LoadBundle(this,"colliders.unity3d");
				GameObject musclecolliders0 = colliders.LoadAsset("muscle_colliders.prefab") as GameObject;
				GameObject musclecolliders1 = GameObject.Instantiate<GameObject>(musclecolliders0);
				colliders.Unload(false);
				Object.Destroy(musclecolliders0);
				
				MUSCLECOLLIDERS = new GameObject("MUSCLECOLLIDERS");
				musclecolliders1.transform.parent = MUSCLECOLLIDERS.transform;
				musclecolliders1.transform.localPosition = new Vector3(0f, 0.04f, -0.16f);
				musclecolliders1.transform.localScale = new Vector3(0.9f, 1f, 0.95f);
							
				GameObject COLL1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
				COLL1.name = "MCOLL1";
				COLL1.transform.parent = MUSCLECOLLIDERS.transform;
				COLL1.transform.localScale = new Vector3(1.4f, 0.3f, 0.3f);
				COLL1.transform.localPosition = new Vector3(0f, 0.217f, 0.05f);
				COLL1.transform.localEulerAngles= new Vector3(0, 0, 0);
				COLL1.GetComponent<MeshRenderer>().enabled = false;	
				GameObject COLL2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
				COLL2.name = "MCOLL2";
				COLL2.transform.parent = MUSCLECOLLIDERS.transform;
				COLL2.transform.localScale = new Vector3(1.4f, 0.3f, 0.219f);
				COLL2.transform.localPosition = new Vector3(0f, 0.217f, -0.709f);
				COLL2.transform.localEulerAngles= new Vector3(0, 0, 0);
				COLL2.GetComponent<MeshRenderer>().enabled = false;
				GameObject COLL3 = GameObject.CreatePrimitive(PrimitiveType.Cube);
				COLL3.name = "MCOLL3";
				COLL3.transform.parent = MUSCLECOLLIDERS.transform;
				COLL3.transform.localScale = new Vector3(1.4f, 0.4f, 0.019f);
				COLL3.transform.localPosition = new Vector3(0f, 0.497f, -1.75f);
				COLL3.transform.localEulerAngles= new Vector3(0, 0, 0);
				COLL3.GetComponent<MeshRenderer>().enabled = false;	
				
				MUSCLECOLLIDERS.transform.position = data.save[0].pos;
                MUSCLECOLLIDERS.transform.rotation = Quaternion.Euler(data.save[0].rotX, data.save[0].rotY, data.save[0].rotZ);
				
				Object.DontDestroyOnLoad(MUSCLECOLLIDERS);
            }
		}
		
        public override void OnLoad()
        {
			FsmVariables.GlobalVariables.FindFsmInt("PlayerKeyFerndale").Value = 1;
			FERNDALE = GameObject.Find("FERNDALE(1630kg)");
			newpos = new Vector3(-13.7473345f, -0.358597517f, 33.1640244f);
			newang = Quaternion.Euler(0.7254235f, 198.5796f, 359.9826f);
			FERNCLONE = GameObject.Instantiate(FERNDALE, newpos, newang) as GameObject;
			
			// FRED TWEAK
            foreach (PlayMakerFSM playmaker in FERNCLONE.GetComponentsInChildren<PlayMakerFSM>().Where(fsm => fsm.FsmStates.Any(state => state.Name != null && (state.Name == "Load game" || state.Name == "Save game"))))
                foreach (FsmState state in playmaker.FsmStates.Where(state => state.Name == "Load game" || state.Name == "Save game"))
                    state.Actions = new FsmStateAction[0];

            // GASOLINE INDICATOR
            Transform indicators = GameObject.Find("GUI/Indicators/Fluids").transform;
            GameObject gasolineIndicator = Object.Instantiate(indicators.Find("GasolineMuscle").gameObject);
            gasolineIndicator.name = "GasolineGAZ24MOD";
            gasolineIndicator.transform.GetChild(1).GetComponent<PlayMakerFSM>().FsmVariables.FindFsmGameObject("Tank").Value = FERNCLONE.transform.Find("FuelTank").gameObject;
            gasolineIndicator.SetActive(false);
            gasolineIndicator.transform.parent = indicators;
            gasolineIndicator.transform.localPosition = Vector3.zero;
            gasolineIndicator.transform.localEulerAngles = Vector3.zero;

            FERNCLONE.transform.Find("LOD/FuelFiller 1/OpenCap/CapTrigger_FuelFerndale").GetComponent<PlayMakerFSM>().FsmVariables.FindFsmGameObject("VehicleGUI").Value = gasolineIndicator;
			
            // FIX DUAL SHIFTING AND INPUT
            string playerCarName = "GAZ24";
            bool lodActive = FERNCLONE.transform.Find("LOD").gameObject.activeSelf;
            FERNCLONE.transform.Find("LOD").gameObject.SetActive(true);
			
            (FERNCLONE.transform.Find("LOD/PlayerTrigger/DriveTrigger").GetComponent<PlayMakerFSM>().FsmStates.First(state => state.Name == "Player in car").Actions[15] as SetStringValue).stringValue = playerCarName;
			
            // GEAR
            foreach (FsmState state in FERNCLONE.transform.Find("LOD/Dashboard/GearShifter/Pivot").GetComponent<PlayMakerFSM>().FsmStates.Where(state => state.Name.Contains("In car")))
                (state.Actions[0] as StringCompare).compareTo = playerCarName;

            // LIGHTS
            (FERNCLONE.transform.Find("LOD/Dashboard/Knobs/Lights").GetComponent<PlayMakerFSM>().FsmStates.First(state => state.Name == "Check down").Actions[0] as StringCompare).compareTo = playerCarName;

            // WIPERS
            (FERNCLONE.transform.Find("LOD/Dashboard/Knobs/ButtonWipers").GetComponent<PlayMakerFSM>().FsmStates.First(state => state.Name == "Check car").Actions[0] as StringCompare).compareTo = playerCarName;

            // INDICATORS
            (FERNCLONE.transform.Find("LOD/Dashboard/TurnSignals").GetComponent<PlayMakerFSM>().FsmStates.First(state => state.Name == "State 2").Actions[2] as StringCompare).compareTo = playerCarName;
			
			(FERNCLONE.transform.Find("LOD/Dashboard/TurnSignals").GetComponent<PlayMakerFSM>().FsmStates.First(state => state.Name == "Check player").Actions[2] as StringCompare).compareTo = playerCarName;

            FERNCLONE.transform.Find("LOD").gameObject.SetActive(lodActive);
            // FRED TWEAK
			
			AssetBundle models = LoadAssets.LoadBundle(this,"models.unity3d"); 
			GameObject MESH1X = models.LoadAsset("body.prefab") as GameObject; 
			GameObject MESH2X = models.LoadAsset("windshield.prefab") as GameObject; 
			GameObject MESH3X = models.LoadAsset("glass.prefab") as GameObject; 
			GameObject MESH4X = models.LoadAsset("interior1.prefab") as GameObject; 
			GameObject MESH5X = models.LoadAsset("interior2.prefab") as GameObject; 
			GameObject MESH6X = models.LoadAsset("engine0.prefab") as GameObject; 
			GameObject MESH7X = models.LoadAsset("engine1.prefab") as GameObject;
			GameObject MESH8X = models.LoadAsset("battery.prefab") as GameObject; 
			GameObject MESH9X = models.LoadAsset("radiator.prefab") as GameObject; 
			GameObject MESH10X = models.LoadAsset("trunk.prefab") as GameObject; 
			GameObject MESH11X = models.LoadAsset("wheel.prefab") as GameObject; 
			GameObject MESH12X = models.LoadAsset("wheel.prefab") as GameObject; 
			GameObject MESH13X = models.LoadAsset("wheel.prefab") as GameObject; 
			GameObject MESH14X = models.LoadAsset("wheel.prefab") as GameObject; 
			GameObject MESH15X = models.LoadAsset("fuel.prefab") as GameObject; 
			GameObject MESH16X = models.LoadAsset("wiperl1.prefab") as GameObject;
			GameObject MESH17X = models.LoadAsset("wiperl2.prefab") as GameObject; 
			GameObject MESH18X = models.LoadAsset("wiperr1.prefab") as GameObject;
			GameObject MESH19X = models.LoadAsset("wiperr2.prefab") as GameObject;
			GameObject MESH20X = models.LoadAsset("dashboard.prefab") as GameObject; 
			GameObject MESH21X = models.LoadAsset("headlights.prefab") as GameObject; 
			GameObject MESH22X = models.LoadAsset("doorl1.prefab") as GameObject; 
			GameObject MESH23X = models.LoadAsset("doorl2.prefab") as GameObject; 
			GameObject MESH24X = models.LoadAsset("doorl3.prefab") as GameObject;
			GameObject MESH25X = models.LoadAsset("doorl4.prefab") as GameObject;
			GameObject MESH26X = models.LoadAsset("doorl5.prefab") as GameObject;
			GameObject MESH27X = models.LoadAsset("doorr1.prefab") as GameObject;
			GameObject MESH28X = models.LoadAsset("doorr2.prefab") as GameObject;
			GameObject MESH29X = models.LoadAsset("cardfl.prefab") as GameObject;
			GameObject MESH30X = models.LoadAsset("cardfr.prefab") as GameObject;
			GameObject MESH31X = models.LoadAsset("body2.prefab") as GameObject;
			GameObject MESH32X = models.LoadAsset("rearaxle.prefab") as GameObject;
			GameObject MESH33X = models.LoadAsset("gauges.prefab") as GameObject; 
			GameObject MESH34X = models.LoadAsset("steerwheel.prefab") as GameObject; 
			GameObject MESH35X = models.LoadAsset("regplates.prefab") as GameObject;
			GameObject MESH36X = models.LoadAsset("keyhole.prefab") as GameObject;
			GameObject MESH37X = models.LoadAsset("gearshifter.prefab") as GameObject;
			GameObject MESH38X = models.LoadAsset("pedalbrake.prefab") as GameObject; 
			GameObject MESH39X = models.LoadAsset("pedalthrottle.prefab") as GameObject;
			GameObject MESH40X = models.LoadAsset("rearmirror.prefab") as GameObject;
			GameObject MESH41X = models.LoadAsset("blinker.prefab") as GameObject; 
			GameObject MESH42X = models.LoadAsset("radiotuner1.prefab") as GameObject;
			GameObject MESH43X = models.LoadAsset("radiotuner2.prefab") as GameObject;
			GameObject MESH44X = models.LoadAsset("belt1.prefab") as GameObject; 
			GameObject MESH45X = models.LoadAsset("belt2.prefab") as GameObject; 
			GameObject MESH46X = models.LoadAsset("needle1.prefab") as GameObject; 
			GameObject MESH47X = models.LoadAsset("needle2.prefab") as GameObject; 
			GameObject MESH48X = models.LoadAsset("needle3.prefab") as GameObject; 
			GameObject MESH49X = models.LoadAsset("needle4.prefab") as GameObject; 
			GameObject MESH50X = models.LoadAsset("needle5.prefab") as GameObject;
			GameObject MESH51X = models.LoadAsset("needle6.prefab") as GameObject;
			GameObject MESH52X = models.LoadAsset("needle7.prefab") as GameObject;
			GameObject MESH53X = models.LoadAsset("cards.prefab") as GameObject;
			GameObject MESH54X = models.LoadAsset("gearshifter2.prefab") as GameObject;
			TEXTURE3 = models.LoadAsset("susp_d.dds") as Texture2D;
			
			MESH1 = GameObject.Instantiate<GameObject>(MESH1X);
			MESH2 = GameObject.Instantiate<GameObject>(MESH2X);
			MESH3 = GameObject.Instantiate<GameObject>(MESH3X);
			MESH4 = GameObject.Instantiate<GameObject>(MESH4X);
			MESH5 = GameObject.Instantiate<GameObject>(MESH5X);
			MESH6 = GameObject.Instantiate<GameObject>(MESH6X);
			MESH7 = GameObject.Instantiate<GameObject>(MESH7X);
			MESH8 = GameObject.Instantiate<GameObject>(MESH8X);
			MESH9 = GameObject.Instantiate<GameObject>(MESH9X);
			MESH10 = GameObject.Instantiate<GameObject>(MESH10X);
			MESH11 = GameObject.Instantiate<GameObject>(MESH11X);
			MESH12 = GameObject.Instantiate<GameObject>(MESH12X);
			MESH13 = GameObject.Instantiate<GameObject>(MESH13X);
			MESH14 = GameObject.Instantiate<GameObject>(MESH14X);
			MESH15 = GameObject.Instantiate<GameObject>(MESH15X);
			MESH16 = GameObject.Instantiate<GameObject>(MESH16X);
			MESH17 = GameObject.Instantiate<GameObject>(MESH17X);
			MESH18 = GameObject.Instantiate<GameObject>(MESH18X);
			MESH19 = GameObject.Instantiate<GameObject>(MESH19X);
			MESH20 = GameObject.Instantiate<GameObject>(MESH20X);
			MESH21 = GameObject.Instantiate<GameObject>(MESH21X);
			MESH22 = GameObject.Instantiate<GameObject>(MESH22X);
			MESH23 = GameObject.Instantiate<GameObject>(MESH23X);
			MESH23A = GameObject.Instantiate<GameObject>(MESH23X);
			MESH24 = GameObject.Instantiate<GameObject>(MESH24X);
			MESH25 = GameObject.Instantiate<GameObject>(MESH25X);
			MESH26 = GameObject.Instantiate<GameObject>(MESH26X);
			MESH27 = GameObject.Instantiate<GameObject>(MESH27X);
			MESH28 = GameObject.Instantiate<GameObject>(MESH28X);
			MESH29 = GameObject.Instantiate<GameObject>(MESH29X);
			MESH30 = GameObject.Instantiate<GameObject>(MESH30X);
			MESH31 = GameObject.Instantiate<GameObject>(MESH31X);
			MESH32 = GameObject.Instantiate<GameObject>(MESH32X);
			MESH33 = GameObject.Instantiate<GameObject>(MESH33X);
			MESH34 = GameObject.Instantiate<GameObject>(MESH34X);
			MESH35 = GameObject.Instantiate<GameObject>(MESH35X);
			MESH36 = GameObject.Instantiate<GameObject>(MESH36X);
			MESH37 = GameObject.Instantiate<GameObject>(MESH37X);
			MESH38 = GameObject.Instantiate<GameObject>(MESH38X);
			MESH39 = GameObject.Instantiate<GameObject>(MESH39X);
			MESH40 = GameObject.Instantiate<GameObject>(MESH40X);
			MESH40A = GameObject.Instantiate<GameObject>(MESH40X);
			MESH41 = GameObject.Instantiate<GameObject>(MESH41X);
			MESH42 = GameObject.Instantiate<GameObject>(MESH42X);
			MESH43 = GameObject.Instantiate<GameObject>(MESH43X);
			MESH44 = GameObject.Instantiate<GameObject>(MESH44X);
			MESH45 = GameObject.Instantiate<GameObject>(MESH45X);
			MESH46 = GameObject.Instantiate<GameObject>(MESH46X);
			MESH47 = GameObject.Instantiate<GameObject>(MESH47X);
			MESH48 = GameObject.Instantiate<GameObject>(MESH48X);
			MESH49 = GameObject.Instantiate<GameObject>(MESH49X);
			MESH50 = GameObject.Instantiate<GameObject>(MESH50X);
			MESH51 = GameObject.Instantiate<GameObject>(MESH51X);
			MESH52 = GameObject.Instantiate<GameObject>(MESH52X);
			MESH53 = GameObject.Instantiate<GameObject>(MESH53X);
			MESH54 = GameObject.Instantiate<GameObject>(MESH54X);
			models.Unload(false);
			
			Object.Destroy(MESH1X);
			Object.Destroy(MESH2X);
			Object.Destroy(MESH3X);
			Object.Destroy(MESH4X);
			Object.Destroy(MESH5X);
			Object.Destroy(MESH6X);
			Object.Destroy(MESH7X);
			Object.Destroy(MESH8X);
			Object.Destroy(MESH9X);
			Object.Destroy(MESH10X);
			Object.Destroy(MESH11X);
			Object.Destroy(MESH12X);
			Object.Destroy(MESH13X);
			Object.Destroy(MESH14X);
			Object.Destroy(MESH15X);
			Object.Destroy(MESH16X);
			Object.Destroy(MESH17X);
			Object.Destroy(MESH18X);
			Object.Destroy(MESH19X);
			Object.Destroy(MESH20X);
			Object.Destroy(MESH21X);
			Object.Destroy(MESH22X);
			Object.Destroy(MESH23X);
			Object.Destroy(MESH24X);
			Object.Destroy(MESH25X);
			Object.Destroy(MESH26X);
			Object.Destroy(MESH27X);
			Object.Destroy(MESH28X);
			Object.Destroy(MESH29X);
			Object.Destroy(MESH30X);
			Object.Destroy(MESH31X);
			Object.Destroy(MESH32X);
			Object.Destroy(MESH33X);
			Object.Destroy(MESH34X);
			Object.Destroy(MESH35X);
			Object.Destroy(MESH36X);
			Object.Destroy(MESH37X);
			Object.Destroy(MESH38X);
			Object.Destroy(MESH39X);
			Object.Destroy(MESH40X);
			Object.Destroy(MESH41X);
			Object.Destroy(MESH42X);
			Object.Destroy(MESH43X);
			Object.Destroy(MESH44X);
			Object.Destroy(MESH45X);
			Object.Destroy(MESH46X);
			Object.Destroy(MESH47X);
			Object.Destroy(MESH48X);
			Object.Destroy(MESH49X);
			Object.Destroy(MESH50X);
			Object.Destroy(MESH51X);
			Object.Destroy(MESH52X);
			Object.Destroy(MESH53X);
			Object.Destroy(MESH54X);
			
			TEXTURE1 = LoadAssets.LoadTexture(this, "body_color.png");
			TEXTURE2 = LoadAssets.LoadTexture(this, "interior_color.png");
			
			Material bodycolormap = new Material(Shader.Find("Diffuse"));
			bodycolormap.SetTexture("_MainTex", TEXTURE1);
			BODYCOLORMAT = new Material[]{         
			bodycolormap as Material,
			MESH1.transform.GetChild(0).gameObject.GetComponent<MeshRenderer>().material as Material,
			};
			Material interiorcolormap = new Material(Shader.Find("Diffuse"));
			interiorcolormap.SetTexture("_MainTex", TEXTURE2);
			INTERIORCOLORMAT = new Material[]{         
			interiorcolormap as Material,
			MESH1.transform.GetChild(0).gameObject.GetComponent<MeshRenderer>().material as Material,
			};
			INTERIOR1COLORMAT = new Material[]{         
			interiorcolormap as Material,
			MESH4.transform.GetChild(0).gameObject.GetComponent<MeshRenderer>().material as Material,
			};
			INTERIOR2COLORMAT = new Material[]{         
			interiorcolormap as Material,
			MESH5.transform.GetChild(0).gameObject.GetComponent<MeshRenderer>().material as Material,
			};
			DASHMAT1 = MESH20.transform.GetChild(0).gameObject.GetComponent<MeshRenderer>().material;
			DASHMAT2 = MESH33.transform.GetChild(0).gameObject.GetComponent<MeshRenderer>().material;
			
			AssetBundle sounds = LoadAssets.LoadBundle(this,"sounds.unity3d");
			IDLE = sounds.LoadAsset("idle_2.wav") as AudioClip;
			REV2 = sounds.LoadAsset("high_3.wav") as AudioClip;
			REV = sounds.LoadAsset("high_4.wav") as AudioClip;
			sounds.Unload(false);
			
			SaveData data = SaveLoad.DeserializeSaveFile<SaveData>(this, "mySaveFile.save");
			if (data != null)
			{
				FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("FuelLevel").Value = data.save[0].fuel;
						
				Object.Destroy(MUSCLECOLLIDERS);
						
				FERNCLONE.transform.position = data.save[0].pos;
                FERNCLONE.transform.rotation = Quaternion.Euler(data.save[0].rotX, data.save[0].rotY, data.save[0].rotZ);
			}
			else
			{
				FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("FuelLevel").Value = 55;
				FERNCLONE.transform.position = newpos;
				FERNCLONE.transform.rotation = newang;
			}
					
			FERNCLONE.name = "GAZ24(1420kg)";
			
			if(!(bool)SettingsBool3.GetValue())
			{
				FERNCLONE.GetComponent<Rigidbody>().mass = 1420;
				FERNCLONE.GetComponent<Drivetrain>().maxPower = 60;
				FERNCLONE.GetComponent<Drivetrain>().maxPowerRPM = 4500;
				FERNCLONE.GetComponent<Drivetrain>().maxTorque = 160;
				FERNCLONE.GetComponent<Drivetrain>().maxTorqueRPM = 2300;
				FERNCLONE.GetComponent<Drivetrain>().minRPM = 750;
				FERNCLONE.GetComponent<Drivetrain>().maxRPM = 5500;
				FERNCLONE.GetComponent<Drivetrain>().engineInertia = 1;
				FERNCLONE.GetComponent<Drivetrain>().differentialLockCoefficient = 0;
				FERNCLONE.GetComponent<Drivetrain>().engageRPM = 850;
				FERNCLONE.GetComponent<Drivetrain>().disengageRPM = 650;
				FERNCLONE.GetComponent<Axles>().frontAxle.leftWheel.suspensionTravel = 0.2f;
				FERNCLONE.GetComponent<Axles>().frontAxle.leftWheel.suspensionRate = 50000f;
				FERNCLONE.GetComponent<Axles>().frontAxle.leftWheel.bumpRate = 1100f;
				FERNCLONE.GetComponent<Axles>().frontAxle.leftWheel.reboundRate = 1100f;
				FERNCLONE.GetComponent<Axles>().frontAxle.rightWheel.suspensionTravel = 0.2f;
				FERNCLONE.GetComponent<Axles>().frontAxle.rightWheel.suspensionRate = 50000f;
				FERNCLONE.GetComponent<Axles>().frontAxle.rightWheel.bumpRate = 1100f;
				FERNCLONE.GetComponent<Axles>().frontAxle.rightWheel.reboundRate = 1100f;
				FERNCLONE.GetComponent<Axles>().rearAxle.leftWheel.suspensionTravel = 0.15f;
				FERNCLONE.GetComponent<Axles>().rearAxle.leftWheel.bumpRate = 1100f;
				FERNCLONE.GetComponent<Axles>().rearAxle.leftWheel.reboundRate = 1100f;
				FERNCLONE.GetComponent<Axles>().rearAxle.rightWheel.suspensionTravel = 0.15f;
				FERNCLONE.GetComponent<Axles>().rearAxle.rightWheel.bumpRate = 1100f;
				FERNCLONE.GetComponent<Axles>().rearAxle.rightWheel.reboundRate = 1100f;
			}
			
			FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("MaxCapacity").Value = 55;
			FERNCLONE.GetComponents<PlayMakerFSM>()[0].FsmVariables.GetFsmString("UniqueTagPosition").Value = "GAZ24Transform";
			FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("UniqueTagFuelLevel").Value = "GAZ24FuelLevel";
					
			MESH1.transform.parent = FERNCLONE.transform;
			MESH1.transform.localScale = new Vector3(1, -1, 1);
			MESH1.transform.localPosition = new Vector3(0, 0, 0);
			MESH1.transform.localEulerAngles = new Vector3(270, 90, 0);
			MESH1.transform.GetChild(0).GetComponent<Renderer>().materials = BODYCOLORMAT;
			MESH1.name = "gaz24body";
					
			FERNCLONE.transform.FindChild("LOD/MESH/glass_rear").gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD/MESH/windshield").gameObject.transform.localScale = new Vector3(-1, 1, 1);
			FERNCLONE.transform.FindChild("LOD/MESH/windshield").GetComponent<MeshFilter>().mesh = MESH2.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
			Object.Destroy(MESH2);
			FERNCLONE.transform.FindChild("LOD/MESH/glass_sides").gameObject.transform.localScale = new Vector3(-1, 1, 1);
			FERNCLONE.transform.FindChild("LOD/MESH/glass_sides").GetComponent<MeshFilter>().mesh = MESH3.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
			Object.Destroy(MESH3);

			MESH4.transform.parent = FERNCLONE.transform;
			MESH4.transform.localScale = new Vector3(1, -1, 1);
			MESH4.transform.localPosition = new Vector3(0, 0, 0);
			MESH4.transform.localEulerAngles = new Vector3(270, 90, 0);
			MESH4.transform.GetChild(0).GetComponent<Renderer>().materials = INTERIOR1COLORMAT;
			FERNCLONE.transform.FindChild("LOD/MESH/muscle_interior").gameObject.SetActive(false);
			MESH5.transform.parent = FERNCLONE.transform;
			MESH5.transform.localScale = new Vector3(1, -1, 1);
			MESH5.transform.localPosition = new Vector3(0, 0, 0);
			MESH5.transform.localEulerAngles = new Vector3(270, 90, 0);
			MESH5.transform.GetChild(0).GetComponent<Renderer>().materials = INTERIOR2COLORMAT;
			FERNCLONE.transform.FindChild("MESH").gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD/MESH/muscle_dashboard").gameObject.SetActive(false);
					
			FERNCLONE.transform.FindChild("LOD/MESH/muscle_chassis").gameObject.transform.localScale = new Vector3(-1, 1, 1);
			FERNCLONE.transform.FindChild("LOD/MESH/muscle_chassis").GetComponent<MeshFilter>().mesh = MESH6.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
			FERNCLONE.transform.FindChild("LOD/MESH/muscle_chassis").GetComponent<MeshRenderer>().material = MESH6.transform.GetChild(0).GetComponent<MeshRenderer>().material;
			Object.Destroy(MESH6);
			
			FERNCLONE.transform.FindChild("LOD/MESH/muscle_chassis 1").gameObject.transform.localScale = new Vector3(-1, 1, 1);
			FERNCLONE.transform.FindChild("LOD/MESH/muscle_chassis 1").GetComponent<MeshFilter>().mesh = MESH7.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
			FERNCLONE.transform.FindChild("LOD/MESH/muscle_chassis 1").GetComponent<MeshRenderer>().material = MESH7.transform.GetChild(0).GetComponent<MeshRenderer>().material;
			Object.Destroy(MESH7);
			
			MESH8.transform.parent = FERNCLONE.transform;
			MESH8.transform.localScale = new Vector3(1, -1, 1);
			MESH8.transform.localPosition = new Vector3(0, 0, 0);
			MESH8.transform.localEulerAngles = new Vector3(270, 90, 0);
			MESH8.transform.GetChild(0).GetComponent<MeshRenderer>().material.mainTexture = TEXTURE1;
			MESH9.transform.parent = FERNCLONE.transform;
			MESH9.transform.localScale = new Vector3(1, -1, 1);
			MESH9.transform.localPosition = new Vector3(0, 0, 0);
			MESH9.transform.localEulerAngles = new Vector3(270, 90, 0);
					
			MESH10.transform.parent = FERNCLONE.transform.FindChild("Bootlid/Bootlid").transform;
			MESH10.transform.localScale = new Vector3(-1, 1, 1);
			MESH10.transform.localPosition = new Vector3(0, 0, 0);
			MESH10.transform.localEulerAngles = new Vector3(0, 0, 0);
			MESH10.transform.GetChild(0).GetComponent<Renderer>().materials = BODYCOLORMAT;
			MESH10.name = "gaz24trunk";
			FERNCLONE.transform.FindChild("Bootlid/Bootlid/muscle_bootlid").gameObject.GetComponent<MeshRenderer>().enabled = false;
			GameObject BOOTLID = FERNCLONE.transform.FindChild("Bootlid").gameObject;
			BOOTLID.SetActive(false);
			BOOTLID.transform.localPosition = new Vector3(0f, 0.643f, -1.766f);
			BOOTLID.SetActive(true);
			GameObject BOOTLID2 = FERNCLONE.transform.FindChild("Bootlid/Bootlid").gameObject;
			BOOTLID2.SetActive(false);
			BOOTLID2.transform.localPosition = new Vector3(0, 0, 0);
			BOOTLID2.SetActive(true);
					
			MESH11.transform.parent = FERNCLONE.transform.FindChild("wheelFL/Tire").transform;
			MESH11.transform.localScale = new Vector3(-1, 1, 1);
			MESH11.transform.localPosition = new Vector3(0, 0, 0);
			MESH11.transform.localEulerAngles = new Vector3(0, 0, 180);
			FERNCLONE.transform.FindChild("wheelFL/Tire/Mesh 3").gameObject.SetActive(false);
					
			MESH12.transform.parent = FERNCLONE.transform.FindChild("wheelFR/Tire").transform;
			MESH12.transform.localScale = new Vector3(-1, 1, 1);
			MESH12.transform.localPosition = new Vector3(0, 0, 0);
			MESH12.transform.localEulerAngles = new Vector3(0, 0, 0);
			FERNCLONE.transform.FindChild("wheelFR/Tire/Mesh 2").gameObject.SetActive(false);
					
			MESH13.transform.parent = FERNCLONE.transform.FindChild("wheelRL/Tire").transform;
			MESH13.transform.localScale = new Vector3(-1, 1, 1);
			MESH13.transform.localPosition = new Vector3(0, 0, 0);
			MESH13.transform.localEulerAngles = new Vector3(0, 0, 180);
			FERNCLONE.transform.FindChild("wheelRL/Tire/Mesh 1").gameObject.SetActive(false);
					
			MESH14.transform.parent = FERNCLONE.transform.FindChild("wheelRR/Tire").transform;
			MESH14.transform.localScale = new Vector3(-1, 1, 1);
			MESH14.transform.localPosition = new Vector3(0, 0, 0);
			MESH14.transform.localEulerAngles = new Vector3(0, 0, 0);
			FERNCLONE.transform.FindChild("wheelRR/Tire/Mesh").gameObject.SetActive(false);
					
			FERNCLONE.transform.FindChild("wheelFL").transform.localPosition = new Vector3(-0.765f, 0.22f, 1.239f);
			FERNCLONE.transform.FindChild("wheelFR").transform.localPosition = new Vector3(0.765f, 0.22f, 1.239f);
			FERNCLONE.transform.FindChild("wheelRL").transform.localPosition = new Vector3(-0.766f, 0.15f, -1.539f);
			FERNCLONE.transform.FindChild("wheelRR").transform.localPosition = new Vector3(0.766f, 0.15f, -1.539f);
					
			FERNCLONE.GetComponent<Axles>().frontAxle.leftWheel.radius = 0.345f;
			FERNCLONE.GetComponent<Axles>().frontAxle.rightWheel.radius = 0.345f;
			FERNCLONE.GetComponent<Axles>().rearAxle.leftWheel.radius = 0.345f;
			FERNCLONE.GetComponent<Axles>().rearAxle.rightWheel.radius = 0.345f;
					
			FERNCLONE.transform.FindChild("LOD/FuelFiller 1").transform.localPosition = new Vector3(0f, 0f, 0f);
			FERNCLONE.transform.FindChild("LOD/FuelFiller 1").transform.GetChild(1).transform.localPosition = new Vector3(-0.371f, 2.401f, -0.816f);
			FERNCLONE.transform.FindChild("LOD/FuelFiller 1").transform.GetChild(1).transform.localEulerAngles = new Vector3(90, 200, 0);
					
			FERNCLONE.transform.FindChild("LOD/FuelFiller 1/Pivot").transform.localPosition = new Vector3(-0.302f, 2.405f, -0.832f);
			FERNCLONE.transform.FindChild("LOD/FuelFiller 1/Pivot/body_fuel_hatch").gameObject.transform.localScale = new Vector3(-1f, 1f, 1f);
			FERNCLONE.transform.FindChild("LOD/FuelFiller 1/Pivot/body_fuel_hatch").GetComponent<MeshFilter>().mesh = MESH15.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
			FERNCLONE.transform.FindChild("LOD/FuelFiller 1/Pivot/body_fuel_hatch").GetComponent<MeshRenderer>().material = MESH15.transform.GetChild(0).GetComponent<MeshRenderer>().material;
			FERNCLONE.transform.FindChild("LOD/FuelFiller 1/Pivot/body_fuel_hatch").GetComponent<Renderer>().materials = BODYCOLORMAT;
			Object.Destroy(MESH15);
			
			FERNCLONE.transform.FindChild("LOD/Wipers/Left/WiperLeftPivot/Tap").gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD/Wipers/Left/WiperLeftPivot/wipers_tap").transform.localScale = new Vector3(1f, 1f, 1f);
			FERNCLONE.transform.FindChild("LOD/Wipers/Left/WiperLeftPivot/wipers_tap").GetComponent<MeshRenderer>().enabled = false;
			MESH16.transform.parent = FERNCLONE.transform.FindChild("LOD/Wipers/Left/WiperLeftPivot/wipers_tap").gameObject.transform;
			MESH16.transform.localScale = new Vector3(-1, 1, 1);
			MESH16.transform.localPosition = new Vector3(0, 0, 0);
			MESH16.transform.localEulerAngles = new Vector3(0, 0, 0);					
			MESH16.transform.GetChild(0).GetComponent<Renderer>().materials = BODYCOLORMAT;
			FERNCLONE.transform.FindChild("LOD/Wipers/Left/WiperLeftPivot/wipers_tap/wipers_rod").GetComponent<MeshRenderer>().enabled = false;
			MESH17.transform.parent = FERNCLONE.transform.FindChild("LOD/Wipers/Left/WiperLeftPivot/wipers_tap/wipers_rod").gameObject.transform;
			MESH17.transform.localScale = new Vector3(-1, 1, 1);
			MESH17.transform.localPosition = new Vector3(0, 0, 0);
			MESH17.transform.localEulerAngles = new Vector3(0, 0, 0);					
			MESH17.transform.GetChild(0).GetComponent<Renderer>().materials = BODYCOLORMAT;
					
			FERNCLONE.transform.FindChild("LOD/Wipers/Right/WiperRightPivot/Tap 1").gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD/Wipers/Right/WiperRightPivot/wipers_tap").transform.localScale = new Vector3(1f, 1f, 1f);
			FERNCLONE.transform.FindChild("LOD/Wipers/Right/WiperRightPivot/wipers_tap").GetComponent<MeshRenderer>().enabled = false;
			MESH18.transform.parent = FERNCLONE.transform.FindChild("LOD/Wipers/Right/WiperRightPivot/wipers_tap").gameObject.transform;
			MESH18.transform.localScale = new Vector3(-1, 1, 1);
			MESH18.transform.localPosition = new Vector3(0, 0, 0);
			MESH18.transform.localEulerAngles = new Vector3(0, 0, 0);					
			MESH18.transform.GetChild(0).GetComponent<Renderer>().materials = BODYCOLORMAT;
			FERNCLONE.transform.FindChild("LOD/Wipers/Right/WiperRightPivot/wipers_tap/wipers_rod").GetComponent<MeshRenderer>().enabled = false;
			MESH19.transform.parent = FERNCLONE.transform.FindChild("LOD/Wipers/Right/WiperRightPivot/wipers_tap/wipers_rod").gameObject.transform;
			MESH19.transform.localScale = new Vector3(-1, 1, 1);
			MESH19.transform.localPosition = new Vector3(0, 0, 0);
			MESH19.transform.localEulerAngles = new Vector3(0, 0, 0);					
			MESH19.transform.GetChild(0).GetComponent<Renderer>().materials = BODYCOLORMAT;
					
			FERNCLONE.transform.FindChild("LOD/Wipers/Left").transform.localPosition = new Vector3(0.2930535f, -0.1360585f, 9.58913E-06f);
			FERNCLONE.transform.FindChild("LOD/Wipers/Left").transform.localEulerAngles = new Vector3(293.006f, 0.06000022f, 18.00017f);
			FERNCLONE.transform.FindChild("LOD/Wipers/Right").transform.localPosition = new Vector3(-0.1770224f, -0.1069566f, 0.02499538f);
			FERNCLONE.transform.FindChild("LOD/Wipers/Right").transform.localEulerAngles = new Vector3(305.9925f, -2.832935E-05f, 17.00003f);
					
			MESH20.transform.parent = FERNCLONE.transform;
			MESH20.transform.localScale = new Vector3(1, -1, 1);
			MESH20.transform.localPosition = new Vector3(0, 0, 0);
			MESH20.transform.localEulerAngles = new Vector3(270, 90, 0);
		
			MESH21.transform.parent = FERNCLONE.transform;
			MESH21.transform.localScale = new Vector3(1, -1, 1);
			MESH21.transform.localPosition = new Vector3(0, 0, 0);
			MESH21.transform.localEulerAngles = new Vector3(270, 90, 0);
					
			FERNCLONE.transform.FindChild("LOD/InteriorLight").gameObject.SetActive(false);

			FERNCLONE.transform.FindChild("LOD").transform.GetChild(11).transform.gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD").transform.GetChild(12).transform.gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD").transform.GetChild(15).transform.gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD").transform.GetChild(16).transform.gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD").transform.GetChild(17).transform.gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD").transform.GetChild(18).transform.gameObject.SetActive(false);
					
			FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door").gameObject.GetComponent<MeshRenderer>().enabled = false;
			
			if((bool)SettingsBool1.GetValue())
			{
				MESH22.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)").gameObject.transform;
				MESH22.transform.localScale = new Vector3(-1, 1, 1);
				MESH22.transform.localPosition = new Vector3(-0.2440001f, 0.03699999f, 0.04500001f);
				MESH22.transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH22.transform.GetChild(0).GetComponent<Renderer>().materials = BODYCOLORMAT;
				MESH22.name = "gaz24doorl";
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/panel").gameObject.SetActive(false);
				MESH23.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)").gameObject.transform;
				MESH23.transform.localScale = new Vector3(-1, 1, 1);
				MESH23.transform.localPosition = new Vector3(-0.2440001f, 0.03699999f, 0.04500001f);
				MESH23.transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH23.transform.GetChild(0).GetComponent<MeshRenderer>().material = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/muscle_side_mirror").gameObject.GetComponent<MeshRenderer>().materials[1];
				MESH23A.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)").gameObject.transform;
				MESH23A.transform.localScale = new Vector3(-1, 1, 1);
				MESH23A.transform.localPosition = new Vector3(-0.2440001f, 0.03699999f, 0.04500001f);
				MESH23A.transform.localEulerAngles = new Vector3(0, 0, 0);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/muscle_side_mirror").gameObject.GetComponent<MeshRenderer>().enabled = false;
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/opener/mesh").gameObject.GetComponent<MeshRenderer>().enabled = false;
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door").transform.localPosition = new Vector3(-0.2440001f, 0.03699999f, 0.04500001f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door").transform.localEulerAngles = new Vector3(0f, 0f, 0f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/opener").transform.localPosition = new Vector3(-0.277f, 0.107f, 0.067f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/opener").transform.localEulerAngles = new Vector3(0f, 0f, 0f);
				MESH24.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/opener/mesh").gameObject.transform;
				MESH24.transform.localScale = new Vector3(-1, 1, 1);
				MESH24.transform.localPosition = new Vector3(0, 0, 0);
				MESH24.transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH24.transform.GetChild(0).GetComponent<Renderer>().materials = BODYCOLORMAT;
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot").transform.localPosition = new Vector3(0f, 0f, 0f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot").transform.localScale = new Vector3(-1f, 1f, 1f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot/Glass/glass").transform.localPosition = new Vector3(0f, 0f, 0f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/Handle").gameObject.transform.localPosition = new Vector3(-0.6f, 0.89f, -0.41f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/PlayerColl").gameObject.transform.localPosition = new Vector3(-0.6f, 0.89f, -0.41f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/Handle").gameObject.transform.localScale = new Vector3(0.6999999f, 1f, 1f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/PlayerColl").gameObject.transform.localScale = new Vector3(0.6999999f, 1f, 1f);
				MESH25.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)").gameObject.transform;
				MESH25.transform.localScale = new Vector3(-1, 1, 1);
				MESH25.transform.localPosition = new Vector3(-0.2440001f, 0.03699999f, 0.04500001f);
				MESH25.transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH25.transform.GetChild(0).GetComponent<MeshRenderer>().material = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot/Glass/glass").gameObject.GetComponent<MeshRenderer>().material;
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot/Glass/glass").GetComponent<MeshFilter>().mesh = MESH26.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
				MESH26.transform.parent = MESH2.transform;
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot/Glass/coll").transform.localPosition = new Vector3(-0.5670002f, 0.9f, -0.44f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot/Glass/coll").transform.localScale = new Vector3(0.8f, 1f, 1f);
				MESH29.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)").gameObject.transform;
				MESH29.transform.localScale = new Vector3(-1, 1, 1);
				MESH29.transform.localPosition = new Vector3(-0.2440001f, 0.03699999f, 0.04500001f);
				MESH29.transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH29.transform.GetChild(0).GetComponent<Renderer>().materials = INTERIORCOLORMAT;
					
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1").gameObject.GetComponent<MeshRenderer>().enabled = false;
				MESH27.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(right)").gameObject.transform;
				MESH27.transform.localScale = new Vector3(-1, 1, 1);
				MESH27.transform.localPosition = new Vector3(-0.2440001f, -0.03699999f, 0.04500001f);
				MESH27.transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH27.transform.GetChild(0).GetComponent<Renderer>().materials = BODYCOLORMAT;
				MESH27.name = "gaz24doorr";
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/panel 1").gameObject.SetActive(false);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/opener 2").gameObject.SetActive(false);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1").transform.localPosition = new Vector3(-0.2440001f, -0.03699999f, 0.04500001f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1").transform.localEulerAngles = new Vector3(0f, 0f, 0f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/Handle").gameObject.transform.localPosition = new Vector3(-0.6f, 0.89f, -0.41f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/PlayerColl").gameObject.transform.localPosition = new Vector3(-0.6f, -0.89f, -0.41f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/Handle").gameObject.transform.localScale = new Vector3(0.6999999f, 1f, 1f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/PlayerColl").gameObject.transform.localScale = new Vector3(0.6999999f, -1f, 1f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/glass").gameObject.transform.localScale = new Vector3(-1f, -1f, 1f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/glass").GetComponent<MeshFilter>().mesh = MESH28.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
				MESH28.transform.parent = MESH2.transform;
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1").gameObject.transform.localScale = new Vector3(1, -1, 1);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/coll2").transform.localPosition = new Vector3(-0.5670002f, -0.9f, -0.44f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/coll2").gameObject.transform.localScale = new Vector3(0.8f, -1f, 1f);
				MESH30.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(right)").gameObject.transform;
				MESH30.transform.localScale = new Vector3(-1, 1, 1);
				MESH30.transform.localPosition = new Vector3(-0.2440001f, -0.03699999f, 0.04500001f);
				MESH30.transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH30.transform.GetChild(0).GetComponent<Renderer>().materials = INTERIORCOLORMAT;
			}
			else
			{
				GameObject DOORL = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)").gameObject;
				GameObject DOORR = FERNCLONE.transform.FindChild("DriverDoors/door(right)").gameObject;
				DOORL.SetActive(false);
				DOORR.SetActive(false);
				FERNCLONE.transform.FindChild("DriverDoors").gameObject.transform.localPosition = new Vector3(0, 0, 0);
				FERNCLONE.transform.FindChild("DriverDoors").gameObject.transform.localEulerAngles = new Vector3(0, 0, 0);
				DOORL.transform.localPosition = new Vector3(-0.863f, 0.416f, 0.515f);
				DOORR.transform.localPosition = new Vector3(0.863f, 0.416f, 0.515f);
				DOORL.SetActive(true);
				DOORR.SetActive(true);
				
				MESH22.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)").gameObject.transform;
				MESH22.transform.localScale = new Vector3(-1, 1, 1);
				MESH22.transform.localPosition = new Vector3(0, 0, 0);
				MESH22.transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH22.transform.GetChild(0).GetComponent<Renderer>().materials = BODYCOLORMAT;
				MESH22.name = "gaz24doorl";
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/panel").gameObject.SetActive(false);
				MESH23.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)").gameObject.transform;
				MESH23.transform.localScale = new Vector3(-1, 1, 1);
				MESH23.transform.localPosition = new Vector3(0, 0, 0);
				MESH23.transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH23.transform.GetChild(0).GetComponent<MeshRenderer>().material = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/muscle_side_mirror").gameObject.GetComponent<MeshRenderer>().materials[1];
				MESH23A.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)").gameObject.transform;
				MESH23A.transform.localScale = new Vector3(-1, 1, 1);
				MESH23A.transform.localPosition = new Vector3(0f, 0, 0);
				MESH23A.transform.localEulerAngles = new Vector3(0, 0, 0);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/muscle_side_mirror").gameObject.GetComponent<MeshRenderer>().enabled = false;
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/opener/mesh").gameObject.GetComponent<MeshRenderer>().enabled = false;
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door").transform.localPosition = new Vector3(0f, 0f, 0f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door").transform.localEulerAngles = new Vector3(0f, 0f, 0f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/opener").transform.localPosition = new Vector3(-0.277f, 0.107f, 0.067f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/opener").transform.localEulerAngles = new Vector3(0f, 0f, 0f);
				MESH24.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/opener/mesh").gameObject.transform;
				MESH24.transform.localScale = new Vector3(-1, 1, 1);
				MESH24.transform.localPosition = new Vector3(0, 0, 0);
				MESH24.transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH24.transform.GetChild(0).GetComponent<Renderer>().materials = BODYCOLORMAT;
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot").transform.localPosition = new Vector3(0f, 0f, 0f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot").transform.localScale = new Vector3(-1f, 1f, 1f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot/Glass/glass").transform.localPosition = new Vector3(0f, 0f, 0f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/Handle").gameObject.transform.localPosition = new Vector3(-0.6f, 0.89f, -0.41f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/PlayerColl").gameObject.transform.localPosition = new Vector3(-0.6f, 0.89f, -0.41f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/Handle").gameObject.transform.localScale = new Vector3(0.6999999f, 1f, 1f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/PlayerColl").gameObject.transform.localScale = new Vector3(0.6999999f, 1f, 1f);
				MESH25.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)").gameObject.transform;
				MESH25.transform.localScale = new Vector3(-1, 1, 1);
				MESH25.transform.localPosition = new Vector3(0, 0, 0);
				MESH25.transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH25.transform.GetChild(0).GetComponent<MeshRenderer>().material = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot/Glass/glass").gameObject.GetComponent<MeshRenderer>().material;
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot/Glass/glass").GetComponent<MeshFilter>().mesh = MESH26.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
				Object.Destroy(MESH26);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot/Glass/coll").transform.localPosition = new Vector3(-0.5670002f, 0.9f, -0.44f);
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot/Glass/coll").transform.localScale = new Vector3(0.8f, 1f, 1f);
				MESH29.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)").gameObject.transform;
				MESH29.transform.localScale = new Vector3(-1, 1, 1);
				MESH29.transform.localPosition = new Vector3(0, 0, 0);
				MESH29.transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH29.transform.GetChild(0).GetComponent<Renderer>().materials = INTERIORCOLORMAT;
					
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1").gameObject.GetComponent<MeshRenderer>().enabled = false;
				MESH27.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(right)").gameObject.transform;
				MESH27.transform.localScale = new Vector3(-1, 1, 1);
				MESH27.transform.localPosition = new Vector3(0, 0, 0);
				MESH27.transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH27.transform.GetChild(0).GetComponent<Renderer>().materials = BODYCOLORMAT;
				MESH27.name = "gaz24doorr";
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/panel 1").gameObject.SetActive(false);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/opener 2").gameObject.SetActive(false);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1").transform.localPosition = new Vector3(0f, 0f, 0f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1").transform.localEulerAngles = new Vector3(0f, 0f, 0f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/Handle").gameObject.transform.localPosition = new Vector3(-0.6f, 0.89f, -0.41f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/PlayerColl").gameObject.transform.localPosition = new Vector3(-0.6f, -0.89f, -0.41f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/Handle").gameObject.transform.localScale = new Vector3(0.6999999f, 1f, 1f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/PlayerColl").gameObject.transform.localScale = new Vector3(0.6999999f, -1f, 1f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/glass").gameObject.transform.localScale = new Vector3(-1f, -1f, 1f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/glass").GetComponent<MeshFilter>().mesh = MESH28.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
				Object.Destroy(MESH28);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1").gameObject.transform.localScale = new Vector3(1, -1, 1);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/coll2").transform.localPosition = new Vector3(-0.5670002f, -0.9f, -0.44f);
				FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1/coll2").gameObject.transform.localScale = new Vector3(0.8f, -1f, 1f);
				MESH30.transform.parent = FERNCLONE.transform.FindChild("DriverDoors/door(right)").gameObject.transform;
				MESH30.transform.localScale = new Vector3(-1, 1, 1);
				MESH30.transform.localPosition = new Vector3(0, 0, 0);
				MESH30.transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH30.transform.GetChild(0).GetComponent<Renderer>().materials = INTERIORCOLORMAT;
			}
					
			FERNCLONE.transform.FindChild("wheelFL/wheel_spindle_fl/spindle").gameObject.transform.GetComponent<Renderer>().material.color = new Color(1, 1, 1, 1);
			FERNCLONE.transform.FindChild("wheelFR/wheel_spindle_fr/spindle").gameObject.transform.GetComponent<Renderer>().material.color = new Color(1, 1, 1, 1);
			FERNCLONE.transform.FindChild("wheelFL/wheel_spindle_fl/spindle").GetComponent<MeshRenderer>().material.mainTexture = TEXTURE3;
			FERNCLONE.transform.FindChild("wheelFR/wheel_spindle_fr/spindle").GetComponent<MeshRenderer>().material.mainTexture = TEXTURE3;
				
			FERNCLONE.transform.FindChild("LOD/generalPivot/front_susp_L/arm").transform.localPosition = new Vector3(-0.256f, 0.359f, -0.117f);
			FERNCLONE.transform.FindChild("LOD/generalPivot/front_susp_R/arm").transform.localPosition = new Vector3(-0.256f, 0.359f, 0.117f);
			FERNCLONE.transform.FindChild("LOD/generalPivot/front_susp_L").GetComponent<SkinnedMeshRenderer>().material.mainTexture = TEXTURE3;
			FERNCLONE.transform.FindChild("LOD/generalPivot/front_susp_R").GetComponent<SkinnedMeshRenderer>().material.mainTexture = TEXTURE3;
			FERNCLONE.transform.FindChild("LOD/generalPivot/front_susp_L").GetComponent<SkinnedMeshRenderer>().material.color = new Color(1, 1, 1, 1);
			FERNCLONE.transform.FindChild("LOD/generalPivot/front_susp_R").GetComponent<SkinnedMeshRenderer>().material.color = new Color(1, 1, 1, 1);
										
			MESH31.transform.parent = FERNCLONE.transform;
			MESH31.transform.localScale = new Vector3(1, -1, 1);
			MESH31.transform.localPosition = new Vector3(0, 0, 0);
			MESH31.transform.localEulerAngles = new Vector3(270, 90, 0);
			MESH31.transform.GetChild(0).GetComponent<Renderer>().materials = BODYCOLORMAT;
								
			FERNCLONE.transform.FindChild("wheelRL/wheel_spindle_rl/Axle/rearaxle/chrome").gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("wheelRL/wheel_spindle_rl/Axle/rearaxle").GetComponent<MeshFilter>().mesh = MESH32.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
			FERNCLONE.transform.FindChild("wheelRL/wheel_spindle_rl/Axle/rearaxle").GetComponent<MeshRenderer>().material = MESH32.transform.GetChild(0).GetComponent<MeshRenderer>().material;
			Object.Destroy(MESH32);
			FERNCLONE.transform.FindChild("wheelRL/wheel_spindle_rl/Axle/rearaxle").GetComponent<Renderer>().materials = BODYCOLORMAT;
			FERNCLONE.transform.FindChild("wheelRL/wheel_spindle_rl/Axle").gameObject.transform.localPosition = new Vector3(0.766f, 0f, 0f);
			FERNCLONE.transform.FindChild("wheelRL/wheel_spindle_rl/Axle/rearaxle").transform.GetChild(2).gameObject.transform.localPosition = new Vector3(0.541f, 0.07399999f, -0.07999999f);
			FERNCLONE.transform.FindChild("wheelRL/wheel_spindle_rl/Axle/rearaxle").transform.GetChild(2).gameObject.transform.localEulerAngles = new Vector3(6.51481f, 2.599451E-05f, 270f);
			FERNCLONE.transform.FindChild("wheelRL/wheel_spindle_rl/Axle/rearaxle").transform.GetChild(2).gameObject.transform.localScale = new Vector3(1f, 1f, 1f);
			FERNCLONE.transform.FindChild("wheelRL/wheel_spindle_rl/Axle/rearaxle").transform.GetChild(3).gameObject.transform.localPosition = new Vector3(-0.541f, 0.07399999f, -0.07999999f);
			FERNCLONE.transform.FindChild("wheelRL/wheel_spindle_rl/Axle/rearaxle").transform.GetChild(3).gameObject.transform.localEulerAngles = new Vector3(6.51481f, 2.599451E-05f, 270f);
			FERNCLONE.transform.FindChild("wheelRL/wheel_spindle_rl/Axle/rearaxle").transform.GetChild(3).gameObject.transform.localScale = new Vector3(1f, 1f, 1f);
			FERNCLONE.transform.FindChild("LOD/LeafSprings/left").transform.localPosition = new Vector3(-0.541f, 0.03899999f, -1.393001f);
			FERNCLONE.transform.FindChild("LOD/LeafSprings/left").transform.localScale = new Vector3(1f, 1f, 1f);
			FERNCLONE.transform.FindChild("LOD/LeafSprings/right").transform.localPosition = new Vector3(0.541f, 0.03899999f, -1.393001f);
			FERNCLONE.transform.FindChild("LOD/LeafSprings/right").transform.localScale = new Vector3(1f, 1f, 1f);
			FERNCLONE.transform.FindChild("LOD/LeafSprings/left/Armature/Bone/Bone_002").transform.localPosition = new Vector3(-1.311f, 1.629815E-09f, 0.199f);
			FERNCLONE.transform.FindChild("LOD/LeafSprings/right/Armature/Bone/Bone_002").transform.localPosition = new Vector3(-1.311f, 1.629815E-09f, 0.199f);
			FERNCLONE.transform.FindChild("wheelRL/wheel_spindle_rl/Axle/rearaxle/Driveshaft_end").transform.localPosition = new Vector3(-0.0017f, -0.1744f, 0.009699998f);
			FERNCLONE.transform.FindChild("LOD/Driveshaft").GetComponent<SkinnedMeshRenderer>().material.mainTexture = TEXTURE3;
			FERNCLONE.transform.FindChild("LOD/Driveshaft").gameObject.transform.GetComponent<SkinnedMeshRenderer>().material.color = new Color(1, 1, 1, 1);
			FERNCLONE.transform.FindChild("LOD/LeafSprings/left").GetComponent<SkinnedMeshRenderer>().material.mainTexture = TEXTURE3;
			FERNCLONE.transform.FindChild("LOD/LeafSprings/left").gameObject.transform.GetComponent<SkinnedMeshRenderer>().material.color = new Color(0.5f, 0.5f, 0.5f, 1);
			FERNCLONE.transform.FindChild("LOD/LeafSprings/right").GetComponent<SkinnedMeshRenderer>().material.mainTexture = TEXTURE3;
			FERNCLONE.transform.FindChild("LOD/LeafSprings/right").gameObject.transform.GetComponent<SkinnedMeshRenderer>().material.color = new Color(0.5f, 0.5f, 0.5f, 1);

			MESH33.transform.parent = FERNCLONE.gameObject.transform;
			MESH33.transform.localScale = new Vector3(1, -1, 1);
			MESH33.transform.localPosition = new Vector3(0, 0, 0);
			MESH33.transform.localEulerAngles = new Vector3(270, 90, 0);
					
			FERNCLONE.transform.FindChild("LOD/Dashboard").transform.localPosition = new Vector3(0f, 0f, 0f);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Steering").gameObject.transform.localPosition = new Vector3(0.408f, 0.16f, 0.6979998f);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Steering").gameObject.transform.localEulerAngles = new Vector3(60, 0, 90);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Steering/MuscleSteeringPivot/wheel_Stock").gameObject.SetActive(false);
			MESH34.transform.parent = FERNCLONE.transform.FindChild("LOD/Dashboard/Steering/MuscleSteeringPivot").gameObject.transform;
			MESH34.transform.localScale = new Vector3(-1f, 1f, 1f);
			MESH34.transform.localPosition = new Vector3(0, 0, 0);
			MESH34.transform.localEulerAngles = new Vector3(0, 0, 0);
			MESH34.transform.GetChild(0).GetComponent<Renderer>().materials = INTERIOR2COLORMAT;
					
			MESH35.transform.parent = FERNCLONE.transform;
			MESH35.transform.localScale = new Vector3(1, -1, 1);
			MESH35.transform.localPosition = new Vector3(0, 0, 0);
			MESH35.transform.localEulerAngles = new Vector3(270, 90, 0);
					
			FERNCLONE.transform.FindChild("LOD/Dashboard/Knobs").transform.localPosition = new Vector3(0f, 0f, 0f);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Knobs/Ignition").transform.localPosition = new Vector3(0.399f, 0.455f, 0.454f);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Knobs/Lights").transform.localPosition = new Vector3(0.168f, 0.514f, 0.475f);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Knobs/ButtonWipers").transform.localPosition = new Vector3(0.625f, 0.514f, 0.478f);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Knobs/Keys").transform.localPosition = new Vector3(0.399f, 0.455f, 0.454f);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Knobs/Keys").transform.localEulerAngles = new Vector3(31, 180, 180);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Knobs/Keys/Keys/mesh").gameObject.SetActive(false);
			MESH36.transform.parent = FERNCLONE.transform.FindChild("LOD/Dashboard/Knobs/Keys/Keys").gameObject.transform;
			MESH36.transform.localScale = new Vector3(-1, 1, 1);
			MESH36.transform.localPosition = new Vector3(0, 0, 0);
			MESH36.transform.localEulerAngles = new Vector3(0, 0, 0);
			MESH36.transform.GetChild(0).GetComponent<Renderer>().materials = INTERIOR1COLORMAT;
			FERNCLONE.transform.FindChild("LOD/Dashboard/Knobs/Keys/Keys").transform.GetChild(0).transform.localPosition = new Vector3(0, 0, 0);
			
			FERNCLONE.transform.FindChild("LOD/Dashboard/GearShifter").transform.localPosition = new Vector3(0, 0, 0);
			FERNCLONE.transform.FindChild("LOD/Dashboard/GearShifter").transform.localEulerAngles = new Vector3(0, 0, 0);
			FERNCLONE.transform.FindChild("LOD/Dashboard/GearShifter").transform.localScale = new Vector3(1, 1, 1);
			FERNCLONE.transform.FindChild("LOD/Dashboard/GearShifter/Pivot").transform.localPosition = new Vector3(-0.044f, 0.424f, 0.277f);		
			FERNCLONE.transform.FindChild("LOD/Dashboard/GearShifter/Pivot/muscle_gear_lever").transform.localPosition = new Vector3(0, 0, 0);
			FERNCLONE.transform.FindChild("LOD/Dashboard/GearShifter/Pivot/muscle_gear_lever").transform.localEulerAngles = new Vector3(0, 0, 0);
			FERNCLONE.transform.FindChild("LOD/Dashboard/GearShifter/Pivot/muscle_gear_lever").GetComponent<MeshFilter>().mesh = MESH37.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
			FERNCLONE.transform.FindChild("LOD/Dashboard/GearShifter/Pivot/muscle_gear_lever").GetComponent<MeshRenderer>().material = MESH37.transform.GetChild(0).GetComponent<MeshRenderer>().material;
			Object.Destroy(MESH37);
			FERNCLONE.transform.FindChild("LOD/Dashboard/GearShifter/Pivot/muscle_gear_lever").GetComponent<Renderer>().materials = INTERIOR1COLORMAT;
			MESH54.transform.parent = FERNCLONE.transform.FindChild("LOD/Dashboard/GearShifter/Pivot/muscle_gear_lever").transform;
			MESH54.transform.localScale = new Vector3(1, 1, 1);
			MESH54.transform.localPosition = new Vector3(0, 0, 0);
			MESH54.transform.localEulerAngles = new Vector3(0, 0, 0);
					
			FERNCLONE.transform.FindChild("LOD/Dashboard/Pedals 2").transform.localPosition = new Vector3(0, 0, 0);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Pedals 2/brake").transform.localPosition = new Vector3(0.407f, 0.687f, 0.406f);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Pedals 2/throttle").transform.localPosition = new Vector3(0.252f, 0.491f, 0.065f);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Pedals 2/brake/mesh").gameObject.transform.localScale = new Vector3(-1f, 1f, 1f);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Pedals 2/brake/mesh").GetComponent<MeshFilter>().mesh = MESH38.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
			FERNCLONE.transform.FindChild("LOD/Dashboard/Pedals 2/brake/mesh").GetComponent<MeshRenderer>().material = MESH38.transform.GetChild(0).GetComponent<MeshRenderer>().material;
			Object.Destroy(MESH38);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Pedals 2/brake/mesh").GetComponent<Renderer>().materials = INTERIOR1COLORMAT;
			FERNCLONE.transform.FindChild("LOD/Dashboard/Pedals 2/throttle/mesh").gameObject.transform.localScale = new Vector3(-1f, 1f, 1f);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Pedals 2/throttle/mesh").GetComponent<MeshFilter>().mesh = MESH39.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
			FERNCLONE.transform.FindChild("LOD/Dashboard/Pedals 2/throttle/mesh").GetComponent<MeshRenderer>().material = MESH39.transform.GetChild(0).GetComponent<MeshRenderer>().material;
			Object.Destroy(MESH39);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Pedals 2/throttle/mesh").GetComponent<Renderer>().materials = INTERIOR1COLORMAT;
					
			FERNCLONE.transform.FindChild("LOD/Dashboard").transform.GetChild(4).transform.localPosition = new Vector3(0, 0, 0);
			FERNCLONE.transform.FindChild("LOD/Dashboard").transform.GetChild(4).GetChild(1).transform.localPosition = new Vector3(-0.5569999f, 0.6529999f, 0.5669997f);
			FERNCLONE.transform.FindChild("LOD/Dashboard").transform.GetChild(4).GetChild(1).transform.localEulerAngles = new Vector3(27.22385f, 9.198031E-05f, 3.775864E-05f);
			FERNCLONE.transform.FindChild("LOD/Dashboard").transform.GetChild(4).GetChild(1).transform.localScale = new Vector3(0.0325048f, 0.0251316f, 0.0566082f);
			FERNCLONE.transform.FindChild("LOD/Dashboard").transform.GetChild(4).GetChild(2).transform.localPosition = new Vector3(-0.2670004f, 0.6529999f, 0.5669997f);
			FERNCLONE.transform.FindChild("LOD/Dashboard").transform.GetChild(4).GetChild(2).transform.localEulerAngles = new Vector3(27.22385f, 9.198031E-05f, 3.775864E-05f);
			FERNCLONE.transform.FindChild("LOD/Dashboard").transform.GetChild(4).GetChild(2).transform.localScale = new Vector3(0.0325048f, 0.0251316f, 0.0566082f);
			FERNCLONE.transform.FindChild("LOD/Dashboard").transform.GetChild(4).GetChild(3).transform.localScale = new Vector3(0, 0, 0);
			FERNCLONE.transform.FindChild("LOD/Dashboard").transform.GetChild(4).GetChild(4).transform.localScale = new Vector3(0, 0, 0);
			FERNCLONE.transform.FindChild("LOD/Dashboard").transform.GetChild(4).GetChild(5).transform.localPosition = new Vector3(-0.2670004f, 0.6529999f, 0.5669997f);
			FERNCLONE.transform.FindChild("LOD/Dashboard").transform.GetChild(4).GetChild(5).transform.localEulerAngles = new Vector3(27.22385f, 9.198031E-05f, 3.775864E-05f);
			FERNCLONE.transform.FindChild("LOD/Dashboard").transform.GetChild(4).GetChild(5).transform.localScale = new Vector3(0.0325048f, 0.0251316f, 0.0566082f);
			FERNCLONE.transform.FindChild("LOD/Dashboard").transform.GetChild(4).GetChild(6).GetComponent<AudioSource>().mute = true;
			
			FERNCLONE.transform.Find("LOD/Dashboard/Steering/MuscleSteeringPivot/linelockbutton").gameObject.SetActive(false);
					
			FERNCLONE.transform.FindChild("LOD/MESH/muscle_mirror_rear").gameObject.transform.localScale = new Vector3(-1f, 1f, 1f);
			FERNCLONE.transform.FindChild("LOD/MESH/muscle_mirror_rear").GetComponent<MeshFilter>().mesh = MESH40.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
			Object.Destroy(MESH40);
			MESH40A.transform.parent = FERNCLONE.transform.FindChild("LOD/MESH").gameObject.transform;
			MESH40A.transform.localScale = new Vector3(-1, 1, 1);
			MESH40A.transform.localPosition = new Vector3(0f, 0, 0);
			MESH40A.transform.localEulerAngles = new Vector3(0, 0, 0);
			FERNCLONE.transform.FindChild("LOD/Dashboard/BlinkerLever").transform.localPosition = new Vector3(0.408f, 0.265f, 0.637f);
			FERNCLONE.transform.FindChild("LOD/Dashboard/BlinkerLever/lever").GetComponent<MeshFilter>().mesh = MESH41.transform.GetChild(0).GetComponent<MeshFilter>().mesh;
			FERNCLONE.transform.FindChild("LOD/Dashboard/BlinkerLever/lever").GetComponent<MeshRenderer>().material = MESH41.transform.GetChild(0).GetComponent<MeshRenderer>().material;
			FERNCLONE.transform.FindChild("LOD/Dashboard/BlinkerLever/lever").GetComponent<Renderer>().materials = INTERIOR2COLORMAT;
			Object.Destroy(MESH41);
					
			FERNCLONE.transform.FindChild("RadioPivot").transform.localPosition = new Vector3(-0.004999999f, 0.6165999f, 0.5953999f);
			FERNCLONE.transform.FindChild("RadioPivot").transform.localEulerAngles = new Vector3(283.2454f, -0.0001331575f, 180.0005f);
			FERNCLONE.transform.FindChild("RadioPivot").transform.localScale = new Vector3(1.25f, 1.25f, 1.25f);
			FERNCLONE.transform.FindChild("RadioPivot/Radio").gameObject.GetComponent<MeshRenderer>().enabled = false;
			FERNCLONE.transform.FindChild("RadioPivot/Radio").transform.GetChild(0).GetChild(0).transform.localScale = new Vector3(0.7f, 0.7f, 0.7f);
			FERNCLONE.transform.FindChild("RadioPivot/Radio").transform.GetChild(1).GetChild(0).transform.localScale = new Vector3(0.7f, 0.7f, 0.7f);
			FERNCLONE.transform.FindChild("RadioPivot/Radio/TunerPivot").transform.transform.localPosition = new Vector3(0.07330001f, 0f, 0f);
			FERNCLONE.transform.FindChild("RadioPivot/Radio").transform.GetChild(0).GetChild(0).GetComponent<MeshRenderer>().enabled = false;
			FERNCLONE.transform.FindChild("RadioPivot/Radio").transform.GetChild(1).GetChild(0).GetComponent<MeshRenderer>().enabled = false;
			MESH42.transform.parent = FERNCLONE.transform.FindChild("RadioPivot/Radio").transform.GetChild(0).GetChild(0).transform;
			MESH42.transform.localScale = new Vector3(1, 1, 1);
			MESH42.transform.localPosition = new Vector3(0, 0, 0);
			MESH42.transform.localEulerAngles = new Vector3(0, 0, 0);
			MESH43.transform.parent = FERNCLONE.transform.FindChild("RadioPivot/Radio").transform.GetChild(1).GetChild(0).transform;
			MESH43.transform.localScale = new Vector3(1, 1, 1);
			MESH43.transform.localPosition = new Vector3(0, 0, 0);
			MESH43.transform.localEulerAngles = new Vector3(0, 0, 0);
					
			FERNCLONE.transform.FindChild("LOD/Seatbelts/Passenger").gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD/Seatbelts").transform.localEulerAngles = new Vector3(0, 0, 0);
			FERNCLONE.transform.FindChild("LOD/Seatbelts").transform.GetChild(0).transform.localPosition = new Vector3(-0.111f, 0.415f, -0.166f);
					
			MESH44.transform.parent = FERNCLONE.transform.FindChild("LOD/Seatbelts").transform.GetChild(1).gameObject.transform;
			MESH44.transform.localScale = new Vector3(1, -1, 1);
			MESH44.transform.localPosition = new Vector3(0, 0, 0);
			MESH44.transform.localEulerAngles = new Vector3(270, 90, 0);
			MESH44.transform.GetChild(0).GetComponent<Renderer>().materials = INTERIOR2COLORMAT;
			FERNCLONE.transform.FindChild("LOD/Seatbelts").transform.GetChild(1).gameObject.GetComponent<MeshRenderer>().enabled = false;
			MESH45.transform.parent = FERNCLONE.transform.FindChild("LOD/Seatbelts").transform.GetChild(2).gameObject.transform;
			MESH45.transform.localScale = new Vector3(1, -1, 1);
			MESH45.transform.localPosition = new Vector3(0, 0, 0);
			MESH45.transform.localEulerAngles = new Vector3(270, 90, 0);
			MESH45.transform.GetChild(0).GetComponent<Renderer>().materials = INTERIOR2COLORMAT;
			FERNCLONE.transform.FindChild("LOD/Seatbelts").transform.GetChild(2).gameObject.GetComponent<MeshRenderer>().enabled = false;
					
			FERNCLONE.transform.FindChild("LOD/Dashboard/Gauges/NeedleSpeedometer/Needle").gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Gauges/NeedleFuel").gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Gauges/NeedleTemp").gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Gauges/NeedleAlternator").gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Gauges/NeedleGear").gameObject.SetActive(false);
			FERNCLONE.transform.FindChild("LOD/Dashboard/Gauges/Tachometer").gameObject.SetActive(false);
					
			MESH46.transform.parent = FERNCLONE.transform;
			MESH46.transform.localScale = new Vector3(1, -1, 1);
			MESH46.transform.localPosition = new Vector3(-0.607f, 0.655f, 0.571f);
			MESH46.transform.localEulerAngles = new Vector3(296, 0, 90);
					
			MESH47.transform.parent = FERNCLONE.transform;
			MESH47.transform.localScale = new Vector3(1, -1, 1);
			MESH47.transform.localPosition = new Vector3(-0.607f, 0.605f, 0.545f);
			MESH47.transform.localEulerAngles = new Vector3(296, 0, 90);
					
			MESH48.transform.parent = FERNCLONE.transform;
			MESH48.transform.localScale = new Vector3(1, -1, 1);
			MESH48.transform.localPosition = new Vector3(-0.513f, 0.637f, 0.562f);
			MESH48.transform.localEulerAngles = new Vector3(296, 0, 90);
				
			MESH49.transform.parent = FERNCLONE.transform;
			MESH49.transform.localScale = new Vector3(1, -1, 1);
			MESH49.transform.localPosition = new Vector3(-0.499f, 0.596f, 0.54f);
			MESH49.transform.localEulerAngles = new Vector3(296, 0, 90);

			MESH50.transform.parent = FERNCLONE.transform;
			MESH50.transform.localScale = new Vector3(1, -1, 1);
			MESH50.transform.localPosition = new Vector3(-0.318f, 0.596f, 0.54f);
			MESH50.transform.localEulerAngles = new Vector3(296, 0, 90);
				
			MESH51.transform.parent = FERNCLONE.transform;
			MESH51.transform.localScale = new Vector3(1, -1, 1);
			MESH51.transform.localPosition = new Vector3(-0.209f, 0.627f, 0.555f);
			MESH51.transform.localEulerAngles = new Vector3(296, 0, 90);
					
			MESH52.transform.parent = FERNCLONE.transform;
			MESH52.transform.localScale = new Vector3(1, -1, 1);
			MESH52.transform.localPosition = new Vector3(-0.209f, 0.627f, 0.555f);
			MESH52.transform.localEulerAngles = new Vector3(296, 0, 90);
					
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(0).GetChild(0).GetChild(0).transform.localPosition = new Vector3(-0.8360002f, 0.2820001f, 1.868001f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(0).GetChild(0).GetChild(1).GetComponent<Light>().color = FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(0).GetChild(0).GetChild(0).GetComponent<Light>().color;
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(0).GetChild(0).GetChild(1).transform.localPosition = new Vector3(-0.743f, 0.446f, -2.701f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(0).GetChild(1).GetChild(0).transform.localPosition = new Vector3(0.8360002f, 0.2820001f, 1.868001f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(0).GetChild(1).GetChild(1).GetComponent<Light>().color = FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(0).GetChild(1).GetChild(0).GetComponent<Light>().color;
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(0).GetChild(1).GetChild(1).transform.localPosition = new Vector3(0.743f, 0.446f, -2.701f);
					
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(0).GetChild(0).transform.localPosition = new Vector3(-0.62f, -0.046f, -0.308f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(0).GetChild(1).transform.localPosition = new Vector3(0.62f, -0.046f, -0.308f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(0).GetChild(2).transform.localPosition = new Vector3(0.743f, 0.075f, -4.724997f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(0).GetChild(3).transform.localPosition = new Vector3(-0.743f, 0.075f, -4.724997f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(0).GetChild(4).transform.localPosition = new Vector3(0.6785952f, -0.02148725f, -0.1057921f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(0).GetChild(4).transform.localScale = new Vector3(1.2f, 2.5f, 1.2f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(0).GetChild(5).transform.localPosition = new Vector3(-0.6785952f, -0.02148725f, -0.1057921f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(0).GetChild(5).transform.localScale = new Vector3(1.2f, 2.5f, 1.2f);
					
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(1).GetChild(0).transform.localPosition = new Vector3(-0.62f, -0.046f, -0.308f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(1).GetChild(1).transform.localPosition = new Vector3(0.62f, -0.046f, -0.308f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(1).GetChild(2).transform.localPosition = new Vector3(0.743f, 0.075f, -4.724997f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(1).GetChild(3).transform.localPosition = new Vector3(-0.743f, 0.075f, -4.724997f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(1).GetChild(4).transform.localPosition = new Vector3(0.6785952f, -0.02148725f, -0.1057921f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(1).GetChild(4).transform.localScale = new Vector3(1.2f, 2.5f, 1.2f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(1).GetChild(5).transform.localPosition = new Vector3(-0.6785952f, -0.02148725f, -0.1057921f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(1).GetChild(1).GetChild(5).transform.localScale = new Vector3(1.2f, 2.5f, 1.2f);

			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(2).GetChild(0).transform.localPosition = new Vector3(0.743f, 0.675f, -2.790002f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(2).GetChild(1).transform.localPosition = new Vector3(-0.743f, 0.675f, -2.790002f);
					
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(3).GetChild(0).transform.localPosition = new Vector3(0.743f, 0.3950003f, -2.685002f);
			FERNCLONE.transform.FindChild("LOD/Electricity").transform.GetChild(0).GetChild(3).GetChild(1).transform.localPosition = new Vector3(-0.743f, 0.3950003f, -2.685002f);

			FERNCLONE.transform.FindChild("LOD/Simulation/Exhaust").transform.GetChild(0).transform.localPosition = new Vector3(0.569f, 0.127f, -2.734f);
			FERNCLONE.transform.FindChild("LOD/Simulation/Exhaust").transform.GetChild(1).gameObject.SetActive(false);
					
			FERNCLONE.transform.FindChild("LOD/CarShadowProjector").transform.localPosition = new Vector3(0f, 0.13f, -0.3000002f);
					
			FERNCLONE.transform.FindChild("LOD/MESH/muscle_gauges").gameObject.SetActive(false);
					
			FERNCLONE.transform.FindChild("LOD/MESH/muscle_windows").gameObject.SetActive(false);
					
			FERNCLONE.transform.FindChild("HookFront").transform.localPosition = new Vector3(0f, 0.1f, 1.881f);
			FERNCLONE.transform.FindChild("HookRear").transform.localPosition = new Vector3(0f, 0.09499999f, -2.487f);
					
			FERNCLONE.GetComponent<Deformable>().meshFilter = FERNCLONE.transform.FindChild("gaz24body").transform.GetChild(0).gameObject.GetComponent<MeshFilter>();
			FERNCLONE.transform.FindChild("Bootlid/Bootlid/muscle_bootlid").gameObject.GetComponent<Deformable>().meshFilter = FERNCLONE.transform.FindChild("Bootlid/Bootlid/gaz24trunk").transform.GetChild(0).gameObject.GetComponent<MeshFilter>();
			FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door").gameObject.GetComponent<Deformable>().meshFilter = FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/gaz24doorl").transform.GetChild(0).gameObject.GetComponent<MeshFilter>();
			FERNCLONE.transform.FindChild("DriverDoors/door(right)/door 1").gameObject.GetComponent<Deformable>().meshFilter = FERNCLONE.transform.FindChild("DriverDoors/door(right)/gaz24doorr").transform.GetChild(0).gameObject.GetComponent<MeshFilter>();
					
			FERNCLONE.transform.FindChild("Colliders").transform.localPosition = new Vector3(0f, 0.04f, -0.16f);
			FERNCLONE.transform.FindChild("Colliders").transform.localScale = new Vector3(0.9f, 1f, 0.95f);
			/*
			GameObject COLL1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
			COLL1.name = "COLL1";
			COLL1.transform.parent = FERNCLONE.transform;
			COLL1.transform.localScale = new Vector3(1.4f, 0.3f, 0.3f);
			COLL1.transform.localPosition = new Vector3(0f, 0.217f, 0.05f);
			COLL1.transform.localEulerAngles= new Vector3(0, 0, 0);
			COLL1.layer = FERNCLONE.transform.FindChild("Colliders/coll10").gameObject.layer;
			COLL1.GetComponent<MeshRenderer>().enabled = false;	
			GameObject COLL2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
			COLL2.name = "COLL2";
			COLL2.transform.parent = FERNCLONE.transform;
			COLL2.transform.localScale = new Vector3(1.4f, 0.3f, 0.219f);
			COLL2.transform.localPosition = new Vector3(0f, 0.217f, -0.709f);
			COLL2.transform.localEulerAngles= new Vector3(0, 0, 0);
			COLL2.layer = FERNCLONE.transform.FindChild("Colliders/coll10").gameObject.layer;
			COLL2.GetComponent<MeshRenderer>().enabled = false;
			*/
			GameObject COLL3 = GameObject.CreatePrimitive(PrimitiveType.Cube);
			COLL3.name = "COLL3";
			COLL3.transform.parent = FERNCLONE.transform;
			COLL3.transform.localScale = new Vector3(1.4f, 0.4f, 0.019f);
			COLL3.transform.localPosition = new Vector3(0f, 0.497f, -1.75f);
			COLL3.transform.localEulerAngles= new Vector3(0, 0, 0);
			COLL3.layer = FERNCLONE.transform.FindChild("Colliders/coll10").gameObject.layer;
			COLL3.GetComponent<MeshRenderer>().enabled = false;						
					
			FERNCLONE.transform.FindChild("Bootlid/Bootlid").transform.GetChild(0).transform.localPosition = new Vector3(1.850003f, 0f, -0.6870005f);
			FERNCLONE.transform.FindChild("Bootlid/Bootlid").transform.GetChild(2).transform.localPosition = new Vector3(1.850003f, 0f, -0.6870005f);
					
			MESH53.transform.parent = FERNCLONE.transform;
			MESH53.transform.localScale = new Vector3(1, -1, 1);
			MESH53.transform.localPosition = new Vector3(0, 0, 0);
			MESH53.transform.localEulerAngles = new Vector3(270, 90, 0);
			MESH53.transform.GetChild(0).GetComponent<Renderer>().materials = INTERIORCOLORMAT;

			FERNCLONE.transform.FindChild("LOD/TaxStickerFerndale").transform.localPosition = new Vector3 (0.7f, 0.78f, 0.523f);
			FERNCLONE.transform.FindChild("LOD/TaxStickerFerndale").transform.localEulerAngles = new Vector3 (46.00001f, 211f, 0f);
			
			if(!(bool)SettingsBool2.GetValue())
			{
				FERNCLONE.transform.GetChild(3).GetComponent<AudioSource>().clip = IDLE;
				FERNCLONE.transform.GetChild(25).GetComponent<AudioSource>().clip = REV2;
				FERNCLONE.transform.GetChild(25).GetComponent<AudioSource>().playOnAwake = true;
				FERNCLONE.transform.GetChild(25).gameObject.SetActive(false);
				FERNCLONE.transform.GetChild(25).gameObject.SetActive(true);
				FERNCLONE.transform.GetChild(26).GetComponent<AudioSource>().clip = REV;
				FERNCLONE.transform.GetChild(26).GetComponent<AudioSource>().playOnAwake = true;
				FERNCLONE.transform.GetChild(26).gameObject.SetActive(false);
				FERNCLONE.transform.GetChild(26).gameObject.SetActive(true);
			}
			
			if(File.Exists(ModLoader.GetModAssetsFolder(this) + "/regplate.png"))
			{
				TEXTURE4 = LoadAssets.LoadTexture(this, "regplate.png");
				MESH35.transform.GetChild(0).GetComponent<MeshRenderer>().material.mainTexture = TEXTURE4;
			}
			else
			{
				MESH35.SetActive(false);
			}
        }
		
		public override void Update()
        {
			if(!loaded)
			{
				if(Camera.main != null)
				{
					if(!(bool)SettingsBool2.GetValue())
					{
						FERNCLONE.transform.GetChild(65).GetComponent<AudioSource>().clip = REV2;
						FERNCLONE.transform.GetChild(65).GetComponent<AudioSource>().playOnAwake = true;
						FERNCLONE.transform.GetChild(65).gameObject.SetActive(false);
						FERNCLONE.transform.GetChild(65).gameObject.SetActive(true);
						FERNCLONE.transform.GetChild(66).GetComponent<AudioSource>().clip = REV;
						FERNCLONE.transform.GetChild(66).GetComponent<AudioSource>().playOnAwake = true;
						FERNCLONE.transform.GetChild(66).gameObject.SetActive(false);
						FERNCLONE.transform.GetChild(66).gameObject.SetActive(true);
					}
					
					loaded = true;
				}
			}
			
			if(FERNCLONE.transform.FindChild("LOD/FuelFiller 1/Pivot").transform.localEulerAngles == new Vector3(0, 0, 240))
			{
				FERNCLONE.transform.FindChild("LOD/FuelFiller 1/Pivot").transform.localEulerAngles = new Vector3(0, 290, 0);
			}
		
			FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot/Glass").gameObject.transform.localPosition = new Vector3(0f, 0f, FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot/Glass").gameObject.transform.localPosition.z);
		
			if(FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot/Glass").gameObject.transform.localEulerAngles.x > 8.5f)
			{
				FERNCLONE.transform.FindChild("DriverDoors/door(leftx)/door/WindowPivot/Glass").gameObject.transform.localEulerAngles = new Vector3(8.5f, 0f, 0f);
			}
			
			if(FERNCLONE.transform.FindChild("LOD/Electricity/PowerON/Driving/BeamsLong").gameObject.activeSelf)
			{
				MESH33.transform.GetChild(0).GetComponent<MeshRenderer>().material = DASHMAT2;
			}
			else
			{
				if(FERNCLONE.transform.FindChild("LOD/Electricity/PowerON/Driving/BeamsShort").gameObject.activeSelf)
				{
					MESH33.transform.GetChild(0).GetComponent<MeshRenderer>().material = DASHMAT2;
				}
				else
				{
					MESH33.transform.GetChild(0).GetComponent<MeshRenderer>().material = DASHMAT1;
				}
			}
			
			if(FERNCLONE.GetComponent<Drivetrain>().rpm>50)
			{
				MESH46.transform.GetChild(0).transform.localEulerAngles = new Vector3(FERNCLONE.GetComponent<Drivetrain>().rpm/200, 0, 0);
				
				MESH47.transform.GetChild(0).transform.localEulerAngles = new Vector3(30-FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("FuelLevel").Value/0.91f, 0, 0);
				
				if(FERNCLONE.GetComponent<Drivetrain>().differentialSpeed>0)
				{
					MESH48.transform.GetChild(0).transform.localPosition = new Vector3(0, FERNCLONE.GetComponent<Drivetrain>().differentialSpeed*1.06f/1000, 0);
				}
				
				if(FERNCLONE.transform.FindChild("LOD/Simulation/Cooling").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("EngineTemp").Value<40)
				{
					MESH49.transform.GetChild(0).transform.localEulerAngles = new Vector3(50, 0, 0);
				}
				else
				{
					MESH49.transform.GetChild(0).transform.localEulerAngles = new Vector3(90-FERNCLONE.transform.FindChild("LOD/Simulation/Cooling").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("EngineTemp").Value*1.125f, 0, 0);
				}
				
				MESH50.transform.GetChild(0).transform.localEulerAngles = new Vector3(50-FERNCLONE.GetComponent<Drivetrain>().rpm/100, 0, 0);
			}
			else
			{
				MESH46.transform.GetChild(0).transform.localEulerAngles = new Vector3(0, 0, 0);
				MESH47.transform.GetChild(0).transform.localEulerAngles = new Vector3(30, 0, 0);
				MESH48.transform.GetChild(0).transform.localPosition = new Vector3(0, 0, 0);
				MESH49.transform.GetChild(0).transform.localEulerAngles = new Vector3(50, 0, 0);
				MESH50.transform.GetChild(0).transform.localEulerAngles = new Vector3(50, 0, 0);
			}
			
			if(GameObject.Find("YARD/Building/Dynamics/SuomiClock") !=null)
			{
				MESH51.transform.GetChild(0).transform.localEulerAngles = new Vector3(-60+GameObject.Find("YARD/Building/Dynamics/SuomiClock/Clock/hour/NeedleHour").transform.localEulerAngles.y, 0, 0);
				MESH52.transform.GetChild(0).transform.localEulerAngles = new Vector3(GameObject.Find("YARD/Building/Dynamics/SuomiClock/Clock/minute/NeedleMinute").transform.localEulerAngles.y, 0, 0);
			}
			
			if(!(bool)SettingsBool3.GetValue())
			{
				FERNCLONE.GetComponent<Rigidbody>().mass = 1420;
				FERNCLONE.GetComponent<Drivetrain>().maxPower = 60;
				FERNCLONE.GetComponent<Drivetrain>().maxPowerRPM = 4500;
				FERNCLONE.GetComponent<Drivetrain>().maxTorque = 160;
				FERNCLONE.GetComponent<Drivetrain>().maxTorqueRPM = 2300;
				FERNCLONE.GetComponent<Drivetrain>().minRPM = 750;
				FERNCLONE.GetComponent<Drivetrain>().maxRPM = 5500;
				FERNCLONE.GetComponent<Drivetrain>().engineInertia = 1;
				FERNCLONE.GetComponent<Drivetrain>().differentialLockCoefficient = 0;
				FERNCLONE.GetComponent<Drivetrain>().engageRPM = 850;
				FERNCLONE.GetComponent<Drivetrain>().disengageRPM = 650;
				FERNCLONE.GetComponent<Axles>().frontAxle.leftWheel.suspensionTravel = 0.2f;
				FERNCLONE.GetComponent<Axles>().frontAxle.leftWheel.suspensionRate = 50000f;
				FERNCLONE.GetComponent<Axles>().frontAxle.leftWheel.bumpRate = 1100f;
				FERNCLONE.GetComponent<Axles>().frontAxle.leftWheel.reboundRate = 1100f;
				FERNCLONE.GetComponent<Axles>().frontAxle.rightWheel.suspensionTravel = 0.2f;
				FERNCLONE.GetComponent<Axles>().frontAxle.rightWheel.suspensionRate = 50000f;
				FERNCLONE.GetComponent<Axles>().frontAxle.rightWheel.bumpRate = 1100f;
				FERNCLONE.GetComponent<Axles>().frontAxle.rightWheel.reboundRate = 1100f;
				FERNCLONE.GetComponent<Axles>().rearAxle.leftWheel.suspensionTravel = 0.15f;
				FERNCLONE.GetComponent<Axles>().rearAxle.leftWheel.bumpRate = 1100f;
				FERNCLONE.GetComponent<Axles>().rearAxle.leftWheel.reboundRate = 1100f;
				FERNCLONE.GetComponent<Axles>().rearAxle.rightWheel.suspensionTravel = 0.15f;
				FERNCLONE.GetComponent<Axles>().rearAxle.rightWheel.bumpRate = 1100f;
				FERNCLONE.GetComponent<Axles>().rearAxle.rightWheel.reboundRate = 1100f;
			}
		}
		
		public override void OnSave()
		{
			SaveData sd = new SaveData();
            SaveDataList sdl = new SaveDataList
            {
                fuel = FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("FuelLevel").Value,
                pos = FERNCLONE.transform.position,
                rotX = FERNCLONE.transform.rotation.eulerAngles.x,
                rotY = FERNCLONE.transform.rotation.eulerAngles.y,
                rotZ = FERNCLONE.transform.rotation.eulerAngles.z
            };
            sd.save.Add(sdl);
			SaveLoad.SerializeSaveFile(this, sd, "mySaveFile.save");		
		}
		
		public override void ModSettings()
		{
			Settings.AddCheckBox(this, SettingsBool1);
			Settings.AddCheckBox(this, SettingsBool2);
			Settings.AddCheckBox(this, SettingsBool3);
			Settings.AddButton(this, ResetButton);
		}
		
		public static void resetcar()
		{
			FERNCLONE.transform.FindChild("FuelTank").GetComponent<PlayMakerFSM>().FsmVariables.GetFsmFloat("FuelLevel").Value = 55;
            FERNCLONE.transform.position = newpos;
            FERNCLONE.transform.rotation = newang;
		}
    }
}
