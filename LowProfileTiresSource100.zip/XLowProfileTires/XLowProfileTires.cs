﻿using System.IO;
using MSCLoader;
using UnityEngine;
using System.Linq;

namespace XLowProfileTires
{
    public class XLowProfileTires : Mod
    {
        public override string ID => "XLowProfileTires";
        public override string Name => "Low Profile Tires";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";
		
		private float RadiusNew;
		Settings normalbutton;
		Settings stretchedbutton;

        public override bool UseAssetsFolder => true;
		
		public override void OnLoad()
        {										
			//Load and replace meshes on load
			LoadMesh();
			
			//Load physical radius from .txt
			string[] array = new string[1];
			array = File.ReadAllLines(ModLoader.GetModAssetsFolder(this) + "/physical_radius.txt");
			RadiusNew = float.Parse(array[0]);
			
			//Change physical radius
			PlayMakerArrayListProxy WheelsList = GameObject.Find("REPAIRSHOP").transform.Find("Jobs/WheelArray1").gameObject.GetComponents<PlayMakerArrayListProxy>()[0];
			
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld10 = WheelsList.preFillGameObjectList[0].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Old").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld10.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld20 = WheelsList.preFillGameObjectList[0].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld20.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld30 = WheelsList.preFillGameObjectList[0].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld30.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld40 = WheelsList.preFillGameObjectList[0].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld40.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld50 = WheelsList.preFillGameObjectList[0].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld50.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[0].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[0].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld11 = WheelsList.preFillGameObjectList[1].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Old").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld11.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld21 = WheelsList.preFillGameObjectList[1].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld21.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld31 = WheelsList.preFillGameObjectList[1].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld31.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld41 = WheelsList.preFillGameObjectList[1].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld41.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld51 = WheelsList.preFillGameObjectList[1].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld51.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[1].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[1].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld12 = WheelsList.preFillGameObjectList[2].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Old").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld12.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld22 = WheelsList.preFillGameObjectList[2].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld22.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld32 = WheelsList.preFillGameObjectList[2].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld32.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld42 = WheelsList.preFillGameObjectList[2].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld42.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld52 = WheelsList.preFillGameObjectList[2].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld52.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[2].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[2].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld13 = WheelsList.preFillGameObjectList[3].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Old").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld13.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld23 = WheelsList.preFillGameObjectList[3].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld23.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld33 = WheelsList.preFillGameObjectList[3].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld33.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld43 = WheelsList.preFillGameObjectList[3].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld43.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld53 = WheelsList.preFillGameObjectList[3].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld53.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[3].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[3].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld14 = WheelsList.preFillGameObjectList[4].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Old").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld14.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld24 = WheelsList.preFillGameObjectList[4].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld24.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld34 = WheelsList.preFillGameObjectList[4].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld34.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld44 = WheelsList.preFillGameObjectList[4].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld44.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld54 = WheelsList.preFillGameObjectList[4].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld54.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[4].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[4].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[5].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld25 = WheelsList.preFillGameObjectList[5].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld25.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld35 = WheelsList.preFillGameObjectList[5].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld35.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld45 = WheelsList.preFillGameObjectList[5].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld45.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld55 = WheelsList.preFillGameObjectList[5].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld55.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[5].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[5].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[6].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld26 = WheelsList.preFillGameObjectList[6].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld26.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld36 = WheelsList.preFillGameObjectList[6].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld36.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld46 = WheelsList.preFillGameObjectList[6].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld46.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld56 = WheelsList.preFillGameObjectList[6].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld56.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[6].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[6].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[7].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld27 = WheelsList.preFillGameObjectList[7].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld27.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld37 = WheelsList.preFillGameObjectList[7].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld37.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld47 = WheelsList.preFillGameObjectList[7].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld47.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld57 = WheelsList.preFillGameObjectList[7].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld57.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[7].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[7].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[8].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld28 = WheelsList.preFillGameObjectList[8].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld28.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld38 = WheelsList.preFillGameObjectList[8].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld38.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld48 = WheelsList.preFillGameObjectList[8].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld48.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld58 = WheelsList.preFillGameObjectList[8].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld58.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[8].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[8].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[9].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld29 = WheelsList.preFillGameObjectList[9].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld29.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld39 = WheelsList.preFillGameObjectList[9].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld39.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld49 = WheelsList.preFillGameObjectList[9].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld49.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld59 = WheelsList.preFillGameObjectList[9].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld59.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[9].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[9].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[10].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld210 = WheelsList.preFillGameObjectList[10].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld210.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld310 = WheelsList.preFillGameObjectList[10].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld310.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld410 = WheelsList.preFillGameObjectList[10].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld410.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld510 = WheelsList.preFillGameObjectList[10].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld510.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[10].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[10].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[11].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld211 = WheelsList.preFillGameObjectList[11].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld211.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld311 = WheelsList.preFillGameObjectList[11].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld311.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld411 = WheelsList.preFillGameObjectList[11].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld411.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld511 = WheelsList.preFillGameObjectList[11].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld511.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[11].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[11].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[12].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld212 = WheelsList.preFillGameObjectList[12].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld212.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld312 = WheelsList.preFillGameObjectList[12].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld312.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld412 = WheelsList.preFillGameObjectList[12].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld412.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld512 = WheelsList.preFillGameObjectList[12].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld512.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[12].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[12].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[13].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld213 = WheelsList.preFillGameObjectList[13].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld213.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld313 = WheelsList.preFillGameObjectList[13].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld313.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld413 = WheelsList.preFillGameObjectList[13].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld413.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld513 = WheelsList.preFillGameObjectList[13].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld513.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[13].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[13].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[14].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld214 = WheelsList.preFillGameObjectList[14].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld214.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld314 = WheelsList.preFillGameObjectList[14].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld314.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld414 = WheelsList.preFillGameObjectList[14].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld414.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld514 = WheelsList.preFillGameObjectList[14].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld514.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[14].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[14].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[15].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld215 = WheelsList.preFillGameObjectList[15].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld215.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld315 = WheelsList.preFillGameObjectList[15].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld315.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld415 = WheelsList.preFillGameObjectList[15].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld415.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld515 = WheelsList.preFillGameObjectList[15].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld515.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[15].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[15].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[16].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld216 = WheelsList.preFillGameObjectList[16].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld216.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld316 = WheelsList.preFillGameObjectList[16].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld316.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld416 = WheelsList.preFillGameObjectList[16].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld416.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld516 = WheelsList.preFillGameObjectList[16].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld516.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[16].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[16].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[17].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld217 = WheelsList.preFillGameObjectList[17].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld217.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld317 = WheelsList.preFillGameObjectList[17].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld317.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld417 = WheelsList.preFillGameObjectList[17].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld417.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld517 = WheelsList.preFillGameObjectList[17].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld517.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[17].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[17].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[18].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld218 = WheelsList.preFillGameObjectList[18].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld218.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld318 = WheelsList.preFillGameObjectList[18].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld318.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld418 = WheelsList.preFillGameObjectList[18].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld418.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld518 = WheelsList.preFillGameObjectList[18].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld518.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[18].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[18].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[19].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld219 = WheelsList.preFillGameObjectList[19].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld219.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld319 = WheelsList.preFillGameObjectList[19].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld319.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld419 = WheelsList.preFillGameObjectList[19].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld419.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld519 = WheelsList.preFillGameObjectList[19].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld519.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[19].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[19].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[20].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld220 = WheelsList.preFillGameObjectList[20].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld220.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld320 = WheelsList.preFillGameObjectList[20].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld320.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld420 = WheelsList.preFillGameObjectList[20].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld420.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld520 = WheelsList.preFillGameObjectList[20].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld520.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[20].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[20].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[21].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld221 = WheelsList.preFillGameObjectList[21].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld221.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld321 = WheelsList.preFillGameObjectList[21].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld321.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld421 = WheelsList.preFillGameObjectList[21].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld421.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld521 = WheelsList.preFillGameObjectList[21].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld521.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[21].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[21].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[22].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld222 = WheelsList.preFillGameObjectList[22].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld222.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld322 = WheelsList.preFillGameObjectList[22].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld322.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld422 = WheelsList.preFillGameObjectList[22].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld422.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld522 = WheelsList.preFillGameObjectList[22].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld522.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[22].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[22].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[23].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld223 = WheelsList.preFillGameObjectList[23].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld223.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld323 = WheelsList.preFillGameObjectList[23].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld323.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld423 = WheelsList.preFillGameObjectList[23].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld423.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld523 = WheelsList.preFillGameObjectList[23].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld523.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[23].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[23].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[24].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld224 = WheelsList.preFillGameObjectList[24].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld224.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld324 = WheelsList.preFillGameObjectList[24].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld324.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld424 = WheelsList.preFillGameObjectList[24].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld424.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld524 = WheelsList.preFillGameObjectList[24].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld524.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[24].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[24].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[25].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld225 = WheelsList.preFillGameObjectList[25].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld225.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld325 = WheelsList.preFillGameObjectList[25].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld325.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld425 = WheelsList.preFillGameObjectList[25].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld425.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld525 = WheelsList.preFillGameObjectList[25].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld525.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[25].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[25].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[26].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld226 = WheelsList.preFillGameObjectList[26].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld226.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld326 = WheelsList.preFillGameObjectList[26].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld326.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld426 = WheelsList.preFillGameObjectList[26].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld426.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld526 = WheelsList.preFillGameObjectList[26].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld526.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[26].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[26].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[27].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld227 = WheelsList.preFillGameObjectList[27].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld227.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld327 = WheelsList.preFillGameObjectList[27].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld327.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld427 = WheelsList.preFillGameObjectList[27].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld427.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld527 = WheelsList.preFillGameObjectList[27].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld527.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[27].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[27].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[28].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld228 = WheelsList.preFillGameObjectList[28].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld228.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld328 = WheelsList.preFillGameObjectList[28].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld328.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld428 = WheelsList.preFillGameObjectList[28].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld428.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld528 = WheelsList.preFillGameObjectList[28].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld528.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[28].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[28].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[29].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld229 = WheelsList.preFillGameObjectList[29].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld229.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld329 = WheelsList.preFillGameObjectList[29].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld329.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld429 = WheelsList.preFillGameObjectList[29].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld429.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld529 = WheelsList.preFillGameObjectList[29].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld529.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[29].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[29].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[30].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld230 = WheelsList.preFillGameObjectList[30].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld230.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld330 = WheelsList.preFillGameObjectList[30].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld330.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld430 = WheelsList.preFillGameObjectList[30].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld430.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld530 = WheelsList.preFillGameObjectList[30].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld530.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[30].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[30].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[31].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld231 = WheelsList.preFillGameObjectList[31].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld231.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld331 = WheelsList.preFillGameObjectList[31].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld331.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld431 = WheelsList.preFillGameObjectList[31].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld431.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld531 = WheelsList.preFillGameObjectList[31].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld531.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[31].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[31].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[32].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld232 = WheelsList.preFillGameObjectList[32].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld232.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld332 = WheelsList.preFillGameObjectList[32].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld332.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld432 = WheelsList.preFillGameObjectList[32].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld432.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld532 = WheelsList.preFillGameObjectList[32].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld532.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[32].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[32].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[33].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld233 = WheelsList.preFillGameObjectList[33].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld233.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld333 = WheelsList.preFillGameObjectList[33].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld333.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld433 = WheelsList.preFillGameObjectList[33].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld433.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld533 = WheelsList.preFillGameObjectList[33].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld533.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[33].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[33].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[34].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld234 = WheelsList.preFillGameObjectList[34].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld234.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld334 = WheelsList.preFillGameObjectList[34].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld334.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld434 = WheelsList.preFillGameObjectList[34].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld434.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld534 = WheelsList.preFillGameObjectList[34].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld534.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[34].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[34].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[35].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld235 = WheelsList.preFillGameObjectList[35].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld235.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld335 = WheelsList.preFillGameObjectList[35].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld335.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld435 = WheelsList.preFillGameObjectList[35].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld435.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld535 = WheelsList.preFillGameObjectList[35].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld535.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[35].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[35].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			WheelsList.preFillGameObjectList[36].GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld236 = WheelsList.preFillGameObjectList[36].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld236.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld336 = WheelsList.preFillGameObjectList[36].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld336.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld436 = WheelsList.preFillGameObjectList[36].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld436.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld536 = WheelsList.preFillGameObjectList[36].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld536.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[36].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[36].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld237 = WheelsList.preFillGameObjectList[37].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld237.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld337 = WheelsList.preFillGameObjectList[37].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld337.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld437 = WheelsList.preFillGameObjectList[37].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld437.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld537 = WheelsList.preFillGameObjectList[37].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld537.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[37].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[37].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
							
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld238 = WheelsList.preFillGameObjectList[38].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld238.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld338 = WheelsList.preFillGameObjectList[38].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld338.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld438 = WheelsList.preFillGameObjectList[38].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld438.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld538 = WheelsList.preFillGameObjectList[38].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld538.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[38].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[38].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
							
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld239 = WheelsList.preFillGameObjectList[39].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld239.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld339 = WheelsList.preFillGameObjectList[39].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld339.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld439 = WheelsList.preFillGameObjectList[39].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld439.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld539 = WheelsList.preFillGameObjectList[39].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld539.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[39].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[39].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
							
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld240 = WheelsList.preFillGameObjectList[40].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Standard").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld240.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld340 = WheelsList.preFillGameObjectList[40].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Slick").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld340.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld440 = WheelsList.preFillGameObjectList[40].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Rally").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld440.floatValue = RadiusNew;
				
			HutongGames.PlayMaker.Actions.SetFloatValue RadiusOld540 = WheelsList.preFillGameObjectList[40].GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "Gobra").Actions[2] as HutongGames.PlayMaker.Actions.SetFloatValue;
			RadiusOld540.floatValue = RadiusNew;
				
			if(WheelsList.preFillGameObjectList[40].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value > 0.16f)
			{
				WheelsList.preFillGameObjectList[40].GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmFloat("SettingTireRadius").Value = RadiusNew;
			}
			
			if(GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Axles>().frontAxle.leftWheel.radius >0.18f)
			{
				GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Axles>().frontAxle.leftWheel.radius = RadiusNew;
			}
			
			if(GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Axles>().frontAxle.rightWheel.radius >0.18f)
			{
				GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Axles>().frontAxle.rightWheel.radius = RadiusNew;
			}
			
			if(GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Axles>().rearAxle.leftWheel.radius >0.18f)
			{
				GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Axles>().rearAxle.leftWheel.radius = RadiusNew;
			}
			
			if(GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Axles>().rearAxle.rightWheel.radius >0.18f)
			{
				GameObject.Find("SATSUMA(557kg, 248)").GetComponent<Axles>().rearAxle.rightWheel.radius = RadiusNew;
			}
        }
		
		public override void ModSettings()
		{
			normalbutton = new Settings("normalbutton", "Normal", true, LoadMesh);
			Settings.AddCheckBox(this, normalbutton, "group1");
			stretchedbutton = new Settings("stretchedbutton", "Stretched", false, LoadMesh);
			Settings.AddCheckBox(this, stretchedbutton, "group1");
		}
		
		private void LoadMesh()
		{
			if(Application.loadedLevelName == "GAME")
			{
				if((bool)normalbutton.Value)
				{
					Mesh Tire13Normal = LoadAssets.LoadOBJMesh(this, "13normal.obj");
					Mesh Tire14Normal = LoadAssets.LoadOBJMesh(this, "14normal.obj");
					
					//Stock tires replace
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireOld"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Normal;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireOld(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Normal;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireStock13"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Normal;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireStock13(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Normal;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireStock14"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Normal;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireStock14(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Normal;
					}
			
					//Gobra tires replace
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireGobra"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Normal;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireGobra(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Normal;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireGobra2"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Normal;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireGobra2(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Normal;	
					}
			
					//Rally tires replace
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireRally"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Normal;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireRally(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Normal;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireRally2"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Normal;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireRally2(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Normal;
					}
			
					//Slick tires replace
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireSlick"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Normal;
					}
				
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireSlick(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Normal;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireSlick2"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Normal;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireSlick2(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Normal;
					}
				}
				if((bool)stretchedbutton.Value)
				{
					Mesh Tire13Stretched = LoadAssets.LoadOBJMesh(this, "13stretched.obj");
					Mesh Tire14Stretched = LoadAssets.LoadOBJMesh(this, "14stretched.obj");
					
					//Stock tires replace
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireOld"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Stretched;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireOld(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Stretched;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireStock13"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Stretched;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireStock13(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Stretched;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireStock14"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Stretched;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireStock14(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Stretched;
					}
			
					//Gobra tires replace
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireGobra"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Stretched;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireGobra(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Stretched;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireGobra2"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Stretched;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireGobra2(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Stretched;	
					}
			
					//Rally tires replace
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireRally"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Stretched;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireRally(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Stretched;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireRally2"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Stretched;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireRally2(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Stretched;
					}
			
					//Slick tires replace
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireSlick"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Stretched;
					}
				
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireSlick(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire14Stretched;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireSlick2"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Stretched;
					}
			
					foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireSlick2(Clone)"))
					{
						tire.GetComponent<MeshFilter>().sharedMesh = Tire13Stretched;
					}
				}
			}
		}
    }
}
