﻿using HutongGames.PlayMaker;
using MSCLoader;
using UnityEngine;
using System.Collections;

namespace Pause
{
    public class Pause : Mod
    {
        public override string ID { get { return "Pause"; } }
        public override string Name { get { return "Pause"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        public float timing;
		public bool isPaused;
		
		public override void OnGUI()
		{
			GUIStyle myStyle = new GUIStyle();
			myStyle.fontSize = (int)(40.0f * (float)(Screen.width)/1000f);
			myStyle.normal.textColor = Color.red;
   
			if(isPaused)
			{
				GUI.Label(new Rect((Screen.width-190)/2, (Screen.height-100)/2, Screen.width, Screen.height), "PAUSE", myStyle);
			}
		}
		
        public override void Update()
		{
			Time.timeScale = timing;
			if(Input.GetKeyDown(KeyCode.Pause) && isPaused == false)
			{
				isPaused = true;
			}
			else if (Input.GetKeyDown(KeyCode.Pause) && isPaused == true)
			{
				isPaused = false;
			}

			if(isPaused == true)
			{
				timing = 0;
			}
			else if(isPaused == false)
			{
				timing = 1;
			}
		}	
    }
}
