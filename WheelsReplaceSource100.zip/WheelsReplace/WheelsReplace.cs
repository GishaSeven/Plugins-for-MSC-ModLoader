﻿using MSCLoader;
using UnityEngine;
using System.Linq;

namespace WheelsReplace
{
    public class WheelsReplace : Mod
    {
        public override string ID => "WheelsReplace";
        public override string Name => "WheelsReplace";
        public override string Author => "Fredrik, Roman266";
        public override string Version => "1.0.0";

        public override bool UseAssetsFolder => true;
		
		public override void OnLoad()
        {										
			//General rim textures
			Texture2D RimsAO = LoadAssets.LoadTexture(this, "rims_ao.dds");
			Texture2D RimsSPEC = LoadAssets.LoadTexture(this, "rims_spec.dds");
			Texture2D RustPatches = LoadAssets.LoadTexture(this, "rims_rust_patches.dds");
			Texture2D RustyNormal = LoadAssets.LoadTexture(this, "rims_rusty_n.dds");
			Texture2D RimsAOInners = LoadAssets.LoadTexture(this, "rim_ao_inners.dds");
			//Steel rim
			Mesh RimSteelMesh = LoadAssets.LoadOBJMesh(this, "rim_steel.obj");
			
            foreach (GameObject rim in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "wheel_regula" && g.GetComponent<MeshFilter>().sharedMesh.name.Contains("rim_steel")))
            {
                rim.GetComponent<MeshFilter>().sharedMesh = RimSteelMesh;
				rim.GetComponent<MeshRenderer>().material.mainTexture = RimsAO;
				rim.GetComponent<MeshRenderer>().material.SetTexture("_DetailAlbedoMap", RustPatches);
				rim.GetComponent<MeshRenderer>().material.SetTexture("_DetailNormalMap", RustyNormal);
				rim.GetComponent<MeshRenderer>().material.SetTexture("_SpecGlossMap", RimsSPEC);
            }
			//Hubcap
			Mesh HubcapMesh = LoadAssets.LoadOBJMesh(this, "tire_fl_hubcap.obj");
			Texture2D ATLASMOTORPARTS = LoadAssets.LoadTexture(this, "ATLAS_MOTORPARTS.dds");
			Texture2D MotorAtlasNormal = LoadAssets.LoadTexture(this, "motorparts_atlas_n.dds");
			Texture2D MotorAtlasSpec = LoadAssets.LoadTexture(this, "motorparts_atlas_spec.dds");
			
			foreach (GameObject hubcap in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "hubcap(Clone)"))
			{
				hubcap.GetComponent<MeshFilter>().sharedMesh = HubcapMesh;
				hubcap.GetComponent<MeshRenderer>().material.mainTexture = ATLASMOTORPARTS;
				hubcap.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", MotorAtlasNormal);
				hubcap.GetComponent<MeshRenderer>().material.SetTexture("_ScecGlossMap", MotorAtlasSpec);
			}
			//GT rim
			Mesh RimGTChromeMesh = LoadAssets.LoadOBJMesh(this, "rim_gt_chrome.obj");
			Mesh RimGTMesh = LoadAssets.LoadOBJMesh(this, "rim_gt.obj");
			
            foreach (GameObject rim in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "wheel_regula" && g.GetComponent<MeshFilter>().sharedMesh.name.Contains("rim_gt_chrome")))
            {
                rim.GetComponent<MeshFilter>().sharedMesh = RimGTChromeMesh;
				rim.GetComponent<MeshRenderer>().material.mainTexture = RimsAO;
				rim.GetComponent<MeshRenderer>().material.SetTexture("_SpecGlossMap", RimsSPEC);
				rim.transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimGTMesh;
				rim.transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
				rim.transform.Find("inner").GetComponent<MeshRenderer>().material.SetTexture("_DetailAlbedoMap", RustPatches);
				rim.transform.Find("inner").GetComponent<MeshRenderer>().material.SetTexture("_DetailNormalMap", RustyNormal);
				rim.transform.Find("inner").GetComponent<MeshRenderer>().material.SetTexture("_SpecGlossMap", RimsSPEC);
            }
			//Hayosiko rim
			Mesh RimHayosikoMesh = LoadAssets.LoadOBJMesh(this, "rim_hayosiko.obj");
			Mesh RimHayoInnerMesh = LoadAssets.LoadOBJMesh(this, "rim_hayosiko_inner.obj");
			
			foreach (GameObject rim in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "wheel_offset" && g.GetComponent<MeshFilter>().sharedMesh.name.Contains("rim_hayosiko")))
            {
                rim.GetComponent<MeshFilter>().sharedMesh = RimHayosikoMesh;
				rim.GetComponent<MeshRenderer>().material.mainTexture = RimsAO;
				rim.GetComponent<MeshRenderer>().material.SetTexture("_SpecGlossMap", RimsSPEC);
				rim.transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimHayoInnerMesh;
				rim.transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
				rim.transform.Find("inner").GetComponent<MeshRenderer>().material.SetTexture("_SpecGlossMap", RimsSPEC);
            }
			//Octo rim
			Mesh RimOctoMesh = LoadAssets.LoadOBJMesh(this, "rim_octo.obj");
			
			foreach (GameObject rim in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "wheel_offset" && g.GetComponent<MeshFilter>().sharedMesh.name.Contains("rim_octo")))
            {
                rim.GetComponent<MeshFilter>().sharedMesh = RimOctoMesh;
				rim.GetComponent<MeshRenderer>().material.mainTexture = RimsAO;
				rim.GetComponent<MeshRenderer>().material.SetTexture("_SpecGlossMap", RimsSPEC);
            }
			//Racing rim
			Mesh RimRacingMesh = LoadAssets.LoadOBJMesh(this, "rim_racing.obj");
			Mesh RimRacChrMesh = LoadAssets.LoadOBJMesh(this, "rim_racing_chrome.obj");
			
			foreach (GameObject rim in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "wheel_offset" && g.GetComponent<MeshFilter>().sharedMesh.name.Contains("rim_racing")))
            {
                rim.GetComponent<MeshFilter>().sharedMesh = RimRacingMesh;
				rim.GetComponent<MeshRenderer>().material.mainTexture = RimsAO;
				rim.GetComponent<MeshRenderer>().material.SetTexture("_SpecGlossMap", RimsSPEC);
				rim.transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimRacChrMesh;
				rim.transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAO;
            }
			//Rally rim
			Mesh RimRallyMesh = LoadAssets.LoadOBJMesh(this, "rim_rally.obj");
			
			foreach (GameObject rim in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "wheel_regula" && g.GetComponent<MeshFilter>().sharedMesh.name.Contains("rim_rally")))
            {
                rim.GetComponent<MeshFilter>().sharedMesh = RimRallyMesh;
				rim.GetComponent<MeshRenderer>().material.mainTexture = RimsAO;
				rim.GetComponent<MeshRenderer>().material.SetTexture("_SpecGlossMap", RimsSPEC);
            }
			//Slot rim
			Mesh RimSlotMesh = LoadAssets.LoadOBJMesh(this, "rim_slot.obj");
			
			foreach (GameObject rim in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "wheel_offset" && g.GetComponent<MeshFilter>().sharedMesh.name.Contains("rim_slot")))
            {
                rim.GetComponent<MeshFilter>().sharedMesh = RimSlotMesh;
				rim.GetComponent<MeshRenderer>().material.mainTexture = RimsAO;
				rim.GetComponent<MeshRenderer>().material.SetTexture("_SpecGlossMap", RimsSPEC);
            }
			//Spoke rim
			Mesh RimSpokeMesh = LoadAssets.LoadOBJMesh(this, "rim_spoke.obj");
			
			foreach (GameObject rim in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "wheel_offset" && g.GetComponent<MeshFilter>().sharedMesh.name.Contains("rim_spoke")))
            {
                rim.GetComponent<MeshFilter>().sharedMesh = RimSpokeMesh;
				rim.GetComponent<MeshRenderer>().material.mainTexture = RimsAO;
				rim.GetComponent<MeshRenderer>().material.SetTexture("_SpecGlossMap", RimsSPEC);
            }
			//Steel 14 rim
			Mesh RimSteel14Mesh = LoadAssets.LoadOBJMesh(this, "rim_steel_14.obj");
			
			foreach (GameObject rim in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "wheel_offset" && g.GetComponent<MeshFilter>().sharedMesh.name.Contains("rim_steel_14")))
            {
				rim.GetComponent<MeshFilter>().sharedMesh = RimSteel14Mesh;
				rim.GetComponent<MeshRenderer>().material.mainTexture = RimsAO;
				rim.GetComponent<MeshRenderer>().material.SetTexture("_SpecGlossMap", RimsSPEC);
            }
			//Turbine rim
			Mesh RimTurbineMesh = LoadAssets.LoadOBJMesh(this, "rim_turbine.obj");
			Mesh RimTurbineInnerMesh = LoadAssets.LoadOBJMesh(this, "rim_turbine_inner.obj");
			
			foreach (GameObject rim in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "wheel_offset" && g.GetComponent<MeshFilter>().sharedMesh.name.Contains("rim_turbine")))
            {
                rim.GetComponent<MeshFilter>().sharedMesh = RimTurbineMesh;
				rim.GetComponent<MeshRenderer>().material.mainTexture = RimsAO;
				rim.GetComponent<MeshRenderer>().material.SetTexture("_SpecGlossMap", RimsSPEC);
				rim.transform.Find("inner").GetComponent<MeshFilter>().sharedMesh = RimTurbineInnerMesh;
				rim.transform.Find("inner").GetComponent<MeshRenderer>().material.mainTexture = RimsAOInners;
				rim.transform.Find("inner").GetComponent<MeshRenderer>().material.SetTexture("_SpecGlossMap", RimsSPEC);
            }
			
			//Stock tire
			Mesh TireStockMesh = LoadAssets.LoadOBJMesh(this, "tire_stock.obj");
			Texture2D TiresStandard2 = LoadAssets.LoadTexture(this, "tires_standard2.dds");
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireOld(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireStockMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresStandard2;
			}
			
			Texture2D TiresNew2 = LoadAssets.LoadTexture(this, "tires_new_2.dds");
					
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireStock13(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireStockMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresNew2;
			}
			
			Mesh TireStockNewMesh = LoadAssets.LoadOBJMesh(this, "tire_stock_new.obj");
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireStock14(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireStockNewMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresNew2;
			}
			//Gobra tire
			Mesh TireGobra2Mesh = LoadAssets.LoadOBJMesh(this, "tire_gobra_2.obj");
			Texture2D TiresGobra = LoadAssets.LoadTexture(this, "tires_gobra.dds");
			Texture2D TiresGobraN = LoadAssets.LoadTexture(this, "tires_gobra_n.dds");
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireGobra2(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireGobra2Mesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresGobra;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresGobraN);
			}
			
			Mesh TireGobraMesh = LoadAssets.LoadOBJMesh(this, "tire_gobra.obj");
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireGobra(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireGobraMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresGobra;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresGobraN);
			}
			//Rally tire
			Mesh TireRally2Mesh = LoadAssets.LoadOBJMesh(this, "tire_rally2.obj");
			Texture2D TiresRally = LoadAssets.LoadTexture(this, "tires_rally.dds");
			Texture2D TiresRallyN = LoadAssets.LoadTexture(this, "tires_rally_n.dds");
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireRally2(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireRally2Mesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresRally;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresRallyN);
			}
			
			Mesh TireRallyMesh = LoadAssets.LoadOBJMesh(this, "tire_rally.obj");
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireRally(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireRallyMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresRally;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresRallyN);
			}
			//Slick tire
			Mesh TireSlick2Mesh = LoadAssets.LoadOBJMesh(this, "tire_slick_2.obj");
			Texture2D TiresSlicks = LoadAssets.LoadTexture(this, "tires_slicks.dds");
			Texture2D TiresSlicksN = LoadAssets.LoadTexture(this, "tires_slicks_n.dds");
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireSlick2(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireSlick2Mesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresSlicks;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresSlicksN);
			}
			
			Mesh TireSlickMesh = LoadAssets.LoadOBJMesh(this, "tire_slick.obj");
			
			foreach (GameObject tire in Resources.FindObjectsOfTypeAll<GameObject>().Where(g => g.name == "TireSlick(Clone)"))
			{
				tire.GetComponent<MeshFilter>().sharedMesh = TireSlickMesh;
				tire.GetComponent<MeshRenderer>().material.mainTexture = TiresSlicks;
				tire.GetComponent<MeshRenderer>().material.SetTexture("_BumpMap", TiresSlicksN);
			}
        }
    }
}
