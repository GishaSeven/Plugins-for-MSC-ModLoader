using MSCLoader;
using UnityEngine;
using HutongGames.PlayMaker;


namespace Pause
{
    public class Pause : Mod
    {
        public override string ID { get { return "Pause"; } }
        public override string Name { get { return "Pause"; } }
        public override string Author { get { return "Roman266(fix by mads232)"; } }
        public override string Version { get { return "1.0.5"; } }

        private bool isPaused;
        private float timing;
        private float originalFatigue;
        private float originalDirtiness;
        private float originalDrunk;
        private float originalHunger;
        private float originalThirst;
        private float originalUrine;
		private float originalStress;
		private float originalStressRate;
		private GameObject PLAYER;
		private Keybind pauseKey = new Keybind("PauseKey", "Pause", KeyCode.Pause);

        public override void OnLoad()
        {
            Keybind.Add(this, pauseKey);
        }

        public override void Update()
        {
            if (pauseKey.IsDown())
            {
                pauseGame();
            }

            if (isPaused)
            {
                FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value = originalFatigue;
                FsmVariables.GlobalVariables.FindFsmFloat("PlayerDirtiness").Value = originalDirtiness;
                FsmVariables.GlobalVariables.FindFsmFloat("PlayerDrunk").Value = originalDrunk;
                FsmVariables.GlobalVariables.FindFsmFloat("PlayerHunger").Value = originalHunger;
                FsmVariables.GlobalVariables.FindFsmFloat("PlayerThirst").Value = originalThirst;
                FsmVariables.GlobalVariables.FindFsmFloat("PlayerUrine").Value = originalUrine;
				
				this.PLAYER = GameObject.Find("PLAYER");
				
				PlayMakerFSM[] componentsInChildren = this.PLAYER.GetComponentsInChildren<PlayMakerFSM>();
				for (int i = 0; i < componentsInChildren.Length; i++)
				{
					PlayMakerFSM playMakerFSM = componentsInChildren[i];
					if (playMakerFSM.name == "PlayerStress")
					{
						playMakerFSM.enabled = false;
					}
				
					if (playMakerFSM.name == "PlayerStressRate")
					{
						playMakerFSM.enabled = false;
					}
				}
				
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerStress").Value = originalStress;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerStressRate").Value = originalStressRate;
            }
        }

        private void pauseGame()
        {
            isPaused = !isPaused;

            if (isPaused == true)
            {
                initVars();
                timing = 0;
                FsmVariables.GlobalVariables.FindFsmBool("PlayerStop").Value = true;
                FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = true;
            }
            else if (isPaused == false)
            {
                timing = 1;
                FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;

                if (FsmVariables.GlobalVariables.FindFsmString("PlayerCurrentVehicle").Value == "")
                {
                    FsmVariables.GlobalVariables.FindFsmBool("PlayerStop").Value = false;
                }
            }

            Time.timeScale = timing;
        }
		
		private void initVars()
        {
            originalFatigue = FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value;
            originalDirtiness = FsmVariables.GlobalVariables.FindFsmFloat("PlayerDirtiness").Value;
            originalDrunk = FsmVariables.GlobalVariables.FindFsmFloat("PlayerDrunk").Value;
            originalHunger = FsmVariables.GlobalVariables.FindFsmFloat("PlayerHunger").Value;
            originalThirst = FsmVariables.GlobalVariables.FindFsmFloat("PlayerThirst").Value;
            originalUrine = FsmVariables.GlobalVariables.FindFsmFloat("PlayerUrine").Value;
			originalStress = FsmVariables.GlobalVariables.FindFsmFloat("PlayerStress").Value;
			originalStressRate = FsmVariables.GlobalVariables.FindFsmFloat("PlayerStressRate").Value;
        }

        public override void OnGUI()
        {
            GUIStyle myStyle = new GUIStyle();
            myStyle.fontSize = (int)(40.0f * (float)(Screen.width) / 1000f);
            myStyle.normal.textColor = Color.red;
			myStyle.alignment = TextAnchor.MiddleCenter;

            if (isPaused)
            {
                GUI.Label(new Rect(0, 0, Screen.width, Screen.height), "PAUSED", myStyle);
            }
        }
    }
}