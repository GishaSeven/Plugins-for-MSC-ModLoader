﻿using MSCLoader;
using UnityEngine;
using System.IO;
using System.Threading;
using System.Collections; 
using HutongGames.PlayMaker;

namespace IllegalTimeAttack
{
    public class IllegalTimeAttack : Mod
    {
        public override string ID => "IllegalTimeAttack";
        public override string Name => "Illegal Time Attack";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";

        public override bool UseAssetsFolder => true;
		
		private int Race1Seconds;
		private int Race1Minuts;
		private int Race2Seconds;
		private int Race2Minuts;
		private int Race3Seconds;
		private int Race3Minuts;
		private bool Race1GUI;
		private bool Race1Actived;
		private bool Race1Actived2;
		private bool Race2GUI;
		private bool Race2Actived;
		private bool Race2Actived2;
		private bool Race3GUI;
		private bool Race3Actived;
		private bool Race3Actived2;
		private bool Race1Started;
		private bool Race2Started;
		private bool Race3Started;
		private bool Race1Checkpoint;
		private bool Race2Checkpoint;
		private bool RaceActivedGUI;
		private bool SatsumaChecker;
		private bool RaceStartedGUI;
		private bool RaceLoseGUI;
		private bool RaceWonGUI;
		private float Race1Time;
		private float Race1TimeToWin;
		private float Race1Bet;
		private float Race1Stage;
		private float Race1StageMax;
		private float Race2Time;
		private float Race2TimeToWin;
		private float Race2Bet;
		private float Race2Stage;
		private float Race2StageMax;
		private float Race3Time;
		private float Race3TimeToWin;
		private float Race3Bet;
		private float Race3Stage;
		private float Race3StageMax;
		private float Race3PreLap;
		private float Race3Lap;
		private string path;
		private string Race1TimeWin;
		private string Race2TimeWin;
		private string Race3TimeWin;
		private Rect Race1BOXGUI = new Rect((Screen.width-700)/2, (Screen.height-700)/2, 700f, 700f);
		private Rect Race2BOXGUI = new Rect((Screen.width-700)/2, (Screen.height-700)/2, 700f, 700f);
		private Rect Race3BOXGUI = new Rect((Screen.width-700)/2, (Screen.height-700)/2, 700f, 700f);

        public override void OnLoad()
        {
			//Load save
			path = ModLoader.GetModAssetsFolder(this);

			if (File.Exists(path + "/save.txt"))
			{
				LoadSave();
			}
			else
			{
				Write0();
				Race1StageMax = 0;
				Race2StageMax = 0;
				Race3StageMax = 0;
			}
			//race1 banner
			GameObject HandleTrigger1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            HandleTrigger1.name = "Roman266Race1Banner";
            HandleTrigger1.transform.localScale = new Vector3(0.01f, 1f, 1f);
			HandleTrigger1.transform.localPosition = new Vector3(-1554.3f, 4.3116154671f, 1186.1682128906f);
			HandleTrigger1.transform.localEulerAngles= new Vector3(0, 58, 0);
            var col1 = HandleTrigger1.GetComponent<Collider>();
            col1.isTrigger = true;
			Texture2D loadtexture1 = LoadAssets.LoadTexture(this, "race1.dds");			
			HandleTrigger1.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1;
			//race2 banner
			GameObject HandleTrigger2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            HandleTrigger2.name = "Roman266Race2Banner";
            HandleTrigger2.transform.localScale = new Vector3(0.01f, 1f, 1f);
			HandleTrigger2.transform.localPosition = new Vector3(-1553.25f, 4.3116154671f, 1186.8389892578f);
			HandleTrigger2.transform.localEulerAngles= new Vector3(0, 58, 0);
            var col2 = HandleTrigger2.GetComponent<Collider>();
            col2.isTrigger = true;
			Texture2D loadtexture2 = LoadAssets.LoadTexture(this, "race2.dds");			
			HandleTrigger2.GetComponent<MeshRenderer>().material.mainTexture = loadtexture2;
			//race3 banner
			GameObject HandleTrigger3 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            HandleTrigger3.name = "Roman266Race3Banner";
            HandleTrigger3.transform.localScale = new Vector3(0.01f, 1f, 1f);
			HandleTrigger3.transform.localPosition = new Vector3(-1552.2f, 4.3116154671f, 1187.50977f);
			HandleTrigger3.transform.localEulerAngles= new Vector3(0, 58, 0);
            var col3 = HandleTrigger3.GetComponent<Collider>();
            col3.isTrigger = true;
			Texture2D loadtexture3 = LoadAssets.LoadTexture(this, "race3.dds");			
			HandleTrigger3.GetComponent<MeshRenderer>().material.mainTexture = loadtexture3;
        }
		
		public override void OnGUI()
		{
			if(Race1GUI)
			{
				GUI.ModalWindow(1, this.Race1BOXGUI, new GUI.WindowFunction(this.WindowR1), "Race 1");
			}
			
			if(Race2GUI)
			{
				GUI.ModalWindow(1, this.Race2BOXGUI, new GUI.WindowFunction(this.WindowR2), "Race 2");
			}
			
			if(Race3GUI)
			{
				GUI.ModalWindow(1, this.Race3BOXGUI, new GUI.WindowFunction(this.WindowR3), "Race 3");
			}
			//Stopwath race 1
			GUIStyle myStyle = new GUIStyle();
			myStyle.fontSize = (int)(20.0f * (float)(Screen.width)/1000f);
			myStyle.normal.textColor = Color.white;
   
			if(Race1Started)
			{
				GUI.Label(new Rect(Screen.width/7*6, Screen.height/7, Screen.width, Screen.height), string.Format("{0:0}:{1:00}", Race1Minuts, Race1Seconds) + "/" + Race1TimeWin, myStyle);
			}
			//Stopwath race 2
			if(Race2Started)
			{
				GUI.Label(new Rect(Screen.width/7*6, Screen.height/7, Screen.width, Screen.height), string.Format("{0:0}:{1:00}", Race2Minuts, Race2Seconds) + "/" + Race2TimeWin, myStyle);
			}
			//Stopwath race 3
			if(Race3Started)
			{
				GUI.Label(new Rect(Screen.width/7*6, Screen.height/7, Screen.width, Screen.height), string.Format("{0:0}:{1:00}", Race3Minuts, Race3Seconds) + "/" + Race3TimeWin + "\n" + "Lap: " + (Race3Lap + 1) + "/" + "5", myStyle);
			}
			//Race started
			GUIStyle myStyle2 = new GUIStyle();
            myStyle2.fontSize = (int)(100.0f * (float)(Screen.width) / 1000f);
            myStyle2.normal.textColor = Color.white;
			myStyle2.alignment = TextAnchor.MiddleCenter;
			
			if(RaceStartedGUI)
			{
				GUI.Label(new Rect(0, 0, Screen.width, Screen.height), "RACE STARTED", myStyle2);
			}
			//Race actived
			GUIStyle myStyle3 = new GUIStyle();
            myStyle3.fontSize = (int)(100.0f * (float)(Screen.width) / 1000f);
            myStyle3.normal.textColor = Color.yellow;
			myStyle3.alignment = TextAnchor.MiddleCenter;
			
			if(RaceActivedGUI)
			{
				GUI.Label(new Rect(0, 0, Screen.width, Screen.height), "DRIVE", myStyle3);
			}
			//Race lose
			GUIStyle myStyle4 = new GUIStyle();
            myStyle4.fontSize = (int)(100.0f * (float)(Screen.width) / 1000f);
            myStyle4.normal.textColor = Color.red;
			myStyle4.alignment = TextAnchor.MiddleCenter;
			
			if(RaceLoseGUI)
			{
				GUI.Label(new Rect(0, 0, Screen.width, Screen.height), "YOU LOSE", myStyle4);
			}
			//Race won
			GUIStyle myStyle5 = new GUIStyle();
            myStyle5.fontSize = (int)(100.0f * (float)(Screen.width) / 1000f);
            myStyle5.normal.textColor = Color.green;
			myStyle5.alignment = TextAnchor.MiddleCenter;
			
			if(RaceWonGUI)
			{
				GUI.Label(new Rect(0, 0, Screen.width, Screen.height), "YOU WON", myStyle5);
			}
		}

        public override void Update()
        {
			//Race1 banner trigger
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			RaycastHit Roman266hit1banner;
            if (Physics.Raycast(ray, out Roman266hit1banner, 1))
            {
                if (Roman266hit1banner.collider.name == "Roman266Race1Banner")
                {
                    if (Input.GetMouseButtonDown(0))
                    {
                        if(!Race1GUI)
						{
							Race1GUI = true;
							FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = true;
						
							if(Race1StageMax == 0)
							{
								Race1Stage = 1;
								Race1TimeToWin = 300;
								Race1Bet = 100;
								Race1TimeWin = "5:00";
							}
						
							if(Race1StageMax == 1)
							{
								Race1Stage = 2;
								Race1TimeToWin = 295;
								Race1Bet = 200;
								Race1TimeWin = "4:55";
							}
						
							if(Race1StageMax == 2)
							{
								Race1Stage = 3;
								Race1TimeToWin = 290;
								Race1Bet = 300;
								Race1TimeWin = "4:50";
							}
						
							if(Race1StageMax == 3)
							{
								Race1Stage = 4;
								Race1TimeToWin = 285;
								Race1Bet = 400;
								Race1TimeWin = "4:45";
							}
					
							if(Race1StageMax == 4)
							{
								Race1Stage = 5;
								Race1TimeToWin = 280;
								Race1Bet = 500;
								Race1TimeWin = "4:40";
							}
				
							if(Race1StageMax == 5)
							{
								Race1Stage = 6;
								Race1TimeToWin = 250;
								Race1Bet = 1000;
								Race1TimeWin = "4:10";
							}
						
							if(Race1StageMax == 6)
							{
								Race1Stage = 7;
								Race1TimeToWin = 245;
								Race1Bet = 2000;
								Race1TimeWin = "4:05";
							}
				
							if(Race1StageMax == 7)
							{
								Race1Stage = 8;
								Race1TimeToWin = 240;
								Race1Bet = 3000;
								Race1TimeWin = "4:00";
							}
			
							if(Race1StageMax == 8)
							{
								Race1Stage = 9;
								Race1TimeToWin = 235;
								Race1Bet = 4000;
								Race1TimeWin = "3:55";
							}
				
							if(Race1StageMax == 9)
							{
								Race1Stage = 10;
								Race1TimeToWin = 230;
								Race1Bet = 5000;
								Race1TimeWin = "3:50";
							}
						}
                    }
                }
            }
			//Race2 banner trigger
			RaycastHit Roman266hit2banner;
            if (Physics.Raycast(ray, out Roman266hit2banner, 1))
            {
                if (Roman266hit2banner.collider.name == "Roman266Race2Banner")
                {
                    if (Input.GetMouseButtonDown(0))
                    {
                        if(!Race2GUI)
						{
							Race2GUI = true;
							FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = true;
						
							if(Race2StageMax == 0)
							{
								Race2Stage = 1;
								Race2TimeToWin = 390;
								Race2Bet = 100;
								Race2TimeWin = "6:30";
							}
						
							if(Race2StageMax == 1)
							{
								Race2Stage = 2;
								Race2TimeToWin = 380;
								Race2Bet = 200;
								Race2TimeWin = "6:20";
							}
						
							if(Race2StageMax == 2)
							{
								Race2Stage = 3;
								Race2TimeToWin = 370;
								Race2Bet = 300;
								Race2TimeWin = "6:10";
							}
						
							if(Race2StageMax == 3)
							{
								Race2Stage = 4;
								Race2TimeToWin = 360;
								Race2Bet = 400;
								Race2TimeWin = "6:00";
							}
					
							if(Race2StageMax == 4)
							{
								Race2Stage = 5;
								Race2TimeToWin = 350;
								Race2Bet = 500;
								Race2TimeWin = "5:50";
							}
				
							if(Race2StageMax == 5)
							{
								Race2Stage = 6;
								Race2TimeToWin = 290;
								Race2Bet = 1000;
								Race2TimeWin = "4:50";
							}
						
							if(Race2StageMax == 6)
							{
								Race2Stage = 7;
								Race2TimeToWin = 280;
								Race2Bet = 2000;
								Race2TimeWin = "4:40";
							}
				
							if(Race2StageMax == 7)
							{
								Race2Stage = 8;
								Race2TimeToWin = 270;
								Race2Bet = 3000;
								Race2TimeWin = "4:30";
							}
			
							if(Race2StageMax == 8)
							{
								Race2Stage = 9;
								Race2TimeToWin = 260;
								Race2Bet = 4000;
								Race2TimeWin = "4:20";
							}
				
							if(Race2StageMax == 9)
							{
								Race2Stage = 10;
								Race2TimeToWin = 250;
								Race2Bet = 5000;
								Race2TimeWin = "4:10";
							}
						}
                    }
                }
            }
			//Race3 banner trigger
			RaycastHit Roman266hit3banner;
            if (Physics.Raycast(ray, out Roman266hit3banner, 1))
            {
                if (Roman266hit3banner.collider.name == "Roman266Race3Banner")
                {
                    if (Input.GetMouseButtonDown(0))
                    {
                        if(!Race3GUI)
						{
							Race3GUI = true;
							FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = true;
						
							if(Race3StageMax == 0)
							{
								Race3Stage = 1;
								Race3TimeToWin = 340;
								Race3Bet = 100;
								Race3TimeWin = "5:40";
							}
						
							if(Race3StageMax == 1)
							{
								Race3Stage = 2;
								Race3TimeToWin = 330;
								Race3Bet = 200;
								Race3TimeWin = "5:30";
							}
						
							if(Race3StageMax == 2)
							{
								Race3Stage = 3;
								Race3TimeToWin = 320;
								Race3Bet = 300;
								Race3TimeWin = "5:20";
							}
						
							if(Race3StageMax == 3)
							{
								Race3Stage = 4;
								Race3TimeToWin = 310;
								Race3Bet = 400;
								Race3TimeWin = "5:10";
							}
					
							if(Race3StageMax == 4)
							{
								Race3Stage = 5;
								Race3TimeToWin = 300;
								Race3Bet = 500;
								Race3TimeWin = "5:00";
							}
				
							if(Race3StageMax == 5)
							{
								Race3Stage = 6;
								Race3TimeToWin = 280;
								Race3Bet = 1000;
								Race3TimeWin = "4:40";
							}
						
							if(Race3StageMax == 6)
							{
								Race3Stage = 7;
								Race3TimeToWin = 270;
								Race3Bet = 2000;
								Race3TimeWin = "4:30";
							}
				
							if(Race3StageMax == 7)
							{
								Race3Stage = 8;
								Race3TimeToWin = 260;
								Race3Bet = 3000;
								Race3TimeWin = "4:20";
							}
			
							if(Race3StageMax == 8)
							{
								Race3Stage = 9;
								Race3TimeToWin = 250;
								Race3Bet = 4000;
								Race3TimeWin = "4:10";
							}
				
							if(Race3StageMax == 9)
							{
								Race3Stage = 10;
								Race3TimeToWin = 240;
								Race3Bet = 5000;
								Race3TimeWin = "4:00";
							}
						}
                    }
                }
            }
			//Race1 logic
			if(Race1Actived)
			{
				if(Race1Actived2 == false)
				{
					CreateTriggers1();
					
					if(SatsumaChecker == false)
					{
						CreateChecker();
					}
				}
				
				if(Race1Started)
				{
					if(Race1Time < Race1TimeToWin)
					{
						Race1Time += Time.deltaTime;
					}
				
					if(Race1Time > Race1TimeToWin)
					{
						Race1Started = false;
						Race1Checkpoint = false;
						Race1Actived = false;
						Race1Time = 0;
						new Thread(RaceLose).Start();
					}
					
					Race1Seconds = (int)(Race1Time % 60);
					Race1Minuts = (int)(Race1Time / 60);
				}
			}
			//Race2 logic
			if(Race2Actived)
			{
				if(Race2Actived2 == false)
				{
					CreateTriggers2();
					
					if(SatsumaChecker == false)
					{
						CreateChecker();
					}
				}
				
				if(Race2Started)
				{
					if(Race2Time < Race2TimeToWin)
					{
						Race2Time += Time.deltaTime;
					}
				
					if(Race2Time > Race2TimeToWin)
					{
						Race2Started = false;
						Race2Checkpoint = false;
						Race2Actived = false;
						Race2Time = 0;
						new Thread(RaceLose).Start();
					}
					
					Race2Seconds = (int)(Race2Time % 60);
					Race2Minuts = (int)(Race2Time / 60);
				}
			}
			//Race3 logic
			if(Race3Actived)
			{
				if(Race3Actived2 == false)
				{
					CreateTriggers3();
					
					if(SatsumaChecker == false)
					{
						CreateChecker();
					}
				}
				
				if(Race3Started)
				{
					if(Race3Time < Race3TimeToWin)
					{
						Race3Time += Time.deltaTime;
					}
				
					if(Race3Time > Race3TimeToWin)
					{
						Race3Started = false;
						Race3Actived = false;
						Race3Time = 0;
						Race3PreLap = 0;
						Race3Lap = 0;
						new Thread(RaceLose).Start();
					}
					
					Race3Seconds = (int)(Race3Time % 60);
					Race3Minuts = (int)(Race3Time / 60);
				}
			}
        }
		
		//Race1 GUI window
		private void WindowR1(int windowId)
		{
			GUIStyle Style1 = new GUIStyle();
            Style1.fontSize = (int)(50.0f * (float)(Screen.width) / 1000f);
            Style1.normal.textColor = Color.white;
			Style1.alignment = TextAnchor.MiddleCenter;
			GUI.Label(new Rect(0, 0, Screen.width-700f, Screen.height-700f), "Stage: " + Race1Stage, Style1);
			GUI.Label(new Rect(0, 0, Screen.width-700f, Screen.height-500f), "Bet: " + Race1Bet + "mk", Style1);
			GUI.Label(new Rect(0, 0, Screen.width-700f, Screen.height-300f), "Time: " + Race1TimeWin, Style1);
			
			GUIStyle Style2 = new GUIStyle();
            Style2.fontSize = (int)(50.0f * (float)(Screen.width) / 1000f);
            Style2.normal.textColor = Color.red;
			Style2.alignment = TextAnchor.MiddleCenter;
			
			if(Race1Stage > Race1StageMax + 1)
			{
				GUI.Label(new Rect(0, 0, Screen.width-700f, Screen.height-100f), "LOCKED", Style2);
			}
			
			bool flag0 = GUI.Button(new Rect(0f, 525f, 175f, 175f), "<<<<");
			if (flag0)
			{
				if(Race1Stage > 1)
				{
					Race1Stage = Race1Stage - 1;
				}
				else
				{
					Race1Stage = 10;
				}
				
				if(Race1Stage == 1)
				{
					Race1TimeToWin = 300;
					Race1Bet = 100;
					Race1TimeWin = "5:00";
				}
			
				if(Race1Stage == 2)
				{
					Race1TimeToWin = 295;
					Race1Bet = 200;
					Race1TimeWin = "4:55";
				}
			
				if(Race1Stage == 3)
				{
					Race1TimeToWin = 290;
					Race1Bet = 300;
					Race1TimeWin = "4:50";
				}
			
				if(Race1Stage == 4)
				{
					Race1TimeToWin = 285;
					Race1Bet = 400;
					Race1TimeWin = "4:45";
				}
			
				if(Race1Stage == 5)
				{
					Race1TimeToWin = 280;
					Race1Bet = 500;
					Race1TimeWin = "4:40";
				}
			
				if(Race1Stage == 6)
				{
					Race1TimeToWin = 250;
					Race1Bet = 1000;
					Race1TimeWin = "4:10";
				}
			
				if(Race1Stage == 7)
				{
					Race1TimeToWin = 245;
					Race1Bet = 2000;
					Race1TimeWin = "4:05";
				}
			
				if(Race1Stage == 8)
				{
					Race1TimeToWin = 240;
					Race1Bet = 3000;
					Race1TimeWin = "4:00";
				}
			
				if(Race1Stage == 9)
				{
					Race1TimeToWin = 235;
					Race1Bet = 4000;
					Race1TimeWin = "3:55";
				}
			
				if(Race1Stage == 10)
				{
					Race1TimeToWin = 230;
					Race1Bet = 5000;
					Race1TimeWin = "3:50";
				}
			}
			bool flag1 = GUI.Button(new Rect(175f, 525f, 175f, 175f), "START");
			if (flag1)
			{
				if(!Race1Actived)
				{
					if(Race1Stage <= Race1StageMax + 1)
					{
						var money = FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value;
						if(money >= Race1Bet)
						{
							FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = money - Race1Bet;
							Race1Actived = true;
							Race1GUI = false;
							FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
							new Thread(RaceActived).Start();
						}
					}
				}
			}
			bool flag2 = GUI.Button(new Rect(350f, 525f, 175f, 175f), "EXIT");
			if (flag2)
			{
				Race1GUI = false;
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
			}
			bool flag3 = GUI.Button(new Rect(525f, 525f, 175f, 175f), ">>>>");
			if (flag3)
			{
				if(Race1Stage == 10)
				{
					Race1Stage = 1;
				}
				else
				{
					Race1Stage = Race1Stage + 1;
				}
				
				if(Race1Stage == 1)
				{
					Race1TimeToWin = 300;
					Race1Bet = 100;
					Race1TimeWin = "5:00";
				}
			
				if(Race1Stage == 2)
				{
					Race1TimeToWin = 295;
					Race1Bet = 200;
					Race1TimeWin = "4:55";
				}
			
				if(Race1Stage == 3)
				{
					Race1TimeToWin = 290;
					Race1Bet = 300;
					Race1TimeWin = "4:50";
				}
			
				if(Race1Stage == 4)
				{
					Race1TimeToWin = 285;
					Race1Bet = 400;
					Race1TimeWin = "4:45";
				}
			
				if(Race1Stage == 5)
				{
					Race1TimeToWin = 280;
					Race1Bet = 500;
					Race1TimeWin = "4:40";
				}
			
				if(Race1Stage == 6)
				{
					Race1TimeToWin = 250;
					Race1Bet = 1000;
					Race1TimeWin = "4:10";
				}
			
				if(Race1Stage == 7)
				{
					Race1TimeToWin = 245;
					Race1Bet = 2000;
					Race1TimeWin = "4:05";
				}
			
				if(Race1Stage == 8)
				{
					Race1TimeToWin = 240;
					Race1Bet = 3000;
					Race1TimeWin = "4:00";
				}
			
				if(Race1Stage == 9)
				{
					Race1TimeToWin = 235;
					Race1Bet = 4000;
					Race1TimeWin = "3:55";
				}
			
				if(Race1Stage == 10)
				{
					Race1TimeToWin = 230;
					Race1Bet = 5000;
					Race1TimeWin = "3:50";
				}
			}
		}
		//Race2 GUI window
		private void WindowR2(int windowId)
		{
			GUIStyle Style1 = new GUIStyle();
            Style1.fontSize = (int)(50.0f * (float)(Screen.width) / 1000f);
            Style1.normal.textColor = Color.white;
			Style1.alignment = TextAnchor.MiddleCenter;
			GUI.Label(new Rect(0, 0, Screen.width-700f, Screen.height-700f), "Stage: " + Race2Stage, Style1);
			GUI.Label(new Rect(0, 0, Screen.width-700f, Screen.height-500f), "Bet: " + Race2Bet + "mk", Style1);
			GUI.Label(new Rect(0, 0, Screen.width-700f, Screen.height-300f), "Time: " + Race2TimeWin, Style1);
			
			GUIStyle Style2 = new GUIStyle();
            Style2.fontSize = (int)(50.0f * (float)(Screen.width) / 1000f);
            Style2.normal.textColor = Color.red;
			Style2.alignment = TextAnchor.MiddleCenter;
			
			if(Race2Stage > Race2StageMax + 1)
			{
				GUI.Label(new Rect(0, 0, Screen.width-700f, Screen.height-100f), "LOCKED", Style2);
			}
			
			bool flag0 = GUI.Button(new Rect(0f, 525f, 175f, 175f), "<<<<");
			if (flag0)
			{
				if(Race2Stage > 1)
				{
					Race2Stage = Race2Stage - 1;
				}
				else
				{
					Race2Stage = 10;
				}
				
				if(Race2Stage == 1)
				{
					Race2TimeToWin = 390; 
					Race2Bet = 100; 
					Race2TimeWin = "6:30"; 
				}
			
				if(Race2Stage == 2)
				{
					Race2TimeToWin = 380; 
					Race2Bet = 200; 
					Race2TimeWin = "6:20"; 
				}
			
				if(Race2Stage == 3)
				{
					Race2TimeToWin = 370; 
					Race2Bet = 300; 
					Race2TimeWin = "6:10"; 
				}
			
				if(Race2Stage == 4)
				{
					Race2TimeToWin = 360; 
					Race2Bet = 400; 
					Race2TimeWin = "6:00"; 
				}
			
				if(Race2Stage == 5)
				{
					Race2TimeToWin = 350; 
					Race2Bet = 500; 
					Race2TimeWin = "5:50"; 
				}
			
				if(Race2Stage == 6)
				{
					Race2TimeToWin = 290; 
					Race2Bet = 1000; 
					Race2TimeWin = "4:50"; 
				}
			
				if(Race2Stage == 7)
				{
					Race2TimeToWin = 280; 
					Race2Bet = 2000; 
					Race2TimeWin = "4:40"; 
				}
			
				if(Race2Stage == 8)
				{
					Race2TimeToWin = 270; 
					Race2Bet = 3000; 
					Race2TimeWin = "4:30"; 
				}
			
				if(Race2Stage == 9)
				{
					Race2TimeToWin = 260; 
					Race2Bet = 4000; 
					Race2TimeWin = "4:20"; 
				}
			
				if(Race2Stage == 10)
				{
					Race2TimeToWin = 250; 
					Race2Bet = 5000; 
					Race2TimeWin = "4:10"; 
				}
			}
			bool flag1 = GUI.Button(new Rect(175f, 525f, 175f, 175f), "START");
			if (flag1)
			{
				if(!Race2Actived)
				{
					if(Race2Stage <= Race2StageMax + 1)
					{
						var money = FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value;
						if(money >= Race2Bet)
						{
							FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = money - Race2Bet;
							Race2Actived = true;
							Race2GUI = false;
							FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
							new Thread(RaceActived).Start();
						}
					}
				}
			}
			bool flag2 = GUI.Button(new Rect(350f, 525f, 175f, 175f), "EXIT");
			if (flag2)
			{
				Race2GUI = false;
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
			}
			bool flag3 = GUI.Button(new Rect(525f, 525f, 175f, 175f), ">>>>");
			if (flag3)
			{
				if(Race2Stage == 10)
				{
					Race2Stage = 1;
				}
				else
				{
					Race2Stage = Race2Stage + 1;
				}
				
				if(Race2Stage == 1)
				{
					Race2TimeToWin = 390; 
					Race2Bet = 100; 
					Race2TimeWin = "6:30"; 
				}
			
				if(Race2Stage == 2)
				{
					Race2TimeToWin = 380; 
					Race2Bet = 200; 
					Race2TimeWin = "6:20"; 
				}
			
				if(Race2Stage == 3)
				{
					Race2TimeToWin = 370; 
					Race2Bet = 300; 
					Race2TimeWin = "6:10"; 
				}
			
				if(Race2Stage == 4)
				{
					Race2TimeToWin = 360; 
					Race2Bet = 400; 
					Race2TimeWin = "6:00"; 
				}
			
				if(Race2Stage == 5)
				{
					Race2TimeToWin = 350; 
					Race2Bet = 500; 
					Race2TimeWin = "5:50"; 
				}
			
				if(Race2Stage == 6)
				{
					Race2TimeToWin = 290; 
					Race2Bet = 1000; 
					Race2TimeWin = "4:50"; 
				}
			
				if(Race2Stage == 7)
				{
					Race2TimeToWin = 280; 
					Race2Bet = 2000; 
					Race2TimeWin = "4:40"; 
				}
			
				if(Race2Stage == 8)
				{
					Race2TimeToWin = 270; 
					Race2Bet = 3000; 
					Race2TimeWin = "4:30"; 
				}
			
				if(Race2Stage == 9)
				{
					Race2TimeToWin = 260; 
					Race2Bet = 4000; 
					Race2TimeWin = "4:20"; 
				}
			
				if(Race2Stage == 10)
				{
					Race2TimeToWin = 250; 
					Race2Bet = 5000; 
					Race2TimeWin = "4:10"; 
				}
			}
		}
		//Race3 GUI window
		private void WindowR3(int windowId)
		{
			GUIStyle Style1 = new GUIStyle();
            Style1.fontSize = (int)(50.0f * (float)(Screen.width) / 1000f);
            Style1.normal.textColor = Color.white;
			Style1.alignment = TextAnchor.MiddleCenter;
			GUI.Label(new Rect(0, 0, Screen.width-700f, Screen.height-700f), "Stage: " + Race3Stage, Style1);
			GUI.Label(new Rect(0, 0, Screen.width-700f, Screen.height-500f), "Bet: " + Race3Bet + "mk", Style1);
			GUI.Label(new Rect(0, 0, Screen.width-700f, Screen.height-300f), "Time: " + Race3TimeWin, Style1);
			
			GUIStyle Style2 = new GUIStyle();
            Style2.fontSize = (int)(50.0f * (float)(Screen.width) / 1000f);
            Style2.normal.textColor = Color.red;
			Style2.alignment = TextAnchor.MiddleCenter;
			
			if(Race3Stage > Race3StageMax + 1)
			{
				GUI.Label(new Rect(0, 0, Screen.width-700f, Screen.height-100f), "LOCKED", Style2);
			}
			
			bool flag0 = GUI.Button(new Rect(0f, 525f, 175f, 175f), "<<<<");
			if (flag0)
			{
				if(Race3Stage > 1)
				{
					Race3Stage = Race3Stage - 1;
				}
				else
				{
					Race3Stage = 10;
				}
				
				if(Race3Stage == 1)
				{
					Race3TimeToWin = 340; 
					Race3Bet = 100; 
					Race3TimeWin = "5:40";
				}
			
				if(Race3Stage == 2)
				{
					Race3TimeToWin = 330;
					Race3Bet = 200;
					Race3TimeWin = "5:30";
				}
			
				if(Race3Stage == 3)
				{
					Race3TimeToWin = 320; 
					Race3Bet = 300; 
					Race3TimeWin = "5:20"; 
				}
			
				if(Race3Stage == 4)
				{ 
					Race3TimeToWin = 310; 
					Race3Bet = 400; 
					Race3TimeWin = "5:10";  
				}
			
				if(Race3Stage == 5)
				{
					Race3TimeToWin = 300; 
					Race3Bet = 500; 
					Race3TimeWin = "5:00";  
				}
			
				if(Race3Stage == 6)
				{
					Race3TimeToWin = 280; 
					Race3Bet = 1000; 
					Race3TimeWin = "4:40";  
				}
			
				if(Race3Stage == 7)
				{
					Race3TimeToWin = 270; 
					Race3Bet = 2000; 
					Race3TimeWin = "4:30"; 
				}
			
				if(Race3Stage == 8)
				{
					Race3TimeToWin = 260; 
					Race3Bet = 3000; 
					Race3TimeWin = "4:20";  
				}
			
				if(Race3Stage == 9)
				{
					Race3TimeToWin = 250; 
					Race3Bet = 4000; 
					Race3TimeWin = "4:10";  
				}
			
				if(Race3Stage == 10)
				{
					Race3TimeToWin = 240; 
					Race3Bet = 5000; 
					Race3TimeWin = "4:00"; 
				}
			}
			bool flag1 = GUI.Button(new Rect(175f, 525f, 175f, 175f), "START");
			if (flag1)
			{
				if(!Race3Actived)
				{
					if(Race3Stage <= Race3StageMax + 1)
					{
						var money = FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value;
						if(money >= Race3Bet)
						{
							FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = money - Race3Bet;
							Race3Actived = true;
							Race3GUI = false;
							FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
							new Thread(RaceActived).Start();
						}
					}
				}
			}
			bool flag2 = GUI.Button(new Rect(350f, 525f, 175f, 175f), "EXIT");
			if (flag2)
			{
				Race3GUI = false;
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
			}
			bool flag3 = GUI.Button(new Rect(525f, 525f, 175f, 175f), ">>>>");
			if (flag3)
			{
				if(Race3Stage == 10)
				{
					Race3Stage = 1;
				}
				else
				{
					Race3Stage = Race3Stage + 1;
				}
				
				if(Race3Stage == 1)
				{
					Race3TimeToWin = 340; 
					Race3Bet = 100; 
					Race3TimeWin = "5:40";
				}
			
				if(Race3Stage == 2)
				{
					Race3TimeToWin = 330;
					Race3Bet = 200;
					Race3TimeWin = "5:30";
				}
			
				if(Race3Stage == 3)
				{
					Race3TimeToWin = 320; 
					Race3Bet = 300; 
					Race3TimeWin = "5:20"; 
				}
			
				if(Race3Stage == 4)
				{ 
					Race3TimeToWin = 310; 
					Race3Bet = 400; 
					Race3TimeWin = "5:10";  
				}
			
				if(Race3Stage == 5)
				{
					Race3TimeToWin = 300; 
					Race3Bet = 500; 
					Race3TimeWin = "5:00";  
				}
			
				if(Race3Stage == 6)
				{
					Race3TimeToWin = 280; 
					Race3Bet = 1000; 
					Race3TimeWin = "4:40";  
				}
			
				if(Race3Stage == 7)
				{
					Race3TimeToWin = 270; 
					Race3Bet = 2000; 
					Race3TimeWin = "4:30"; 
				}
			
				if(Race3Stage == 8)
				{
					Race3TimeToWin = 260; 
					Race3Bet = 3000; 
					Race3TimeWin = "4:20";  
				}
			
				if(Race3Stage == 9)
				{
					Race3TimeToWin = 250; 
					Race3Bet = 4000; 
					Race3TimeWin = "4:10";  
				}
			
				if(Race3Stage == 10)
				{
					Race3TimeToWin = 240; 
					Race3Bet = 5000; 
					Race3TimeWin = "4:00"; 
				}
			}
		}
		
		private void CreateTriggers1()
        {
            //Race 1 Trigger 1
			GameObject Race1Trigger1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Race1Trigger1.name = "Race1Trigger1";
            Race1Trigger1.transform.localScale = new Vector3(20f, 20f, 20f);
            Race1Trigger1.transform.position = new Vector3(-1509.8449707031f, 3.1741199493f, 1188.2073974609f);
            var Race1col1 = Race1Trigger1.GetComponent<Collider>();
            Race1col1.isTrigger = true;
			Race1col1.gameObject.AddComponent<R1Trigger1>().race1trig1 = this;
			Race1Trigger1.GetComponent<MeshRenderer>().enabled = false;
			//Race 1 Trigger 2
			GameObject Race1Trigger2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Race1Trigger2.name = "Race1Trigger2";
            Race1Trigger2.transform.localScale = new Vector3(20f, 20f, 20f);
            Race1Trigger2.transform.position = new Vector3(1605.1303710938f, 9.2821874619f, 984.6170654297f);
            var Race1col2 = Race1Trigger2.GetComponent<Collider>();
            Race1col2.isTrigger = true;
			Race1col2.gameObject.AddComponent<R1Trigger2>().race1trig2 = this;
            Race1Trigger2.GetComponent<MeshRenderer>().enabled = false;
			//Race 1 Trigger 3
			GameObject Race1Trigger3 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Race1Trigger3.name = "Race1Trigger3";
            Race1Trigger3.transform.localScale = new Vector3(20f, 20f, 20f);
            Race1Trigger3.transform.position = new Vector3(-1581.7672119141f, 2.864782095f, 1144.2366943359f);
            var Race1col3 = Race1Trigger3.GetComponent<Collider>();
            Race1col3.isTrigger = true;
			Race1col3.gameObject.AddComponent<R1Trigger3>().race1trig3 = this;
            Race1Trigger3.GetComponent<MeshRenderer>().enabled = false;
			
			Race1Actived2 = true;
        }
		
		private void CreateTriggers2()
        {
            //Race 2 Trigger 1
			GameObject Race2Trigger1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Race2Trigger1.name = "Race2Trigger1";
            Race2Trigger1.transform.localScale = new Vector3(20f, 20f, 20f);
            Race2Trigger1.transform.position = new Vector3(-1581.7672119141f, 2.864782095f, 1144.2366943359f);
            var Race2col1 = Race2Trigger1.GetComponent<Collider>();
            Race2col1.isTrigger = true;
			Race2col1.gameObject.AddComponent<R2Trigger1>().race2trig1 = this;
			Race2Trigger1.GetComponent<MeshRenderer>().enabled = false;
			//Race 2 Trigger 2
			GameObject Race2Trigger2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Race2Trigger2.name = "Race2Trigger2";
            Race2Trigger2.transform.localScale = new Vector3(20f, 20f, 20f);
            Race2Trigger2.transform.position = new Vector3(2132.8764648438f, 1.8155575991f, -966.9815063477f);
            var Race2col2 = Race2Trigger2.GetComponent<Collider>();
            Race2col2.isTrigger = true;
			Race2col2.gameObject.AddComponent<R2Trigger2>().race2trig2 = this;
            Race2Trigger2.GetComponent<MeshRenderer>().enabled = false;
			
			Race2Actived2 = true;
        }
		
		private void CreateTriggers3()
        {
            //Race 3 Trigger 1
			GameObject Race3Trigger1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Race3Trigger1.name = "Race3Trigger1";
            Race3Trigger1.transform.localScale = new Vector3(20f, 20f, 20f);
            Race3Trigger1.transform.position = new Vector3(-1510.5014648438f, 3.4748113155f, 1167.0892333984f);
            var Race3col1 = Race3Trigger1.GetComponent<Collider>();
            Race3col1.isTrigger = true;
			Race3col1.gameObject.AddComponent<R3Trigger1>().race3trig1 = this;
			Race3Trigger1.GetComponent<MeshRenderer>().enabled = false;
			//Race 3 Trigger 2
			GameObject Race3Trigger2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Race3Trigger2.name = "Race3Trigger2";
            Race3Trigger2.transform.localScale = new Vector3(20f, 20f, 20f);
            Race3Trigger2.transform.position = new Vector3(-1498.4312744141f, 7.0586900711f, 1483.2193603516f);
            var Race3col2 = Race3Trigger2.GetComponent<Collider>();
            Race3col2.isTrigger = true;
			Race3col2.gameObject.AddComponent<R3Trigger2>().race3trig2 = this;
            Race3Trigger2.GetComponent<MeshRenderer>().enabled = false;
			
			Race3Actived2 = true;
        }
		
		private void CreateChecker()
        {
			GameObject SATSUMACHECKER = GameObject.CreatePrimitive(PrimitiveType.Cube);
            SATSUMACHECKER.name = "SATSUMACHECKER";
			SATSUMACHECKER.transform.parent = GameObject.Find("SATSUMA(557kg, 248)").transform;
            SATSUMACHECKER.transform.localScale = new Vector3(0.001f, 0.001f, 0.001f);
			SATSUMACHECKER.transform.localPosition = new Vector3(0f, 0.83f, -0.397f);
			SATSUMACHECKER.transform.localEulerAngles= new Vector3(0, 0, 0);
            SATSUMACHECKER.GetComponent<MeshRenderer>().enabled = false;
			
			SatsumaChecker = true;
        }
		
		public void Race1Trig1()
        {
			if(Race1Actived & !Race1Started)
			{
				Race1Started = true;
				new Thread(RaceStarted).Start();
			}
        }
		
		public void Race1Trig2()
        {
			if(Race1Actived)
			{
				Race1Checkpoint = true;
			}
        }
		
		public void Race1Trig3()
        {
			if(Race1Actived)
			{
				if(Race1Checkpoint)
				{
					var money = FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value;
					FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = money + Race1Bet*2;
					
					Race1Started = false;
					Race1Checkpoint = false;
					Race1Actived = false;
					Race1Time = 0;
					new Thread(RaceWon).Start();
					
					if(Race1Stage == 1 & Race1Stage > Race1StageMax)
					{
						Race1StageMax = 1;
						WriteR1S1();
					}
					
					if(Race1Stage == 2 & Race1Stage > Race1StageMax)
					{
						Race1StageMax = 2;
						WriteR1S2();
					}
					
					if(Race1Stage == 3 & Race1Stage > Race1StageMax)
					{
						Race1StageMax = 3;
						WriteR1S3();
					}
					
					if(Race1Stage == 4 & Race1Stage > Race1StageMax)
					{
						Race1StageMax = 4;
						WriteR1S4();
					}
					
					if(Race1Stage == 5 & Race1Stage > Race1StageMax)
					{
						Race1StageMax = 5;
						WriteR1S5();
					}
					
					if(Race1Stage == 6 & Race1Stage > Race1StageMax)
					{
						Race1StageMax = 6;
						WriteR1S6();
					}
					
					if(Race1Stage == 7 & Race1Stage > Race1StageMax)
					{
						Race1StageMax = 7;
						WriteR1S7();
					}
					
					if(Race1Stage == 8 & Race1Stage > Race1StageMax)
					{
						Race1StageMax = 8;
						WriteR1S8();
					}
					
					if(Race1Stage == 9 & Race1Stage > Race1StageMax)
					{
						Race1StageMax = 9;
						WriteR1S9();
					}					
				}
			}
        }
		
		public void Race2Trig1()
        {
			if(Race2Actived)
			{
				if(!Race2Started)
				{
					Race2Started = true;
					new Thread(RaceStarted).Start();
				}
				else
				{
					if(Race2Checkpoint)
					{
						var money = FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value;
						FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = money + Race2Bet*2;
					
						Race2Started = false;
						Race2Checkpoint = false;
						Race2Actived = false;
						Race2Time = 0;
						new Thread(RaceWon).Start();
						
						if(Race2Stage == 1 & Race2Stage > Race2StageMax)
						{
							Race2StageMax = 1;
							WriteR2S1();
						}
					
						if(Race2Stage == 2 & Race2Stage > Race2StageMax)
						{
							Race2StageMax = 2;
							WriteR2S2();
						}
					
						if(Race2Stage == 3 & Race2Stage > Race2StageMax)
						{
							Race2StageMax = 3;
							WriteR2S3();
						}
					
						if(Race2Stage == 4 & Race2Stage > Race2StageMax)
						{
							Race2StageMax = 4;
							WriteR2S4();
						}
					
						if(Race2Stage == 5 & Race2Stage > Race2StageMax)
						{
							Race2StageMax = 5;
							WriteR2S5();
						}
					
						if(Race2Stage == 6 & Race2Stage > Race2StageMax)
						{
							Race2StageMax = 6;
							WriteR2S6();
						}
					
						if(Race2Stage == 7 & Race2Stage > Race2StageMax)
						{
							Race2StageMax = 7;
							WriteR2S7();
						}
					
						if(Race2Stage == 8 & Race2Stage > Race2StageMax)
						{
							Race2StageMax = 8;
							WriteR2S8();
						}
					
						if(Race2Stage == 9 & Race2Stage > Race2StageMax)
						{
							Race2StageMax = 9;
							WriteR2S9();
						}					
					}
				}
			}
        }
		
		public void Race2Trig2()
        {
			if(Race2Actived)
			{
				Race2Checkpoint = true;
			}
        }
		
		public void Race3Trig1()
        {
			if(Race3Actived)
			{
				if(!Race3Started)
				{
					Race3Started = true;
					new Thread(RaceStarted).Start();
				}
				else
				{
					if(Race3PreLap == 1)
					{
						Race3Lap = 1;
					}
					
					if(Race3PreLap == 2)
					{
						Race3Lap = 2;
					}
					
					if(Race3PreLap == 3)
					{
						Race3Lap = 3;
					}
					
					if(Race3PreLap == 4)
					{
						Race3Lap = 4;
					}
					
					if(Race3PreLap == 5)
					{
						Race3Lap = 5;
					}
					
					if(Race3Lap == 5)
					{
						var money = FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value;
						FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = money + Race3Bet*2;
					
						Race3Started = false;
						Race3Actived = false;
						Race3Time = 0;
						Race3PreLap = 0;
						Race3Lap = 0;
						new Thread(RaceWon).Start();
						
						if(Race3Stage == 1 & Race3Stage > Race3StageMax)
						{
							Race3StageMax = 1;
							WriteR3S1();
						}
					
						if(Race3Stage == 2 & Race3Stage > Race3StageMax)
						{
							Race3StageMax = 2;
							WriteR3S2();
						}
					
						if(Race3Stage == 3 & Race3Stage > Race3StageMax)
						{
							Race3StageMax = 3;
							WriteR3S3();
						}
					
						if(Race3Stage == 4 & Race3Stage > Race3StageMax)
						{
							Race3StageMax = 4;
							WriteR3S4();
						}
					
						if(Race3Stage == 5 & Race3Stage > Race3StageMax)
						{
							Race3StageMax = 5;
							WriteR3S5();
						}
					
						if(Race3Stage == 6 & Race3Stage > Race3StageMax)
						{
							Race3StageMax = 6;
							WriteR3S6();
						}
					
						if(Race3Stage == 7 & Race3Stage > Race3StageMax)
						{
							Race3StageMax = 7;
							WriteR3S7();
						}
					
						if(Race3Stage == 8 & Race3Stage > Race3StageMax)
						{
							Race3StageMax = 8;
							WriteR3S8();
						}
					
						if(Race3Stage == 9 & Race3Stage > Race3StageMax)
						{
							Race3StageMax = 9;
							WriteR3S9();
						}					
					}
				}
			}
        }
		
		public void Race3Trig2()
        {
			if(Race3Actived)
			{
				if(Race3Lap == 0)
				{
					Race3PreLap = 1;
				}
				
				if(Race3Lap == 1)
				{
					Race3PreLap = 2;
				}
				
				if(Race3Lap == 2)
				{
					Race3PreLap = 3;
				}
				
				if(Race3Lap == 3)
				{
					Race3PreLap = 4;
				}
				
				if(Race3Lap == 4)
				{
					Race3PreLap = 5;
				}
			}
        }
		
		private void RaceActived()
		{			
			RaceActivedGUI = true;
			Thread.Sleep( 5 * 1000 );
			RaceActivedGUI = false;
		}
				
		private void RaceStarted()
		{
			RaceStartedGUI = true;
			Thread.Sleep( 5 * 1000 );
			RaceStartedGUI = false;
		}
		
		private void RaceLose()
		{
			RaceLoseGUI = true;
			Thread.Sleep( 5 * 1000 );
			RaceLoseGUI = false;
		}
		
		private void RaceWon()
		{
			RaceWonGUI = true;
			Thread.Sleep( 5 * 1000 );
			RaceWonGUI = false;
		}
		
		private void Write0()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = 0;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = 0;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = 0;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR1S1()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = 1;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR1S2()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = 2;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR1S3()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = 3;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR1S4()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = 4;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR1S5()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = 5;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR1S6()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = 6;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR1S7()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = 7;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR1S8()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = 8;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR1S9()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = 9;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR2S1()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = 1;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR2S2()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = 2;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR2S3()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = 3;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR2S4()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = 4;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR2S5()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = 5;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR2S6()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = 6;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR2S7()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = 7;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR2S8()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = 8;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR2S9()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = 9;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = Race3StageMax;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR3S1()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = 1;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR3S2()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = 2;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR3S3()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = 3;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR3S4()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = 4;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR3S5()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = 5;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR3S6()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = 6;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR3S7()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = 7;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR3S8()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = 8;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void WriteR3S9()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = Race1StageMax;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = Race2StageMax;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = 9;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/save.txt", array);
		}
		
		private void LoadSave()
		{
			string[] array = new string[3];
			
			array = File.ReadAllLines(path + "/save.txt");
				
			Race1StageMax = float.Parse(array[0]);
			Race2StageMax = float.Parse(array[1]);
			Race3StageMax = float.Parse(array[2]);
		}
    }
}
