﻿using UnityEngine;

namespace IllegalTimeAttack
{
    public class R3Trigger2 : MonoBehaviour
    {
		public IllegalTimeAttack race3trig2;
		
        private void OnTriggerEnter(Collider col)
        {
            if (col.name == "SATSUMACHECKER")
            {
				race3trig2.Race3Trig2();
            }
        }
    }
}
