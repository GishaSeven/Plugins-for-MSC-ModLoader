﻿using UnityEngine;

namespace IllegalTimeAttack
{
    public class R2Trigger1 : MonoBehaviour
    {
		public IllegalTimeAttack race2trig1;
		
        private void OnTriggerEnter(Collider col)
        {
            if (col.name == "SATSUMACHECKER")
            {
				race2trig1.Race2Trig1();
            }
        }
    }
}
