﻿using UnityEngine;

namespace IllegalTimeAttack
{
    public class R1Trigger2 : MonoBehaviour
    {
		public IllegalTimeAttack race1trig2;
		
        private void OnTriggerEnter(Collider col)
        {
            if (col.name == "SATSUMACHECKER")
            {
				race1trig2.Race1Trig2();
            }
        }
    }
}
