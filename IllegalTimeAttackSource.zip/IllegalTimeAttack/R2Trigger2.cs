﻿using UnityEngine;

namespace IllegalTimeAttack
{
    public class R2Trigger2 : MonoBehaviour
    {
		public IllegalTimeAttack race2trig2;
		
        private void OnTriggerEnter(Collider col)
        {
            if (col.name == "SATSUMACHECKER")
            {
				race2trig2.Race2Trig2();
            }
        }
    }
}
