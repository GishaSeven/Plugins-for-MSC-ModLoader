﻿using UnityEngine;

namespace IllegalTimeAttack
{
    public class R1Trigger3 : MonoBehaviour
    {
		public IllegalTimeAttack race1trig3;
		
        private void OnTriggerEnter(Collider col)
        {
            if (col.name == "SATSUMACHECKER")
            {
				race1trig3.Race1Trig3();
            }
        }
    }
}
