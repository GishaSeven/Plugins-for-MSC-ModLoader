﻿using UnityEngine;

namespace IllegalTimeAttack
{
    public class R1Trigger1 : MonoBehaviour
    {
		public IllegalTimeAttack race1trig1;
		
        private void OnTriggerEnter(Collider col)
        {
            if (col.name == "SATSUMACHECKER")
            {
				race1trig1.Race1Trig1();
            }
        }
    }
}
