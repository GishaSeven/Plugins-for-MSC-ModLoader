﻿using UnityEngine;

namespace IllegalTimeAttack
{
    public class R3Trigger1 : MonoBehaviour
    {
		public IllegalTimeAttack race3trig1;
		
        private void OnTriggerEnter(Collider col)
        {
            if (col.name == "SATSUMACHECKER")
            {
				race3trig1.Race3Trig1();
            }
        }
    }
}
