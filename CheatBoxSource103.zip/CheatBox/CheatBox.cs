﻿using HutongGames.PlayMaker;
using MSCLoader;
using UnityEngine;

namespace CheatBox
{
    public class CheatBox : Mod
    {
        public override string ID { get { return "CheatBox"; } }
        public override string Name { get { return "CheatBox"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.3"; } }

        private Keybind CheatsGuiKey = new Keybind("ShowCheatGUI", "Show Cheat GUI", KeyCode.C, KeyCode.LeftControl);
		private Keybind teleport1Key = new Keybind("teleport1Key", "Teleport 1", KeyCode.Alpha1, KeyCode.LeftControl);
		private Keybind teleport2Key = new Keybind("teleport2Key", "Teleport 2", KeyCode.Alpha2, KeyCode.LeftControl);
		private Keybind teleport3Key = new Keybind("teleport3Key", "Teleport 3", KeyCode.Alpha3, KeyCode.LeftControl);
		private Keybind teleport4Key = new Keybind("teleport4Key", "Teleport 4", KeyCode.Alpha4, KeyCode.LeftControl);
		private Keybind teleport5Key = new Keybind("teleport5Key", "Teleport 5", KeyCode.Alpha5, KeyCode.LeftControl);
		private Keybind teleport6Key = new Keybind("teleport6Key", "Teleport 6", KeyCode.Alpha6, KeyCode.LeftControl);
		private Keybind teleport7Key = new Keybind("teleport7Key", "Teleport 7", KeyCode.Alpha7, KeyCode.LeftControl);
		private Keybind teleport8Key = new Keybind("teleport8Key", "Teleport 8", KeyCode.Alpha8, KeyCode.LeftControl);
		private Keybind teleport9Key = new Keybind("teleport9Key", "Teleport 9", KeyCode.Alpha9, KeyCode.LeftControl);
		private Keybind teleport10Key = new Keybind("teleport10Key", "Teleport 10", KeyCode.Alpha0, KeyCode.LeftControl);
		private Keybind teleport11Key = new Keybind("teleport11Key", "Teleport 11", KeyCode.Alpha0, KeyCode.RightControl);
		private Rect guiBox = new Rect((Screen.width-1090)/2, 10f, 1090f, 700f);
		private bool guiShow;
		private bool needs;
		
        public override void OnLoad()
        {
			Keybind.Add(this, CheatsGuiKey);
			Keybind.Add(this, teleport1Key);
			Keybind.Add(this, teleport2Key);
			Keybind.Add(this, teleport3Key);
			Keybind.Add(this, teleport4Key);
			Keybind.Add(this, teleport5Key);
			Keybind.Add(this, teleport6Key);
			Keybind.Add(this, teleport7Key);
			Keybind.Add(this, teleport8Key);
			Keybind.Add(this, teleport9Key);
			Keybind.Add(this, teleport10Key);
			Keybind.Add(this, teleport11Key);
        }
		
		public override void OnGUI()
		{
			bool guiShow = this.guiShow;
			if (guiShow)
			{
				GUI.ModalWindow(1, this.guiBox, new GUI.WindowFunction(this.Window), "CheatBox");
			}
		}
		
		private void Window(int windowId)
		{
			bool flag0 = GUI.Button(new Rect(980f, 650f, 60f, 30f), "Close");
			if (flag0)
			{
				this.guiShow = false;
			}
			GUI.Label(new Rect(117f, 25f, 120f, 30f), "Teleports");
			bool flag1 = GUI.Button(new Rect(85f, 50f, 120f, 30f), "Me to home");
			if (flag1)
			{
				TpTo("PLAYER", "GraveYardSpawn");
			}
			GUI.Label(new Rect(15f, 55f, 120f, 30f), "L.CTRL + 1");
			bool flag2 = GUI.Button(new Rect(85f, 85f, 120f, 30f), "Me to store");
			if (flag2)
			{
				TpTo("PLAYER", "SpawnToStore");
			}
			GUI.Label(new Rect(15f, 90f, 120f, 30f), "L.CTRL + 2");
			bool flag3 = GUI.Button(new Rect(85f, 120f, 120f, 30f), "Me to repair shop");
			if (flag3)
			{
				TpTo("PLAYER", "SpawnToRepair");
			}
			GUI.Label(new Rect(15f, 125f, 120f, 30f), "L.CTRL + 3");
			bool flag4 = GUI.Button(new Rect(85f, 155f, 120f, 30f), "Me to drag");
			if (flag4)
			{
				TpTo("PLAYER", "SpawnToDrag");
			}
			GUI.Label(new Rect(15f, 160f, 120f, 30f), "L.CTRL + 4");
			bool flag5 = GUI.Button(new Rect(85f, 190f, 120f, 30f), "Me to cottage");
			if (flag5)
			{
				TpTo("PLAYER", "SpawnToCottage");
			}
			GUI.Label(new Rect(15f, 195f, 120f, 30f), "L.CTRL + 5");
			bool flag6 = GUI.Button(new Rect(85f, 225f, 120f, 30f), "Me to Satsuma");
			if (flag6)
			{
				TpTo("PLAYER", "SATSUMA(557kg)");
			}
			GUI.Label(new Rect(15f, 230f, 120f, 30f), "L.CTRL + 6");
			bool flag7 = GUI.Button(new Rect(85f, 260f, 120f, 30f), "Satsuma to me");
			if (flag7)
			{
				TpMe("SATSUMA(557kg)", "PLAYER");
			}
			bool flag8 = GUI.Button(new Rect(85f, 295f, 120f, 30f), "Me to muscle car");
			if (flag8)
			{
				TpTo("PLAYER", "FERNDALE(1630kg)");
			}
			GUI.Label(new Rect(15f, 300f, 120f, 30f), "L.CTRL + 7");
			bool flag9 = GUI.Button(new Rect(85f, 330f, 120f, 30f), "Muscle car to me");
			if (flag9)
			{
				TpMe("FERNDALE(1630kg)", "PLAYER");
			}
			bool flag10 = GUI.Button(new Rect(85f, 365f, 120f, 30f), "Me to truck");
			if (flag10)
			{
				TpTo("PLAYER", "GIFU(750/450psi)");
			}
			GUI.Label(new Rect(15f, 370f, 120f, 30f), "L.CTRL + 8");
			bool flag11 = GUI.Button(new Rect(85f, 400f, 120f, 30f), "Truck to me");
			if (flag11)
			{
				TpMe("GIFU(750/450psi)", "PLAYER");
			}
			bool flag12 = GUI.Button(new Rect(85f, 435f, 120f, 30f), "Me to tractor");
			if (flag12)
			{
				TpTo("PLAYER", "KEKMET(350-400psi)");
			}
			GUI.Label(new Rect(15f, 440f, 120f, 30f), "L.CTRL + 9");
			bool flag13 = GUI.Button(new Rect(85f, 470f, 120f, 30f), "Tractor to me");
			if (flag13)
			{
				TpTo("KEKMET(350-400psi)", "PLAYER");
			}
			bool flag14 = GUI.Button(new Rect(85f, 505f, 120f, 30f), "Me to van");
			if (flag14)
			{
				TpTo("PLAYER", "HAYOSIKO(1500kg)");
			}
			GUI.Label(new Rect(15f, 510f, 120f, 30f), "L.CTRL + 0");
			bool flag15 = GUI.Button(new Rect(85f, 540f, 120f, 30f), "Van to me");
			if (flag15)
			{
				TpTo("HAYOSIKO(1500kg)", "PLAYER");
			}
			bool flag16 = GUI.Button(new Rect(85f, 575f, 120f, 30f), "Me to moped");
			if (flag16)
			{
				TpTo("PLAYER", "JONNEZ ES(Clone)");
			}
			GUI.Label(new Rect(15f, 580f, 120f, 30f), "R.CTRL + 0");
			bool flag17 = GUI.Button(new Rect(85f, 610f, 120f, 30f), "Moped to me");
			if (flag17)
			{
				TpTo("JONNEZ ES(Clone)", "PLAYER");
			}
			GUI.Label(new Rect(250f, 25f, 120f, 30f), "Needs");
			bool flag18 = GUI.Button(new Rect(210f, 50f, 120f, 30f), "off/on needs");
			if (flag18)
			{
				this.needs = !this.needs;
			}
			bool flag19 = GUI.Button(new Rect(210f, 85f, 120f, 30f), "Set full fatigue");
			if (flag19)
			{
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value = 100f;
			}
			GUI.Label(new Rect(250f, 130f, 120f, 30f), "Money");
			bool flag20 = GUI.Button(new Rect(210f, 155f, 120f, 30f), "Set 3 000mk");
			if (flag20)
			{
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = 3000;
			}
			bool flag21 = GUI.Button(new Rect(210f, 190f, 120f, 30f), "Set 50 000mk");
			if (flag21)
			{
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = 50000;
			}
			bool flag22 = GUI.Button(new Rect(210f, 225f, 120f, 30f), "Set 500 000mk");
			if (flag22)
			{
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = 500000;
			}
			GUI.Label(new Rect(232f, 270f, 120f, 30f), "Day of week");
			bool flag23 = GUI.Button(new Rect(210f, 295f, 120f, 30f), "Monday");
			if (flag23)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 1;
			}
			bool flag24 = GUI.Button(new Rect(210f, 330f, 120f, 30f), "Tuesday");
			if (flag24)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 2;
			}
			bool flag25 = GUI.Button(new Rect(210f, 365f, 120f, 30f), "Wednesday");
			if (flag25)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 3;
			}
			bool flag26 = GUI.Button(new Rect(210f, 400f, 120f, 30f), "Thursday");
			if (flag26)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 4;
			}
			bool flag27 = GUI.Button(new Rect(210f, 435f, 120f, 30f), "Friday");
			if (flag27)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 5;
			}
			bool flag28 = GUI.Button(new Rect(210f, 470f, 120f, 30f), "Saturday");
			if (flag28)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 6;
			}
			bool flag29 = GUI.Button(new Rect(210f, 505f, 120f, 30f), "Sunday");
			if (flag29)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 7;
			}
			GUI.Label(new Rect(350f, 25f, 120f, 30f), "Teleports to me");
			bool flag30 = GUI.Button(new Rect(335f, 50f, 120f, 30f), "Spanner set");
			if (flag30)
			{
				TpMe("spanner set(itemx)", "PLAYER");
			}
			bool flag31 = GUI.Button(new Rect(335f, 85f, 120f, 30f), "Diesel jerrycan");
			if (flag31)
			{
				TpMe("diesel(itemx)", "PLAYER");
			}
			bool flag32 = GUI.Button(new Rect(335f, 120f, 120f, 30f), "Gasoline jerrycan");
			if (flag32)
			{
				TpMe("gasoline(itemx)", "PLAYER");
			}
			bool flag33 = GUI.Button(new Rect(335f, 155f, 120f, 30f), "Fuel tank");
			if (flag33)
			{
				TpMe("fuel tank(Clone)", "PLAYER");
			}
			bool flag34 = GUI.Button(new Rect(335f, 190f, 120f, 30f), "Muffler stock");
			if (flag34)
			{
				TpMe("exhaust muffler(Clone)", "PLAYER");
			}
			bool flag35 = GUI.Button(new Rect(335f, 225f, 120f, 30f), "Pipe stock");
			if (flag35)
			{
				TpMe("exhaust pipe(Clone)", "PLAYER");
			}
			bool flag36 = GUI.Button(new Rect(335f, 260f, 120f, 30f), "Muffler racing");
			if (flag36)
			{
				TpMe("racing muffler(Clone)", "PLAYER");
			}
			bool flag37 = GUI.Button(new Rect(335f, 295f, 120f, 30f), "Pipe racing");
			if (flag37)
			{
				TpMe("racing exhaust(Clone)", "PLAYER");
			}
			bool flag38 = GUI.Button(new Rect(335f, 330f, 120f, 30f), "Front bumper");
			if (flag38)
			{
				TpMe("bumper front(Clone)", "PLAYER");
			}
			bool flag39 = GUI.Button(new Rect(335f, 365f, 120f, 30f), "Rear bumper");
			if (flag39)
			{
				TpMe("bumper rear(Clone)", "PLAYER");
			}
			bool flag40 = GUI.Button(new Rect(335f, 400f, 120f, 30f), "Fender left");
			if (flag40)
			{
				TpMe("fender left(Clone)", "PLAYER");
			}
			bool flag41 = GUI.Button(new Rect(335f, 435f, 120f, 30f), "Fender right");
			if (flag41)
			{
				TpMe("fender right(Clone)", "PLAYER");
			}
			bool flag42 = GUI.Button(new Rect(335f, 470f, 120f, 30f), "Door left");
			if (flag42)
			{
				TpMe("door left(Clone)", "PLAYER");
			}
			bool flag43 = GUI.Button(new Rect(335f, 505f, 120f, 30f), "Door right");
			if (flag43)
			{
				TpMe("door right(Clone)", "PLAYER");
			}
			bool flag44 = GUI.Button(new Rect(335f, 540f, 120f, 30f), "Bootlid");
			if (flag44)
			{
				TpMe("bootlid(Clone)", "PLAYER");
			}
			bool flag45 = GUI.Button(new Rect(335f, 575f, 120f, 30f), "Hood");
			if (flag45)
			{
				TpMe("hood(Clone)", "PLAYER");
			}
			bool flag46 = GUI.Button(new Rect(335f, 610f, 120f, 30f), "Fiberglass hood");
			if (flag46)
			{
				TpMe("fiberglass hood(Clone)", "PLAYER");
			}
			bool flag47 = GUI.Button(new Rect(460f, 50f, 120f, 30f), "Wishbone FL");
			if (flag47)
			{
				TpMe("wishbone fl(Clone)", "PLAYER");
			}
			bool flag48 = GUI.Button(new Rect(460f, 85f, 120f, 30f), "Spindle FL");
			if (flag48)
			{
				TpMe("spindle fl(Clone)", "PLAYER");
			}
			bool flag49 = GUI.Button(new Rect(460f, 120f, 120f, 30f), "Strut FL");
			if (flag49)
			{
				TpMe("strut fl(Clone)", "PLAYER");
			}
			bool flag50 = GUI.Button(new Rect(460f, 155f, 120f, 30f), "Disc brake");
			if (flag50)
			{
				TpMe("disc brake(Clone)", "PLAYER");
			}
			bool flag51 = GUI.Button(new Rect(460f, 190f, 120f, 30f), "Wishbone FR");
			if (flag51)
			{
				TpMe("wishbone fr(Clone)", "PLAYER");
			}
			bool flag52 = GUI.Button(new Rect(460f, 225f, 120f, 30f), "Spindle FR");
			if (flag52)
			{
				TpMe("spindle fr(Clone)", "PLAYER");
			}
			bool flag53 = GUI.Button(new Rect(460f, 260f, 120f, 30f), "Strut FR");
			if (flag53)
			{
				TpMe("strut fr(Clone)", "PLAYER");
			}
			bool flag54 = GUI.Button(new Rect(460f, 295f, 120f, 30f), "Trail arm RL");
			if (flag54)
			{
				TpMe("trail arm rl(Clone)", "PLAYER");
			}
			bool flag55 = GUI.Button(new Rect(460f, 330f, 120f, 30f), "Coil spring");
			if (flag55)
			{
				TpMe("coil spring(Clone)", "PLAYER");
			}
			bool flag56 = GUI.Button(new Rect(460f, 365f, 120f, 30f), "Long coil spring");
			if (flag56)
			{
				TpMe("long coil spring(Clone)", "PLAYER");
			}
			bool flag57 = GUI.Button(new Rect(460f, 400f, 120f, 30f), "Shock absorber");
			if (flag57)
			{
				TpMe("shock absorber(Clone)", "PLAYER");
			}
			bool flag58 = GUI.Button(new Rect(460f, 435f, 120f, 30f), "Drum brake");
			if (flag58)
			{
				TpMe("drum brake(Clone)", "PLAYER");
			}
			bool flag59 = GUI.Button(new Rect(460f, 470f, 120f, 30f), "Trail arm RR");
			if (flag59)
			{
				TpMe("trail arm rr(Clone)", "PLAYER");
			}
			bool flag60 = GUI.Button(new Rect(585f, 50f, 120f, 30f), "Steel wheel FL");
			if (flag60)
			{
				TpMe("wheel steel fl(Clone)", "PLAYER");
			}
			bool flag61 = GUI.Button(new Rect(585f, 85f, 120f, 30f), "Steel wheel FR");
			if (flag61)
			{
				TpMe("wheel steel fr(Clone)", "PLAYER");
			}
			bool flag62 = GUI.Button(new Rect(585f, 120f, 120f, 30f), "Steel wheel RL");
			if (flag62)
			{
				TpMe("wheel steel rl(Clone)", "PLAYER");
			}
			bool flag63 = GUI.Button(new Rect(585f, 155f, 120f, 30f), "Steel wheel RR");
			if (flag63)
			{
				TpMe("wheel steel rr(Clone)", "PLAYER");
			}
			bool flag64 = GUI.Button(new Rect(585f, 190f, 120f, 30f), "Rally wheel FL");
			if (flag64)
			{
				TpMe("wheel rally fl(Clone)", "PLAYER");
			}
			bool flag65 = GUI.Button(new Rect(585f, 225f, 120f, 30f), "Rally wheel FR");
			if (flag65)
			{
				TpMe("wheel rally fr(Clone)", "PLAYER");
			}
			bool flag66 = GUI.Button(new Rect(585f, 260f, 120f, 30f), "Rally wheel RL");
			if (flag66)
			{
				TpMe("wheel rally rl(Clone)", "PLAYER");
			}
			bool flag67 = GUI.Button(new Rect(585f, 295f, 120f, 30f), "Rally wheel RR");
			if (flag67)
			{
				TpMe("wheel rally rr(Clone)", "PLAYER");
			}		
			bool flag68 = GUI.Button(new Rect(585f, 330f, 120f, 30f), "Racing wheel FL");
			if (flag68)
			{
				TpMe("wheel racing fl(Clone)", "PLAYER");
			}
			bool flag69 = GUI.Button(new Rect(585f, 365f, 120f, 30f), "Racing wheel FR");
			if (flag69)
			{
				TpMe("wheel racing fr(Clone)", "PLAYER");
			}
			bool flag70 = GUI.Button(new Rect(585f, 400f, 120f, 30f), "Racing wheel RL");
			if (flag70)
			{
				TpMe("wheel racing rl(Clone)", "PLAYER");
			}
			bool flag71 = GUI.Button(new Rect(585f, 435f, 120f, 30f), "Racing wheel RR");
			if (flag71)
			{
				TpMe("wheel racing rr(Clone)", "PLAYER");
			}
			bool flag72 = GUI.Button(new Rect(585f, 470f, 120f, 30f), "Spoke wheel FL");
			if (flag72)
			{
				TpMe("wheel spoke fl(Clone)", "PLAYER");
			}
			bool flag73 = GUI.Button(new Rect(585f, 505f, 120f, 30f), "Spoke wheel FR");
			if (flag73)
			{
				TpMe("wheel spoke fr(Clone)", "PLAYER");
			}
			bool flag74 = GUI.Button(new Rect(585f, 540f, 120f, 30f), "Spoke wheel RL");
			if (flag74)
			{
				TpMe("wheel spoke rl(Clone)", "PLAYER");
			}
			bool flag75 = GUI.Button(new Rect(585f, 575f, 120f, 30f), "Spoke wheel RR");
			if (flag75)
			{
				TpMe("wheel spoke rr(Clone)", "PLAYER");
			}		
			bool flag76 = GUI.Button(new Rect(710f, 50f, 120f, 30f), "Hayosi. wheel FL");
			if (flag76)
			{
				TpMe("wheel hayosiko fl(Clone)", "PLAYER");
			}
			bool flag77 = GUI.Button(new Rect(710f, 85f, 120f, 30f), "Hayosi. wheel FR");
			if (flag77)
			{
				TpMe("wheel hayosiko fr(Clone)", "PLAYER");
			}
			bool flag78 = GUI.Button(new Rect(710f, 120f, 120f, 30f), "Hayosi. wheel RL");
			if (flag78)
			{
				TpMe("wheel hayosiko rl(Clone)", "PLAYER");
			}
			bool flag79 = GUI.Button(new Rect(710f, 155f, 120f, 30f), "Hayosi. wheel RR");
			if (flag79)
			{
				TpMe("wheel hayosiko rr(Clone)", "PLAYER");
			}
			bool flag80 = GUI.Button(new Rect(710f, 225f, 120f, 30f), "Main bridge 1");
			if (flag80)
			{
				TpMe("main bearing1(Clone)", "PLAYER");
			}
			bool flag81 = GUI.Button(new Rect(710f, 260f, 120f, 30f), "Main bridge 2");
			if (flag81)
			{
				TpMe("main bearing2(Clone)", "PLAYER");
			}
			bool flag82 = GUI.Button(new Rect(710f, 295f, 120f, 30f), "Main bridge 3");
			if (flag82)
			{
				TpMe("main bearing3(Clone)", "PLAYER");
			}
			bool flag83 = GUI.Button(new Rect(710f, 365f, 120f, 30f), "RPM gauge");
			if (flag83)
			{
				TpMe("rpm gauge(Clone)", "PLAYER");
			}
			bool flag84 = GUI.Button(new Rect(710f, 400f, 120f, 30f), "Clock gauge");
			if (flag84)
			{
				TpMe("clock gauge(Clone)", "PLAYER");
			}
			bool flag85 = GUI.Button(new Rect(710f, 435f, 120f, 30f), "Fuel mixtur. gauge");
			if (flag85)
			{
				TpMe("fuel mixture gauge(Clone)", "PLAYER");
			}
			bool flag86 = GUI.Button(new Rect(710f, 470f, 120f, 30f), "Extra gauges");
			if (flag86)
			{
				TpMe("extra gauges(Clone)", "PLAYER");
			}
			bool flag87 = GUI.Button(new Rect(710f, 505f, 120f, 30f), "Tachometer");
			if (flag87)
			{
				TpMe("tachometer(Clone)", "PLAYER");
			}
			bool flag88 = GUI.Button(new Rect(835f, 50f, 120f, 30f), "Flashlight");
			if (flag88)
			{
				TpMe("flashlight(itemx)", "PLAYER");
			}
			bool flag89 = GUI.Button(new Rect(835f, 85f, 120f, 30f), "Sledgehammer");
			if (flag89)
			{
				TpMe("sledgehammer(itemx)", "PLAYER");
			}
			bool flag90 = GUI.Button(new Rect(835f, 120f, 120f, 30f), "Floor jack");
			if (flag90)
			{
				TpMe2("floor jack(itemx)", "PLAYER");
			}
			bool flag91 = GUI.Button(new Rect(835f, 155f, 120f, 30f), "Motor hoist");
			if (flag91)
			{
				TpMe3("motor hoist(itemx)", "PLAYER");
			}
			bool flag92 = GUI.Button(new Rect(835f, 190f, 120f, 30f), "Car jack");
			if (flag92)
			{
				TpMe("car jack(itemx)", "PLAYER");
			}
			bool flag93 = GUI.Button(new Rect(835f, 225f, 120f, 30f), "Lantern");
			if (flag93)
			{
				TpMe("lantern(itemx)", "PLAYER");
			}
			bool flag94 = GUI.Button(new Rect(835f, 260f, 120f, 30f), "Bucket");
			if (flag94)
			{
				TpMe("bucket(itemx)", "PLAYER");
			}
			bool flag95 = GUI.Button(new Rect(835f, 295f, 120f, 30f), "Bucket lid");
			if (flag95)
			{
				TpMe("bucket lid(itemx)", "PLAYER");
			}
			bool flag96 = GUI.Button(new Rect(835f, 330f, 120f, 30f), "Fish trap");
			if (flag96)
			{
				TpMe("fish trap(itemx)", "PLAYER");
			}
			bool flag97 = GUI.Button(new Rect(835f, 365f, 120f, 30f), "Water bucket");
			if (flag97)
			{
				TpMe("water bucket(itemx)", "PLAYER");
			}
			bool flag98 = GUI.Button(new Rect(835f, 400f, 120f, 30f), "Dipper");
			if (flag98)
			{
				TpMe("dipper(itemx)", "PLAYER");
			}
			bool flag99 = GUI.Button(new Rect(835f, 435f, 120f, 30f), "Ax");
			if (flag99)
			{
				TpMe("ax(itemx)", "PLAYER");
			}
			bool flag100 = GUI.Button(new Rect(835f, 470f, 120f, 30f), "Basketball");
			if (flag100)
			{
				TpMe("basketball(Clone)", "PLAYER");
			}
			bool flag101 = GUI.Button(new Rect(835f, 505f, 120f, 30f), "Radio");
			if (flag101)
			{
				TpMe("radio(itemx)", "PLAYER");
			}
			bool flag102 = GUI.Button(new Rect(835f, 540f, 120f, 30f), "Sofa");
			if (flag102)
			{
				TpMe("sofa(itemx)", "PLAYER");
			}
			bool flag103 = GUI.Button(new Rect(835f, 575f, 120f, 30f), "Shopping bag");
			if (flag103)
			{
				TpMe("shopping bag(itemx)", "PLAYER");
			}
			bool flag104 = GUI.Button(new Rect(835f, 610f, 120f, 30f), "Fire exth. holder");
			if (flag104)
			{
				TpMe("fire extinguisher holder(Clone)", "PLAYER");
			}
			bool flag105 = GUI.Button(new Rect(710f, 575f, 120f, 30f), "Spray can");
			if (flag105)
			{
				TpMe("spray can(itemx)", "PLAYER");
			}
			bool flag106 = GUI.Button(new Rect(710f, 610f, 120f, 30f), "Warning triangle");
			if (flag106)
			{
				TpMe("warning triangle(Clone)", "PLAYER");
			}
			bool flag107 = GUI.Button(new Rect(960f, 50f, 120f, 30f), "Ratchet set");
			if (flag107)
			{
				TpMe("ratchet set(Clone)", "PLAYER");
			}
			bool flag108 = GUI.Button(new Rect(960f, 85f, 120f, 30f), "Envelope");
			if (flag108)
			{
				TpMe("envelope(xxxxx)", "PLAYER");
			}
			bool flag109 = GUI.Button(new Rect(960f, 120f, 120f, 30f), "Camera");
			if (flag109)
			{
				TpMe("camera(itemx)", "PLAYER");
			}
			bool flag110 = GUI.Button(new Rect(960f, 155f, 120f, 30f), "Suitcase");
			if (flag110)
			{
				TpMe("suitcase(itemx)", "PLAYER");
			}
			GUI.DragWindow();
		}

        public override void Update()
        {
			if (CheatsGuiKey.IsDown()) { GuiShow(); };
			if (teleport1Key.IsDown()) { Telep1(); };
			if (teleport2Key.IsDown()) { Telep2(); };
			if (teleport3Key.IsDown()) { Telep3(); };
			if (teleport4Key.IsDown()) { Telep4(); };
			if (teleport5Key.IsDown()) { Telep5(); };
			if (teleport6Key.IsDown()) { Telep6(); };
			if (teleport7Key.IsDown()) { Telep7(); };
			if (teleport8Key.IsDown()) { Telep8(); };
			if (teleport9Key.IsDown()) { Telep9(); };
			if (teleport10Key.IsDown()) { Telep10(); };
			if (teleport11Key.IsDown()) { Telep11(); };
			
			if(needs)
			{
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerDirtiness").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerDrunk").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerHunger").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerThirst").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerUrine").Value = 0.0f;
			}
        }
		
		private void GuiShow()
		{
			this.guiShow = !this.guiShow;
		}
		
		private void TpTo(string tpObject, string tptoObject)
        {
            ModConsole.Print("Teleportation to:" + tptoObject);
            var posFinder = GameObject.Find(tptoObject);
            Vector3 newPlayerPos = new Vector3(posFinder.transform.position.x + 3, posFinder.transform.position.y, posFinder.transform.position.z);
            GameObject.Find(tpObject).transform.position = newPlayerPos;
        }

        private void TpMe(string tpObject, string tptoObject)
        {
            ModConsole.Print("Teleporte me to:" + tptoObject);
            var posFinder = GameObject.Find(tptoObject);
            Vector3 newCarPos = new Vector3(posFinder.transform.position.x + 3, posFinder.transform.position.y, posFinder.transform.position.z);
            GameObject.Find(tpObject).transform.position = newCarPos;
        }
		
		private void TpMe2(string tpObject, string tptoObject)
        {
            ModConsole.Print("Teleporte me to:" + tptoObject);
            var posFinder = GameObject.Find(tptoObject);
            Vector3 newCarPos = new Vector3(posFinder.transform.position.x + 3, posFinder.transform.position.y - 0.15f, posFinder.transform.position.z);
            GameObject.Find(tpObject).transform.position = newCarPos;
        }
		
		private void TpMe3(string tpObject, string tptoObject)
        {
            ModConsole.Print("Teleporte me to:" + tptoObject);
            var posFinder = GameObject.Find(tptoObject);
            Vector3 newCarPos = new Vector3(posFinder.transform.position.x + 3, posFinder.transform.position.y - 0.22f, posFinder.transform.position.z);
            GameObject.Find(tpObject).transform.position = newCarPos;
        }
		
		private void Telep1()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "GraveYardSpawn");
			}
        }
		
		private void Telep2()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "SpawnToStore");
			}
        }
		
		private void Telep3()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "SpawnToRepair");
			}
        }
		
		private void Telep4()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "SpawnToDrag");
			}
        }
		
		private void Telep5()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "SpawnToCottage");
			}
        }
		
		private void Telep6()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "SATSUMA(557kg)");
			}
        }
		
		private void Telep7()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "FERNDALE(1630kg)");
			}
        }
		
		private void Telep8()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "GIFU(750/450psi)");
			}
        }
		
		private void Telep9()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "KEKMET(350-400psi)");
			}
        }
		
		private void Telep10()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "HAYOSIKO(1500kg)");
			}
        }
		
		private void Telep11()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "JONNEZ ES(Clone)");
			}
        }
    }
}
