﻿using MSCLoader;
using UnityEngine;
using System.Collections;
using System.Threading;

namespace DragWheel
{
    public class DragWheel : Mod
    {
        public override string ID { get { return "DragWheel"; } }
        public override string Name { get { return "Drag Wheel"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject FLRIM;
		private GameObject FLRIMCHRM;
		private GameObject FRRIM;
		private GameObject FRRIMCHRM;
		private GameObject RLRIM;
		private GameObject RLRIMCHRM;
		private GameObject RRRIM;
		private GameObject RRRIMCHRM;
		private string path = ModLoader.ModsFolder+@"\DragWheel\";
		
        public override void Update()
        {
            if (Application.loadedLevelName == "GAME" && !loaded)
            {
				new Thread(waiting4r).Start();				
				loaded = true;
            }
			
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
		
		private void waiting4r()
		{
			Thread.Sleep( 10 * 1000 );
			
			ObjImporter objimporter = new ObjImporter();
			Mesh new_mesh2 = new Mesh();
			new_mesh2 = objimporter.ImportFile(path + "tire_slick.obj");
			
			WWW loadtexture2 = new WWW("");
			loadtexture2 = new WWW("file://" + @path + "tires_slicks.png");
			
			GameObject[] allObjects = UnityEngine.Object.FindObjectsOfType<GameObject>();
			foreach(GameObject findme in allObjects)
			{
				if(findme.name == "TireSlick(Clone)")
				{
					findme.GetComponent<MeshFilter>().mesh = new_mesh2;
					findme.GetComponent<MeshRenderer>().material.mainTexture = loadtexture2.texture;
				}
			}
			
			if(GameObject.Find("wheel racing fl(Clone)").activeSelf == true)
			{
				FLRIM = GameObject.Find("wheel racing fl(Clone)");
				FLRIMCHRM = FLRIM.transform.FindChild("chrome").gameObject;
				FRRIM = GameObject.Find("wheel racing fr(Clone)");
				FRRIMCHRM = FRRIM.transform.FindChild("chrome").gameObject;
				RLRIM = GameObject.Find("wheel racing rl(Clone)");
				RLRIMCHRM = RLRIM.transform.FindChild("chrome").gameObject;
				RRRIM = GameObject.Find("wheel racing rr(Clone)");
				RRRIMCHRM = RRRIM.transform.FindChild("chrome").gameObject;
				
				Mesh new_mesh0 = new Mesh();
				new_mesh0 = objimporter.ImportFile(path + "rim_racing.obj");
				Mesh new_mesh1 = new Mesh();
				new_mesh1 = objimporter.ImportFile(path + "rim_racing_chrome.obj");
					
				FLRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				FLRIMCHRM.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				FRRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				FRRIMCHRM.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				RLRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				RLRIMCHRM.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				RRRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				RRRIMCHRM.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
					
				WWW loadtexture1 = new WWW("");
				loadtexture1 = new WWW("file://" + @path + "rims_ao.png");
	
				FLRIM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				FRRIM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				RLRIM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				RRRIM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				FLRIMCHRM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				FRRIMCHRM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				RLRIMCHRM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				RRRIMCHRM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
			}
		}
    }
}
