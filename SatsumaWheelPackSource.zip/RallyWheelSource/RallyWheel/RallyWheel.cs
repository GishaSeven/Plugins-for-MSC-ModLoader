﻿using MSCLoader;
using UnityEngine;
using System.Collections;
using System.Threading;

namespace RallyWheel
{
    public class RallyWheel : Mod
    {
        public override string ID { get { return "RallyWheel"; } }
        public override string Name { get { return "Rally Wheel"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject FLRIM;
		private GameObject FRRIM;
		private GameObject RLRIM;
		private GameObject RRRIM;
		private string path = ModLoader.ModsFolder+@"\RallyWheel\";
		
        public override void Update()
        {
            if (Application.loadedLevelName == "GAME" && !loaded)
            {
				new Thread(waiting2r).Start();					
				loaded = true;
            }
						
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
		
		private void waiting2r()
		{
			Thread.Sleep( 10 * 1000 );
			
			ObjImporter objimporter = new ObjImporter();
			Mesh new_mesh1 = new Mesh();
			new_mesh1 = objimporter.ImportFile(path + "tire_rally.obj");
			
			WWW loadtexture2 = new WWW("");
			loadtexture2 = new WWW("file://" + @path + "tires_rally.png");
			
			GameObject[] allObjects = UnityEngine.Object.FindObjectsOfType<GameObject>();
			foreach(GameObject findme in allObjects)
			{
				if(findme.name == "TireRally(Clone)")
				{
					findme.GetComponent<MeshFilter>().mesh = new_mesh1;
					findme.GetComponent<MeshRenderer>().material.mainTexture = loadtexture2.texture;
				}
			}
			
			if(GameObject.Find("wheel rally fl(Clone)").activeSelf == true)
			{
				FLRIM = GameObject.Find("wheel rally fl(Clone)");
				FRRIM = GameObject.Find("wheel rally fr(Clone)");
				RLRIM = GameObject.Find("wheel rally rl(Clone)");
				RRRIM = GameObject.Find("wheel rally rr(Clone)");
					
				Mesh new_mesh0 = new Mesh();
				new_mesh0 = objimporter.ImportFile(path + "rim_rally.obj");
					
				FLRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				FRRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				RLRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				RRRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
					
				WWW loadtexture1 = new WWW("");
				loadtexture1 = new WWW("file://" + @path + "rims_ao.png");
	
				FLRIM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				FRRIM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				RLRIM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				RRRIM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
			}
		}
    }
}
