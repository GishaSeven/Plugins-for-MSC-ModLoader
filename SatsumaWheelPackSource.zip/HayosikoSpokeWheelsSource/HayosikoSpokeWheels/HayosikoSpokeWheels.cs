﻿using MSCLoader;
using UnityEngine;
using System.Collections;
using System.Threading;

namespace HayosikoSpokeWheels
{
    public class HayosikoSpokeWheels : Mod
    {
        public override string ID { get { return "HayosikoSpokeWheels"; } }
        public override string Name { get { return "Hayosiko Spoke Wheels"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject FLRIMHAYO;
		private GameObject FLRIMHAYOIN;
		private GameObject FRRIMHAYO;
		private GameObject FRRIMHAYOIN;
		private GameObject RLRIMHAYO;
		private GameObject RLRIMHAYOIN;
		private GameObject RRRIMHAYO;
		private GameObject RRRIMHAYOIN;
		private GameObject FLRIMSPOK;
		private GameObject FRRIMSPOK;
		private GameObject RLRIMSPOK;
		private GameObject RRRIMSPOK;
		
		private string path = ModLoader.ModsFolder+@"\HayosikoSpokeWheels\";
		
        public override void Update()
        {
            if (Application.loadedLevelName == "GAME" && !loaded)
            {
				new Thread(waiting3r).Start();					
				loaded = true;
            }
				
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
		
		private void waiting3r()
		{
			Thread.Sleep( 10 * 1000 );
			
			ObjImporter objimporter = new ObjImporter();
			Mesh new_mesh3 = new Mesh();
			new_mesh3 = objimporter.ImportFile(path + "tire_gobra.obj");
			
			WWW loadtexture3 = new WWW("");
			loadtexture3 = new WWW("file://" + @path + "tires_gobra.png");
			
			GameObject[] allObjects = UnityEngine.Object.FindObjectsOfType<GameObject>();
			foreach(GameObject findme in allObjects)
			{
				if(findme.name == "TireGobra(Clone)")
				{
					findme.GetComponent<MeshFilter>().mesh = new_mesh3;
					findme.GetComponent<MeshRenderer>().material.mainTexture = loadtexture3.texture;
				}
			}
			
			if(GameObject.Find("wheel hayosiko fl(Clone)").activeSelf == true)
			{
				FLRIMHAYO = GameObject.Find("wheel hayosiko fl(Clone)");
				FLRIMHAYOIN = FLRIMHAYO.transform.FindChild("inner").gameObject;
				FRRIMHAYO = GameObject.Find("wheel hayosiko fr(Clone)");
				FRRIMHAYOIN = FRRIMHAYO.transform.FindChild("inner").gameObject;
				RLRIMHAYO = GameObject.Find("wheel hayosiko rl(Clone)");
				RLRIMHAYOIN = RLRIMHAYO.transform.FindChild("inner").gameObject;
				RRRIMHAYO = GameObject.Find("wheel hayosiko rr(Clone)");
				RRRIMHAYOIN = RRRIMHAYO.transform.FindChild("inner").gameObject;
					
				Mesh new_mesh0 = new Mesh();
				new_mesh0 = objimporter.ImportFile(path + "rim_hayosiko.obj");
				Mesh new_mesh1 = new Mesh();
				new_mesh1 = objimporter.ImportFile(path + "rim_hayosiko_inner.obj");
					
				FLRIMHAYO.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				FLRIMHAYOIN.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				FRRIMHAYO.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				FRRIMHAYOIN.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				RLRIMHAYO.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				RLRIMHAYOIN.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
				RRRIMHAYO.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
				RRRIMHAYOIN.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
					
				WWW loadtexture1 = new WWW("");
				loadtexture1 = new WWW("file://" + @path + "rims_ao.png");
	
				FLRIMHAYO.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				FRRIMHAYO.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				RLRIMHAYO.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				RRRIMHAYO.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
					
				WWW loadtexture2 = new WWW("");
				loadtexture2 = new WWW("file://" + @path + "rims_ao_inner.png");
					
				FLRIMHAYOIN.GetComponent<MeshRenderer>().material.mainTexture = loadtexture2.texture;
				FRRIMHAYOIN.GetComponent<MeshRenderer>().material.mainTexture = loadtexture2.texture;
				RLRIMHAYOIN.GetComponent<MeshRenderer>().material.mainTexture = loadtexture2.texture;
				RRRIMHAYOIN.GetComponent<MeshRenderer>().material.mainTexture = loadtexture2.texture;
			}
				
			if(GameObject.Find("wheel spoke fl(Clone)").activeSelf == true)
			{
				FLRIMSPOK = GameObject.Find("wheel spoke fl(Clone)");
				FRRIMSPOK = GameObject.Find("wheel spoke fr(Clone)");
				RLRIMSPOK = GameObject.Find("wheel spoke rl(Clone)");
				RRRIMSPOK = GameObject.Find("wheel spoke rr(Clone)");
					
				Mesh new_mesh2 = new Mesh();
				new_mesh2 = objimporter.ImportFile(path + "rim_spoke.obj");
				
				FLRIMSPOK.transform.GetComponent<MeshFilter>().mesh = new_mesh2;
				FRRIMSPOK.transform.GetComponent<MeshFilter>().mesh = new_mesh2;
				RLRIMSPOK.transform.GetComponent<MeshFilter>().mesh = new_mesh2;
				RRRIMSPOK.transform.GetComponent<MeshFilter>().mesh = new_mesh2;
					
				WWW loadtexture1 = new WWW("");
				loadtexture1 = new WWW("file://" + @path + "rims_ao.png");
					
				FLRIMSPOK.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				FRRIMSPOK.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				RLRIMSPOK.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
				RRRIMSPOK.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
			}
		}
    }
}
