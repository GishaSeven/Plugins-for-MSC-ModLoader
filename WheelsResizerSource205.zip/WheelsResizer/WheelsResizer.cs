﻿using MSCLoader;
using UnityEngine;
using System;
using System.IO;
using HutongGames.PlayMaker;

namespace WheelsResizer
{
    public class WheelsResizer : Mod
    {
        public override string ID => "WheelsResizer";
        public override string Name => "Wheels Resizer";
        public override string Author => "Roman266";
        public override string Version => "2.0.5";

        public override bool UseAssetsFolder => true;

		private bool guiShow;
		private bool Loaded;
		private float FLOrigRadius;
		private float FROrigRadius;
		private float RLOrigRadius;
		private float RROrigRadius;
		private GameObject SATSUMA;
		private GameObject WHEELRR;
		private GameObject WHEELRL;
		private GameObject WHEELFR;
		private GameObject WHEELFL;
		private string path;
		private Rect guiBox = new Rect((Screen.width-360)/2, 10f, 360f, 465f);
		private Keybind ResizerGuiKey = new Keybind("ShowGUI", "Show GUI", KeyCode.F8);
		
		public override void OnLoad()
        {
            Keybind.Add(this, ResizerGuiKey);
			
			path = ModLoader.GetModAssetsFolder(this);
			
			SATSUMA = GameObject.Find("SATSUMA(557kg, 248)");
			WHEELFL = SATSUMA.transform.FindChild("FL").gameObject;
			WHEELFR = SATSUMA.transform.FindChild("FR").gameObject;
			WHEELRL = SATSUMA.transform.FindChild("RL").gameObject;
			WHEELRR = SATSUMA.transform.FindChild("RR").gameObject;
			
			FLOrigRadius = SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius;
			FROrigRadius = SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius;
			RLOrigRadius = SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius;
			RROrigRadius = SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius;
			
			loadsettings();
        }
		
		public override void OnGUI()
		{
			if (guiShow)
			{
				GUI.ModalWindow(1, guiBox, new GUI.WindowFunction(Window), "Wheels Resizer");
			}
		}
		
        public override void Update()
        {			
			if (ResizerGuiKey.IsDown()) { GuiShow(); };
        }
				
		private void GuiShow()
		{
			if(Loaded)
			{
				guiShow = !guiShow;
			
				if(guiShow)
				{
					FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = true;
				}
				else
				{
					FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
				}
			}
		}
				
		private void Window(int windowId)
		{
			bool flag0 = GUI.Button(new Rect(130f, 425f, 100f, 30f), "Close");
			if (flag0)
			{
				GuiShow();
			}
			GUI.Label(new Rect(15f, 25f, 120f, 30f), "Front left wheel");
			bool flag1 = GUI.RepeatButton(new Rect(15f, 50f, 60f, 30f), "Size -");
			if (flag1)
			{
				fl_size_minus();
			}
			bool flag2 = GUI.RepeatButton(new Rect(75f, 50f, 60f, 30f), "Size +");
			if (flag2)
			{
				fl_size_plus();
			}
			GUI.Label(new Rect(140f, 55f, 60f, 30f), WHEELFL.transform.localScale.y.ToString());
			bool flag3 = GUI.RepeatButton(new Rect(15f, 80f, 60f, 30f), "Width -");
			if (flag3)
			{
				fl_width_minus();
			}
			bool flag4 = GUI.RepeatButton(new Rect(75f, 80f, 60f, 30f), "Width +");
			if (flag4)
			{
				fl_width_plus();
			}
			GUI.Label(new Rect(140f, 85f, 60f, 30f), WHEELFL.transform.localScale.x.ToString());
			GUI.Label(new Rect(15f, 115f, 120f, 30f), "Front right wheel");
			bool flag5 = GUI.RepeatButton(new Rect(15f, 140f, 60f, 30f), "Size -");
			if (flag5)
			{
				fr_size_minus();
			}
			bool flag6 = GUI.RepeatButton(new Rect(75f, 140f, 60f, 30f), "Size +");
			if (flag6)
			{
				fr_size_plus();
			}
			GUI.Label(new Rect(140f, 145f, 60f, 30f), WHEELFR.transform.localScale.y.ToString());
			bool flag7 = GUI.RepeatButton(new Rect(15f, 170f, 60f, 30f), "Width -");
			if (flag7)
			{
				fr_width_minus();
			}
			bool flag8 = GUI.RepeatButton(new Rect(75f, 170f, 60f, 30f), "Width +");
			if (flag8)
			{
				fr_width_plus();
			}
			GUI.Label(new Rect(140f, 175f, 60f, 30f), WHEELFR.transform.localScale.x.ToString());
			GUI.Label(new Rect(15f, 210f, 120f, 30f), "Rear left wheel");
			bool flag9 = GUI.RepeatButton(new Rect(15f, 235f, 60f, 30f), "Size -");
			if (flag9)
			{
				rl_size_minus();
			}
			bool flag10 = GUI.RepeatButton(new Rect(75f, 235f, 60f, 30f), "Size +");
			if (flag10)
			{
				rl_size_plus();
			}
			GUI.Label(new Rect(140f, 240f, 60f, 30f), WHEELRL.transform.localScale.y.ToString());
			bool flag11 = GUI.RepeatButton(new Rect(15f, 265f, 60f, 30f), "Width -");
			if (flag11)
			{
				rl_width_minus();
			}
			bool flag12 = GUI.RepeatButton(new Rect(75f, 265f, 60f, 30f), "Width +");
			if (flag12)
			{
				rl_width_plus();
			}
			GUI.Label(new Rect(140f, 270f, 60f, 30f), WHEELRL.transform.localScale.x.ToString());
			GUI.Label(new Rect(15f, 300f, 120f, 30f), "Rear right wheel");
			bool flag13 = GUI.RepeatButton(new Rect(15f, 325f, 60f, 30f), "Size -");
			if (flag13)
			{
				rr_size_minus();
			}
			bool flag14 = GUI.RepeatButton(new Rect(75f, 325f, 60f, 30f), "Size +");
			if (flag14)
			{
				rr_size_plus();
			}
			GUI.Label(new Rect(140f, 330f, 60f, 30f), WHEELRR.transform.localScale.y.ToString());
			bool flag15 = GUI.RepeatButton(new Rect(15f, 355f, 60f, 30f), "Width -");
			if (flag15)
			{
				rr_width_minus();
			}
			bool flag16 = GUI.RepeatButton(new Rect(75f, 355f, 60f, 30f), "Width +");
			if (flag16)
			{
				rr_width_plus();
			}
			GUI.Label(new Rect(140f, 360f, 60f, 30f), WHEELRR.transform.localScale.x.ToString());
			GUI.Label(new Rect(225f, 25f, 120f, 30f), "Front wheels");
			bool flag17 = GUI.RepeatButton(new Rect(225f, 50f, 60f, 30f), "Size -");
			if (flag17)
			{
				fl_size_minus();
				fr_size_minus();
			}
			bool flag18 = GUI.RepeatButton(new Rect(285f, 50f, 60f, 30f), "Size +");
			if (flag18)
			{
				fl_size_plus();
				fr_size_plus();
			}
			bool flag19 = GUI.RepeatButton(new Rect(225f, 80f, 60f, 30f), "Width -");
			if (flag19)
			{
				fl_width_minus();
				fr_width_minus();
			}
			bool flag20 = GUI.RepeatButton(new Rect(285f, 80f, 60f, 30f), "Width +");
			if (flag20)
			{
				fl_width_plus();
				fr_width_plus();
			}
			GUI.Label(new Rect(225f, 115f, 120f, 30f), "Rear wheels");
			bool flag21 = GUI.RepeatButton(new Rect(225f, 140f, 60f, 30f), "Size -");
			if (flag21)
			{
				rl_size_minus();
				rr_size_minus();
			}
			bool flag22 = GUI.RepeatButton(new Rect(285f, 140f, 60f, 30f), "Size +");
			if (flag22)
			{
				rl_size_plus();
				rr_size_plus();
			}
			bool flag23 = GUI.RepeatButton(new Rect(225f, 170f, 60f, 30f), "Width -");
			if (flag23)
			{
				rl_width_minus();
				rr_width_minus();
			}
			bool flag24 = GUI.RepeatButton(new Rect(285f, 170f, 60f, 30f), "Width +");
			if (flag24)
			{
				rl_width_plus();
				rr_width_plus();
			}
			GUI.Label(new Rect(225f, 210f, 120f, 30f), "All wheels");
			bool flag25 = GUI.RepeatButton(new Rect(225f, 235f, 60f, 30f), "Size -");
			if (flag25)
			{
				fl_size_minus();
				fr_size_minus();
				rl_size_minus();
				rr_size_minus();
			}
			bool flag26 = GUI.RepeatButton(new Rect(285f, 235f, 60f, 30f), "Size +");
			if (flag26)
			{
				fl_size_plus();
				fr_size_plus();
				rl_size_plus();
				rr_size_plus();
			}
			bool flag27 = GUI.RepeatButton(new Rect(225f, 265f, 60f, 30f), "Width -");
			if (flag27)
			{
				fl_width_minus();
				fr_width_minus();
				rl_width_minus();
				rr_width_minus();
			}
			bool flag28 = GUI.RepeatButton(new Rect(285f, 265f, 60f, 30f), "Width +");
			if (flag28)
			{
				fl_width_plus();
				fr_width_plus();
				rl_width_plus();
				rr_width_plus();
			}
			bool flag29 = GUI.Button(new Rect(225f, 325f, 120f, 30f), "Reset to default");
			if (flag29)
			{
				resetsettings();
			}
			bool flag30 = GUI.Button(new Rect(225f, 355f, 120f, 30f), "Save settings");
			if (flag30)
			{
				savesettings();
			}
			bool flag31 = GUI.Button(new Rect(225f, 385f, 120f, 30f), "Load settings");
			if (flag31)
			{
				loadsettings();
			}
			GUI.DragWindow();
		}
		
		private void resetsettings()
		{
			WHEELFL.transform.localScale = new Vector3(1, 1, 1);
			WHEELFR.transform.localScale = new Vector3(1, 1, 1);
			WHEELRL.transform.localScale = new Vector3(1, 1, 1);
			WHEELRR.transform.localScale = new Vector3(1, 1, 1);

			SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = FLOrigRadius;
			SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = FROrigRadius;
			SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = RLOrigRadius;
			SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = RROrigRadius;
		}
		
		private void savesettings()
        {
			if(FLOrigRadius == 0.2715f)
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = WHEELFL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = WHEELFL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius.ToString();
			
				File.WriteAllLines(path + "/fl_stock.txt", array);
			}
			
			if(FLOrigRadius == 0.2875f)
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = WHEELFL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = WHEELFL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius.ToString();
			
				File.WriteAllLines(path + "/fl_rally.txt", array);
			}
				
			if(FLOrigRadius == 0.255f)
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = WHEELFL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = WHEELFL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius.ToString();

				File.WriteAllLines(path + "/fl_drag.txt", array);
			}

			if(FROrigRadius == 0.2715f)
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = WHEELFR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = WHEELFR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/fr_stock.txt", array);
			}
				
			if(FROrigRadius == 0.2875f)
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = WHEELFR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = WHEELFR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/fr_rally.txt", array);
			}
				
			if(FROrigRadius == 0.255f)
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = WHEELFR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = WHEELFR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/fr_drag.txt", array);
			}

			if(RLOrigRadius == 0.2715f)
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = WHEELRL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = WHEELRL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius.ToString();

				File.WriteAllLines(path + "/rl_stock.txt", array);
			}
				
			if(RLOrigRadius == 0.2875f)
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = WHEELRL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = WHEELRL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius.ToString();

				File.WriteAllLines(path + "/rl_rally.txt", array);
			}
				
			if(RLOrigRadius == 0.255f)
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = WHEELRL.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = WHEELRL.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius.ToString();

				File.WriteAllLines(path + "/rl_drag.txt", array);
			}
			
			if(RROrigRadius == 0.2715f)
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = WHEELRR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = WHEELRR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/rr_stock.txt", array);
			}
				
			if(RROrigRadius == 0.2875f)
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = WHEELRR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = WHEELRR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/rr_rally.txt", array);
			}
				
			if(RROrigRadius == 0.255f)
			{
				string[] array = new string[3];
			
				string[] arg_11_0 = array;
				int arg_11_1 = 0;
				float num1 = WHEELRR.transform.localScale.y;
				arg_11_0[arg_11_1] = num1.ToString();
			
				string[] arg_12_0 = array;
				int arg_12_1 = 1;
				float num2 = WHEELRR.transform.localScale.x;
				arg_12_0[arg_12_1] = num2.ToString();
			
				array[2] = SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius.ToString();

				File.WriteAllLines(path + "/rr_drag.txt", array);
			}
        }
		
		private void loadsettings()
        {
			if(FLOrigRadius == 0.2715f)
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fl_stock.txt"))
				{
					array = File.ReadAllLines(path + "/fl_stock.txt");
				
					WHEELFL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(FLOrigRadius == 0.2875f)
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fl_rally.txt"))
				{
					array = File.ReadAllLines(path + "/fl_rally.txt");
				
					WHEELFL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(FLOrigRadius == 0.255f)
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fl_drag.txt"))
				{
					array = File.ReadAllLines(path + "/fl_drag.txt");
				
					WHEELFL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}

			if(FROrigRadius == 0.2715f)
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fr_stock.txt"))
				{
					array = File.ReadAllLines(path + "/fr_stock.txt");
				
					WHEELFR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(FROrigRadius == 0.2875f)
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fr_rally.txt"))
				{
					array = File.ReadAllLines(path + "/fr_rally.txt");
				
					WHEELFR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(FROrigRadius == 0.255f)
			{
				string[] array = new string[3];
				if (File.Exists(path + "/fr_drag.txt"))
				{
					array = File.ReadAllLines(path + "/fr_drag.txt");
				
					WHEELFR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}

			if(RLOrigRadius == 0.2715f)
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rl_stock.txt"))
				{
					array = File.ReadAllLines(path + "/rl_stock.txt");
				
					WHEELRL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(RLOrigRadius == 0.2875f)
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rl_rally.txt"))
				{
					array = File.ReadAllLines(path + "/rl_rally.txt");
				
					WHEELRL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(RLOrigRadius == 0.255f)
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rl_drag.txt"))
				{
					array = File.ReadAllLines(path + "/rl_drag.txt");
				
					WHEELRL.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius = float.Parse(array[2]);
				}
			}

			if(RROrigRadius == 0.2715f)
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rr_stock.txt"))
				{
					array = File.ReadAllLines(path + "/rr_stock.txt");
				
					WHEELRR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(RROrigRadius == 0.2875f)
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rr_rally.txt"))
				{
					array = File.ReadAllLines(path + "/rr_rally.txt");
				
					WHEELRR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}
				
			if(RROrigRadius == 0.255f)
			{
				string[] array = new string[3];
				if (File.Exists(path + "/rr_drag.txt"))
				{
					array = File.ReadAllLines(path + "/rr_drag.txt");
				
					WHEELRR.transform.localScale = new Vector3(float.Parse(array[1]), float.Parse(array[0]), float.Parse(array[0]));
				
					SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius = float.Parse(array[2]);
				}
			}
			
			Loaded = true;
        }
		
		private void fl_size_minus()
		{
			WHEELFL.transform.localScale = new Vector3(WHEELFL.transform.localScale.x - 0.001f, WHEELFL.transform.localScale.y - 0.001f, WHEELFL.transform.localScale.z - 0.001f);
			
			SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius -= FLOrigRadius/1000f;
		}
		
		private void fl_size_plus()
		{
			WHEELFL.transform.localScale = new Vector3(WHEELFL.transform.localScale.x + 0.001f, WHEELFL.transform.localScale.y + 0.001f, WHEELFL.transform.localScale.z + 0.001f);
			
			SATSUMA.GetComponent<Axles>().frontAxle.leftWheel.radius += FLOrigRadius/1000f;
		}
		
		private void fl_width_minus()
		{
			WHEELFL.transform.localScale = new Vector3(WHEELFL.transform.localScale.x - 0.001f, WHEELFL.transform.localScale.y, WHEELFL.transform.localScale.z);
		}
		
		private void fl_width_plus()
		{
			WHEELFL.transform.localScale = new Vector3(WHEELFL.transform.localScale.x + 0.001f, WHEELFL.transform.localScale.y, WHEELFL.transform.localScale.z);
		}
		
		private void fr_size_minus()
		{
			WHEELFR.transform.localScale = new Vector3(WHEELFR.transform.localScale.x - 0.001f, WHEELFR.transform.localScale.y - 0.001f, WHEELFR.transform.localScale.z - 0.001f);
				
			SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius -= FROrigRadius/1000f;
		}
		
		private void fr_size_plus()
		{
			WHEELFR.transform.localScale = new Vector3(WHEELFR.transform.localScale.x + 0.001f, WHEELFR.transform.localScale.y + 0.001f, WHEELFR.transform.localScale.z + 0.001f);
				
			SATSUMA.GetComponent<Axles>().frontAxle.rightWheel.radius += FROrigRadius/1000f;
		}
		
		private void fr_width_minus()
		{
			WHEELFR.transform.localScale = new Vector3(WHEELFR.transform.localScale.x - 0.001f, WHEELFR.transform.localScale.y, WHEELFR.transform.localScale.z);
		}
		
		private void fr_width_plus()
		{
			WHEELFR.transform.localScale = new Vector3(WHEELFR.transform.localScale.x + 0.001f, WHEELFR.transform.localScale.y, WHEELFR.transform.localScale.z);
		}

		private void rl_size_minus()
		{
			WHEELRL.transform.localScale = new Vector3(WHEELRL.transform.localScale.x - 0.001f, WHEELRL.transform.localScale.y - 0.001f, WHEELRL.transform.localScale.z - 0.001f);
				
			SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius -= RLOrigRadius/1000f;
		}
		
		private void rl_size_plus()
		{
			WHEELRL.transform.localScale = new Vector3(WHEELRL.transform.localScale.x + 0.001f, WHEELRL.transform.localScale.y + 0.001f, WHEELRL.transform.localScale.z + 0.001f);
				
			SATSUMA.GetComponent<Axles>().rearAxle.leftWheel.radius += RLOrigRadius/1000f;
		}
		
		private void rl_width_minus()
		{
			WHEELRL.transform.localScale = new Vector3(WHEELRL.transform.localScale.x - 0.001f, WHEELRL.transform.localScale.y, WHEELRL.transform.localScale.z);
		}
		
		private void rl_width_plus()
		{
			WHEELRL.transform.localScale = new Vector3(WHEELRL.transform.localScale.x + 0.001f, WHEELRL.transform.localScale.y, WHEELRL.transform.localScale.z);
		}
		
		private void rr_size_minus()
		{
			WHEELRR.transform.localScale = new Vector3(WHEELRR.transform.localScale.x - 0.001f, WHEELRR.transform.localScale.y - 0.001f, WHEELRR.transform.localScale.z - 0.001f);
				
			SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius -= RROrigRadius/1000f;
		}
		
		private void rr_size_plus()
		{
			WHEELRR.transform.localScale = new Vector3(WHEELRR.transform.localScale.x + 0.001f, WHEELRR.transform.localScale.y + 0.001f, WHEELRR.transform.localScale.z + 0.001f);
				
			SATSUMA.GetComponent<Axles>().rearAxle.rightWheel.radius += RROrigRadius/1000f;
		}
		
		private void rr_width_minus()
		{
			WHEELRR.transform.localScale = new Vector3(WHEELRR.transform.localScale.x - 0.001f, WHEELRR.transform.localScale.y, WHEELRR.transform.localScale.z);
		}
		
		private void rr_width_plus()
		{
			WHEELRR.transform.localScale = new Vector3(WHEELRR.transform.localScale.x + 0.001f, WHEELRR.transform.localScale.y, WHEELRR.transform.localScale.z);
		}
    }
}
