﻿using HutongGames.PlayMaker;
using MSCLoader;
using System;
using UnityEngine;

namespace DUSTMAN
{
    public class DUSTMAN : Mod
    {
        public override string ID => "Plymouth";
        public override string Name => "Plymouth project";
        public override string Author => "Flat0ut Reincarnated";
        public override string Version => "1.0";

		private GameObject DOORR;
		private GameObject DOORTRIGGERR;
		private GameObject DOORL;
		private GameObject DOORTRIGGERL;
		private GameObject interiorlight;
		private GameObject SPECLIGHTS;
		private GameObject BRAKELIGHTS;
		private GameObject Exhaust;
		private GameObject TRUNKTRIGGER;
		private GameObject TRUNK;
		private GameObject PLAYER;
		private GameObject DOORCLOSEL;
		private GameObject DOORCLOSER;
		private GameObject DOOROPENL;
		private GameObject DOOROPENR;
		private GameObject TRUNKCLOSE;
		private GameObject TRUNKOPEN;
		private GameObject NEEDLE;
		private GameObject NEEDLESPEED;
		private GameObject HANDBRAKE;
		private GameObject HANDBRAKETRIGGER;
		private GameObject PEDAL_gas;
		private GameObject PEDAL_clutch;
		private GameObject PEDAL_brake;
		public GameObject AUTHOR;
		public GameObject KEY;
		public GameObject INSIDECAR;
		public GameObject WHEELFL;
		public GameObject WHEELFR;
		public GameObject WHEELRL;
		public GameObject WHEELRR;
		private GameObject IMPACT_FRONT_R;
		private GameObject IMPACT_FRONT_L;
		private GameObject IMPACT_REAR_R;
		private GameObject IMPACT_REAR_L;
		public GameObject SHIFTER;
		public GameObject positionRR;
		public GameObject positionRL;
		public GameObject IGNITION;
		public GameObject BUYTRIGGER;
		public GameObject BUYTRIGGER2;
		public GameObject BUYTRIGGER3;
		public GameObject ORIGINALLIGHTS;
		public GameObject FOLIGHTS;
		public GameObject LODACTIVATOR;
		public GameObject FLICKERINGLIGHT;
		public GameObject FLICKERSOUND;
		public GameObject FLICKERSOUND2;
		public GameObject SPARKLES;
		public GameObject OLDRIMS1;
		public GameObject OLDRIMS2;
		public GameObject OLDRIMS3;
		public GameObject OLDRIMS4;
		public GameObject NEWRIMS1;
		public GameObject NEWRIMS2;
		public GameObject NEWRIMS3;
		public GameObject NEWRIMS4;
		public GameObject OLDCHASSIS;
		public GameObject OLDFENDERS;
		public GameObject OLDHOOD;
		public GameObject OLDTRUNK;
		public GameObject OLDDOOR1;
		public GameObject OLDDOOR2;
		public GameObject NEWCHASSIS;
		public GameObject NEWTRUNK;
		public GameObject NEWDOOR1;
		public GameObject NEWDOOR2;
		public GameObject SUBMASK;
		private float flickertime = 5f;
		private float flickertime2 = 6f;
		private float flickertime3 = 0.08f;
		private float sparklestime = 5f;
		public bool bought;
		public bool newrims;
		public bool GTCAR;
		public bool in_game;
		public float interactR = 1f;
		public float interactL = 1f;
		public float interactREAR = 1f;
		private float actualangle;
		private float SPEEDFACTOR = -1.5733f;
		private float anglespeedo;
		private float TIMER = 2f;
		private float RRELEVATION;
		private float RLELEVATION;
		private float FINALPOSITIONRL;
		private float FINALPOSITIONRR;
		public float DISTANCE;
		private GameObject CAR;
		private GameObject BUYING;
		private GameObject BUYING2;
		private GameObject SIGN;
		private GameObject PURHCASERIMS;
		public Drivetrain drivetrain;
		private AxisCarController acc;
		
		public override bool LoadInMenu => true;
		public override bool UseAssetsFolder => true;
		
		public override void OnMenuLoad()
        {
			AssetBundle assetBundle = LoadAssets.LoadBundle(this, "plymouth.unity3d");
			this.CAR = GameObject.Instantiate<GameObject>(assetBundle.LoadAsset<GameObject>("plymouth.prefab"));
			this.CAR.transform.position = new Vector3(1551.797f, 4.7037f, 743.98f);
			this.CAR.transform.rotation = Quaternion.Euler(0.40696f, 249.447f, 356.0525f);
			assetBundle.Unload(false);
			GameObject.DontDestroyOnLoad(this.CAR);
			this.CAR.GetComponent<Rigidbody>().isKinematic = true;
			GameObject gameObject = GameObject.Find("plymouth(Clone)");
			gameObject.name = "DUSTMAN(1408kg)";
			GameObject.Find("DUSTMAN(1408kg)/collisionsworld/coll").layer = 17;
			Dustmansave dustmansave = SaveLoad.DeserializeSaveFile<Dustmansave>(this, "trophy.save");
			bool flag = dustmansave != null;
			if (flag)
			{
				this.CAR.transform.position = dustmansave.pos;
				this.CAR.transform.rotation = Quaternion.Euler(dustmansave.rotX, dustmansave.rotY, dustmansave.rotZ);
				this.bought = dustmansave.bought;
				this.newrims = dustmansave.newrims;
				this.GTCAR = dustmansave.GTCAR;
			}
        }
		
        public override void OnLoad()
        {
			AssetBundle assetBundle = LoadAssets.LoadBundle(this, "store.unity3d");
			this.BUYING = GameObject.Instantiate<GameObject>(assetBundle.LoadAsset<GameObject>("BUYTRIGGER.prefab"));
			AssetBundle assetBundle2 = LoadAssets.LoadBundle(this, "sign.unity3d");
			this.SIGN = GameObject.Instantiate<GameObject>(assetBundle2.LoadAsset<GameObject>("sign.prefab"));
			AssetBundle assetBundle3 = LoadAssets.LoadBundle(this, "brochuregt.unity3d");
			this.BUYING2 = GameObject.Instantiate<GameObject>(assetBundle3.LoadAsset<GameObject>("brochureGT.prefab"));
			AssetBundle assetBundle4 = LoadAssets.LoadBundle(this, "purchaserims.unity3d");
			this.PURHCASERIMS = GameObject.Instantiate<GameObject>(assetBundle4.LoadAsset<GameObject>("PURCHASERIMS.prefab"));
			assetBundle.Unload(false);
			assetBundle2.Unload(false);
			assetBundle3.Unload(false);
			assetBundle4.Unload(false);
			this.BUYING.transform.position = new Vector3(1553.735f, 5.55f, 740.55f);
			this.BUYING2.transform.position = new Vector3(1553.783f, 5.668f, 740.649f);
			this.PURHCASERIMS.transform.position = new Vector3(1552.35f, 6.65f, 740.15f);
			this.SIGN.transform.position = new Vector3(1554f, 6.5f, 741.6f);
			this.CAR.transform.position = new Vector3(1551.797f, 4.7037f, 743.98f);
			this.CAR.transform.rotation = Quaternion.Euler(0.40696f, 249.447f, 356.0525f);
			this.acc = this.CAR.GetComponent<AxisCarController>();
			this.drivetrain = this.CAR.GetComponent<Drivetrain>();
			this.SteeringEnabler(false);
			this.CAR.transform.FindChild("PlayerTrigger").gameObject.AddComponent<PlayerTrigger>().tm = this;
			this.CAR.GetComponent<CarDynamics>().physicMaterials = GameObject.Find("FERNDALE(1630kg)").GetComponent<CarDynamics>().physicMaterials;
			this.CAR.GetComponent<CarDynamics>().skidmarks = GameObject.Find("FERNDALE(1630kg)").GetComponent<CarDynamics>().skidmarks;
			GameObject.Find("DUSTMAN(1408kg)/collisionsworld/coll").layer = 17;
			GameObject.Find("DUSTMAN(1408kg)").layer = 18;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/seatcoll").layer = 9;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/seatcolltop").layer = 9;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/groundcollider").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/bonnetcollider").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/DASHBOARDCOLL").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/DASHBOARDCOLL 1").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/maskcollider").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/windshieldcollider").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/rearwindowcollider").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/underwindshield").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/bodysideR").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/bodysideL").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/REARSEAT_lower").layer = 9;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/REARSEAT_upper").layer = 9;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/Front_int_right").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/Front_int_left").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/roofside_l").layer = 9;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/roofside_r").layer = 9;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/roofcollider").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/trunkcolground").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/trunkcollr").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/trunkcolll").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/trunkcollback").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/trunkcollfront").layer = 22;
			GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/trunkcollfront2").layer = 22;
			this.PLAYER = GameObject.Find("PLAYER");
			this.BUYTRIGGER = GameObject.Find("BUYTRIGGER(Clone)/COLLISION");
			this.BUYTRIGGER2 = this.BUYING2.transform.GetChild(1).gameObject;
			this.BUYTRIGGER3 = this.PURHCASERIMS.transform.GetChild(1).gameObject;
			this.positionRR = GameObject.Find("DUSTMAN(1408kg)/Wheels/WheelRR/TireRR");
			this.positionRL = GameObject.Find("DUSTMAN(1408kg)/Wheels/WheelRL/TireRL");
			this.NEEDLE = GameObject.Find("DUSTMAN(1408kg)/speedometer");
			this.NEEDLESPEED = GameObject.Find("DUSTMAN(1408kg)/rpmmeter");
			this.PEDAL_gas = GameObject.Find("DUSTMAN(1408kg)/PEDALS/PEDAL_gas");
			this.PEDAL_brake = GameObject.Find("DUSTMAN(1408kg)/PEDALS/PEDAL_brake");
			this.PEDAL_clutch = GameObject.Find("DUSTMAN(1408kg)/PEDALS/PEDAL_clutch");
			this.KEY = GameObject.Find("DUSTMAN(1408kg)/DashBoard/KEYS");
			this.IMPACT_FRONT_R = GameObject.Find("DUSTMAN(1408kg)/SOUNDS/SUS_IMPACT_FRONT_R");
			this.IMPACT_FRONT_L = GameObject.Find("DUSTMAN(1408kg)/SOUNDS/SUS_IMPACT_FRONT_L");
			this.IMPACT_REAR_R = GameObject.Find("DUSTMAN(1408kg)/SOUNDS/SUS_IMPACT_REAR_R");
			this.IMPACT_REAR_L = GameObject.Find("DUSTMAN(1408kg)/SOUNDS/SUS_IMPACT_REAR_L");
			this.WHEELFR = GameObject.Find("DUSTMAN(1408kg)/Wheels/WheelFR");
			this.WHEELFL = GameObject.Find("DUSTMAN(1408kg)/Wheels/WheelFL");
			this.WHEELRR = GameObject.Find("DUSTMAN(1408kg)/Wheels/WheelRR");
			this.WHEELRL = GameObject.Find("DUSTMAN(1408kg)/Wheels/WheelRL");
			this.IGNITION = GameObject.Find("DUSTMAN(1408kg)/collisionsplayer/ignition");
			this.OLDRIMS1 = GameObject.Find("DUSTMAN(1408kg)/Wheels/WheelFL/TireFL/oldrims");
			this.OLDRIMS2 = GameObject.Find("DUSTMAN(1408kg)/Wheels/WheelFR/TireFR/oldrims");
			this.OLDRIMS3 = GameObject.Find("DUSTMAN(1408kg)/Wheels/WheelRL/TireRL/oldrims");
			this.OLDRIMS4 = GameObject.Find("DUSTMAN(1408kg)/Wheels/WheelRR/TireRR/oldrims");
			this.NEWRIMS1 = GameObject.Find("DUSTMAN(1408kg)/Wheels/WheelFL/TireFL/newrims");
			this.NEWRIMS2 = GameObject.Find("DUSTMAN(1408kg)/Wheels/WheelFR/TireFR/newrims");
			this.NEWRIMS3 = GameObject.Find("DUSTMAN(1408kg)/Wheels/WheelRL/TireRL/newrims");
			this.NEWRIMS4 = GameObject.Find("DUSTMAN(1408kg)/Wheels/WheelRR/TireRR/newrims");
			this.OLDCHASSIS = GameObject.Find("DUSTMAN(1408kg)/Body/DUSTMAN_BODY");
			this.OLDFENDERS = GameObject.Find("DUSTMAN(1408kg)/Body/fender");
			this.OLDHOOD = GameObject.Find("DUSTMAN(1408kg)/Body/Hood");
			this.OLDTRUNK = GameObject.Find("DUSTMAN(1408kg)/RearDoors/Bootlid/Mesh/bootlid");
			this.OLDDOOR1 = GameObject.Find("DUSTMAN(1408kg)/DriverDoors/DOOR_RIGHT/MESHES/door_right");
			this.OLDDOOR2 = GameObject.Find("DUSTMAN(1408kg)/DriverDoors/DOOR_LEFT/MESHES/door_left");
			this.NEWCHASSIS = GameObject.Find("DUSTMAN(1408kg)/GTCAR");
			this.NEWDOOR1 = GameObject.Find("DUSTMAN(1408kg)/DriverDoors/DOOR_RIGHT/MESHES/DOORR");
			this.NEWDOOR2 = GameObject.Find("DUSTMAN(1408kg)/DriverDoors/DOOR_LEFT/MESHES/DOORL");
			this.NEWTRUNK = GameObject.Find("DUSTMAN(1408kg)/RearDoors/Bootlid/Mesh/TRUNK");
			this.SUBMASK = GameObject.Find("DUSTMAN(1408kg)/Body/plymouth 1970 submask");
			this.SHIFTER = GameObject.Find("DUSTMAN(1408kg)/SHIFTER/Armature2/Bone/Bone.001");
			this.CAR.AddComponent<Deformable>().meshFilter = this.CAR.transform.GetChild(3).FindChild("DUSTMAN_BODY").GetComponent<MeshFilter>();
			this.CAR.AddComponent<Deformable>().meshFilter = this.CAR.transform.GetChild(3).FindChild("Hood").GetComponent<MeshFilter>();
			this.CAR.AddComponent<Deformable>().meshFilter = this.CAR.transform.GetChild(3).FindChild("fender").GetComponent<MeshFilter>();
			this.CAR.AddComponent<Deformable>().meshFilter = this.CAR.transform.GetChild(3).FindChild("Maska").GetComponent<MeshFilter>();
			this.CAR.AddComponent<Deformable>().meshFilter = this.CAR.transform.GetChild(3).FindChild("grille").GetComponent<MeshFilter>();
			this.CAR.AddComponent<Deformable>().meshFilter = this.CAR.transform.GetChild(3).FindChild("BUMPER_REAR").GetComponent<MeshFilter>();
			this.CAR.AddComponent<Deformable>().meshFilter = this.CAR.transform.GetChild(3).FindChild("BUMPER_FRONT").GetComponent<MeshFilter>();
			this.CAR.AddComponent<Deformable>().meshFilter = this.CAR.transform.GetChild(3).GetChild(47).GetComponent<MeshFilter>();
			this.CAR.AddComponent<Deformable>().meshFilter = this.CAR.transform.GetChild(3).GetChild(49).GetComponent<MeshFilter>();
			this.CAR.AddComponent<Deformable>().meshFilter = this.CAR.transform.FindChild("DriverDoors").FindChild("DOOR_RIGHT").GetChild(2).FindChild("door_right").GetComponent<MeshFilter>();
			this.CAR.AddComponent<Deformable>().meshFilter = this.CAR.transform.FindChild("DriverDoors").FindChild("DOOR_LEFT").GetChild(2).FindChild("door_left").GetComponent<MeshFilter>();
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[0].MaxVertexMov = 0.06f;
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[0].Hardness = 1f;
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[1].MaxVertexMov = 0.1f;
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[1].Hardness = 1.5f;
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[2].MaxVertexMov = 0.12f;
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[2].Hardness = 1.5f;
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[3].MaxVertexMov = 0.03f;
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[5].MaxVertexMov = 0.04f;
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[5].Hardness = 0.5f;
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[6].MaxVertexMov = 0.03f;
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[6].Hardness = 0.89f;
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[9].MaxVertexMov = 0.02f;
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[9].Hardness = 0.89f;
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[10].MaxVertexMov = 0.02f;
			GameObject.Find("DUSTMAN(1408kg)").GetComponents<Deformable>()[10].Hardness = 0.89f;
			this.CAR.transform.FindChild("collisionsplayer").gameObject.AddComponent<CarDashBoard>().drivetrain = this.drivetrain;
			GameObject gameObject = GameObject.Instantiate<GameObject>(GameObject.Find("HAYOSIKO(1500kg, 250)/RadioPivot"));
			gameObject.transform.SetParent(GameObject.Find("DUSTMAN(1408kg)").transform);
			gameObject.transform.localPosition = new Vector3(0f, 0.26f, 0.78f);
			gameObject.transform.localRotation = Quaternion.Euler(310f, 5.008889E-06f, 180f);
			this.interiorlight = GameObject.Find("DUSTMAN(1408kg)/Interiorlight/interiorlight");
			this.interiorlight.SetActive(false);
			this.SPECLIGHTS = GameObject.Find("DUSTMAN(1408kg)/SPECLIGHTS");
			this.SPECLIGHTS.SetActive(false);
			this.BRAKELIGHTS = GameObject.Find("DUSTMAN(1408kg)/BRAKELIGHTS");
			this.HANDBRAKE = GameObject.Find("DUSTMAN(1408kg)/HANDBRAKE");
			this.HANDBRAKETRIGGER = GameObject.Find("DUSTMAN(1408kg)/HANDBRAKE/TRIGGER");
			this.HANDBRAKE.transform.localPosition = new Vector3(-0.5578f, 0.1605f, 0.8454f);
			this.FOLIGHTS = this.SIGN.transform.GetChild(2).gameObject;
			bool flag10 = GameObject.Find("MAP/StreetLights/4/LOD") == null;
			if (flag10)
			{
				GameObject.Find("MAP/StreetLights/4/LOD").SetActive(true);
			}
			GameObject gameObject2 = GameObject.Find("REPAIRSHOP");
			gameObject2.transform.Find("LOD").gameObject.SetActive(true);
			GameObject.Find("REPAIRSHOP/LOD/Garbage/Flatbed").SetActive(false);
			GameObject.Find("REPAIRSHOP/LOD/Garbage/bus_stop").SetActive(false);
			this.ORIGINALLIGHTS = GameObject.Find("MAP/StreetLights/4/LOD/Lights/Street Light");
			this.LODACTIVATOR = GameObject.Find("MAP/StreetLights/4/LOD");
			this.FLICKERINGLIGHT = GameObject.Find("sign(Clone)/LIGHTS/GameObject 1");
			this.FLICKERSOUND = GameObject.Find("sign(Clone)/FLICKERSOUND");
			this.FLICKERSOUND2 = GameObject.Find("sign(Clone)/FLICKERSOUND2");
			this.SPARKLES = GameObject.Find("sign(Clone)/SPARKLES");
			this.Exhaust = GameObject.Find("DUSTMAN(1408kg)/Exhaust");
			this.DOORCLOSER = GameObject.Find("DUSTMAN(1408kg)/DriverDoors/DOOR_RIGHT/SOUND");
			this.DOORCLOSEL = GameObject.Find("DUSTMAN(1408kg)/DriverDoors/DOOR_LEFT/SOUND");
			this.DOOROPENR = GameObject.Find("DUSTMAN(1408kg)/DriverDoors/DOOR_RIGHT/SOUNDOPEN");
			this.DOOROPENL = GameObject.Find("DUSTMAN(1408kg)/DriverDoors/DOOR_LEFT/SOUNDOPEN");
			this.TRUNKCLOSE = GameObject.Find("DUSTMAN(1408kg)/RearDoors/Bootlid/SOUND");
			this.TRUNKOPEN = GameObject.Find("DUSTMAN(1408kg)/RearDoors/Bootlid/SOUNDOPEN");
			this.DOORR = GameObject.Find("DUSTMAN(1408kg)/DriverDoors/DOOR_RIGHT");
			this.DOORTRIGGERR = GameObject.Find("DUSTMAN(1408kg)/DriverDoors/DOOR_RIGHT/door_trigger");
			this.DOORL = GameObject.Find("DUSTMAN(1408kg)/DriverDoors/DOOR_LEFT");
			this.DOORTRIGGERL = GameObject.Find("DUSTMAN(1408kg)/DriverDoors/DOOR_LEFT/door_trigger");
			this.TRUNK = GameObject.Find("DUSTMAN(1408kg)/RearDoors/Bootlid");
			this.TRUNKTRIGGER = GameObject.Find("DUSTMAN(1408kg)/RearDoors/Bootlid/triger");
			Dustmansave dustmansave = SaveLoad.DeserializeSaveFile<Dustmansave>(this, "trophy.save");
			bool flag11 = dustmansave != null;
			if (flag11)
			{
				this.CAR.transform.position = dustmansave.pos;
				this.CAR.transform.rotation = Quaternion.Euler(dustmansave.rotX, dustmansave.rotY, dustmansave.rotZ);
				this.bought = dustmansave.bought;
				this.newrims = dustmansave.newrims;
				this.GTCAR = dustmansave.GTCAR;
			}
			this.CAR.GetComponent<Rigidbody>().isKinematic = false;
			this.in_game = true;
        }
		
		public void SteeringEnabler(bool enable)
		{
			if (enable)
			{
				this.acc.throttleAxis = "Throttle";
				this.acc.brakeAxis = "Brake";
				this.acc.steerAxis = "Horizontal";
				this.acc.handbrakeAxis = "Handbrake";
				this.acc.clutchAxis = "Clutch";
				this.acc.shiftUpButton = "ShiftUp";
				this.acc.shiftDownButton = "ShiftDown";
			}
			else
			{
				this.acc.throttleAxis = null;
				this.acc.brakeAxis = null;
				this.acc.steerAxis = null;
				this.acc.handbrakeAxis = null;
				this.acc.clutchAxis = null;
				this.acc.shiftUpButton = null;
				this.acc.shiftDownButton = null;
			}
		}

		public override void OnSave()
		{
			GameObject gameObject = this.CAR.gameObject;
			SaveLoad.SerializeSaveFile<Dustmansave>(this, new Dustmansave
			{
				pos = gameObject.transform.position,
				rotX = gameObject.transform.rotation.eulerAngles.x,
				rotY = gameObject.transform.rotation.eulerAngles.y,
				rotZ = gameObject.transform.rotation.eulerAngles.z,
				bought = this.bought,
				newrims = this.newrims,
				GTCAR = this.GTCAR
			}, "trophy.save");
		}

        public override void Update()
        {
			bool flag = !this.in_game;
			if (!flag)
			{
				bool flag2 = Camera.main != null;
				if (flag2)
				{
					Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
					RaycastHit[] array = Physics.RaycastAll(ray, 1f);
					RaycastHit[] array2 = array;
					for (int i = 0; i < array2.Length; i++)
					{
						RaycastHit raycastHit = array2[i];
						bool flag3 = raycastHit.collider == this.BUYTRIGGER.GetComponent<Collider>();
						if (flag3)
						{
							PlayMakerGlobals.Instance.Variables.FindFsmString("GUIinteraction").Value = "BUY THE CAR (56,900 MK)";
							bool keyDown = Input.GetMouseButtonDown(0);
							if (keyDown)
							{
								bool flag4 = !this.bought;
								if (flag4)
								{
									bool flag5 = FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value < 56900f;
									if (flag5)
									{
										PlayMakerGlobals.Instance.Variables.FindFsmString("GUIsubtitle").Value = "Im not wasting my time with poor, go smell somewhere else...";
									}
									else
									{
										this.bought = true;
										this.BUYING.transform.GetChild(2).gameObject.SetActive(false);
										this.BUYING.transform.GetChild(2).gameObject.SetActive(true);
										FsmFloat expr_159 = FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney");
										expr_159.Value = expr_159.Value - 56900f;
										PlayMakerGlobals.Instance.Variables.FindFsmString("GUIsubtitle").Value = "Enjoy the car! No money back guaranteed!!";
									}
								}
							}
						}
						bool flag6 = raycastHit.collider == this.BUYTRIGGER2.GetComponent<Collider>();
						if (flag6)
						{
							PlayMakerGlobals.Instance.Variables.FindFsmString("GUIinteraction").Value = "GT UPGRADE (38,600 MK)";
							bool keyDown2 = Input.GetMouseButtonDown(0);
							if (keyDown2)
							{
								bool flag7 = !this.GTCAR;
								if (flag7)
								{
									bool flag8 = this.bought;
									if (flag8)
									{
										bool flag9 = FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value < 38600f;
										if (flag9)
										{
											PlayMakerGlobals.Instance.Variables.FindFsmString("GUIsubtitle").Value = "This is a business place, stop wasting my time!!";
										}
										else
										{
											this.GTCAR = true;
											this.BUYING.transform.GetChild(2).gameObject.SetActive(false);
											this.BUYING.transform.GetChild(2).gameObject.SetActive(true);
											FsmFloat expr_29D = FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney");
											expr_29D.Value = expr_29D.Value - 38600f;
											PlayMakerGlobals.Instance.Variables.FindFsmString("GUIsubtitle").Value = "Good choice! Have good fun !";
										}
									}
								}
							}
						}
						bool flag10 = raycastHit.collider == this.BUYTRIGGER3.GetComponent<Collider>();
						if (flag10)
						{
							PlayMakerGlobals.Instance.Variables.FindFsmString("GUIinteraction").Value = "GT RIMS (7600 MK)";
							bool keyDown3 = Input.GetMouseButtonDown(0);
							if (keyDown3)
							{
								bool flag11 = !this.newrims;
								if (flag11)
								{
									bool flag12 = this.bought;
									if (flag12)
									{
										bool flag13 = FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value < 7600f;
										if (flag13)
										{
											PlayMakerGlobals.Instance.Variables.FindFsmString("GUIsubtitle").Value = "Seriously?! How you got this car that you dont have money for rims?";
										}
										else
										{
											this.newrims = true;
											this.BUYING.transform.GetChild(2).gameObject.SetActive(false);
											this.BUYING.transform.GetChild(2).gameObject.SetActive(true);
											FsmFloat expr_3E2 = FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney");
											expr_3E2.Value = expr_3E2.Value - 7600f;
											PlayMakerGlobals.Instance.Variables.FindFsmString("GUIsubtitle").Value = "This should do it!";
										}
									}
								}
							}
						}
					}
				}
				bool flag14 = this.bought;
				if (flag14)
				{
					this.IGNITION.SetActive(true);
					this.WHEELFL.SetActive(true);
					this.WHEELFR.SetActive(true);
					this.WHEELRL.SetActive(true);
					this.WHEELRR.SetActive(true);
				}
				else
				{
					this.IGNITION.SetActive(false);
					this.WHEELFL.SetActive(false);
					this.WHEELFR.SetActive(false);
					this.WHEELRL.SetActive(false);
					this.WHEELRR.SetActive(false);
				}
				bool flag15 = this.newrims;
				if (flag15)
				{
					this.NEWRIMS1.SetActive(true);
					this.NEWRIMS2.SetActive(true);
					this.NEWRIMS3.SetActive(true);
					this.NEWRIMS4.SetActive(true);
					this.OLDRIMS1.SetActive(false);
					this.OLDRIMS2.SetActive(false);
					this.OLDRIMS3.SetActive(false);
					this.OLDRIMS4.SetActive(false);
				}
				else
				{
					this.NEWRIMS1.SetActive(false);
					this.NEWRIMS2.SetActive(false);
					this.NEWRIMS3.SetActive(false);
					this.NEWRIMS4.SetActive(false);
					this.OLDRIMS1.SetActive(true);
					this.OLDRIMS2.SetActive(true);
					this.OLDRIMS3.SetActive(true);
					this.OLDRIMS4.SetActive(true);
				}
				bool gTCAR = this.GTCAR;
				if (gTCAR)
				{
					this.OLDCHASSIS.SetActive(false);
					this.OLDDOOR1.SetActive(false);
					this.OLDDOOR2.SetActive(false);
					this.OLDFENDERS.SetActive(false);
					this.OLDHOOD.SetActive(false);
					this.OLDTRUNK.SetActive(false);
					this.NEWCHASSIS.SetActive(true);
					this.NEWDOOR1.SetActive(true);
					this.NEWDOOR2.SetActive(true);
					this.NEWTRUNK.SetActive(true);
					this.SUBMASK.SetActive(false);
					this.drivetrain.maxPower = 288f;
					this.drivetrain.maxTorque = 340f;
					this.drivetrain.maxTorqueRPM = 2300f;
					this.drivetrain.maxRPM = 4500f;
					this.drivetrain.gearRatios = new float[]
					{
						-3.21f,
						0f,
						2.8f,
						1.45f,
						0.95f,
						0.6f
					};
					this.drivetrain.finalDriveRatio = 3f;
					this.drivetrain.revLimiterTime = 0.165f;
					this.drivetrain.engineFrictionFactor = 0.41f;
					this.drivetrain.maxNetTorqueRPM = 2100f;
				}
				else
				{
					this.OLDCHASSIS.SetActive(true);
					this.OLDDOOR1.SetActive(true);
					this.OLDDOOR2.SetActive(true);
					this.OLDFENDERS.SetActive(true);
					this.OLDHOOD.SetActive(true);
					this.OLDTRUNK.SetActive(true);
					this.NEWCHASSIS.SetActive(false);
					this.NEWDOOR1.SetActive(false);
					this.NEWDOOR2.SetActive(false);
					this.NEWTRUNK.SetActive(false);
					this.SUBMASK.SetActive(true);
					this.drivetrain.maxPower = 145f;
					this.drivetrain.maxTorque = 215f;
					this.drivetrain.maxTorqueRPM = 2000f;
					this.drivetrain.maxRPM = 6000f;
					this.drivetrain.gearRatios = new float[]
					{
						-3.21f,
						0f,
						2.7f,
						1.7f,
						1f
					};
					this.drivetrain.finalDriveRatio = 3.4f;
					this.drivetrain.revLimiterTime = 0.13f;
					this.drivetrain.engineFrictionFactor = 0.28f;
					this.drivetrain.maxNetTorqueRPM = 1800f;
				}
				bool flag16 = Camera.main != null;
				if (flag16)
				{
					Ray ray2 = Camera.main.ScreenPointToRay(Input.mousePosition);
					RaycastHit[] array3 = Physics.RaycastAll(ray2, 1f);
					RaycastHit[] array4 = array3;
					for (int j = 0; j < array4.Length; j++)
					{
						RaycastHit raycastHit2 = array4[j];
						bool flag17 = raycastHit2.collider == this.DOORTRIGGERR.GetComponent<Collider>();
						if (flag17)
						{
							PlayMakerGlobals.Instance.Variables.FindFsmBool("GUIuse").Value = true;
							bool keyDown4 = Input.GetMouseButtonDown(0);
							if (keyDown4)
							{
								this.interactR = this.interactR + 1f;
							}
						}
						bool flag18 = raycastHit2.collider == this.DOORTRIGGERL.GetComponent<Collider>();
						if (flag18)
						{
							PlayMakerGlobals.Instance.Variables.FindFsmBool("GUIuse").Value = true;
							bool keyDown5 = Input.GetMouseButtonDown(0);
							if (keyDown5)
							{
								this.interactL = this.interactL + 1f;
							}
						}
					}
				}
				bool flag19 = this.interactR > 1f;
				if (flag19)
				{
					bool keyUp = Input.GetMouseButtonUp(0);
					if (keyUp)
					{
						this.interactR = 0f;
					}
				}
				bool flag20 = this.interactR == 2f;
				if (flag20)
				{
					HingeJoint component = this.DOORR.GetComponent<HingeJoint>();
					JointSpring spring = component.spring;
					spring.targetPosition = 60f;
					spring.spring = 600f;
					component.spring = spring;
					this.interiorlight.SetActive(true);
					this.DOOROPENR.SetActive(true);
					this.DOORCLOSER.SetActive(false);
				}
				bool flag21 = this.interactR == 1f;
				if (flag21)
				{
					HingeJoint component2 = this.DOORR.GetComponent<HingeJoint>();
					JointSpring spring2 = component2.spring;
					spring2.targetPosition = -5f;
					spring2.spring = 99999f;
					component2.spring = spring2;
					this.interiorlight.SetActive(false);
					this.DOORCLOSER.SetActive(true);
					this.DOOROPENR.SetActive(false);
				}
				bool flag22 = this.interactR == 0f;
				if (flag22)
				{
					HingeJoint component3 = this.DOORR.GetComponent<HingeJoint>();
					JointSpring spring3 = component3.spring;
					spring3.targetPosition = 0f;
					spring3.spring = 0f;
					component3.spring = spring3;
				}
				bool flag23 = this.interactL > 1f;
				if (flag23)
				{
					bool keyUp2 = Input.GetMouseButtonUp(0);
					if (keyUp2)
					{
						this.interactL = 0f;
					}
				}
				bool flag24 = this.interactL == 2f;
				if (flag24)
				{
					HingeJoint component4 = this.DOORL.GetComponent<HingeJoint>();
					JointSpring spring4 = component4.spring;
					spring4.targetPosition = 60f;
					spring4.spring = 600f;
					component4.spring = spring4;
					this.interiorlight.SetActive(true);
					this.DOORCLOSEL.SetActive(false);
					this.DOOROPENL.SetActive(true);
				}
				bool flag25 = this.interactL == 1f;
				if (flag25)
				{
					HingeJoint component5 = this.DOORL.GetComponent<HingeJoint>();
					JointSpring spring5 = component5.spring;
					spring5.targetPosition = -5f;
					spring5.spring = 99999f;
					component5.spring = spring5;
					this.interiorlight.SetActive(false);
					this.DOORCLOSEL.SetActive(true);
					this.DOOROPENL.SetActive(false);
				}
				bool flag26 = this.interactL == 0f;
				if (flag26)
				{
					HingeJoint component6 = this.DOORL.GetComponent<HingeJoint>();
					JointSpring spring6 = component6.spring;
					spring6.targetPosition = 0f;
					spring6.spring = 0f;
					component6.spring = spring6;
				}
				bool flag27 = this.drivetrain.gear == 0;
				if (flag27)
				{
					this.SPECLIGHTS.SetActive(true);
				}
				else
				{
					this.SPECLIGHTS.SetActive(false);
				}
				bool brakeKey = this.acc.brakeKey;
				if (brakeKey)
				{
					this.BRAKELIGHTS.SetActive(true);
				}
				bool flag28 = !this.acc.brakeKey;
				if (flag28)
				{
					this.BRAKELIGHTS.SetActive(false);
				}
				bool flag29 = this.drivetrain.rpm >= 450f;
				if (flag29)
				{
					this.Exhaust.SetActive(true);
				}
				else
				{
					this.Exhaust.SetActive(false);
				}
				bool flag30 = Camera.main != null;
				if (flag30)
				{
					Ray ray3 = Camera.main.ScreenPointToRay(Input.mousePosition);
					RaycastHit[] array5 = Physics.RaycastAll(ray3, 1f);
					RaycastHit[] array6 = array5;
					for (int k = 0; k < array6.Length; k++)
					{
						RaycastHit raycastHit3 = array6[k];
						bool flag31 = raycastHit3.collider == this.TRUNKTRIGGER.GetComponent<Collider>();
						if (flag31)
						{
							PlayMakerGlobals.Instance.Variables.FindFsmBool("GUIuse").Value = true;
							bool keyDown6 = Input.GetMouseButtonDown(0);
							if (keyDown6)
							{
								this.interactREAR += 1f;
							}
						}
					}
				}
				bool flag32 = this.interactREAR == 1f;
				if (flag32)
				{
					HingeJoint component7 = this.TRUNK.GetComponent<HingeJoint>();
					JointSpring spring7 = component7.spring;
					spring7.targetPosition = 50f;
					spring7.spring = 999999f;
					component7.spring = spring7;
					this.TRUNKCLOSE.SetActive(true);
					this.TRUNKOPEN.SetActive(false);
				}
				bool flag33 = this.interactREAR == 2f;
				if (flag33)
				{
					HingeJoint component8 = this.TRUNK.GetComponent<HingeJoint>();
					JointSpring spring8 = component8.spring;
					spring8.targetPosition = -100f;
					spring8.spring = 200f;
					component8.spring = spring8;
					this.TRUNKCLOSE.SetActive(false);
					this.TRUNKOPEN.SetActive(true);
				}
				bool flag34 = this.interactREAR > 2f;
				if (flag34)
				{
					this.interactREAR = 1f;
				}
				bool key = Input.GetKey(KeyCode.Return);
				if (key)
				{
					this.acc.steerInput = 0f;
					this.acc.throttleInput = 0f;
					this.acc.handbrakeInput = 0f;
					this.acc.clutchInput = 0f;
				}
				this.actualangle = this.drivetrain.rpm * -0.032f + 12f;
				this.NEEDLE.transform.localRotation = Quaternion.Euler(10f, 0f, this.actualangle);
				this.anglespeedo = this.drivetrain.differentialSpeed * this.SPEEDFACTOR * 0.6213712f;
				this.NEEDLESPEED.transform.localRotation = Quaternion.Euler(10f, 0f, this.anglespeedo);
				bool flag35 = this.WHEELFR.GetComponent<Wheel>().normalForce > 10900f;
				if (flag35)
				{
					this.IMPACT_FRONT_R.SetActive(true);
				}
				else
				{
					this.TIMER -= Time.deltaTime;
					bool flag36 = this.TIMER < 0f;
					if (flag36)
					{
						this.IMPACT_FRONT_R.SetActive(false);
						this.TIMER = 2f;
					}
				}
				bool flag37 = this.WHEELFL.GetComponent<Wheel>().normalForce > 10900f;
				if (flag37)
				{
					this.IMPACT_FRONT_L.SetActive(true);
				}
				else
				{
					this.TIMER -= Time.deltaTime;
					bool flag38 = this.TIMER < 0f;
					if (flag38)
					{
						this.IMPACT_FRONT_L.SetActive(false);
						this.TIMER = 2f;
					}
				}
				bool flag39 = this.WHEELRR.GetComponent<Wheel>().normalForce > 10900f;
				if (flag39)
				{
					this.IMPACT_REAR_R.SetActive(true);
				}
				else
				{
					this.TIMER -= Time.deltaTime;
					bool flag40 = this.TIMER < 0f;
					if (flag40)
					{
						this.IMPACT_REAR_R.SetActive(false);
						this.TIMER = 2f;
					}
				}
				bool flag41 = this.WHEELRL.GetComponent<Wheel>().normalForce > 10900f;
				if (flag41)
				{
					this.IMPACT_REAR_L.SetActive(true);
				}
				else
				{
					this.TIMER -= Time.deltaTime;
					bool flag42 = this.TIMER < 0f;
					if (flag42)
					{
						this.IMPACT_REAR_L.SetActive(false);
						this.TIMER = 2f;
					}
				}
				bool flag43 = Camera.main != null;
				if (flag43)
				{
					Ray ray4 = Camera.main.ScreenPointToRay(Input.mousePosition);
					RaycastHit[] array7 = Physics.RaycastAll(ray4, 1f);
					RaycastHit[] array8 = array7;
					for (int l = 0; l < array8.Length; l++)
					{
						RaycastHit raycastHit4 = array8[l];
						bool flag44 = raycastHit4.collider == this.HANDBRAKETRIGGER.GetComponent<Collider>();
						if (flag44)
						{
							PlayMakerGlobals.Instance.Variables.FindFsmBool("GUIuse").Value = true;
							PlayMakerGlobals.Instance.Variables.FindFsmString("GUIinteraction").Value = "HANDBRAKE";
							bool key2 = Input.GetMouseButtonDown(0);
							if (key2)
							{
								this.HANDBRAKE.transform.localPosition = new Vector3(-0.5578f, 0.1663f, 0.795f);
								this.acc.normalizeBrakesInput = true;
							}
							bool key3 = Input.GetMouseButtonDown(1);
							if (key3)
							{
								this.HANDBRAKE.transform.localPosition = new Vector3(-0.5578f, 0.1605f, 0.8454f);
								this.acc.normalizeBrakesInput = false;
							}
						}
					}
				}
				bool flag45 = this.acc.brakeInput == 1f;
				if (flag45)
				{
					this.PEDAL_brake.transform.localPosition = new Vector3(0f, -0.334f, 0.085f);
					this.PEDAL_brake.transform.localRotation = Quaternion.Euler(-20f, 0f, 0f);
				}
				else
				{
					this.PEDAL_brake.transform.localPosition = new Vector3(0f, 0f, 0f);
					this.PEDAL_brake.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
				}
				bool flag46 = this.acc.clutchInput > 0.5f;
				if (flag46)
				{
					this.PEDAL_clutch.transform.localPosition = new Vector3(0f, -0.2441f, 0.0653f);
					this.PEDAL_clutch.transform.localRotation = Quaternion.Euler(-14.72681f, 0f, 0f);
				}
				else
				{
					this.PEDAL_clutch.transform.localPosition = new Vector3(0f, 0f, 0f);
					this.PEDAL_clutch.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
				}
				bool flag47 = this.acc.throttleInput > 0.2f;
				if (flag47)
				{
					this.PEDAL_gas.transform.localPosition = new Vector3(0f, -0.2597f, 0.0561f);
					this.PEDAL_gas.transform.localRotation = Quaternion.Euler(-14.32629f, 0f, 0f);
				}
				else
				{
					this.PEDAL_gas.transform.localPosition = new Vector3(0f, 0f, 0f);
					this.PEDAL_gas.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
				}
				bool flag48 = !this.drivetrain.canStall;
				if (flag48)
				{
					this.KEY.SetActive(true);
				}
				else
				{
					this.KEY.SetActive(false);
				}
				bool flag49 = this.drivetrain.gear == 1;
				if (flag49)
				{
					this.SHIFTER.transform.localRotation = Quaternion.Euler(-8.439514f, 1.525879E-05f, 0f);
					this.SHIFTER.transform.localPosition = new Vector3(0f, 0.002418704f, 0f);
				}
				bool flag50 = this.drivetrain.gear == 2;
				if (flag50)
				{
					this.SHIFTER.transform.localRotation = Quaternion.Euler(-20f, 0.160614f, 11f);
				}
				bool flag51 = this.drivetrain.gear == 3;
				if (flag51)
				{
					this.SHIFTER.transform.localRotation = Quaternion.Euler(-3f, 0.160614f, 11f);
				}
				bool flag52 = this.drivetrain.gear == 4;
				if (flag52)
				{
					this.SHIFTER.transform.localRotation = Quaternion.Euler(-20f, 0.160614f, 0f);
				}
				bool flag53 = this.drivetrain.gear == 5;
				if (flag53)
				{
					this.SHIFTER.transform.localRotation = Quaternion.Euler(-3f, 0.160614f, 0f);
				}
				bool flag54 = this.drivetrain.gear == 0;
				if (flag54)
				{
					this.SHIFTER.transform.localRotation = Quaternion.Euler(-20f, 0.160614f, -11f);
				}
				this.RRELEVATION = this.positionRR.transform.localPosition.y;
				this.RLELEVATION = this.positionRL.transform.localPosition.y;
				this.FINALPOSITIONRL = this.RLELEVATION * -38.25001f - this.RRELEVATION * -38.25001f;
				this.FINALPOSITIONRR = this.RRELEVATION * -38.25001f - this.RLELEVATION * -38.25001f;
				this.WHEELRL.transform.localRotation = Quaternion.Euler(0f, 0f, this.FINALPOSITIONRL);
				this.WHEELRR.transform.localRotation = Quaternion.Euler(0f, 0f, -this.FINALPOSITIONRR);
				this.LODACTIVATOR.SetActive(true);
				bool activeInHierarchy = this.ORIGINALLIGHTS.activeInHierarchy;
				if (activeInHierarchy)
				{
					this.FOLIGHTS.SetActive(true);
					this.flickertime -= Time.deltaTime;
					this.flickertime2 -= Time.deltaTime;
					this.flickertime3 -= Time.deltaTime;
					bool flag55 = this.flickertime2 < 0f;
					if (flag55)
					{
						this.FOLIGHTS.SetActive(false);
						this.FLICKERSOUND.SetActive(false);
						this.FLICKERSOUND.SetActive(true);
						this.flickertime2 = UnityEngine.Random.Range(0.5f, 8f);
					}
					bool flag56 = this.flickertime < 0f;
					if (flag56)
					{
						this.FLICKERINGLIGHT.SetActive(!this.FLICKERINGLIGHT.activeSelf);
						this.FLICKERSOUND2.SetActive(true);
						this.SPARKLES.SetActive(true);
						this.sparklestime -= Time.deltaTime;
						bool flag57 = this.sparklestime < 0f;
						if (flag57)
						{
							this.sparklestime = (float)UnityEngine.Random.Range(2, 5);
							this.SPARKLES.SetActive(false);
						}
						bool flag58 = this.flickertime3 < 0f;
						if (flag58)
						{
							this.FLICKERINGLIGHT.SetActive(true);
							this.flickertime = UnityEngine.Random.Range(0.3f, 1f);
							this.flickertime3 = (float)UnityEngine.Random.Range(1, 2);
						}
					}
					else
					{
						this.FLICKERSOUND2.SetActive(false);
					}
				}
				else
				{
					this.FOLIGHTS.SetActive(false);
				}
				this.DISTANCE = Vector3.Distance(this.CAR.transform.position, this.PLAYER.transform.position);
				bool flag59 = this.DISTANCE < 0.8f;
				if (flag59)
				{
					this.PLAYER.GetComponents<PlayMakerFSM>()[1].FsmVariables.FindFsmBool("PlayerInCar").Value = true;
				}
				bool flag60 = this.DISTANCE > 0.8f;
				if (flag60)
				{
					bool flag61 = this.DISTANCE < 1.2f;
					if (flag61)
					{
						this.PLAYER.GetComponents<PlayMakerFSM>()[1].FsmVariables.FindFsmBool("PlayerInCar").Value = false;
					}
				}
			}
        }
    }
}
