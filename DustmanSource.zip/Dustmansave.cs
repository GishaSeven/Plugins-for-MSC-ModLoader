﻿using System;
using UnityEngine;

namespace DUSTMAN
{
    public class Dustmansave
    {
		public Vector3 pos;
		public float rotX;
		public float rotY;
		public float rotZ;
		public bool bought;
		public bool newrims;
		public bool GTCAR;
    }
}
