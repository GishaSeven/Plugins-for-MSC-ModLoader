﻿using System;
using System.Collections;
using UnityEngine;

namespace DUSTMAN
{
    public class CarDashBoard : MonoBehaviour
    {
		public Drivetrain drivetrain;
		private GameObject lights;
		private bool tryToStopEngine = false;
		private bool engineStopped = false;
		private AudioSource starter;
		private float timer = 0f;
		private GameObject SHUTOFF;
		public GameObject INCAR;
		public GameObject CHILD;

		private void Start()
		{
			base.StartCoroutine(this.TryStopEngine(true));
			this.lights = base.transform.parent.FindChild("ZLIGHTS").gameObject;
			this.lights.SetActive(false);
			this.starter = base.transform.GetChild(16).GetComponent<AudioSource>();
			this.starter.volume = 0.5f;
			this.SHUTOFF = GameObject.Find("DUSTMAN(1408kg)/SOUNDS/Engine_ShutOff");
			this.INCAR = GameObject.Find("DUSTMAN(1408kg)/PlayerTrigger");
			this.CHILD = GameObject.Find("PLAYER");
		}

		private IEnumerator TryStopEngine(bool wait)
		{
			this.tryToStopEngine = true;
			float maxTorque = this.drivetrain.maxTorque;
			if (wait)
			{
				yield return new WaitForSeconds(2f);
			}
			while (this.drivetrain.rpm >= 20f)
			{
				this.drivetrain.maxTorque = -200f;
				yield return null;
			}
			this.drivetrain.maxTorque = maxTorque;
			this.tryToStopEngine = false;
			this.engineStopped = true;
			yield break;
		}

		private void Engine(bool start)
		{
			if (start)
			{
				this.timer = 0f;
				this.engineStopped = false;
				this.drivetrain.StartEngine();
			}
			else
			{
				base.StartCoroutine(this.TryStopEngine(false));
			}
		}

		private void Update()
		{
			bool flag = Camera.main != null;
			if (flag)
			{
				Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
				RaycastHit[] array = Physics.RaycastAll(ray, 1f);
				RaycastHit[] array2 = array;
				for (int i = 0; i < array2.Length; i++)
				{
					RaycastHit raycastHit = array2[i];
					bool flag2 = raycastHit.collider == base.transform.GetChild(14).GetComponent<Collider>();
					if (flag2)
					{
						PlayMakerGlobals.Instance.Variables.FindFsmBool("GUIuse").Value = true;
						PlayMakerGlobals.Instance.Variables.FindFsmString("GUIinteraction").Value = "LIGHTS";
						bool mouseButtonDown = Input.GetMouseButtonDown(0);
						if (mouseButtonDown)
						{
							this.lights.SetActive(!this.lights.activeSelf);
						}
					}
					bool flag3 = raycastHit.collider == base.transform.GetChild(15).GetComponent<Collider>();
					if (flag3)
					{
						PlayMakerGlobals.Instance.Variables.FindFsmBool("GUIuse").Value = true;
						PlayMakerGlobals.Instance.Variables.FindFsmString("GUIinteraction").Value = "IGNITION";
						bool flag4 = this.engineStopped;
						if (flag4)
						{
							bool mouseButtonUp = Input.GetMouseButtonUp(0);
							if (mouseButtonUp)
							{
								this.starter.Stop();
								this.timer = 0f;
							}
							bool mouseButton = Input.GetMouseButton(0);
							if (mouseButton)
							{
								this.drivetrain.engineFrictionFactor = 0.28f;
								this.drivetrain.gear = 1;
								bool flag5 = !this.starter.isPlaying;
								if (flag5)
								{
									this.starter.Play();
								}
								this.timer += Time.deltaTime;
								bool flag6 = this.timer % 60f > 1.3f;
								if (flag6)
								{
									this.starter.Stop();
									this.drivetrain.canStall = false;
									this.Engine(true);
									return;
								}
							}
						}
						else
						{
							bool mouseButtonDown2 = Input.GetMouseButtonDown(0);
							if (mouseButtonDown2)
							{
								bool flag7 = !this.tryToStopEngine;
								if (flag7)
								{
									this.drivetrain.engineFrictionFactor = 5f;
								}
								this.SHUTOFF.SetActive(false);
								this.SHUTOFF.SetActive(true);
								this.drivetrain.canStall = true;
								this.Engine(false);
							}
						}
					}
				}
			}
			bool flag8 = this.CHILD.transform.IsChildOf(this.INCAR.transform);
			if (flag8)
			{
				bool keyDown = Input.GetKeyDown(KeyCode.L);
				if (keyDown)
				{
					this.lights.SetActive(!this.lights.activeSelf);
				}
			}
		}
    }
}
