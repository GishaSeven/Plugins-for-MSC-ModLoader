﻿using System;
using System.Collections;
using UnityEngine;

namespace DUSTMAN
{
    public class PlayerTrigger : MonoBehaviour
	{
		private bool entered;
		private bool inCar;
		private bool wait;
		private GameObject player;
		public DUSTMAN tm;
		private GameObject gears_obj;
		private TextMesh gears;
		private GameObject DUSTMANCAR;

		private void Start()
		{
			this.gears_obj = GameObject.Find("GUI/Indicators").transform.FindChild("Gear").gameObject;
			this.gears = this.gears_obj.GetComponent<TextMesh>();
			this.DUSTMANCAR = GameObject.Find("DUSTMAN(1408kg)");
		}

		private void Update()
		{
			bool flag = this.entered && this.player != null && !this.wait;
			if (flag)
			{
				PlayMakerGlobals.Instance.Variables.FindFsmBool("GUIdrive").Value = true;
				PlayMakerGlobals.Instance.Variables.FindFsmString("GUIinteraction").Value = "Enter Driving Mode";
				bool keyDown = Input.GetKeyDown(KeyCode.Return);
				if (keyDown)
				{
					this.wait = true;
					base.StartCoroutine(this.WaitForASec());
					this.player.GetComponents<PlayMakerFSM>()[1].FsmVariables.FindFsmBool("PlayerInCar").Value = true;
					PlayMakerGlobals.Instance.Variables.FindFsmBool("PlayerCarControl").Value = true;
					this.entered = false;
					this.player.GetComponent<CharacterController>().enabled = false;
					this.player.GetComponent<CharacterMotor>().enabled = false;
					this.player.GetComponent<FPSInputController>().enabled = false;
					this.player.transform.SetParent(base.transform);
					this.tm.SteeringEnabler(true);
					this.inCar = true;
					PlayMakerGlobals.Instance.Variables.FindFsmBool("GUIdrive").Value = false;
					PlayMakerGlobals.Instance.Variables.FindFsmString("GUIinteraction").Value = string.Empty;
					this.gears_obj.SetActive(true);
					this.gears_obj.GetComponent<PlayMakerFSM>().enabled = false;
				}
			}
			bool flag2 = this.inCar && !this.wait;
			if (flag2)
			{
				bool flag3 = this.DUSTMANCAR.GetComponent<CarDynamics>().velo < 0.3f;
				if (flag3)
				{
					bool keyDown2 = Input.GetKeyDown(KeyCode.Return);
					if (keyDown2)
					{
						this.wait = true;
						base.StartCoroutine(this.WaitForASec());
						this.player.GetComponents<PlayMakerFSM>()[1].FsmVariables.FindFsmBool("PlayerInCar").Value = false;
						PlayMakerGlobals.Instance.Variables.FindFsmBool("PlayerCarControl").Value = false;
						this.player.transform.SetParent(null);
						this.player.GetComponent<CharacterController>().enabled = true;
						this.player.GetComponent<CharacterMotor>().enabled = true;
						this.player.GetComponent<FPSInputController>().enabled = true;
						this.tm.SteeringEnabler(false);
						this.inCar = false;
						this.gears_obj.SetActive(false);
						this.gears_obj.GetComponent<PlayMakerFSM>().enabled = true;
						this.player.transform.eulerAngles = new Vector3(0f, this.player.transform.eulerAngles.y, 0f);
					}
				}
			}
		}

		private void GearsText(string text)
		{
			this.gears.text = text;
			this.gears_obj.transform.GetChild(0).GetComponent<TextMesh>().text = text;
		}

		private IEnumerator WaitForASec()
		{
			yield return new WaitForSeconds(2f);
			this.wait = false;
			yield break;
		}

		private void FixedUpdate()
		{
			bool flag = this.inCar;
			if (flag)
			{
				bool flag2 = this.tm.drivetrain.gear < this.tm.drivetrain.neutral;
				if (flag2)
				{
					this.GearsText("R");
				}
				else
				{
					bool flag3 = this.tm.drivetrain.gear == this.tm.drivetrain.neutral;
					if (flag3)
					{
						this.GearsText("N");
					}
					else
					{
						this.GearsText((this.tm.drivetrain.gear - this.tm.drivetrain.neutral).ToString());
					}
				}
			}
		}

		private void OnTriggerEnter(Collider other)
		{
			bool flag = other.name == "PLAYER" && !this.inCar;
			if (flag)
			{
				this.player = other.gameObject;
				this.entered = true;
				PlayMakerGlobals.Instance.Variables.FindFsmBool("GUIdrive").Value = true;
				PlayMakerGlobals.Instance.Variables.FindFsmString("GUIinteraction").Value = "Enter Driving Mode";
				this.player.GetComponents<PlayMakerFSM>()[1].FsmVariables.FindFsmBool("PlayerInCar").Value = true;
			}
		}

		private void OnTriggerExit()
		{
			bool flag = !this.inCar;
			if (flag)
			{
				this.entered = false;
				this.player.GetComponents<PlayMakerFSM>()[1].FsmVariables.FindFsmBool("PlayerInCar").Value = false;
				this.player = null;
				PlayMakerGlobals.Instance.Variables.FindFsmBool("GUIdrive").Value = false;
				PlayMakerGlobals.Instance.Variables.FindFsmString("GUIinteraction").Value = string.Empty;
			}
		}
	}
}
