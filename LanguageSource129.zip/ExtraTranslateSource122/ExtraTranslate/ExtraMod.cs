﻿using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using MSCLoader;
using UnityEngine;
using HutongGames.PlayMaker;

namespace ExtraTranslate
{
    public class ExtraMod : Mod
    {
        public override string ID => "ExtraTranslate";
        public override string Name => "Extra Translate";
        public override string Author => "Roman266";
        public override string Version => "1.2.2";
		public override string Description => "Part of translation.";

		public override bool LoadInMenu => true;
		public override bool UseAssetsFolder => true;
		
		private string path;
		private string cashreg;
		private string mk;
		private string takemoney;
		private string standat;
		private string currentbet;
		private string hitcards;
		private string addevilery;
		private string ruler;
		private string alctest1;
		private string alctest2;
		private string dumpfi;
		private string dump1;
		private string dump2;
		private string unpaidfines;
		public static string notimported;
		public static string radioimported;
		public static string cdimported;
		private string reddrag;
		private string rallyx;
		private string ttrally1;
		private string ttrally2;
		private string monday;
		private string tuesday;
		private string wednesday;
		private string thursday;
		private string friday;
		private string saturday;
		private string sunday;
		private string finews0;
		private string finews1;
		private string finews2;
		private string finews3;
		private string finews4;
		private string finews5;
		private string finews6;
		private string finews7;
		private string finews8;
		private string finews9;
		private string finews10;
		private string finews11;
		private string finews12;
		private string finews13;
		private string finews14;
		private string finews15;
		private string finews16;
		private string wdnews0;
		private string wdnews1;
		private string econews0;
		private string econews1;
		private string econews2;
		private string econews3;
		private string econews4;
		private string econews5;
		private string econews6;
		private string weather1;
		private string weather2;
		private string weather3;
		private string weather4;
		private string sportnews0;
		private string sportnews1;
		private string sportnews2;
		private string sportnews3;
		private string sportnews4;
		private string sportnews5;
		private string sportnews6;
		private string sportnews7;
		private string sportnews8;
		private string sportnews9;
		private string sportnews10;
		private string sportnews11;
		private string recipe0;
		private string recipe1;
		private string recipe2;
		private string recipe3;
		private string recipe4;
		private string quote0;
		private string quote1;
		private string quote2;
		private string quote3;
		private string quote4;
		private string quote5;
		private string quote6;
		private string quote7;
		private string quote8;
		private string quote9;
		private string quote10;
		private string culture0;
		private string culture1;
		private string culture2;
		private string culture3;
		private string computer1;
		private string computer2;
		private string computer3;
		private string computer4;
		private string computer5;
		private string computer6;
		private string computer7;
		private string computer8;
		private string computer9;
		private string computer10;
		private string computer11;
		private string computer12;
		private string computer13;
		private string computer14;
		private string computer15;
		private string computer16;
		private string stop;
		private string haku;
		private string spdfineen1;
		private string spdfineen2;
		private string spdfineen3;
		private string spdfineen4;
		private string spdfinefi1;
		private string spdfinefi2;
		private string spdfinefi3;
		private string spdfinefi4;
		private string rallysprint;
		private string insertdisc;
		private string errordisc;
		private string telebbs;
		private string sethandle;
		private string tooshort;
		private string sending;
		private string failsending;
		private string cccccccc;
		private string fishgame1;
		private string fishgame2;
		private string fishgame3;
		private string fishgame4;
		private string fishgame5;
		private string fishgame6;
		private string fishgame7;
		private string fishgame8;
		private string fishgame9;
		private string fishgame10;
		private string fishgame11;
		private string fishgame12;
		private string fishgame13;
		private string fishgame14;
		private string fishgame15;
		private string fishgame16;
		private string fishgame17;
		private string fishgame18;
		private string fishgame19;
		private string fishgame20;
		private string fishgame21;
		private string fishgame22;
		private string fishgame23;
		private string gameover;
		private string newfishing1;
		private string newfishing2;
		private string newfishing3;
		private string newfishing4;
		private string newfishing5;
		private string newfishing6;
		private string newfishing7;
		private string winpressenter;
		private string traumiren;
		private string compmemerror;
		private string shralresu1;
		private string shralresu2;
		private string shralresu3;
		private string shralresu4;
		private string arrestwe1;
		private string arrestwe2;
		private string compcopy;
		private string compformat;
		private string compvolumea;
		private string compvolumec;
		private string playersting;
		private string gstring;
		private string rallyclass1;
		private string rallyclass2;
		private string rallyclass3;
		private string born;
		private string credits;
		private string rallyname0;
		private string rallyname1;
		private string rallyname2;
		private string rallyname3;
		private string rallyname4;
		private string rallyname5;
		private string rallyname6;
		private string rallyname7;
		private string rallyname8;
		private string rallyname9;
		private string rallyname10;
		private string rallyname11;
		private string rallyname12;
		private string rallyname13;
		private string rallyname14;
		private string rallyname15;
		private string rallyname16;
		private string rallyname17;
		private string rallyname18;
		private string rallyname19;
		private string rallyname20;
		private string rallyname21;
		private string rallyname22;
		private string rallyname23;
		private string rallyname24;
		private string rallyname25;
		private string rallyname26;
		private string rallyname27;
		private string rallyname28;
		private string rallyname29;
		private string rallyname30;
		private string rallyname31;
		private string rallyname32;
		private string rallyname33;
		private string rallyname34;
		private string rallyname35;
		private string rallyname36;
		private string rallyname37;
		private string rallyname38;
		private string rallyname39;
		private string rallyname40;
		private string rallyname41;
		private string rallyname42;
		private string rallyname43;
		private string rallyname44;
		private string rallyname45;
		private string rallyname46;
		private string rallyname47;
		private string rallyname48;
		private string rallyname49;
		private string rallyname50;
		private string rallyname51;
		private string rallyname52;
		private string rallyname53;
		private string rallyname54;
		private string rallyname55;
		private string rallyname56;
		private string rallyname57;
		private string rallyname58;
		private string rallyname59;
		private string rallyname60;
		private string rallyname61;
		private string rallyname62;
		private string rallyname63;
		private string rallyname64;
		private string rallyname65;
		private string rallyname66;
		private string rallyname67;
		private string rallyname68;
		private string rallyname69;
		private string rallyname70;
		private string rallyname71;
		private string rallyname72;
		private string rallyname73;
		private string rallyname74;
		private string rallyname75;
		private string rallyname76;
		private string rallyname77;
		private string rallyname78;
		private string rallyname79;
		private string rallyname80;
		private string rallyname81;
		private string rallyname82;
		private string rallyname83;
		private string rallyname84;
		private string rallyname85;
		private string rallyname86;
		private string rallyname87;
		private string rallyname88;
		private string rallyname89;
		private string rallyname90;
		private string rallyname91;
		private string rallyname92;
		private string rallyname93;
		private string rallyname94;
		private string rallyname95;
		private string rallyname96;
		private string rallyname97;
		private string rallyname98;
		private string rallyname99;
		private string rallyname100;
		private string rallyname101;
		private string rallyname102;
		private string rallyname103;
		private string rallyname104;
		private string rallyname105;
		private string rallyname106;
		private string rallyname107;
		private string rallyname108;
		private string fishname1;
		private string fishname2;
		private string fishname3;
		private string fishname4;
		private string fishname5;
		private string fishname6;
		private string fishname7;
		private string dragname1;
		private string dragname2;
		private string dragname3;
		private string dragname4;
		private string dragname5;
		private string fetching;
		private string longstring1;
		private string longstring2;
		private string longstring3;
		private string longstring4;
		private string longstring5;
		private string longstring6;
		private string longstring7;
		private string longstring8;
		private string longstring9;
		private string longstring10;
		private string longstring11;
		private string longstring12;
		private string longstring13;
		private string longstring14;
		private string longstring15;
		private string longstring16;
		private string longstring17;
		private string longstring18;
		private string longstring19;
		private string longstring20;
		private string longstring21;
		private string longstring22;
		private string longstring23;
		private string longstring24;
		private string longstring25;
		private string longstring26;
		private string longstring27;
		private string longstring28;
		private string fleeteridriveway;
		private string teimohello;
		private string finews17;
		private string wdnews2;
		private string wdnews3;
		private string wdnews4;
		private string econews7;
		private string econews8;
		private string sportnews12;
		private string culture4;
		private string culture5;
		private string culture6;
		private string culture7;
		private bool teletext2;
		private bool ttfinews;
		private bool ttupdate;
		private bool ttwdnews;
		private bool tteconews;
		private bool ttsportnews;
		private bool ttrecipes;
		private bool ttquotes;
		private bool ttcultures;
		private bool endingtranslated;
		private bool uncle3;
		private bool rallytvnames;
		
		public override void OnMenuLoad() 
	    {			
			path = ModLoader.GetModAssetsFolder(this);
			
			string[] array = new string[339];
			{
				array = File.ReadAllLines(path + "/etranslate.txt");
				notimported = array[14];
				radioimported = array[15];
				cdimported = array[16];
				credits = string.Format(array[173], Environment.NewLine);
			}
			
			GameObject MyGameObject = new GameObject("Translate");
			MyGameObject.AddComponent<UpdateMainMenu>();
			
			GameObject.Find("Interface").transform.Find("Credits/CreditsTV/creditsCAM/name").gameObject.GetComponents<PlayMakerFSM>()[0].Fsm.InitData();
			HutongGames.PlayMaker.Actions.SetProperty creditsstring = GameObject.Find("Interface").transform.Find("Credits/CreditsTV/creditsCAM/name").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[2] as HutongGames.PlayMaker.Actions.SetProperty;
			creditsstring.targetProperty.StringParameter = credits;
		}
		
		public override void OnNewGame()
		{
			path = ModLoader.GetModAssetsFolder(this);
			
			string[] array = new string[339];
			{
				array = File.ReadAllLines(path + "/etranslate.txt");
				born = array[172];
			}
			
			GameObject.Find("Intro").transform.Find("title/name").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildString bornstring = GameObject.Find("Intro").transform.Find("title/name").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.BuildString;
			bornstring.stringParts[1] = born;
		}
		
		public override void OnLoad()
		{
			path = ModLoader.GetModAssetsFolder(this);
			
			string[] array = new string[339];
			{
				array = File.ReadAllLines(path + "/etranslate.txt");
				cashreg = array[0];
				mk = array[1];
				takemoney = array[2];
				standat = array[3];
				currentbet = array[4];
				hitcards = array[5];
				addevilery = array[6];
				ruler = array[7];
				alctest1 = array[8];
				alctest2 = array[9];
				dumpfi = array[10];
				dump1 = array[11];
				dump2 = array[12];
				unpaidfines = array[13];
				reddrag = array[17];
				monday = array[18];
				tuesday = array[19];
				wednesday = array[20];
				thursday = array[21];
				friday = array[22];
				saturday = array[23];
				sunday = array[24];
				finews0 = string.Format(array[25], Environment.NewLine);
				finews1 = string.Format(array[26], Environment.NewLine);
				finews2 = string.Format(array[27], Environment.NewLine);
				finews3 = string.Format(array[28], Environment.NewLine);
				finews4 = string.Format(array[29], Environment.NewLine);
				finews5 = string.Format(array[30], Environment.NewLine);
				finews6 = string.Format(array[31], Environment.NewLine);
				finews7 = string.Format(array[32], Environment.NewLine);
				finews8 = string.Format(array[33], Environment.NewLine);
				finews9 = string.Format(array[34], Environment.NewLine);
				finews10 = string.Format(array[35], Environment.NewLine);
				finews11 = string.Format(array[36], Environment.NewLine);
				finews12 = string.Format(array[37], Environment.NewLine);
				finews13 = string.Format(array[38], Environment.NewLine);
				finews14 = string.Format(array[39], Environment.NewLine);
				finews15 = string.Format(array[40], Environment.NewLine);
				finews16 = string.Format(array[41], Environment.NewLine);
				wdnews0 = string.Format(array[42], Environment.NewLine);
				wdnews1 = string.Format(array[43], Environment.NewLine);
				econews0 = string.Format(array[44], Environment.NewLine);
				econews1 = string.Format(array[45], Environment.NewLine);
				econews2 = string.Format(array[46], Environment.NewLine);
				econews3 = string.Format(array[47], Environment.NewLine);
				econews4 = string.Format(array[48], Environment.NewLine);
				econews5 = string.Format(array[49], Environment.NewLine);
				econews6 = string.Format(array[50], Environment.NewLine);
				weather1 = array[51];
				weather2 = array[52];
				weather3 = array[53];
				weather4 = array[54];
				sportnews0 = string.Format(array[55], Environment.NewLine);
				sportnews1 = string.Format(array[56], Environment.NewLine);
				sportnews2 = string.Format(array[57], Environment.NewLine);
				sportnews3 = string.Format(array[58], Environment.NewLine);
				sportnews4 = string.Format(array[59], Environment.NewLine);
				sportnews5 = string.Format(array[60], Environment.NewLine);
				sportnews6 = string.Format(array[61], Environment.NewLine);
				sportnews7 = string.Format(array[62], Environment.NewLine);
				sportnews8 = string.Format(array[63], Environment.NewLine);
				sportnews9 = string.Format(array[64], Environment.NewLine);
				sportnews10 = string.Format(array[65], Environment.NewLine);
				sportnews11 = string.Format(array[66], Environment.NewLine);
				recipe0 = string.Format(array[67], Environment.NewLine);
				recipe1 = string.Format(array[68], Environment.NewLine);
				recipe2 = string.Format(array[69], Environment.NewLine);
				recipe3 = string.Format(array[70], Environment.NewLine);
				recipe4 = string.Format(array[71], Environment.NewLine);
				quote0 = string.Format(array[72], Environment.NewLine);
				quote1 = string.Format(array[73], Environment.NewLine);
				quote2 = string.Format(array[74], Environment.NewLine);
				quote3 = string.Format(array[75], Environment.NewLine);
				quote4 = string.Format(array[76], Environment.NewLine);
				quote5 = string.Format(array[77], Environment.NewLine);
				quote6 = string.Format(array[78], Environment.NewLine);
				quote7 = string.Format(array[79], Environment.NewLine);
				quote8 = string.Format(array[80], Environment.NewLine);
				quote9 = string.Format(array[81], Environment.NewLine);
				quote10 = string.Format(array[82], Environment.NewLine);
				culture0 = string.Format(array[83], Environment.NewLine);
				culture1 = string.Format(array[84], Environment.NewLine);
				culture2 = string.Format(array[85], Environment.NewLine);
				culture3 = string.Format(array[86], Environment.NewLine);
				computer1 = array[87];
				computer2 = array[88];
				computer3 = array[89];
				computer4 = array[90];
				computer5 = array[91];
				computer6 = array[92];
				computer7 = array[93];
				computer8 = array[94];
				computer9 = array[95];
				computer10 = array[96];
				computer11 = array[97];
				computer12 = array[98];
				computer13 = array[99];
				computer14 = array[100];
				computer15 = array[101];
				computer16 = array[102];
				stop = array[103];
				haku = array[104];
				spdfineen1 = array[105];
				spdfineen2 = array[106];
				spdfineen3 = array[107];
				spdfinefi1 = array[108];
				spdfinefi2 = array[109];
				spdfinefi3 = array[110];
				rallysprint = array[111];
				insertdisc = array[112];
				errordisc = array[113];
				telebbs = array[114];
				sethandle = array[115];
				tooshort = array[116];
				sending = array[117];
				failsending = array[118];
				cccccccc = string.Format(array[119], Environment.NewLine);
				fishgame1 = array[120];
				fishgame2 = array[121];
				fishgame3 = array[122];
				fishgame4 = array[123];
				fishgame5 = array[124];
				fishgame6 = array[125];
				fishgame7 = array[126];
				fishgame8 = array[127];
				fishgame9 = array[128];
				fishgame10 = array[129];
				fishgame11 = array[130];
				fishgame12 = array[131];
				fishgame13 = array[132];
				fishgame14 = array[133];
				fishgame15 = array[134];
				fishgame16 = array[135];
				fishgame17 = array[136];
				fishgame18 = array[137];
				fishgame19 = array[138];
				fishgame20 = array[139];
				fishgame21 = array[140];
				fishgame22 = array[141];
				fishgame23 = array[142];
				gameover = array[143];
				newfishing1 = array[144];
				newfishing2 = array[145];
				newfishing3 = array[146];
				newfishing4 = array[147];
				newfishing5 = array[148];
				newfishing6 = array[149];
				newfishing7 = array[150];
				winpressenter = array[151];
				traumiren = array[152];
				compmemerror = array[153];
				shralresu1 = array[154];
				shralresu2 = array[155];
				shralresu3 = array[156];
				shralresu4 = array[157];
				rallyx = array[158];
				ttrally1 = array[159];
				ttrally2 = array[160];
				arrestwe1 = array[161];
				arrestwe2 = array[162];
				compcopy = array[163];
				compformat = array[164];
				compvolumea = array[165];
				compvolumec = array[166];
				playersting = array[167];
				gstring = array[168];
				rallyclass1 = array[169];
				rallyclass2 = array[170];
				rallyclass3 = array[171];
				born = array[172];
				credits = string.Format(array[173], Environment.NewLine);
				rallyname0 = array[174];
				rallyname1 = array[175];
				rallyname2 = array[176];
				rallyname3 = array[177];
				rallyname4 = array[178];
				rallyname5 = array[179];
				rallyname6 = array[180];
				rallyname7 = array[181];
				rallyname8 = array[182];
				rallyname9 = array[183];
				rallyname10 = array[184];
				rallyname11 = array[185];
				rallyname12 = array[186];
				rallyname13 = array[187];
				rallyname14 = array[188];
				rallyname15 = array[189];
				rallyname16 = array[190];
				rallyname17 = array[191];
				rallyname18 = array[192];
				rallyname19 = array[193];
				rallyname20 = array[194];
				rallyname21 = array[195];
				rallyname22 = array[196];
				rallyname23 = array[197];
				rallyname24 = array[198];
				rallyname25 = array[199];
				rallyname26 = array[200];
				rallyname27 = array[201];
				rallyname28 = array[202];
				rallyname29 = array[203];
				rallyname30 = array[204];
				rallyname31 = array[205];
				rallyname32 = array[206];
				rallyname33 = array[207];
				rallyname34 = array[208];
				rallyname35 = array[209];
				rallyname36 = array[210];
				rallyname37 = array[211];
				rallyname38 = array[212];
				rallyname39 = array[213];
				rallyname40 = array[214];
				rallyname41 = array[215];
				rallyname42 = array[216];
				rallyname43 = array[217];
				rallyname44 = array[218];
				rallyname45 = array[219];
				rallyname46 = array[220];
				rallyname47 = array[221];
				rallyname48 = array[222];
				rallyname49 = array[223];
				rallyname50 = array[224];
				rallyname51 = array[225];
				rallyname52 = array[226];
				rallyname53 = array[227];
				rallyname54 = array[228];
				rallyname55 = array[229];
				rallyname56 = array[230];
				rallyname57 = array[231];
				rallyname58 = array[232];
				rallyname59 = array[233];
				rallyname60 = array[234];
				rallyname61 = array[235];
				rallyname62 = array[236];
				rallyname63 = array[237];
				rallyname64 = array[238];
				rallyname65 = array[239];
				rallyname66 = array[240];
				rallyname67 = array[241];
				rallyname68 = array[242];
				rallyname69 = array[243];
				rallyname70 = array[244];
				rallyname71 = array[245];
				rallyname72 = array[246];
				rallyname73 = array[247];
				rallyname74 = array[248];
				rallyname75 = array[249];
				rallyname76 = array[250];
				rallyname77 = array[251];
				rallyname78 = array[252];
				rallyname79 = array[253];
				rallyname80 = array[254];
				rallyname81 = array[255];
				rallyname82 = array[256];
				rallyname83 = array[257];
				rallyname84 = array[258];
				rallyname85 = array[259];
				rallyname86 = array[260];
				rallyname87 = array[261];
				rallyname88 = array[262];
				rallyname89 = array[263];
				rallyname90 = array[264];
				rallyname91 = array[265];
				rallyname92 = array[266];
				rallyname93 = array[267];
				rallyname94 = array[268];
				rallyname95 = array[269];
				rallyname96 = array[270];
				rallyname97 = array[271];
				rallyname98 = array[272];
				rallyname99 = array[273];
				rallyname100 = array[274];
				rallyname101 = array[275];
				rallyname102 = array[276];
				rallyname103 = array[277];
				rallyname104 = array[278];
				rallyname105 = array[279];
				rallyname106 = array[280];
				rallyname107 = array[281];
				rallyname108 = array[282];
				fishname1 = array[283];
				fishname2 = array[284];
				fishname3 = array[285];
				fishname4 = array[286];
				fishname5 = array[287];
				fishname6 = array[288];
				fishname7 = array[289];
				dragname1 = array[290];
				dragname2 = array[291];
				dragname3 = array[292];
				dragname4 = array[293];
				dragname5 = array[294];
				spdfineen4 = array[295];
				spdfinefi4 = array[296];
				fetching = array[297];
				longstring1 = string.Format(array[298], Environment.NewLine);
				longstring2 = string.Format(array[299], Environment.NewLine);
				longstring3 = string.Format(array[300], Environment.NewLine);
				longstring4 = string.Format(array[301], Environment.NewLine);
				longstring5 = string.Format(array[302], Environment.NewLine);
				longstring6 = string.Format(array[303], Environment.NewLine);
				longstring7 = string.Format(array[304], Environment.NewLine);
				longstring8 = string.Format(array[305], Environment.NewLine);
				longstring9 = string.Format(array[306], Environment.NewLine);
				longstring10 = string.Format(array[307], Environment.NewLine);
				longstring11 = string.Format(array[308], Environment.NewLine);
				longstring12 = string.Format(array[309], Environment.NewLine);
				longstring13 = string.Format(array[310], Environment.NewLine);
				longstring14 = string.Format(array[311], Environment.NewLine);
				longstring15 = string.Format(array[312], Environment.NewLine);
				longstring16 = string.Format(array[313], Environment.NewLine);
				longstring17 = string.Format(array[314], Environment.NewLine);
				longstring18 = string.Format(array[315], Environment.NewLine);
				longstring19 = string.Format(array[316], Environment.NewLine);
				longstring20 = string.Format(array[317], Environment.NewLine);
				longstring21 = string.Format(array[318], Environment.NewLine);
				longstring22 = string.Format(array[319], Environment.NewLine);
				longstring23 = string.Format(array[320], Environment.NewLine);
				longstring24 = string.Format(array[321], Environment.NewLine);
				longstring25 = string.Format(array[322], Environment.NewLine);
				longstring26 = string.Format(array[323], Environment.NewLine);
				longstring27 = string.Format(array[324], Environment.NewLine);
				longstring28 = string.Format(array[325], Environment.NewLine);
				fleeteridriveway = string.Format(array[326], Environment.NewLine);
				teimohello = string.Format(array[327], Environment.NewLine);
				finews17 = string.Format(array[328], Environment.NewLine);
				wdnews2 = string.Format(array[329], Environment.NewLine);
				wdnews3 = string.Format(array[330], Environment.NewLine);
				wdnews4 = string.Format(array[331], Environment.NewLine);
				econews7 = string.Format(array[332], Environment.NewLine);
				econews8 = string.Format(array[333], Environment.NewLine);
				sportnews12 = string.Format(array[334], Environment.NewLine);
				culture4 = string.Format(array[335], Environment.NewLine);
				culture5 = string.Format(array[336], Environment.NewLine);
				culture6 = string.Format(array[337], Environment.NewLine);
				culture7 = string.Format(array[338], Environment.NewLine);
			}
			
			//Shop
			HutongGames.PlayMaker.Actions.BuildString shopstring = GameObject.Find("STORE/StoreCashRegister/Register").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Wait button").Actions[0] as HutongGames.PlayMaker.Actions.BuildString;
			shopstring.stringParts[0] = cashreg;
			shopstring.stringParts[2] = mk;
			//Repair shop
			HutongGames.PlayMaker.Actions.BuildString repairshopstring = GameObject.Find("REPAIRSHOP").transform.Find("LOD/Store/ShopCashRegister/Register").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Wait button").Actions[0] as HutongGames.PlayMaker.Actions.BuildString;			
			repairshopstring.stringParts[0] = cashreg;
			repairshopstring.stringParts[2] = mk;
			//Granny 
			GameObject.Find("JOBS/Mummola").transform.Find("LOD/GrannyTalking/Granny/Char/skeleton/pelvis/spine_middle/spine_upper/collar_right/shoulder_right/arm_right/hand_right/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildString granystring = GameObject.Find("JOBS/Mummola").transform.Find("LOD/GrannyTalking/Granny/Char/skeleton/pelvis/spine_middle/spine_upper/collar_right/shoulder_right/arm_right/hand_right/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[1] as HutongGames.PlayMaker.Actions.BuildString;
			granystring.stringParts[0] = takemoney;
			granystring.stringParts[2] = mk;
			//Shit 1
			GameObject.Find("JOBS/HouseShit1").transform.Find("LOD/ShitNPC/Man/skeleton/pelvis/RotationPivot/spine_middle/spine_upper/collar_left/shoulder_left/arm_left/hand_left/finger_left/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildString shit1string = GameObject.Find("JOBS/HouseShit1").transform.Find("LOD/ShitNPC/Man/skeleton/pelvis/RotationPivot/spine_middle/spine_upper/collar_left/shoulder_left/arm_left/hand_left/finger_left/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[1] as HutongGames.PlayMaker.Actions.BuildString;
			shit1string.stringParts[0] = takemoney;
			shit1string.stringParts[2] = mk;
			//Shit 2
			GameObject.Find("JOBS/HouseShit2").transform.Find("LOD/ShitNPC/Man/skeleton/pelvis/RotationPivot/spine_middle/spine_upper/collar_left/shoulder_left/arm_left/hand_left/finger_left/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildString shit2string = GameObject.Find("JOBS/HouseShit2").transform.Find("LOD/ShitNPC/Man/skeleton/pelvis/RotationPivot/spine_middle/spine_upper/collar_left/shoulder_left/arm_left/hand_left/finger_left/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[1] as HutongGames.PlayMaker.Actions.BuildString;
			shit2string.stringParts[0] = takemoney;
			shit2string.stringParts[2] = mk;
			ModConsole.Print("Extra translated: 1/8");
			//Shit 3
			GameObject.Find("JOBS/HouseShit3").transform.Find("LOD/ShitNPC/Man/skeleton/pelvis/RotationPivot/spine_middle/spine_upper/collar_left/shoulder_left/arm_left/hand_left/finger_left/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildString shit3string = GameObject.Find("JOBS/HouseShit3").transform.Find("LOD/ShitNPC/Man/skeleton/pelvis/RotationPivot/spine_middle/spine_upper/collar_left/shoulder_left/arm_left/hand_left/finger_left/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[1] as HutongGames.PlayMaker.Actions.BuildString;
			shit3string.stringParts[0] = takemoney;
			shit3string.stringParts[2] = mk;
			//Shit 4
			GameObject.Find("JOBS/HouseShit4").transform.Find("LOD/ShitNPC/Man/skeleton/pelvis/RotationPivot/spine_middle/spine_upper/collar_left/shoulder_left/arm_left/hand_left/finger_left/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildString shit4string = GameObject.Find("JOBS/HouseShit4").transform.Find("LOD/ShitNPC/Man/skeleton/pelvis/RotationPivot/spine_middle/spine_upper/collar_left/shoulder_left/arm_left/hand_left/finger_left/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[1] as HutongGames.PlayMaker.Actions.BuildString;
			shit4string.stringParts[0] = takemoney;
			shit4string.stringParts[2] = mk;
			//Shit 5
			GameObject.Find("JOBS/HouseShit5").transform.Find("LOD/ShitNPC/Man/skeleton/pelvis/RotationPivot/spine_middle/spine_upper/collar_left/shoulder_left/arm_left/hand_left/finger_left/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildString shit5string = GameObject.Find("JOBS/HouseShit5").transform.Find("LOD/ShitNPC/Man/skeleton/pelvis/RotationPivot/spine_middle/spine_upper/collar_left/shoulder_left/arm_left/hand_left/finger_left/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[1] as HutongGames.PlayMaker.Actions.BuildString;
			shit5string.stringParts[0] = takemoney;
			shit5string.stringParts[2] = mk;
			//Moving
			if(GameObject.Find("JOBS/HouseDrunk").transform.Find("Moving/JokkeHiker1") != null)
			{
				GameObject.Find("JOBS/HouseDrunk").transform.Find("Moving/JokkeHiker1/Pivot/Char/skeleton/pelvis/spine_middle/spine_upper/collar_right/shoulder_right/arm_right/hand_right/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
				HutongGames.PlayMaker.Actions.BuildString movingstring = GameObject.Find("JOBS/HouseDrunk").transform.Find("Moving/JokkeHiker1/Pivot/Char/skeleton/pelvis/spine_middle/spine_upper/collar_right/shoulder_right/arm_right/hand_right/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Calc money").Actions[1] as HutongGames.PlayMaker.Actions.BuildString;
				movingstring.stringParts[0] = takemoney;
				movingstring.stringParts[2] = mk;
			}
			//Hitch
			if(GameObject.Find("KILJUGUY/HikerPivot").transform.Find("JokkeHiker2/Char") != null)
			{
				GameObject.Find("KILJUGUY/HikerPivot").transform.Find("JokkeHiker2/Char/skeleton/pelvis/spine_middle/spine_upper/collar_right/shoulder_right/arm_right/hand_right/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
				HutongGames.PlayMaker.Actions.BuildString hitchstring = GameObject.Find("KILJUGUY/HikerPivot").transform.Find("JokkeHiker2/Char/skeleton/pelvis/spine_middle/spine_upper/collar_right/shoulder_right/arm_right/hand_right/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[5] as HutongGames.PlayMaker.Actions.BuildString;
				hitchstring.stringParts[0] = takemoney;
				hitchstring.stringParts[2] = mk;
			}
			//KiljuOld
			if(GameObject.Find("JOBS/HouseDrunk").transform.Find("BeerCampOld/BeerCamp/KiljuBuyer") != null)
			{
				GameObject.Find("JOBS/HouseDrunk").transform.Find("BeerCampOld/BeerCamp/KiljuBuyer/Char/skeleton/pelvis/spine_middle/spine_upper/collar_left/shoulder_left/arm_left/hand_left/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
				HutongGames.PlayMaker.Actions.BuildString kiljustring = GameObject.Find("JOBS/HouseDrunk").transform.Find("BeerCampOld/BeerCamp/KiljuBuyer/Char/skeleton/pelvis/spine_middle/spine_upper/collar_left/shoulder_left/arm_left/hand_left/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[1] as HutongGames.PlayMaker.Actions.BuildString;
				kiljustring.stringParts[0] = takemoney;
				kiljustring.stringParts[2] = mk;
			}	
			//KiljuNew
			if(GameObject.Find("JOBS/HouseDrunkNew").transform.Find("BeerCampNew/BeerCamp") != null)
			{
				GameObject.Find("JOBS/HouseDrunkNew").transform.Find("BeerCampNew/BeerCamp/KiljuBuyer/Char/skeleton/pelvis/spine_middle/spine_upper/collar_left/shoulder_left/arm_left/hand_left/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
				HutongGames.PlayMaker.Actions.BuildString kiljunewstring = GameObject.Find("JOBS/HouseDrunkNew").transform.Find("BeerCampNew/BeerCamp/KiljuBuyer/Char/skeleton/pelvis/spine_middle/spine_upper/collar_left/shoulder_left/arm_left/hand_left/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[1] as HutongGames.PlayMaker.Actions.BuildString;
				kiljunewstring.stringParts[0] = takemoney;
				kiljunewstring.stringParts[2] = mk;
			}
			ModConsole.Print("Extra translated: 2/8");
			//Wood
			GameObject.Find("JOBS/HouseWood1").transform.Find("LOD/NPC/Char/skeleton/pelvis/spine_middle/spine_upper/collar_right/shoulder_right/arm_right/hand_right/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildString woodstring = GameObject.Find("JOBS/HouseWood1").transform.Find("LOD/NPC/Char/skeleton/pelvis/spine_middle/spine_upper/collar_right/shoulder_right/arm_right/hand_right/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[1] as HutongGames.PlayMaker.Actions.BuildString;
			woodstring.stringParts[0] = takemoney;
			woodstring.stringParts[2] = mk;
			//Uncle
			GameObject.Find("YARD/UNCLE").transform.Find("UncleWalking/Uncle/Char/skeleton/pelvis/spine_middle/spine_upper/collar_right/shoulder_right/arm_right/hand_right/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildString unclestring = GameObject.Find("YARD/UNCLE").transform.Find("UncleWalking/Uncle/Char/skeleton/pelvis/spine_middle/spine_upper/collar_right/shoulder_right/arm_right/hand_right/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[5] as HutongGames.PlayMaker.Actions.BuildString;
			unclestring.stringParts[0] = takemoney;
			unclestring.stringParts[2] = mk;
			//Rally
			GameObject.Find("RALLY").transform.Find("Sunday/FinishArea/Stuff/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildString rallystring = GameObject.Find("RALLY").transform.Find("Sunday/FinishArea/Stuff/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[1] as HutongGames.PlayMaker.Actions.BuildString;
			rallystring.stringParts[0] = takemoney;
			rallystring.stringParts[2] = mk;
			//junk
			GameObject.Find("REPAIRSHOP").transform.Find("JunkYardJob/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildString junkstring = GameObject.Find("REPAIRSHOP").transform.Find("JunkYardJob/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[1] as HutongGames.PlayMaker.Actions.BuildString;
			junkstring.stringParts[0] = takemoney;
			junkstring.stringParts[2] = mk;
			//ventti stand at
			if(GameObject.Find("CABIN/Cabin/Ventti/Table/GAME/Gamestuff") != null)
			{
				GameObject.Find("CABIN").transform.Find("Cabin/Ventti/Table/GAME/Gamestuff/Stand").GetComponent<PlayMakerFSM>().Fsm.InitData();
				HutongGames.PlayMaker.Actions.BuildStringFast standatstring = GameObject.Find("CABIN").transform.Find("Cabin/Ventti/Table/GAME/Gamestuff/Stand").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Wait button").Actions[2] as HutongGames.PlayMaker.Actions.BuildStringFast;
				standatstring.stringParts[0] = standat;
				//ventti current bet
				GameObject.Find("CABIN").transform.Find("Cabin/Ventti/Table/GAME/Gamestuff/Bet").GetComponent<PlayMakerFSM>().Fsm.InitData();
				HutongGames.PlayMaker.Actions.BuildStringFast curbetstring = GameObject.Find("CABIN").transform.Find("Cabin/Ventti/Table/GAME/Gamestuff/Bet").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Wait button").Actions[1] as HutongGames.PlayMaker.Actions.BuildStringFast;
				curbetstring.stringParts[0] = currentbet;
				curbetstring.stringParts[2] = mk;
				//ventti hit cards
				GameObject.Find("CABIN").transform.Find("Cabin/Ventti/Table/GAME/Gamestuff/HitPlayer").GetComponent<PlayMakerFSM>().Fsm.InitData();
				HutongGames.PlayMaker.Actions.SetStringValue hitcardstring = GameObject.Find("CABIN").transform.Find("Cabin/Ventti/Table/GAME/Gamestuff/HitPlayer").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Wait button").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;
				hitcardstring.stringValue = hitcards;
			}
			ModConsole.Print("Extra translated: 3/8");
			//ad devilery
			HutongGames.PlayMaker.Actions.BuildStringFast addevilstring = GameObject.Find("STORE").transform.Find("LOD/ActivateStore/PayMoneyAdvert").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Calculate").Actions[4] as HutongGames.PlayMaker.Actions.BuildStringFast;
			addevilstring.stringParts[0] = addevilery;
			addevilstring.stringParts[2] = mk;

			//ruler
			GameObject.Find("PLAYER").transform.Find("Pivot/AnimPivot/Camera/FPSCamera/2Spanner/Pivot/Ruler").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildStringFast rulerstring = GameObject.Find("PLAYER").transform.Find("Pivot/AnimPivot/Camera/FPSCamera/2Spanner/Pivot/Ruler").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Condition").Actions[2] as HutongGames.PlayMaker.Actions.BuildStringFast;
			rulerstring.stringParts[0] = ruler;

			//alc test
			GameObject Sheets = Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "TrafficTicket").transform.parent.gameObject;
			Sheets.transform.Find("TrafficTicket/TicketData").GetComponent<PlayMakerFSM>().Fsm.InitData();

			HutongGames.PlayMaker.Actions.BuildString alctest1string = Sheets.transform.Find("TrafficTicket/TicketData").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Calc fine 2").Actions[4] as HutongGames.PlayMaker.Actions.BuildString;
			alctest1string.stringParts[0] = alctest1;
			alctest1string.stringParts[2] = alctest2;

			HutongGames.PlayMaker.Actions.BuildString alctest2string = Sheets.transform.Find("TrafficTicket/TicketData").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Calc fine 2").Actions[5] as HutongGames.PlayMaker.Actions.BuildString;
			alctest2string.stringParts[0] = alctest1;
			alctest2string.stringParts[2] = alctest2;
			
			Sheets.transform.Find("EnviroCrime/TicketData").GetComponent<PlayMakerFSM>().Fsm.InitData();
			
			HutongGames.PlayMaker.Actions.BuildString dump1string = Sheets.transform.Find("EnviroCrime/TicketData").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Calc fine 5").Actions[8] as HutongGames.PlayMaker.Actions.BuildString;
			dump1string.stringParts[1] = dumpfi;

			HutongGames.PlayMaker.Actions.BuildString dump2string = Sheets.transform.Find("EnviroCrime/TicketData").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Calc fine 5").Actions[9] as HutongGames.PlayMaker.Actions.BuildString;
			dump2string.stringParts[0] = dump1;
			dump2string.stringParts[2] = dump2;

			HutongGames.PlayMaker.Actions.BuildString speed1string = Sheets.transform.Find("TrafficTicket/TicketData").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "100kmh").Actions[4] as HutongGames.PlayMaker.Actions.BuildString;
			speed1string.stringParts[0] = spdfinefi1;
			speed1string.stringParts[2] = spdfinefi3;

			HutongGames.PlayMaker.Actions.BuildString speed2string = Sheets.transform.Find("TrafficTicket/TicketData").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "100kmh").Actions[5] as HutongGames.PlayMaker.Actions.BuildString;
			speed2string.stringParts[0] = spdfineen1;
			speed2string.stringParts[2] = spdfineen2;

			HutongGames.PlayMaker.Actions.BuildString speed3string = Sheets.transform.Find("TrafficTicket/TicketData").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "80kmh").Actions[4] as HutongGames.PlayMaker.Actions.BuildString;
			speed3string.stringParts[0] = spdfinefi2;
			speed3string.stringParts[2] = spdfinefi3;

			HutongGames.PlayMaker.Actions.BuildString speed4string = Sheets.transform.Find("TrafficTicket/TicketData").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "80kmh").Actions[5] as HutongGames.PlayMaker.Actions.BuildString;
			speed4string.stringParts[0] = spdfineen1;
			speed4string.stringParts[2] = spdfineen3;

			HutongGames.PlayMaker.Actions.BuildString speed5string = Sheets.transform.Find("TrafficTicket/TicketData").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "45kmh").Actions[4] as HutongGames.PlayMaker.Actions.BuildString;
			speed5string.stringParts[0] = spdfinefi4;
			speed5string.stringParts[2] = spdfinefi3;

			HutongGames.PlayMaker.Actions.BuildString speed6string = Sheets.transform.Find("TrafficTicket/TicketData").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "45kmh").Actions[5] as HutongGames.PlayMaker.Actions.BuildString;
			speed6string.stringParts[0] = spdfineen1;
			speed6string.stringParts[2] = spdfineen4;

			//rally results sheet
			Sheets.transform.Find("RallyResults/PlayerPenalties").GetComponent<PlayMakerFSM>().Fsm.InitData();
			
			HutongGames.PlayMaker.Actions.BuildStringFast ralressheetstring1 = Sheets.transform.Find("RallyResults/PlayerPenalties").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[6] as HutongGames.PlayMaker.Actions.BuildStringFast;
			ralressheetstring1.stringParts[0] = shralresu1;
			ralressheetstring1.stringParts[2] = shralresu2;
			
			HutongGames.PlayMaker.Actions.BuildStringFast ralressheetstring2 = Sheets.transform.Find("RallyResults/PlayerPenalties").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[7] as HutongGames.PlayMaker.Actions.BuildStringFast;
			ralressheetstring2.stringParts[0] = shralresu3;
			ralressheetstring2.stringParts[2] = rallyx;

			HutongGames.PlayMaker.Actions.BuildStringFast ralressheetstring3 = Sheets.transform.Find("RallyResults/PlayerPenalties").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[8] as HutongGames.PlayMaker.Actions.BuildStringFast;
			ralressheetstring3.stringParts[0] = shralresu4;
			ralressheetstring3.stringParts[2] = rallyx;
			
			Sheets.transform.Find("RallyResults/PlayerResults").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildStringFast ralressheetstring4 = Sheets.transform.Find("RallyResults/PlayerResults").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.BuildStringFast;
			ralressheetstring4.stringParts[0] = rallyclass3;
			ralressheetstring4.stringParts[1] = rallyclass1;
			
			HutongGames.PlayMaker.Actions.SetProperty ralressheetstring5 = Sheets.transform.Find("RallyResults/PlayerResults").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[2] as HutongGames.PlayMaker.Actions.SetProperty;
			ralressheetstring5.targetProperty.StringParameter = rallyclass2;
			
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 0"] = rallyname0;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 1"] = rallyname1;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 2"] = rallyname2;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 3"] = rallyname3;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 4"] = rallyname4;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 5"] = rallyname5;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 6"] = rallyname6;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 7"] = rallyname7;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 8"] = rallyname8;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 9"] = rallyname9;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 10"] = rallyname10;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 11"] = rallyname11;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 12"] = rallyname12;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 13"] = rallyname13;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 14"] = rallyname14;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 15"] = rallyname15;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 16"] = rallyname16;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 17"] = rallyname17;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 18"] = rallyname18;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 19"] = rallyname19;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 20"] = rallyname20;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 21"] = rallyname21;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 22"] = rallyname22;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 23"] = rallyname23;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 24"] = rallyname24;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 25"] = rallyname25;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 26"] = rallyname26;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 27"] = rallyname27;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 28"] = rallyname28;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 29"] = rallyname29;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 30"] = rallyname30;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 31"] = rallyname31;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 32"] = rallyname32;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 33"] = rallyname33;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 34"] = rallyname34;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 35"] = rallyname35;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 36"] = rallyname36;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 37"] = rallyname37;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 38"] = rallyname38;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 39"] = rallyname39;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 40"] = rallyname40;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 41"] = rallyname41;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 42"] = rallyname42;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 43"] = rallyname43;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 44"] = rallyname44;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 45"] = rallyname45;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 46"] = rallyname46;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 47"] = rallyname47;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 48"] = rallyname48;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[0]._hashTable["key 49"] = rallyname49;

			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 0"] = rallyname50;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 1"] = rallyname51;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 2"] = rallyname52;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 3"] = rallyname53;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 4"] = rallyname54;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 5"] = rallyname55;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 6"] = rallyname56;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 7"] = rallyname57;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 8"] = rallyname58;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 9"] = rallyname59;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 10"] = rallyname60;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 11"] = rallyname61;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 12"] = rallyname62;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 13"] = rallyname63;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 14"] = rallyname64;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 15"] = rallyname65;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 16"] = rallyname66;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 17"] = rallyname67;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 18"] = rallyname68;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 19"] = rallyname69;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 20"] = rallyname70;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 21"] = rallyname71;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 22"] = rallyname72;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 23"] = rallyname73;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 24"] = rallyname74;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 25"] = rallyname75;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 26"] = rallyname76;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 27"] = rallyname77;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 28"] = rallyname78;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 29"] = rallyname79;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 30"] = rallyname80;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 31"] = rallyname81;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 32"] = rallyname82;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 33"] = rallyname83;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 34"] = rallyname84;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 35"] = rallyname85;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 36"] = rallyname86;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 37"] = rallyname87;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 38"] = rallyname88;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 39"] = rallyname89;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 40"] = rallyname90;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 41"] = rallyname91;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 42"] = rallyname92;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 43"] = rallyname93;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 44"] = rallyname94;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 45"] = rallyname95;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 46"] = rallyname96;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 47"] = rallyname97;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 48"] = rallyname98;
			GameObject.Find("RALLY/DriversList").GetComponents<PlayMakerHashTableProxy>()[1]._hashTable["key 49"] = rallyname99;
			//unpaid fines
			GameObject.Find("YARD/Building").transform.Find("Dynamics/Fines").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildString unpfinestring = GameObject.Find("YARD/Building").transform.Find("Dynamics/Fines").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[1] as HutongGames.PlayMaker.Actions.BuildString;
			unpfinestring.stringParts[0] = unpaidfines;
			unpfinestring.stringParts[2] = mk;
			ModConsole.Print("Extra translated: 4/8");
			//teletext days
			ArrayList daylist = new ArrayList();
			daylist.AddRange(new string[] { "?", monday, tuesday, wednesday, thursday, friday, saturday, sunday });
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[0]._arrayList = daylist;
			//tt weather
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/CurrentWeather").GetComponent<PlayMakerFSM>().Fsm.InitData();
			
			HutongGames.PlayMaker.Actions.SetStringValue weather11string = GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/CurrentWeather").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			weather11string.stringValue = weather1;
			
			HutongGames.PlayMaker.Actions.SetStringValue weather12string = GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/CurrentWeather").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 4").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			weather12string.stringValue = weather2;
			
			HutongGames.PlayMaker.Actions.SetStringValue weather13string = GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/CurrentWeather").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 5").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			weather13string.stringValue = weather3;
			
			HutongGames.PlayMaker.Actions.SetStringValue weather14string = GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/CurrentWeather").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 6").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			weather14string.stringValue = weather4;
			
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Forecast").GetComponent<PlayMakerFSM>().Fsm.InitData();

			HutongGames.PlayMaker.Actions.SetStringValue weather21string = GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Forecast").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			weather21string.stringValue = weather1;
			
			HutongGames.PlayMaker.Actions.SetStringValue weather22string = GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Forecast").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 4").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			weather22string.stringValue = weather2;
			
			HutongGames.PlayMaker.Actions.SetStringValue weather23string = GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Forecast").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 5").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			weather23string.stringValue = weather3;
			
			HutongGames.PlayMaker.Actions.SetStringValue weather24string = GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/188/Texts/Forecast").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 6").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			weather24string.stringValue = weather4;
			//teletext rally
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/TeleTextResults").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.SetProperty ttrallystring = GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/TeleTextResults").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
			ttrallystring.targetProperty.StringParameter = ttrally1;
			//teletext rally
			GameObject.Find("RALLY/RallyTV").transform.Find("Program/RallyTVGUI/Results").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.SetProperty ttrally2string = GameObject.Find("RALLY/RallyTV").transform.Find("Program/RallyTVGUI/Results").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
			ttrally2string.targetProperty.StringParameter = ttrally2;
			//computer
			if(GameObject.Find("YARD/Building/BEDROOM1") != null)
			{				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/POS/BootSequence").GetComponent<PlayMakerFSM>().Fsm.InitData();

				HutongGames.PlayMaker.Actions.BuildStringFast comp1string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/BootSequence").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.BuildStringFast;
				comp1string.stringParts[0] = computer1;

				HutongGames.PlayMaker.Actions.BuildStringFast comp2string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/BootSequence").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[0] as HutongGames.PlayMaker.Actions.BuildStringFast;
				comp2string.stringParts[2] = computer2;

				HutongGames.PlayMaker.Actions.BuildStringFast comp3string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/BootSequence").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 4").Actions[0] as HutongGames.PlayMaker.Actions.BuildStringFast;
				comp3string.stringParts[1] = computer3;

				HutongGames.PlayMaker.Actions.BuildStringFast comp4string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/BootSequence").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 5").Actions[0] as HutongGames.PlayMaker.Actions.BuildStringFast;
				comp4string.stringParts[1] = computer4;

				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponent<PlayMakerFSM>().Fsm.InitData();

				HutongGames.PlayMaker.Actions.SetStringValue comp5string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Error").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
				comp5string.stringValue = computer5;

				HutongGames.PlayMaker.Actions.SetStringValue comp6string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Format disk").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
				comp6string.stringValue = computer6;

				HutongGames.PlayMaker.Actions.SetStringValue comp7string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Format drive").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
				comp7string.stringValue = computer6;

				HutongGames.PlayMaker.Actions.SetStringValue comp8string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Copy disk").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;
				comp8string.stringValue = computer7;
				
				HutongGames.PlayMaker.Actions.SetStringValue comp9string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Data error").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;
				comp9string.stringValue = computer8;
				
				HutongGames.PlayMaker.Actions.SetFsmString comp10string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Write new line 2").Actions[0] as HutongGames.PlayMaker.Actions.SetFsmString;
				comp10string.setValue = computer9;
				
				HutongGames.PlayMaker.Actions.SetStringValue comp11string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Reset POS 2").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
				comp11string.stringValue = computer10;
				
				HutongGames.PlayMaker.Actions.SetStringValue comp12string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Error 2").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
				comp12string.stringValue = computer11;
				
				HutongGames.PlayMaker.Actions.SetFsmString comp13string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Calling...").Actions[0] as HutongGames.PlayMaker.Actions.SetFsmString;
				comp13string.setValue = computer12;
				
				HutongGames.PlayMaker.Actions.SetFsmString comp14string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Waiting...").Actions[0] as HutongGames.PlayMaker.Actions.SetFsmString;
				comp14string.setValue = computer13;
				
				HutongGames.PlayMaker.Actions.SetFsmString comp15string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Calling....").Actions[0] as HutongGames.PlayMaker.Actions.SetFsmString;
				comp15string.setValue = computer12;
				
				HutongGames.PlayMaker.Actions.SetStringValue comp16string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Wrong number").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
				comp16string.stringValue = computer14;
				
				HutongGames.PlayMaker.Actions.SetStringValue comp17string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Incorrect").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
				comp17string.stringValue = computer15;

				HutongGames.PlayMaker.Actions.SetStringValue comp18string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "New baud").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
				comp18string.stringValue = computer16;
				
				HutongGames.PlayMaker.Actions.SetStringValue compmemerrorstring = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Mem error").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;
				compmemerrorstring.stringValue = compmemerror;
				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/POS/NoOS").GetComponent<PlayMakerFSM>().Fsm.InitData();
				
				HutongGames.PlayMaker.Actions.SetProperty insertstring = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/NoOS").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				insertstring.targetProperty.StringParameter = insertdisc;
				
				HutongGames.PlayMaker.Actions.SetProperty errordiscstring = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/NoOS").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				errordiscstring.targetProperty.StringParameter = errordisc;
				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/TELEBBS/Software/text").transform.GetComponent<TextMesh>().text = telebbs;
				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/TELEBBS/Software/StatusBar").GetComponent<PlayMakerFSM>().Fsm.InitData();
				
				HutongGames.PlayMaker.Actions.SetProperty notconstring = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/Software/StatusBar").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				notconstring.targetProperty.StringParameter = computer9;

				HutongGames.PlayMaker.Actions.BuildStringFast compcopystring = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Copyying").Actions[4] as HutongGames.PlayMaker.Actions.BuildStringFast;
				compcopystring.stringParts[0] = compcopy;
				
				HutongGames.PlayMaker.Actions.BuildStringFast compformat1string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Remove mem").Actions[3] as HutongGames.PlayMaker.Actions.BuildStringFast;
				compformat1string.stringParts[0] = compformat;
				
				HutongGames.PlayMaker.Actions.BuildStringFast compformat2string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Remove mem 2").Actions[3] as HutongGames.PlayMaker.Actions.BuildStringFast;
				compformat2string.stringParts[0] = compformat;
				
				HutongGames.PlayMaker.Actions.StringAddNewLine compvolumeastring = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Dir list A").Actions[3] as HutongGames.PlayMaker.Actions.StringAddNewLine;
				compvolumeastring.stringParts[1] = compvolumea;
				
				HutongGames.PlayMaker.Actions.StringAddNewLine compvolumecstring = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/POS/CommandPrompt").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Dir list C").Actions[3] as HutongGames.PlayMaker.Actions.StringAddNewLine;
				compvolumecstring.stringParts[1] = compvolumec;
			}
			ModConsole.Print("Extra translated: 5/8");
			//conline
			if(GameObject.Find("YARD/Building/BEDROOM1") != null)
			{
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/Initialize").GetComponent<PlayMakerFSM>().Fsm.InitData();
				
				HutongGames.PlayMaker.Actions.SetProperty sethandlestring = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/Initialize").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Wait").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				sethandlestring.targetProperty.StringParameter = sethandle;
				
				HutongGames.PlayMaker.Actions.SetProperty tooshortstring = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/Initialize").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Too short").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				tooshortstring.targetProperty.StringParameter = tooshort;
				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/CHAT").GetComponent<PlayMakerFSM>().Fsm.InitData();
				
				HutongGames.PlayMaker.Actions.SetProperty sendingstring = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/CHAT").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Download").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				sendingstring.targetProperty.StringParameter = sending;
				
				HutongGames.PlayMaker.Actions.SetProperty sendinfailgstring = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/CHAT").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Fail").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				sendinfailgstring.targetProperty.StringParameter = failsending;
				
				HutongGames.PlayMaker.Actions.SetProperty fetchingstring = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/CHAT").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Upload").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				fetchingstring.targetProperty.StringParameter = fetching;
				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/TELEBBS/CONLINE/GFX/text").transform.GetComponent<TextMesh>().text = cccccccc;
			}
			//computer games
			if(GameObject.Find("YARD/Building/BEDROOM1") != null)
			{
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kaljalaskuri").GetComponent<PlayMakerFSM>().Fsm.InitData();
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame1string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kaljalaskuri").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Reset").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame1string.targetProperty.StringParameter = fishgame1;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame2string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kaljalaskuri").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "kännikala 6").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame2string.targetProperty.StringParameter = fishgame2;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame3string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kaljalaskuri").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Kalja 1").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame3string.targetProperty.StringParameter = fishgame3;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame4string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kaljalaskuri").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Kalja 2").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame4string.targetProperty.StringParameter = fishgame4;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame5string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kaljalaskuri").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Kalja 3").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame5string.targetProperty.StringParameter = fishgame5;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame6string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kaljalaskuri").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Kalja 4").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame6string.targetProperty.StringParameter = fishgame6;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame7string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kaljalaskuri").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Kalja 5").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame7string.targetProperty.StringParameter = fishgame7;
				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().Fsm.InitData();
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame8string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Peruskala").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame8string.targetProperty.StringParameter = fishgame8;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame9string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Karkasi").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame9string.targetProperty.StringParameter = fishgame9;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame10string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Ahven").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame10string.targetProperty.StringParameter = fishgame10;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame11string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Hauki").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame11string.targetProperty.StringParameter = fishgame11;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame12string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Särki").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame12string.targetProperty.StringParameter = fishgame12;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame13string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Lahna").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame13string.targetProperty.StringParameter = fishgame13;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame14string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Kalakukko").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame14string.targetProperty.StringParameter = fishgame14;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame15string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Sakko").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame15string.targetProperty.StringParameter = fishgame15;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame16string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Kännikala").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame16string.targetProperty.StringParameter = fishgame16;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame17string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Erikoiskala").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame17string.targetProperty.StringParameter = fishgame17;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame18string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "UKK").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame18string.targetProperty.StringParameter = fishgame18;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame19string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Kultakala").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame19string.targetProperty.StringParameter = fishgame19;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame20string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Rahasäkki").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame20string.targetProperty.StringParameter = fishgame20;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame21string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Tonnikala").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame21string.targetProperty.StringParameter = fishgame21;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame22string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Kala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Rosvo").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame22string.targetProperty.StringParameter = fishgame22;
				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/MENU").GetComponent<PlayMakerFSM>().Fsm.InitData();
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame23string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/MENU").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault().Actions[5] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame23string.targetProperty.StringParameter = fishgame23;
				
				HutongGames.PlayMaker.Actions.SetProperty fishgame24string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/MENU").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Play").Actions[2] as HutongGames.PlayMaker.Actions.SetProperty;
				fishgame24string.targetProperty.StringParameter = mk;
				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/Kaappis-Grilli/Asiakkaat").GetComponent<PlayMakerFSM>().Fsm.InitData();
				
				HutongGames.PlayMaker.Actions.SetProperty grillistring = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Grilli/Asiakkaat").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Game over").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				grillistring.targetProperty.StringParameter = gameover;
				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/Saalis").GetComponent<PlayMakerFSM>().Fsm.InitData();
				
				HutongGames.PlayMaker.Actions.SetStringValue newfishing3string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/Saalis").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 7").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;
				newfishing3string.stringValue = newfishing1;
				
				HutongGames.PlayMaker.Actions.SetStringValue newfishing4string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/Saalis").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 8").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;
				newfishing4string.stringValue = newfishing2;
				
				HutongGames.PlayMaker.Actions.SetStringValue newfishing5string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/Saalis").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 11").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;
				newfishing5string.stringValue = newfishing3;
				
				HutongGames.PlayMaker.Actions.SetStringValue newfishing6string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/Saalis").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 16").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;
				newfishing6string.stringValue = newfishing4;
				
				HutongGames.PlayMaker.Actions.SetStringValue newfishing7string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/Saalis").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 21").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;
				newfishing7string.stringValue = newfishing5;
				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Tulokset/TuloksetKisa/SuurinKala").GetComponent<PlayMakerFSM>().Fsm.InitData();
				
				HutongGames.PlayMaker.Actions.BuildStringFast newfishing8string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Tulokset/TuloksetKisa/SuurinKala").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[5] as HutongGames.PlayMaker.Actions.BuildStringFast;
				newfishing8string.stringParts[0] = newfishing6;
				newfishing8string.stringParts[4] = newfishing7;
				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Alkuvalikko/Asetukset").GetComponents<PlayMakerFSM>()[1].Fsm.InitData();
				
				GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Alkuvalikko/Asetukset").GetComponents<PlayMakerFSM>()[1].FsmVariables.GetFsmString("Name").Value = playersting;
				
				HutongGames.PlayMaker.Actions.GetFsmString newfishing9string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Alkuvalikko/Asetukset").GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[0] as HutongGames.PlayMaker.Actions.GetFsmString;
				newfishing9string.storeValue = playersting;
				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/CPUpelaajat").GetComponent<PlayMakerFSM>().Fsm.InitData();
				
				HutongGames.PlayMaker.Actions.SetStringValue newfishing10string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/CPUpelaajat").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 7").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
				newfishing10string.stringValue = newfishing1;
				
				HutongGames.PlayMaker.Actions.SetStringValue newfishing11string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/CPUpelaajat").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 8").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
				newfishing11string.stringValue = newfishing2;
				
				HutongGames.PlayMaker.Actions.SetStringValue newfishing12string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/CPUpelaajat").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 11").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
				newfishing12string.stringValue = newfishing3;
				
				HutongGames.PlayMaker.Actions.SetStringValue newfishing13string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/CPUpelaajat").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 16").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
				newfishing13string.stringValue = newfishing4;
				
				HutongGames.PlayMaker.Actions.SetStringValue newfishing14string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/CPUpelaajat").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 21").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
				newfishing14string.stringValue = newfishing5;
				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Tulokset").GetComponent<PlayMakerFSM>().Fsm.InitData();
				
				HutongGames.PlayMaker.Actions.BuildStringFast newfishing15string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Tulokset").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Grammat").Actions[3] as HutongGames.PlayMaker.Actions.BuildStringFast;
				newfishing15string.stringParts[1] = gstring;
				
				HutongGames.PlayMaker.Actions.BuildStringFast newfishing16string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Tulokset").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Kalan paino").Actions[2] as HutongGames.PlayMaker.Actions.BuildStringFast;
				newfishing16string.stringParts[1] = gstring;
				
				ArrayList fishnameslist = new ArrayList { playersting, fishname1, fishname2, fishname3, fishname4, fishname5, fishname6, fishname7 };
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/Saalis").GetComponents<PlayMakerArrayListProxy>()[2]._arrayList = fishnameslist;
				
				GameObject.Find("YARD/Building").transform.Find("BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest/Mekaanikka").GetComponent<PlayMakerFSM>().Fsm.InitData();
				
				HutongGames.PlayMaker.Actions.SetProperty wildvest1string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest/Mekaanikka").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				wildvest1string.targetProperty.StringParameter = winpressenter;
				
				HutongGames.PlayMaker.Actions.SetProperty wildvest2string = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest/Mekaanikka").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Lose").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
				wildvest2string.targetProperty.StringParameter = traumiren;
			}
			//farmer
			GameObject.Find("HUMANS").transform.Find("Farmer/Walker/Char/skeleton/pelvis/spine_middle/spine_upper/collar_right/shoulder_right/arm_right/hand_right/PayMoney").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildString farmerstring = GameObject.Find("HUMANS").transform.Find("Farmer/Walker/Char/skeleton/pelvis/spine_middle/spine_upper/collar_right/shoulder_right/arm_right/hand_right/PayMoney").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[1] as HutongGames.PlayMaker.Actions.BuildString;
			farmerstring.stringParts[0] = takemoney;
			farmerstring.stringParts[2] = mk;
			//arrest weight
			Sheets.transform.Find("Arrestwarrant/Texts/Description").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildStringFast arrestwstring = Sheets.transform.Find("Arrestwarrant/Texts/Description").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[2] as HutongGames.PlayMaker.Actions.BuildStringFast;
			arrestwstring.stringParts[0] = arrestwe1;
			arrestwstring.stringParts[2] = arrestwe2;
			//drag racing
			GameObject.Find("DRAGRACE").transform.Find("LOD/DRAGSTRIP/DragTiming").GetComponents<PlayMakerFSM>()[2].Fsm.InitData();
			HutongGames.PlayMaker.Actions.SetStringValue dragredstring = GameObject.Find("DRAGRACE").transform.Find("LOD/DRAGSTRIP/DragTiming").GetComponents<PlayMakerFSM>()[2].FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			dragredstring.stringValue = reddrag;
			ModConsole.Print("Extra translated: 6/8");
			//Rally tv drivers name
			GameObject RALLYCAR1 = Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "RALLYCAR1").transform.gameObject;
			GameObject RALLYCAR2 = Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "RALLYCAR2").transform.gameObject;
			GameObject RALLYCAR3 = Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "RALLYCAR3").transform.gameObject;
			
			RALLYCAR1.GetComponents<PlayMakerFSM>()[4].Fsm.InitData();
			
			RALLYCAR1.GetComponents<PlayMakerFSM>()[4].FsmVariables.GetFsmString("DriverName").Value = rallyname100;
						
			HutongGames.PlayMaker.Actions.SetStringValue rallytvname1string = RALLYCAR1.GetComponents<PlayMakerFSM>()[4].FsmStates.FirstOrDefault(state => state.Name == "Skin 1").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			rallytvname1string.stringValue = rallyname100;
			
			HutongGames.PlayMaker.Actions.SetStringValue rallytvname2string = RALLYCAR1.GetComponents<PlayMakerFSM>()[4].FsmStates.FirstOrDefault(state => state.Name == "Skin 2").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			rallytvname2string.stringValue = rallyname101;
			
			HutongGames.PlayMaker.Actions.SetStringValue rallytvname3string = RALLYCAR1.GetComponents<PlayMakerFSM>()[4].FsmStates.FirstOrDefault(state => state.Name == "Skin 3").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			rallytvname3string.stringValue = rallyname102;
			
			RALLYCAR2.GetComponents<PlayMakerFSM>()[4].Fsm.InitData();
			
			RALLYCAR2.GetComponents<PlayMakerFSM>()[4].FsmVariables.GetFsmString("DriverName").Value = rallyname103;
			
			HutongGames.PlayMaker.Actions.SetStringValue rallytvname4string = RALLYCAR2.GetComponents<PlayMakerFSM>()[4].FsmStates.FirstOrDefault(state => state.Name == "Skin 1").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			rallytvname4string.stringValue = rallyname103;
			
			HutongGames.PlayMaker.Actions.SetStringValue rallytvname5string = RALLYCAR2.GetComponents<PlayMakerFSM>()[4].FsmStates.FirstOrDefault(state => state.Name == "Skin 2").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			rallytvname5string.stringValue = rallyname104;
			
			HutongGames.PlayMaker.Actions.SetStringValue rallytvname6string = RALLYCAR2.GetComponents<PlayMakerFSM>()[4].FsmStates.FirstOrDefault(state => state.Name == "Skin 3").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			rallytvname6string.stringValue = rallyname105;
			
			RALLYCAR3.GetComponents<PlayMakerFSM>()[4].Fsm.InitData();
			
			RALLYCAR3.GetComponents<PlayMakerFSM>()[4].FsmVariables.GetFsmString("DriverName").Value = rallyname106;
			
			HutongGames.PlayMaker.Actions.SetStringValue rallytvname7string = RALLYCAR3.GetComponents<PlayMakerFSM>()[4].FsmStates.FirstOrDefault(state => state.Name == "Skin 1").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			rallytvname7string.stringValue = rallyname106;
			
			HutongGames.PlayMaker.Actions.SetStringValue rallytvname8string = RALLYCAR3.GetComponents<PlayMakerFSM>()[4].FsmStates.FirstOrDefault(state => state.Name == "Skin 2").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			rallytvname8string.stringValue = rallyname107;
			
			HutongGames.PlayMaker.Actions.SetStringValue rallytvname9string = RALLYCAR3.GetComponents<PlayMakerFSM>()[4].FsmStates.FirstOrDefault(state => state.Name == "Skin 3").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			rallytvname9string.stringValue = rallyname108;
			//Rally tv results names
			if(!GameObject.Find("RALLY").transform.Find("RallyCars").gameObject.activeSelf)
			{
				GameObject.Find("RALLY").transform.Find("RallyCars").gameObject.SetActive(true);
				rallytvnames = true;
			}
			
			ArrayList rallyresultslist1 = GameObject.Find("RALLY/RallyCars").GetComponents<PlayMakerArrayListProxy>()[2]._arrayList;
			
			List<string> rallyresultslist2 = new List<string>() { rallyname100, rallyname101, rallyname102, rallyname103, rallyname104, rallyname105, rallyname106, rallyname107, rallyname108 };
			GameObject.Find("RALLY/RallyCars").GetComponent<PlayMakerHashTableProxy>().preFillKeyList = rallyresultslist2;
			
			GameObject.Find("RALLY/RallyCars").GetComponent<PlayMakerHashTableProxy>()._hashTable.Clear();
			
			if(!rallytvnames)
			{
				ArrayList rallyresultslist3 = new ArrayList { rallyname108, rallyname103, rallyname102, rallyname100, rallyname105, rallyname107, rallyname104, rallyname101, rallyname106 };
				
				GameObject.Find("RALLY/RallyCars").GetComponents<PlayMakerArrayListProxy>()[1]._arrayList = rallyresultslist3;
			}
			
			GameObject.Find("RALLY/RallyCars").GetComponents<PlayMakerArrayListProxy>()[2]._arrayList = rallyresultslist1;
			
			if(rallytvnames)
			{
				GameObject.Find("RALLY/RallyCars").gameObject.SetActive(false);
			}
			//drag racers names
			Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "KYLAJANI").transform.Find("StagingWheel").transform.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("Name").Value = dragname1;
			Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "AMIS2").transform.Find("StagingWheel").transform.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("Name").Value = dragname2;
			Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "MENACE").transform.Find("StagingWheel").transform.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("Name").Value = dragname3;
			Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "dragcar1").transform.Find("StagingWheel").transform.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("Name").Value = dragname4;
			Resources.FindObjectsOfTypeAll<GameObject>().First(g => g.name == "dragcar2").transform.Find("StagingWheel").transform.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmString("Name").Value = dragname5;
			//long strings
			HutongGames.PlayMaker.Actions.SetStringValue stringlong1 = GameObject.Find("STORE").transform.Find("TeimoInShop/Pivot/Speak").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 34").Actions[2] as HutongGames.PlayMaker.Actions.SetStringValue;			
			stringlong1.stringValue = longstring1;
			
			HutongGames.PlayMaker.Actions.SetStringValue stringlong2 = GameObject.Find("STORE").transform.Find("TeimoInShop/Pivot/Speak").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 15").Actions[2] as HutongGames.PlayMaker.Actions.SetStringValue;			
			stringlong2.stringValue = longstring2;
			
			HutongGames.PlayMaker.Actions.SetStringValue stringlong3 = GameObject.Find("STORE").transform.Find("TeimoInShop/Pivot/Speak").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 21").Actions[2] as HutongGames.PlayMaker.Actions.SetStringValue;			
			stringlong3.stringValue = longstring3;
			
			HutongGames.PlayMaker.Actions.SetStringValue stringlong4 = GameObject.Find("STORE").transform.Find("TeimoInShop/Pivot/Speak").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 22").Actions[2] as HutongGames.PlayMaker.Actions.SetStringValue;			
			stringlong4.stringValue = longstring4;
			
			HutongGames.PlayMaker.Actions.SetStringValue stringlong5 = GameObject.Find("STORE").transform.Find("TeimoInShop/Pivot/Speak").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 16").Actions[2] as HutongGames.PlayMaker.Actions.SetStringValue;			
			stringlong5.stringValue = longstring5;
			
			HutongGames.PlayMaker.Actions.SetStringValue stringlong6 = GameObject.Find("STORE").transform.Find("TeimoInShop/Pivot/Speak").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 11").Actions[2] as HutongGames.PlayMaker.Actions.SetStringValue;			
			stringlong6.stringValue = longstring6;
			
			HutongGames.PlayMaker.Actions.SetStringValue stringlong7 = GameObject.Find("STORE").transform.Find("TeimoInShop/Pivot/Speak").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 24").Actions[2] as HutongGames.PlayMaker.Actions.SetStringValue;			
			stringlong7.stringValue = longstring7;
			
			HutongGames.PlayMaker.Actions.SetStringValue stringlong8 = GameObject.Find("STORE").transform.Find("TeimoInShop/Pivot/Speak").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 5").Actions[2] as HutongGames.PlayMaker.Actions.SetStringValue;			
			stringlong8.stringValue = longstring8;
			
			HutongGames.PlayMaker.Actions.SetStringValue stringlong9 = GameObject.Find("STORE").transform.Find("TeimoInShop/Pivot/Speak").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 6").Actions[2] as HutongGames.PlayMaker.Actions.SetStringValue;			
			stringlong9.stringValue = longstring9;
			
			HutongGames.PlayMaker.Actions.SetStringValue stringlong10 = GameObject.Find("STORE").transform.Find("TeimoInShop/Pivot/Speak").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 7").Actions[2] as HutongGames.PlayMaker.Actions.SetStringValue;			
			stringlong10.stringValue = longstring10;
			
			HutongGames.PlayMaker.Actions.SetStringValue stringlong11 = GameObject.Find("STORE").transform.Find("TeimoInShop/Pivot/Speak").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 8").Actions[2] as HutongGames.PlayMaker.Actions.SetStringValue;			
			stringlong11.stringValue = longstring11;
			
			HutongGames.PlayMaker.Actions.SetStringValue stringlong12 = GameObject.Find("STORE").transform.Find("TeimoInShop/Pivot/Speak").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 10").Actions[2] as HutongGames.PlayMaker.Actions.SetStringValue;			
			stringlong12.stringValue = longstring12;
			
			HutongGames.PlayMaker.Actions.SetStringValue stringlong13 = GameObject.Find("STORE").transform.Find("TeimoInShop/Pivot/Speak").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 27").Actions[2] as HutongGames.PlayMaker.Actions.SetStringValue;			
			stringlong13.stringValue = longstring13;
			
			if(GameObject.Find("KILJUGUY/HikerPivot/JokkeHiker2") != null)
			{	
				HutongGames.PlayMaker.Actions.SetStringValue stringlong14 = GameObject.Find("KILJUGUY/HikerPivot/JokkeHiker2").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Marriage 2").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;			
				stringlong14.stringValue = longstring14;
				
				HutongGames.PlayMaker.Actions.SetStringValue stringlong15 = GameObject.Find("KILJUGUY/HikerPivot/JokkeHiker2").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Lotto1 2").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;			
				stringlong15.stringValue = longstring15;
				
				HutongGames.PlayMaker.Actions.SetStringValue stringlong16 = GameObject.Find("KILJUGUY/HikerPivot/JokkeHiker2").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Lotto1 3").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;			
				stringlong16.stringValue = longstring16;
				
				HutongGames.PlayMaker.Actions.Wait stringlong16wait = GameObject.Find("KILJUGUY/HikerPivot/JokkeHiker2").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Lotto1 3").Actions[3] as HutongGames.PlayMaker.Actions.Wait;			
				stringlong16wait.time = 60f;
				
				HutongGames.PlayMaker.Actions.SetStringValue stringlong17 = GameObject.Find("KILJUGUY/HikerPivot/JokkeHiker2").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Lotto1 4").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;			
				stringlong17.stringValue = longstring17;
				
				HutongGames.PlayMaker.Actions.Wait stringlong17wait = GameObject.Find("KILJUGUY/HikerPivot/JokkeHiker2").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Lotto1 4").Actions[3] as HutongGames.PlayMaker.Actions.Wait;			
				stringlong17wait.time = 60f;
			}
			
			if(GameObject.Find("YARD/Building/LIVINGROOM") != null)
			{
				GameObject.Find("YARD/Building").transform.Find("LIVINGROOM/Telephone/Logic/Ring").GetComponents<PlayMakerFSM>()[0].Fsm.InitData();
				
				HutongGames.PlayMaker.Actions.SetStringValue stringlong18 = GameObject.Find("YARD/Building/LIVINGROOM/Telephone/Logic/Ring").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Drunk lift").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;			
				stringlong18.stringValue = longstring18;
				
				HutongGames.PlayMaker.Actions.SetStringValue stringlong19 = GameObject.Find("YARD/Building/LIVINGROOM/Telephone/Logic/Ring").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Moving").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;			
				stringlong19.stringValue = longstring19;
				
				HutongGames.PlayMaker.Actions.SetStringValue stringlong21 = GameObject.Find("YARD/Building/LIVINGROOM/Telephone/Logic/Ring").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Fleetari rally").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;			
				stringlong21.stringValue = longstring21;
				
				HutongGames.PlayMaker.Actions.Wait stringlong21wait = GameObject.Find("YARD/Building/LIVINGROOM/Telephone/Logic/Ring").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Fleetari rally").Actions[3] as HutongGames.PlayMaker.Actions.Wait;			
				stringlong21wait.time = 80f;
				
				HutongGames.PlayMaker.Actions.SetStringValue stringlong22 = GameObject.Find("YARD/Building/LIVINGROOM/Telephone/Logic/Ring").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 12").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;			
				stringlong22.stringValue = longstring22;
				
				HutongGames.PlayMaker.Actions.Wait stringlong22wait = GameObject.Find("YARD/Building/LIVINGROOM/Telephone/Logic/Ring").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 12").Actions[2] as HutongGames.PlayMaker.Actions.Wait;			
				stringlong22wait.time = 80f;
				
				HutongGames.PlayMaker.Actions.SetStringValue stringlong23 = GameObject.Find("YARD/Building/LIVINGROOM/Telephone/Logic/Ring").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Fleetari shit").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;			
				stringlong23.stringValue = longstring23;
				
				HutongGames.PlayMaker.Actions.Wait stringlong23wait = GameObject.Find("YARD/Building/LIVINGROOM/Telephone/Logic/Ring").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Fleetari shit").Actions[6] as HutongGames.PlayMaker.Actions.Wait;			
				stringlong23wait.time = 80f;
			}
			
			GameObject.Find("NPC_CARS/Amikset").transform.Find("KYLAJANI/Driver/Animations").gameObject.GetComponent<PlayMakerFSM>().Fsm.InitData();
			
			HutongGames.PlayMaker.Actions.SetStringValue stringlong20 = GameObject.Find("NPC_CARS/Amikset/KYLAJANI/Driver/Animations").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Race").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
			stringlong20.stringValue = longstring20;
			
			HutongGames.PlayMaker.Actions.Wait stringlong20wait = GameObject.Find("NPC_CARS/Amikset/KYLAJANI/Driver/Animations").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Race").Actions[2] as HutongGames.PlayMaker.Actions.Wait;
			stringlong20wait.time = 50f;
			
			HutongGames.PlayMaker.Actions.SetStringValue stringlong24 = GameObject.Find("JOBS/Mummola/TalkEngine").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Speak 1").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;
			stringlong24.stringValue = longstring24;
			
			HutongGames.PlayMaker.Actions.Wait stringlong24wait = GameObject.Find("JOBS/Mummola/TalkEngine").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Speak 1").Actions[2] as HutongGames.PlayMaker.Actions.Wait;
			stringlong24wait.time = 90f;
			
			if(GameObject.Find("YARD/UNCLE").transform.Find("Home/UncleDrinking") !=null)
			{
				if(!GameObject.Find("YARD/UNCLE/Home/UncleDrinking").gameObject.activeSelf)
				{
					GameObject.Find("YARD/UNCLE/Home").transform.Find("UncleDrinking").gameObject.SetActive(true);
					uncle3 = true;
				}
			
				GameObject.Find("YARD/UNCLE/Home/UncleDrinking/Uncle").GetComponents<PlayMakerArrayListProxy>()[1]._arrayList[4] = longstring25;
				GameObject.Find("YARD/UNCLE/Home/UncleDrinking/Uncle").GetComponents<PlayMakerArrayListProxy>()[1].preFillStringList[4] = longstring25;
			
				HutongGames.PlayMaker.Actions.SetStringValue stringlong26 = GameObject.Find("YARD/UNCLE/Home/UncleDrinking/Uncle").GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "No license").Actions[2] as HutongGames.PlayMaker.Actions.SetStringValue;
				stringlong26.stringValue = longstring26;
			
				HutongGames.PlayMaker.Actions.Wait stringlong26wait = GameObject.Find("YARD/UNCLE/Home/UncleDrinking/Uncle").GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "No license").Actions[3] as HutongGames.PlayMaker.Actions.Wait;
				stringlong26wait.time = 60f;
			
				GameObject.Find("YARD/UNCLE/Home/UncleDrinking/Uncle").GetComponents<PlayMakerArrayListProxy>()[1]._arrayList[6] = longstring27;
				GameObject.Find("YARD/UNCLE/Home/UncleDrinking/Uncle").GetComponents<PlayMakerArrayListProxy>()[1].preFillStringList[6] = longstring27;
			
				HutongGames.PlayMaker.Actions.SetStringValue stringlong28 = GameObject.Find("YARD/UNCLE/Home/UncleDrinking/Uncle").GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "No license 2").Actions[0] as HutongGames.PlayMaker.Actions.SetStringValue;
				stringlong28.stringValue = longstring28;
			
				HutongGames.PlayMaker.Actions.Wait stringlong28wait = GameObject.Find("YARD/UNCLE/Home/UncleDrinking/Uncle").GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "No license 2").Actions[1] as HutongGames.PlayMaker.Actions.Wait;
				stringlong28wait.time = 60f;
			
				if(uncle3)
				{
					GameObject.Find("YARD/UNCLE/Home/UncleDrinking").gameObject.SetActive(false);
				}
			}
			//TT stop/haku
			GameObject.Find("Systems").transform.Find("Teletext").gameObject.GetComponent<PlayMakerFSM>().Fsm.InitData();
			
			HutongGames.PlayMaker.Actions.SetProperty stop1string = GameObject.Find("Systems").transform.Find("Teletext").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault().Actions[4] as HutongGames.PlayMaker.Actions.SetProperty;
			stop1string.targetProperty.StringParameter = stop;
			
			HutongGames.PlayMaker.Actions.SetProperty stop2string = GameObject.Find("Systems").transform.Find("Teletext").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Open page").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
			stop2string.targetProperty.StringParameter = stop;
			
			HutongGames.PlayMaker.Actions.SetProperty hakustring = GameObject.Find("Systems").transform.Find("Teletext").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Load").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
			hakustring.targetProperty.StringParameter = haku;
			
			ModConsole.Print("Extra translated: 7/8");
			//Rally tv results
			GameObject.Find("RALLY/RallyTV").transform.Find("Program/RallyTVGUI/Results").gameObject.GetComponent<PlayMakerFSM>().Fsm.InitData();
			
			HutongGames.PlayMaker.Actions.SetProperty rallytvstring1 = GameObject.Find("RALLY/RallyTV/Program/RallyTVGUI/Results").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
			rallytvstring1.targetProperty.StringParameter = rallysprint;
			//Rally results
			GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/TeleTextResults").gameObject.GetComponent<PlayMakerFSM>().Fsm.InitData();
			
			HutongGames.PlayMaker.Actions.SetProperty rallytvstring2 = GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/250/Texts/TeleTextResults").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[0] as HutongGames.PlayMaker.Actions.SetProperty;
			rallytvstring2.targetProperty.StringParameter = rallysprint;
			//Fleetari driveway
			HutongGames.PlayMaker.Actions.SetStringValue stringfledrive = GameObject.Find("REPAIRSHOP").transform.Find("LOD/Office/Fleetari").gameObject.GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Say fuck").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;
			stringfledrive.stringValue = fleeteridriveway;
			//Teimo hello
			HutongGames.PlayMaker.Actions.SetStringValue stringteimohello = GameObject.Find("STORE").transform.Find("TeimoInShop/Pivot/Speak").GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[1] as HutongGames.PlayMaker.Actions.SetStringValue;
			stringteimohello.stringValue = teimohello;
			//Strawberry
			GameObject.Find("JOBS").transform.Find("StrawberryField/LOD/Functions/Money").GetComponent<PlayMakerFSM>().Fsm.InitData();
			HutongGames.PlayMaker.Actions.BuildStringFast strawberry = GameObject.Find("JOBS").transform.Find("StrawberryField/LOD/Functions/Money").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Wait button").Actions[1] as HutongGames.PlayMaker.Actions.BuildStringFast;
			strawberry.stringParts[0] = takemoney;
			strawberry.stringParts[2] = mk;
		}
		
		public override void FixedUpdate()
		{
			if(Application.loadedLevelName == "Ending")
			{
				if(!endingtranslated)
				{
					GameObject.Find("Intro").transform.Find("Credits/name").gameObject.GetComponent<PlayMakerFSM>().Fsm.InitData();
					
					HutongGames.PlayMaker.Actions.SetProperty endingstring = GameObject.Find("Intro/Credits/name").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[1] as HutongGames.PlayMaker.Actions.SetProperty;
					endingstring.targetProperty.StringParameter = credits;
					
					endingtranslated = true;
				}
			}
			
			if(!ttupdate)
			{
				if(!GameObject.Find("Systems").transform.Find("Teletext").gameObject.activeSelf)
				{
					GameObject.Find("Systems").transform.Find("Teletext").gameObject.SetActive(true);
					teletext2 = true;
				}
				
				if(!ttfinews)
				{
					if(GameObject.Find("Systems/Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[1]._arrayList.Count > 0 & finews17 !=null)
					{
						ArrayList finews = new ArrayList();
						finews.AddRange(new string[] { finews0, finews1, finews2, finews3, finews4, finews5, finews6, finews7, finews8, finews9, finews10, finews11, finews12, finews13, finews14, finews15, finews16, finews17 });
					
						GameObject.Find("Systems/Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[1]._arrayList = finews;
						
						ttfinews = true;
					}
				}
				
				if(!ttwdnews)
				{
					if(GameObject.Find("Systems/Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[2]._arrayList.Count > 0 & wdnews4 !=null)
					{
						ArrayList wdnews = new ArrayList();
						wdnews.AddRange(new string[] { wdnews0, wdnews1, wdnews2, wdnews3, wdnews4 });
					
						GameObject.Find("Systems/Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[2]._arrayList = wdnews;
						
						ttwdnews = true;
					}
				}
				
				if(!tteconews)
				{
					if(GameObject.Find("Systems/Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[3]._arrayList.Count > 0 & econews8 !=null)
					{
						ArrayList econews = new ArrayList();
						econews.AddRange(new string[] { econews0, econews1, econews2, econews3, econews4, econews5, econews6, econews7, econews8 });
					
						GameObject.Find("Systems/Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[3]._arrayList = econews;
						
						tteconews = true;
					}
				}
				
				if(!ttsportnews)
				{
					if(GameObject.Find("Systems/Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[4]._arrayList.Count > 0 & sportnews12 !=null)
					{
						ArrayList sportnews = new ArrayList();
						sportnews.AddRange(new string[] { sportnews0, sportnews1, sportnews2, sportnews3, sportnews4, sportnews5, sportnews6, sportnews7, sportnews8, sportnews9, sportnews10, sportnews11, sportnews12 });
					
						GameObject.Find("Systems/Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[4]._arrayList = sportnews;
						
						ttsportnews = true;
					}
				}
				
				if(!ttrecipes)
				{
					if(GameObject.Find("Systems/Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[5]._arrayList.Count > 0 & recipe4 !=null)
					{
						ArrayList recipes = new ArrayList();
						recipes.AddRange(new string[] { recipe0, recipe1, recipe2, recipe3, recipe4 });
					
						GameObject.Find("Systems/Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[5]._arrayList = recipes;
						
						ttrecipes = true;
					}
				}
				
				if(!ttquotes)
				{
					if(GameObject.Find("Systems/Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[6]._arrayList.Count > 0 & quote10 !=null)
					{
						ArrayList quotes = new ArrayList();
						quotes.AddRange(new string[] { quote0, quote1, quote2, quote3, quote4, quote5, quote6, quote7, quote8, quote9, quote10 });
					
						GameObject.Find("Systems/Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[6]._arrayList = quotes;
						
						ttquotes = true;
					}
				}
				
				if(!ttcultures)
				{
					if(GameObject.Find("Systems/Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[7]._arrayList.Count > 0 & culture7 !=null)
					{
						ArrayList cultures = new ArrayList();
						cultures.AddRange(new string[] { culture0, culture1, culture2, culture3, culture4, culture5, culture6, culture7 });
					
						GameObject.Find("Systems/Teletext/VKTekstiTV/Database").GetComponents<PlayMakerArrayListProxy>()[7]._arrayList = cultures;
						
						ttcultures = true;
					}
				}
				
				if(ttfinews && ttwdnews && tteconews && ttsportnews && ttrecipes && ttquotes && ttcultures)
				{
					if(teletext2)
					{
						GameObject.Find("Systems/Teletext").gameObject.SetActive(false);
					}
					
					ttupdate = true;
					ModConsole.Print("Extra translated: 8/8");
				}
			}
		}
    }
}
