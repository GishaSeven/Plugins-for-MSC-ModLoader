﻿using MSCLoader;
using UnityEngine;
using System.Collections;
using System.Threading;

namespace StockWheel
{
    public class StockWheel : Mod
    {
        public override string ID { get { return "StockWheel"; } }
        public override string Name { get { return "StockWheel"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject FLRIM;
		private GameObject FLHUBCAP;	
		private GameObject FRRIM;
		private GameObject FRHUBCAP;
		private GameObject RLRIM;
		private GameObject RLHUBCAP;
		private GameObject RRRIM;
		private GameObject RRHUBCAP;
		private GameObject FLHUBCAPCH;
		private GameObject FRHUBCAPCH;
		private GameObject RLHUBCAPCH;
		private GameObject RRHUBCAPCH;
		private GameObject SHOP;
		private GameObject SHOPLOD;
		private GameObject SHOPGFX;
		private GameObject SHOPSHELFS;
		private GameObject SHOPEQUIPM;
		private GameObject SHOPCHROME;
		
		private string path = ModLoader.ModsFolder+@"\StockWheel\";
		
        public override void Update()
        {
            if (Application.loadedLevelName == "GAME" && !loaded)
            {
				new Thread(waiting1r).Start();
				loaded = true;
            }
						
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
		
		private void waiting1r()
		{
			Thread.Sleep( 10 * 1000 );
			
			ObjImporter objimporter = new ObjImporter();
			Mesh new_mesh1 = new Mesh();
			new_mesh1 = objimporter.ImportFile(path + "tire_stock.obj");
			
			WWW loadtexture2 = new WWW("");
			loadtexture2 = new WWW("file://" + @path + "tires_standard.png");
			
			GameObject[] allObjects = UnityEngine.Object.FindObjectsOfType<GameObject>();
			foreach(GameObject findme in allObjects)
			{
				if(findme.name == "TireStandard(Clone)")
				{
					findme.GetComponent<MeshFilter>().mesh = new_mesh1;
					findme.GetComponent<MeshRenderer>().material.mainTexture = loadtexture2.texture;
				}
			}
			
			FLRIM = GameObject.Find("wheel steel fl(Clone)");
			FLHUBCAP = GameObject.Find("hubcap fl(Clone)");
			FRRIM = GameObject.Find("wheel steel fr(Clone)");
			FRHUBCAP = GameObject.Find("hubcap fr(Clone)");
			RLRIM = GameObject.Find("wheel steel rl(Clone)");
			RLHUBCAP = GameObject.Find("hubcap rl(Clone)");
			RRRIM = GameObject.Find("wheel steel rr(Clone)");
			RRHUBCAP = GameObject.Find("hubcap rr(Clone)");
			
			Mesh new_mesh0 = new Mesh();
			new_mesh0 = objimporter.ImportFile(path + "rim_steel.obj");
			Mesh new_mesh2 = new Mesh();
			new_mesh2 = objimporter.ImportFile(path + "tire_fl_hubcap.obj");
								
			FLRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
			FLHUBCAP.transform.GetComponent<MeshFilter>().mesh = new_mesh2;
			FRRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
			FRHUBCAP.transform.GetComponent<MeshFilter>().mesh = new_mesh2;
			RLRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
			RLHUBCAP.transform.GetComponent<MeshFilter>().mesh = new_mesh2;
			RRRIM.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
			RRHUBCAP.transform.GetComponent<MeshFilter>().mesh = new_mesh2;
				
			WWW loadtexture1 = new WWW("");
			loadtexture1 = new WWW("file://" + @path + "rims_ao.png");
								
			FLRIM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
			FRRIM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
			RLRIM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
			RRRIM.GetComponent<MeshRenderer>().material.mainTexture = loadtexture1.texture;
			
			FLHUBCAPCH = new GameObject("Roman266FLHUBCAPCH");
			FLHUBCAPCH.AddComponent<MeshFilter>();
			FLHUBCAPCH.AddComponent<MeshRenderer>();
			FRHUBCAPCH = new GameObject("Roman266FRHUBCAPCH");
			FRHUBCAPCH.AddComponent<MeshFilter>();
			FRHUBCAPCH.AddComponent<MeshRenderer>();
			RLHUBCAPCH = new GameObject("Roman266RLHUBCAPCH");
			RLHUBCAPCH.AddComponent<MeshFilter>();
			RLHUBCAPCH.AddComponent<MeshRenderer>();
			RRHUBCAPCH = new GameObject("Roman266RRHUBCAPCH");
			RRHUBCAPCH.AddComponent<MeshFilter>();
			RRHUBCAPCH.AddComponent<MeshRenderer>();
			
			FLHUBCAPCH.transform.parent = FLHUBCAP.transform;
			FLHUBCAPCH.transform.localScale = new Vector3(1, 1, 1);
			FLHUBCAPCH.transform.localPosition = new Vector3(0, 0, 0);
			FLHUBCAPCH.transform.localEulerAngles= new Vector3(0, 0, 0);
			FRHUBCAPCH.transform.parent = FRHUBCAP.transform;
			FRHUBCAPCH.transform.localScale = new Vector3(1, 1, 1);
			FRHUBCAPCH.transform.localPosition = new Vector3(0, 0, 0);
			FRHUBCAPCH.transform.localEulerAngles= new Vector3(0, 0, 0);
			RLHUBCAPCH.transform.parent = RLHUBCAP.transform;
			RLHUBCAPCH.transform.localScale = new Vector3(1, 1, 1);
			RLHUBCAPCH.transform.localPosition = new Vector3(0, 0, 0);
			RLHUBCAPCH.transform.localEulerAngles= new Vector3(0, 0, 0);
			RRHUBCAPCH.transform.parent = RRHUBCAP.transform;
			RRHUBCAPCH.transform.localScale = new Vector3(1, 1, 1);
			RRHUBCAPCH.transform.localPosition = new Vector3(0, 0, 0);
			RRHUBCAPCH.transform.localEulerAngles= new Vector3(0, 0, 0);
			
			Mesh new_mesh3 = new Mesh();
			new_mesh3 = objimporter.ImportFile(path + "hubcap_chrome.obj");
			
			FLHUBCAPCH.transform.GetComponent<MeshFilter>().mesh = new_mesh3;
			FRHUBCAPCH.transform.GetComponent<MeshFilter>().mesh = new_mesh3;
			RLHUBCAPCH.transform.GetComponent<MeshFilter>().mesh = new_mesh3;
			RRHUBCAPCH.transform.GetComponent<MeshFilter>().mesh = new_mesh3;
			
			SHOP = GameObject.Find("STORE");
			SHOPLOD = SHOP.transform.FindChild("LOD").gameObject;
			SHOPGFX = SHOPLOD.transform.FindChild("GFX_Store").gameObject;
			SHOPSHELFS = SHOPGFX.transform.FindChild("StoreShelfs").gameObject;
			SHOPEQUIPM = SHOPSHELFS.transform.FindChild("store_equipment").gameObject;
			SHOPCHROME = SHOPEQUIPM.transform.FindChild("store_equipment_mirror").gameObject;
									
			FLHUBCAPCH.GetComponent<MeshRenderer>().material = SHOPCHROME.GetComponent<MeshRenderer>().material;
			FRHUBCAPCH.GetComponent<MeshRenderer>().material = SHOPCHROME.GetComponent<MeshRenderer>().material;
			RLHUBCAPCH.GetComponent<MeshRenderer>().material = SHOPCHROME.GetComponent<MeshRenderer>().material;
			RRHUBCAPCH.GetComponent<MeshRenderer>().material = SHOPCHROME.GetComponent<MeshRenderer>().material;
			
			WWW loadtexture3 = new WWW("");
			loadtexture3 = new WWW("file://" + @path + "hubcap_center.png");
			
			FLHUBCAP.GetComponent<MeshRenderer>().material.mainTexture = loadtexture3.texture;
			FRHUBCAP.GetComponent<MeshRenderer>().material.mainTexture = loadtexture3.texture;
			RLHUBCAP.GetComponent<MeshRenderer>().material.mainTexture = loadtexture3.texture;
			RRHUBCAP.GetComponent<MeshRenderer>().material.mainTexture = loadtexture3.texture;
		}
    }
}
