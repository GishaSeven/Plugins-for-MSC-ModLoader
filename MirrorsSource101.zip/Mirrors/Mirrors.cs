﻿using MSCLoader;
using UnityEngine;

namespace Mirrors
{
    public class Mirrors : Mod
    {
        public override string ID => "Mirrors";
        public override string Name => "Mirrors";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";
		
        public override void OnLoad()
        {
			GameObject LDOOR = GameObject.Find("door left(Clone)");		
			GameObject MIRRORMESH = LDOOR.transform.FindChild("mirror").gameObject;
			GameObject MIRRORCAMERA = LDOOR.transform.FindChild("CarSideMirrorPivot").gameObject;
			GameObject LFENDER = GameObject.Find("fender left(Clone)");
			GameObject RFENDER = GameObject.Find("fender right(Clone)");
				
			MIRRORMESH.transform.parent = LFENDER.transform;
			MIRRORMESH.transform.localPosition = new Vector3(-0.06f, 0.5f, 0.08f);
			MIRRORMESH.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
			MIRRORMESH.transform.localEulerAngles = new Vector3(0f, 0f, 0f);
				
			GameObject MirrorClone = GameObject.Instantiate(MIRRORMESH, MIRRORMESH.transform.position, MIRRORMESH.transform.rotation) as GameObject;
				
			MirrorClone.transform.parent = RFENDER.transform;
			MirrorClone.transform.localScale = new Vector3(1.2f, 1.2f, -1.2f);
			MirrorClone.transform.localPosition = new Vector3(0.078f, 0.5f, 0.08f);
			MirrorClone.transform.localEulerAngles = new Vector3(0f, 180f, 0f);
				
			MIRRORCAMERA.transform.parent = LFENDER.transform;
			MIRRORCAMERA.transform.localPosition = new Vector3(0.5f, 0f, 0.5f);
			MIRRORCAMERA.transform.localEulerAngles = new Vector3(90f, 0f, 0f);
        }
    }
}
