﻿using MSCLoader;
using UnityEngine;
using System.Threading;

namespace RearSpoilers
{
    public class RearSpoilers : Mod
    {
        public override string ID => "RearSpoilers";
        public override string Name => "Rear Spoilers";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => true;
		
		private GameObject SPOILER;
		private GameObject SPOILER2;

		public override void OnLoad()
        {			
			new Thread(waiting).Start();
        }
		
		private void waiting()
		{
			Thread.Sleep( 20 * 1000 );
			
			if(GameObject.Find("rear spoiler(Clone)").activeSelf == true)
			{
				SPOILER = GameObject.Find("rear spoiler(Clone)");
				
				Mesh new_mesh0 = LoadAssets.LoadOBJMesh(this, "spoiler_rear.obj");
				
				SPOILER.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
			}
				
			if(GameObject.Find("rear spoiler2(Clone)").activeSelf == true)
			{
				SPOILER2 = GameObject.Find("rear spoiler2(Clone)");
				
				Mesh new_mesh1 = LoadAssets.LoadOBJMesh(this, "spoiler2_rear.obj");
											
				SPOILER2.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
			}
		}
    }
}
