﻿using MSCLoader;
using UnityEngine;

namespace RearSpoilers
{
    public class RearSpoilers : Mod
    {
        public override string ID => "RearSpoilers";
        public override string Name => "Rear spoilers";
        public override string Author => "Roman266";
        public override string Version => "1.0.2";

        public override bool UseAssetsFolder => true;

		public override void OnLoad()
        {			
			if(GameObject.Find("rear spoiler(Clone)") != null)
			{				
				Mesh new_mesh0 = LoadAssets.LoadOBJMesh(this, "spoiler_rear.obj");
				GameObject.Find("rear spoiler(Clone)").transform.GetComponent<MeshFilter>().mesh = new_mesh0;
			}
				
			if(GameObject.Find("rear spoiler2(Clone)") != null)
			{
				Mesh new_mesh1 = LoadAssets.LoadOBJMesh(this, "spoiler2_rear.obj");
				GameObject.Find("rear spoiler2(Clone)").transform.GetComponent<MeshFilter>().mesh = new_mesh1;
			}
        }
    }
}
