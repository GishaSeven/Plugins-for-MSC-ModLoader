﻿using MSCLoader;
using UnityEngine;

namespace Strutbars
{
    public class Strutbars : Mod
    {
        public override string ID => "Strutbars";
        public override string Name => "Strut bars";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => true;
		
		private GameObject SATSUMA;

		public override void OnLoad()
        {
			SATSUMA = GameObject.Find("SATSUMA(557kg)");
			
            GameObject Roman266STRUTBARS = LoadAssets.LoadOBJ(this, "strutbars.obj");
			
			Roman266STRUTBARS.transform.parent = SATSUMA.transform;
			Roman266STRUTBARS.transform.localScale = new Vector3(1, 1, 1);
			Roman266STRUTBARS.transform.localPosition = new Vector3(0, 0, 0);
			Roman266STRUTBARS.transform.localEulerAngles= new Vector3(0, 0, 0);
			
			Texture2D loadtexture = LoadAssets.LoadTexture(this, "strutbars.png");
			Roman266STRUTBARS.GetComponent<MeshRenderer>().material.mainTexture = loadtexture;
        }
    }
}
