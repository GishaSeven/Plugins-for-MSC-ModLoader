﻿using System;
using System.IO;
using System.Linq;
using MSCLoader;
using UnityEngine;
using HutongGames.PlayMaker;

namespace Paint
{
    public class Paint : Mod
    {
        public override string ID => "PaintSatsuma";
        public override string Name => "Paint Satsuma";
        public override string Author => "Roman266";
        public override string Version => "1.0.2";
		public override string Description => "Paint Satsuma in desired color in real time.";
		
		private bool GUI1;
		private bool GUI2;
		private bool BODY;
		private bool DOORL;
		private bool DOORR;
		private bool FENDERL;
		private bool FENDERR;
		private bool HOOD;
		private bool BOOTLID;
		private bool FIBERHOOD;
		private bool FLARESPOILER;
		private bool FLAREFL;
		private bool FLAREFR;
		private bool FLARERL;
		private bool FLARERR;
		private bool FSPOILER;
		private bool SPOILER;
		private bool SPOILER2;
		private bool WGRILLE;
		private bool ROLL;
		private bool GTGRILLE;
		private bool WHEELS;
		private bool WFLRegula;
		private bool WFRRegula;
		private bool WRLRegula;
		private bool WRRRegula;
		private bool WFLOffset;
		private bool WFROffset;
		private bool WRLOffset;
		private bool WRROffset;
		private bool GRILLE;
		private bool FBUMPER;
		private bool RBUMPER;
		private bool BLOCK;
		private bool CPULLEY;
		private bool RCOVER;
		private bool LSKIRT;
		private bool RSKIRT;
		private bool RMUFFLER;
		private bool AIRFILTER;
		private bool SUBPANEL;
		private Renderer bodyRender;
		private Renderer ldoorRender;
		private Renderer rdoorRender;
		private Renderer lfenderRender;
		private Renderer rfenderRender;
		private Renderer hoodRender;
		private Renderer bootlidRender;
		private Renderer fibhoodRender;
		private Renderer flarespoRender;
		private Renderer flareflRender;
		private Renderer flarefrRender;
		private Renderer flarerlRender;
		private Renderer flarerrRender;
		private Renderer fspoilRender;
		private Renderer rspoilRender;
		private Renderer rspoil2Render;
		private Renderer grilleRender;
		private Renderer rollRender;
		private Renderer gtgrilRender;
		private Renderer wflregRender;
		private Renderer wfrregRender;
		private Renderer wrlregRender;
		private Renderer wrrregRender;
		private Renderer wfloffsRender;
		private Renderer wfroffsRender;
		private Renderer wrloffsRender;
		private Renderer wrroffsRender;
		private Renderer lskirtRender;
		private Renderer rskirtRender;
		private Renderer rmufflRender;
		private Renderer sgrilRender;
		private Renderer fbumperRender;
		private Renderer rbumperRender;
		private Renderer rcoverRender;
		private Renderer cpulleyRender;
		private Renderer blockRender;
		private Renderer airfilRender;
		private Renderer subpanRender;
		private float r;
		private float g;
		private float b;
		private string path;
		private Rect gui1box = new Rect((Screen.width-640)/2, 10f, 640f, 400f);
		private Rect gui2box = new Rect((Screen.width-530)/2, 10f, 530f, 185f);
		private Keybind opengui = new Keybind("OpenGUI", "Open GUI", KeyCode.C, KeyCode.RightControl);

		public override void OnLoad()
        {				
			Keybind.Add(this, opengui);
			
			bodyRender = GameObject.Find("car body(xxxxx)").transform.GetComponent<Renderer>();
			ldoorRender = GameObject.Find("door left(Clone)").transform.GetComponent<Renderer>();
			rdoorRender = GameObject.Find("door right(Clone)").transform.GetComponent<Renderer>();
			lfenderRender = GameObject.Find("fender left(Clone)").transform.GetComponent<Renderer>();
			rfenderRender = GameObject.Find("fender right(Clone)").transform.GetComponent<Renderer>();
			hoodRender = GameObject.Find("hood(Clone)").transform.GetComponent<Renderer>();
			bootlidRender = GameObject.Find("bootlid(Clone)").transform.GetComponent<Renderer>();
			fibhoodRender = Resources.FindObjectsOfTypeAll<MeshFilter>().Where(x => x.name.IndexOf("fiberglass hood(Clone)") >= 0).Last().transform.GetComponent<Renderer>();
			flarespoRender = Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("fender flare spoiler(Clone)") >= 0).Last().transform.GetComponent<Renderer>();
			flareflRender = Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("fender flare fl(Clone)") >= 0).Last().transform.GetComponent<Renderer>();
			flarefrRender = Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("fender flare fr(Clone)") >= 0).Last().transform.GetComponent<Renderer>();
			flarerlRender = Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("fender flare rl(Clone)") >= 0).Last().transform.GetComponent<Renderer>();
			flarerrRender = Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("fender flare rr(Clone)") >= 0).Last().transform.GetComponent<Renderer>();
			fspoilRender = Resources.FindObjectsOfTypeAll<MeshFilter>().Where(x => x.name.IndexOf("front spoiler(Clone)") >= 0).Last().transform.GetComponent<Renderer>();
			rspoilRender = Resources.FindObjectsOfTypeAll<MeshFilter>().Where(x => x.name.IndexOf("rear spoiler(Clone)") >= 0).Last().transform.GetComponent<Renderer>();
			rspoil2Render = Resources.FindObjectsOfTypeAll<MeshFilter>().Where(x => x.name.IndexOf("rear spoiler2(Clone)") >= 0).First().transform.GetComponent<Renderer>();
			grilleRender = Resources.FindObjectsOfTypeAll<MeshFilter>().Where(x => x.name.IndexOf("window grille(Clone)") >= 0).First().transform.GetComponent<Renderer>();
			rollRender = Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("roll cage(xxxxx)") >= 0).Last().transform.GetComponent<Renderer>();
			gtgrilRender = GameObject.Find("grille gt(Clone)").transform.GetComponent<Renderer>();
			
			if(GameObject.Find("SATSUMA(557kg, 248)/FL/AckerFL/wheelFL/TireFL/OFFSET/pivot_wheel_standard/wheel_regula") != null)
			{
				WFLRegula = true;
				wflregRender = GameObject.Find("SATSUMA(557kg, 248)/FL/AckerFL/wheelFL/TireFL/OFFSET/pivot_wheel_standard/wheel_regula").transform.GetComponent<Renderer>();
			}
			if(GameObject.Find("SATSUMA(557kg, 248)/FR/AckerFR/wheelFR/TireFR/OFFSET/pivot_wheel_standard/wheel_regula") != null)
			{
				WFRRegula = true;
				wfrregRender = GameObject.Find("SATSUMA(557kg, 248)/FR/AckerFR/wheelFR/TireFR/OFFSET/pivot_wheel_standard/wheel_regula").transform.GetComponent<Renderer>();
			}
			if(GameObject.Find("SATSUMA(557kg, 248)/RL/wheelRL/TireRL/pivot_wheel_standard/wheel_regula") != null)
			{
				WRLRegula = true;
				wrlregRender = GameObject.Find("SATSUMA(557kg, 248)/RL/wheelRL/TireRL/pivot_wheel_standard/wheel_regula").transform.GetComponent<Renderer>();
			}
			if(GameObject.Find("SATSUMA(557kg, 248)/RR/wheelRR/TireRR/pivot_wheel_standard/wheel_regula") != null)
			{
				WRRRegula = true;
				wrrregRender = GameObject.Find("SATSUMA(557kg, 248)/RR/wheelRR/TireRR/pivot_wheel_standard/wheel_regula").transform.GetComponent<Renderer>();
			}
			
			if(GameObject.Find("SATSUMA(557kg, 248)/FL/AckerFL/wheelFL/TireFL/OFFSET/pivot_wheel_offset/wheel_offset") != null)
			{
				WFLOffset = true;
				wfloffsRender = GameObject.Find("SATSUMA(557kg, 248)/FL/AckerFL/wheelFL/TireFL/OFFSET/pivot_wheel_offset/wheel_offset").transform.GetComponent<Renderer>();
			}
			if(GameObject.Find("SATSUMA(557kg, 248)/FR/AckerFR/wheelFR/TireFR/OFFSET/pivot_wheel_offset/wheel_offset") != null)
			{
				WFROffset = true;
				wfroffsRender = GameObject.Find("SATSUMA(557kg, 248)/FR/AckerFR/wheelFR/TireFR/OFFSET/pivot_wheel_offset/wheel_offset").transform.GetComponent<Renderer>();
			}
			if(GameObject.Find("SATSUMA(557kg, 248)/RL/wheelRL/TireRL/pivot_wheel_offset/wheel_offset") != null)
			{
				WRLOffset = true;
				wrloffsRender = GameObject.Find("SATSUMA(557kg, 248)/RL/wheelRL/TireRL/pivot_wheel_offset/wheel_offset").transform.GetComponent<Renderer>();
			}
			if(GameObject.Find("SATSUMA(557kg, 248)/RR/wheelRR/TireRR/pivot_wheel_offset/wheel_offset") != null)
			{
				WRROffset = true;
				wrroffsRender = GameObject.Find("SATSUMA(557kg, 248)/RR/wheelRR/TireRR/pivot_wheel_offset/wheel_offset").transform.GetComponent<Renderer>();
			}
			
			lskirtRender = Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("side skirt left(Clone)") >= 0).Last().transform.GetComponent<Renderer>();
			rskirtRender = Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("side skirt right(Clone)") >= 0).First().transform.GetComponent<Renderer>();
			rmufflRender = Resources.FindObjectsOfTypeAll<MeshFilter>().Where(x => x.name.IndexOf("racing muffler(Clone)") >= 0).First().transform.GetComponent<Renderer>();
			sgrilRender = GameObject.Find("grille(Clone)").transform.GetComponent<Renderer>();
			fbumperRender = GameObject.Find("bumper front(Clone)").transform.GetComponent<Renderer>();
			rbumperRender = GameObject.Find("bumper rear(Clone)").transform.GetComponent<Renderer>();
			rcoverRender = GameObject.Find("rocker cover(Clone)").transform.GetComponent<Renderer>();
			cpulleyRender = GameObject.Find("crankshaft pulley(Clone)/crankshaft_pulley_mesh").transform.GetComponent<Renderer>();
			blockRender = GameObject.Find("block(Clone)/New").transform.GetComponent<Renderer>();
			airfilRender = Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("airfilter(Clone)") >= 0).Last().transform.GetComponent<Renderer>();
			subpanRender = Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("subwoofer panel(Clone)") >= 0).Last().transform.GetComponent<Renderer>();
			
			path = ModLoader.GetModAssetsFolder(this);
			
			r = 0f;
			g = 0f;
			b = 0f;
        }
		
		public override void Update()
        {
            if(opengui.GetKeybindDown()) { GuiShow(); };
			
			if(GUI2)
			{
				if(BODY)
				{
					bodyRender.material.color = new Color(r, g, b, 1);
				}
				
				if(DOORL)
				{
					ldoorRender.material.color = new Color(r, g, b, 1);
				}
				
				if(DOORR)
				{
					rdoorRender.material.color = new Color(r, g, b, 1);
				}
				
				if(FENDERL)
				{
					lfenderRender.material.color = new Color(r, g, b, 1);
				}
				
				if(FENDERR)
				{
					rfenderRender.material.color = new Color(r, g, b, 1);
				}
				
				if(HOOD)
				{
					hoodRender.material.color = new Color(r, g, b, 1);
				}
				
				if(BOOTLID)
				{
					bootlidRender.material.color = new Color(r, g, b, 1);
				}
				
				if(FIBERHOOD)
				{
					fibhoodRender.material.color = new Color(r, g, b, 1);
				}
				
				if(FLARESPOILER)
				{
					flarespoRender.material.color = new Color(r, g, b, 1);
				}
				
				if(FLAREFL)
				{
					flareflRender.material.color = new Color(r, g, b, 1);
				}
				
				if(FLAREFR)
				{
					flarefrRender.material.color = new Color(r, g, b, 1);
				}
				
				if(FLARERL)
				{
					flarerlRender.material.color = new Color(r, g, b, 1);
				}
				
				if(FLARERR)
				{
					flarerrRender.material.color = new Color(r, g, b, 1);
				}
				
				if(FSPOILER)
				{
					fspoilRender.material.color = new Color(r, g, b, 1);
				}
				
				if(SPOILER)
				{
					rspoilRender.material.color = new Color(r, g, b, 1);
				}
				
				if(SPOILER2)
				{
					rspoil2Render.material.color = new Color(r, g, b, 1);
				}
				
				if(WGRILLE)
				{
					grilleRender.material.color = new Color(r, g, b, 1);
				}
				
				if(ROLL)
				{
					rollRender.material.color = new Color(r, g, b, 1);
				}
				
				if(GTGRILLE)
				{
					gtgrilRender.material.color = new Color(r, g, b, 1);
				}
				
				if(WHEELS)
				{
					if(WFLRegula)
					{
						wflregRender.material.color = new Color(r, g, b, 1);
					}
					if(WFRRegula)
					{
						wfrregRender.material.color = new Color(r, g, b, 1);
					}
					if(WRLRegula)
					{
						wrlregRender.material.color = new Color(r, g, b, 1);
					}
					if(WRRRegula)
					{
						wrrregRender.material.color = new Color(r, g, b, 1);
					}
					
					if(WFLOffset)
					{
						wfloffsRender.material.color = new Color(r, g, b, 1);
					}
					if(WFROffset)
					{
						wfroffsRender.material.color = new Color(r, g, b, 1);
					}
					if(WRLOffset)
					{
						wrloffsRender.material.color = new Color(r, g, b, 1);
					}
					if(WRROffset)
					{
						wrroffsRender.material.color = new Color(r, g, b, 1);
					}
				}
				
				if(GRILLE)
				{
					sgrilRender.material.color = new Color(r, g, b, 1);
				}
				
				if(FBUMPER)
				{
					fbumperRender.material.color = new Color(r, g, b, 1);
				}
				
				if(RBUMPER)
				{
					rbumperRender.material.color = new Color(r, g, b, 1);
				}
				
				if(BLOCK)
				{
					blockRender.material.color = new Color(r, g, b, 1);
				}
				
				if(CPULLEY)
				{
					cpulleyRender.material.color = new Color(r, g, b, 1);
				}
				
				if(RCOVER)
				{
					rcoverRender.material.color = new Color(r, g, b, 1);
				}
				
				if(LSKIRT)
				{
					lskirtRender.material.color = new Color(r, g, b, 1);
				}
				
				if(RSKIRT)
				{
					rskirtRender.material.color = new Color(r, g, b, 1);
				}
				
				if(RMUFFLER)
				{
					rmufflRender.material.color = new Color(r, g, b, 1);
				}
				
				if(AIRFILTER)
				{
					airfilRender.material.color = new Color(r, g, b, 1);
				}
				
				if(SUBPANEL)
				{
					subpanRender.material.color = new Color(r, g, b, 1);
				}
			}
		}
		
		public override void OnGUI()
		{
			if(GUI1)
			{
				GUI.ModalWindow(1, this.gui1box, new GUI.WindowFunction(this.Window1), "Select parts to paint");
			}
			
			if(GUI2)
			{
				GUI.ModalWindow(1, this.gui2box, new GUI.WindowFunction(this.Window2), "Select color");
			}
		}
		
		private void GuiShow()
		{
			GUI1 = true;
			FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = true;
		}
		
		private void Window1(int windowId)
		{
			bool flag00 = GUI.Button(new Rect(140f, 355f, 120f, 30f), "Select all parts");
			if (flag00)
			{
				if(BODY)
				{
					BODY = false;
					DOORL = false;
					DOORR = false;
					FENDERL = false;
					FENDERR = false;
					HOOD = false;
					BOOTLID = false;
					FIBERHOOD = false;
					FLARESPOILER = false;
					FLAREFL = false;
					FLAREFR = false;
					FLARERL = false;
					FLARERR = false;
					FSPOILER = false;
					SPOILER = false;
					SPOILER2 = false;
					WGRILLE = false;
					ROLL = false;
					GTGRILLE = false;
					WHEELS = false;
					GRILLE = false;
					FBUMPER = false;
					RBUMPER = false;
					BLOCK = false;
					CPULLEY = false;
					RCOVER = false;
					LSKIRT = false;
					RSKIRT = false;
					RMUFFLER = false;
					AIRFILTER = false;
					SUBPANEL = false;
				}
				else
				{
					BODY = true;
					DOORL = true;
					DOORR = true;
					FENDERL = true;
					FENDERR = true;
					HOOD = true;
					BOOTLID = true;
					FIBERHOOD = true;
					FLARESPOILER = true;
					FLAREFL = true;
					FLAREFR = true;
					FLARERL = true;
					FLARERR = true;
					FSPOILER = true;
					SPOILER = true;
					SPOILER2 = true;
					WGRILLE = true;
					ROLL = true;
					GTGRILLE = true;
					WHEELS = true;
					GRILLE = true;
					FBUMPER = true;
					RBUMPER = true;
					BLOCK = true;
					CPULLEY = true;
					RCOVER = true;
					LSKIRT = true;
					RSKIRT = true;
					RMUFFLER = true;
					AIRFILTER = true;
					SUBPANEL = true;
				}
			}
			bool flag0 = GUI.Button(new Rect(380f, 355f, 120f, 30f), "Close");
			if (flag0)
			{
				GUI1 = false;
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
			}
			bool flag1 = GUI.Button(new Rect(260f, 355f, 120f, 30f), "Select color");
			if (flag1)
			{
				GUI1 = false;
				GUI2 = true;
			}
			bool flag2 = GUI.Button(new Rect(15f, 25f, 120f, 30f), "Body");
			if (flag2)
			{
				BODY = !BODY;
			}
			
			if(BODY)
			{
				GUI.Label(new Rect(135f, 30f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 30f, 120f, 30f), " NO");
			}
			
			bool flag3 = GUI.Button(new Rect(15f, 55f, 120f, 30f), "Door left");
			if (flag3)
			{
				DOORL = !DOORL;
			}
			
			if(DOORL)
			{
				GUI.Label(new Rect(135f, 60f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 60f, 120f, 30f), " NO");
			}
			
			bool flag4 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Door right");
			if (flag4)
			{
				DOORR = !DOORR;
			}
			
			if(DOORR)
			{
				GUI.Label(new Rect(135f, 90f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 90f, 120f, 30f), " NO");
			}
			
			bool flag5 = GUI.Button(new Rect(15f, 115f, 120f, 30f), "Fender left");
			if (flag5)
			{
				FENDERL = !FENDERL;
			}
			
			if(FENDERL)
			{
				GUI.Label(new Rect(135f, 120f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 120f, 120f, 30f), " NO");
			}
			
			bool flag6 = GUI.Button(new Rect(15f, 145f, 120f, 30f), "Fender right");
			if (flag6)
			{
				FENDERR = !FENDERR;
			}
			
			if(FENDERR)
			{
				GUI.Label(new Rect(135f, 150f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 150f, 120f, 30f), " NO");
			}
			
			bool flag7 = GUI.Button(new Rect(15f, 175f, 120f, 30f), "Hood");
			if (flag7)
			{
				HOOD = !HOOD;
			}
			
			if(HOOD)
			{
				GUI.Label(new Rect(135f, 180f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 180f, 120f, 30f), " NO");
			}
			
			bool flag8 = GUI.Button(new Rect(15f, 205f, 120f, 30f), "Boot lid");
			if (flag8)
			{
				BOOTLID = !BOOTLID;
			}
			
			if(BOOTLID)
			{
				GUI.Label(new Rect(135f, 210f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 210f, 120f, 30f), " NO");
			}
			
			bool flag9 = GUI.Button(new Rect(15f, 235f, 120f, 30f), "Grille");
			if (flag9)
			{
				GRILLE = !GRILLE;
			}
			
			if(GRILLE)
			{
				GUI.Label(new Rect(135f, 240f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 240f, 120f, 30f), " NO");
			}
			
			bool flag10 = GUI.Button(new Rect(15f, 265f, 120f, 30f), "Front bumper");
			if (flag10)
			{
				FBUMPER = !FBUMPER;
			}
			
			if(FBUMPER)
			{
				GUI.Label(new Rect(135f, 270f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 270f, 120f, 30f), " NO");
			}
			
			bool flag11 = GUI.Button(new Rect(15f, 295f, 120f, 30f), "Rear bumper");
			if (flag11)
			{
				RBUMPER = !RBUMPER;
			}
			
			if(RBUMPER)
			{
				GUI.Label(new Rect(135f, 300f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(135f, 300f, 120f, 30f), " NO");
			}
			
			bool flag12 = GUI.Button(new Rect(170f, 25f, 120f, 30f), "Engine block");
			if (flag12)
			{
				BLOCK = !BLOCK;
			}
			
			if(BLOCK)
			{
				GUI.Label(new Rect(290f, 30f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(290f, 30f, 120f, 30f), " NO");
			}
			
			bool flag13 = GUI.Button(new Rect(170f, 55f, 120f, 30f), "Crankshaft pulley");
			if (flag13)
			{
				CPULLEY = !CPULLEY;
			}
			
			if(CPULLEY)
			{
				GUI.Label(new Rect(290f, 60f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(290f, 60f, 120f, 30f), " NO");
			}
			
			bool flag14 = GUI.Button(new Rect(170f, 85f, 120f, 30f), "Rocker cover");
			if (flag14)
			{
				RCOVER = !RCOVER;
			}
			
			if(RCOVER)
			{
				GUI.Label(new Rect(290f, 90f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(290f, 90f, 120f, 30f), " NO");
			}
			
			bool flag140 = GUI.Button(new Rect(170f, 115f, 120f, 30f), "Air filter");
			if (flag140)
			{
				AIRFILTER = !AIRFILTER;
			}
			
			if(AIRFILTER)
			{
				GUI.Label(new Rect(290f, 120f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(290f, 120f, 120f, 30f), " NO");
			}
			
			bool flag15 = GUI.Button(new Rect(170f, 175f, 120f, 30f), "Installed wheels");
			if (flag15)
			{
				WHEELS = !WHEELS;
			}
			
			if(WHEELS)
			{
				GUI.Label(new Rect(290f, 180f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(290f, 180f, 120f, 30f), " NO");
			}
			
			bool flag16 = GUI.Button(new Rect(170f, 235f, 120f, 30f), "GT grille");
			if (flag16)
			{
				GTGRILLE = !GTGRILLE;
			}
			
			if(GTGRILLE)
			{
				GUI.Label(new Rect(290f, 240f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(290f, 240f, 120f, 30f), " NO");
			}
			
			bool flag17 = GUI.Button(new Rect(170f, 265f, 120f, 30f), "Roll cage");
			if (flag17)
			{
				ROLL = !ROLL;
			}
			
			if(ROLL)
			{
				GUI.Label(new Rect(290f, 270f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(290f, 270f, 120f, 30f), " NO");
			}
			
			bool flag18 = GUI.Button(new Rect(170f, 295f, 120f, 30f), "Fiberglass hood");
			if (flag18)
			{
				FIBERHOOD = !FIBERHOOD;
			}
			
			if(FIBERHOOD)
			{
				GUI.Label(new Rect(290f, 300f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(290f, 300f, 120f, 30f), " NO");
			}
			
			bool flag20 = GUI.Button(new Rect(325f, 25f, 120f, 30f), "Fender fl. spoiler");
			if (flag20)
			{
				FLARESPOILER = !FLARESPOILER;
			}
			
			if(FLARESPOILER)
			{
				GUI.Label(new Rect(445f, 30f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(445f, 30f, 120f, 30f), " NO");
			}
			
			bool flag21 = GUI.Button(new Rect(325f, 55f, 120f, 30f), "Fender flare FL");
			if (flag21)
			{
				FLAREFL = !FLAREFL;
			}
			
			if(FLAREFL)
			{
				GUI.Label(new Rect(445f, 60f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(445f, 60f, 120f, 30f), " NO");
			}
			
			bool flag22 = GUI.Button(new Rect(325f, 85f, 120f, 30f), "Fender flare FR");
			if (flag22)
			{
				FLAREFR = !FLAREFR;
			}
			
			if(FLAREFR)
			{
				GUI.Label(new Rect(445f, 90f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(445f, 90f, 120f, 30f), " NO");
			}
			
			bool flag23 = GUI.Button(new Rect(325f, 115f, 120f, 30f), "Fender flare RL");
			if (flag23)
			{
				FLARERL = !FLARERL;
			}
			
			if(FLARERL)
			{
				GUI.Label(new Rect(445f, 120f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(445f, 120f, 120f, 30f), " NO");
			}
			
			bool flag24 = GUI.Button(new Rect(325f, 145f, 120f, 30f), "Fender flare RR");
			if (flag24)
			{
				FLARERR = !FLARERR;
			}
			
			if(FLARERR)
			{
				GUI.Label(new Rect(445f, 150f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(445f, 150f, 120f, 30f), " NO");
			}
			
			bool flag25 = GUI.Button(new Rect(325f, 175f, 120f, 30f), "Left side skirt");
			if (flag25)
			{
				LSKIRT = !LSKIRT;
			}
			
			if(LSKIRT)
			{
				GUI.Label(new Rect(445f, 180f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(445f, 180f, 120f, 30f), " NO");
			}
			
			bool flag26 = GUI.Button(new Rect(325f, 205f, 120f, 30f), "Right side skirt");
			if (flag26)
			{
				RSKIRT = !RSKIRT;
			}
			
			if(RSKIRT)
			{
				GUI.Label(new Rect(445f, 210f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(445f, 210f, 120f, 30f), " NO");
			}
			
			bool flag27 = GUI.Button(new Rect(325f, 235f, 120f, 30f), "Front spoiler");
			if (flag27)
			{
				FSPOILER = !FSPOILER;
			}
			
			if(FSPOILER)
			{
				GUI.Label(new Rect(445f, 240f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(445f, 240f, 120f, 30f), " NO");
			}
			
			bool flag28 = GUI.Button(new Rect(325f, 265f, 120f, 30f), "Rear spoiler");
			if (flag28)
			{
				SPOILER = !SPOILER;
			}
			
			if(SPOILER)
			{
				GUI.Label(new Rect(445f, 270f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(445f, 270f, 120f, 30f), " NO");
			}
			
			bool flag29 = GUI.Button(new Rect(325f, 295f, 120f, 30f), "Rear spoiler 2");
			if (flag29)
			{
				SPOILER2 = !SPOILER2;
			}
			
			if(SPOILER2)
			{
				GUI.Label(new Rect(445f, 300f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(445f, 300f, 120f, 30f), " NO");
			}
			
			bool flag19 = GUI.Button(new Rect(480f, 25f, 120f, 30f), "Window grille");
			if (flag19)
			{
				WGRILLE = !WGRILLE;
			}
			
			if(WGRILLE)
			{
				GUI.Label(new Rect(600f, 30f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(600f, 30f, 120f, 30f), " NO");
			}
			
			bool flag30 = GUI.Button(new Rect(480f, 85f, 120f, 30f), "Subwoofer panel");
			if (flag30)
			{
				SUBPANEL = !SUBPANEL;
			}
			
			if(SUBPANEL)
			{
				GUI.Label(new Rect(600f, 90f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(600f, 90f, 120f, 30f), " NO");
			}
			
			bool flag31 = GUI.Button(new Rect(480f, 155f, 120f, 30f), "Racing muffler");
			if (flag31)
			{
				RMUFFLER = !RMUFFLER;
			}
			
			if(RMUFFLER)
			{
				GUI.Label(new Rect(600f, 160f, 120f, 30f), " YES");
			}
			else
			{
				GUI.Label(new Rect(600f, 160f, 120f, 30f), " NO");
			}
			GUI.DragWindow();
		}
		
		private void Window2(int windowId)
		{
			GUI.Label(new Rect(15f, 25f, 300f, 30f), "Color code: " + r + ", " + g + ", " + b);
			bool flag0 = GUI.Button(new Rect(355f, 150f, 160f, 30f), "Close");
			if (flag0)
			{
				GUI2 = false;
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
			}
			bool flag1 = GUI.Button(new Rect(15f, 50f, 80f, 30f), "red ---");
			if (flag1)
			{
				if(r > 0.1f)
				{
					r = r - 0.1f;
				}
				else
				{
					r = 0f;
				}
			}
			bool flag2 = GUI.Button(new Rect(95f, 50f, 80f, 30f), "red +++");
			if (flag2)
			{
				if(r < 0.9f)
				{
					r = r + 0.1f;
				}
				else
				{
					r = 1f;
				}
			}
			bool flag3 = GUI.Button(new Rect(15f, 80f, 80f, 30f), "red --");
			if (flag3)
			{
				if(r > 0.01f)
				{
					r = r - 0.01f;
				}
				else
				{
					r = 0f;
				}
			}
			bool flag4 = GUI.Button(new Rect(95f, 80f, 80f, 30f), "red ++");
			if (flag4)
			{
				if(r < 0.99f)
				{
					r = r + 0.01f;
				}
				else
				{
					r = 1f;
				}
			}
			bool flag5 = GUI.Button(new Rect(15f, 110f, 80f, 30f), "red -");
			if (flag5)
			{
				if(r > 0.001f)
				{
					r = r - 0.001f;
				}
				else
				{
					r = 0f;
				}
			}
			bool flag6 = GUI.Button(new Rect(95f, 110f, 80f, 30f), "red +");
			if (flag6)
			{
				if(r < 0.999f)
				{
					r = r + 0.001f;
				}
				else
				{
					r = 1f;
				}
			}
			bool flag7 = GUI.Button(new Rect(185f, 50f, 80f, 30f), "green ---");
			if (flag7)
			{
				if(g > 0.1f)
				{
					g = g - 0.1f;
				}
				else
				{
					g = 0f;
				}
			}
			bool flag8 = GUI.Button(new Rect(265f, 50f, 80f, 30f), "green +++");
			if (flag8)
			{
				if(g < 0.9f)
				{
					g = g + 0.1f;
				}
				else
				{
					g = 1f;
				}
			}
			bool flag9 = GUI.Button(new Rect(185f, 80f, 80f, 30f), "green --");
			if (flag9)
			{
				if(g > 0.01f)
				{
					g = g - 0.01f;
				}
				else
				{
					g = 0f;
				}
			}
			bool flag10 = GUI.Button(new Rect(265f, 80f, 80f, 30f), "green ++");
			if (flag10)
			{
				if(g < 0.99f)
				{
					g = g + 0.01f;
				}
				else
				{
					g = 1f;
				}
			}
			bool flag11 = GUI.Button(new Rect(185f, 110f, 80f, 30f), "green -");
			if (flag11)
			{
				if(g > 0.001f)
				{
					g = g - 0.001f;
				}
				else
				{
					g = 0f;
				}
			}
			bool flag12 = GUI.Button(new Rect(265f, 110f, 80f, 30f), "green +");
			if (flag12)
			{
				if(g < 0.999f)
				{
					g = g + 0.001f;
				}
				else
				{
					g = 1f;
				}
			}
			bool flag13 = GUI.Button(new Rect(355f, 50f, 80f, 30f), "blue ---");
			if (flag13)
			{
				if(b > 0.1f)
				{
					b = b - 0.1f;
				}
				else
				{
					b = 0f;
				}
			}
			bool flag14 = GUI.Button(new Rect(435f, 50f, 80f, 30f), "blue +++");
			if (flag14)
			{
				if(b < 0.9f)
				{
					b = b + 0.1f;
				}
				else
				{
					b = 1f;
				}
			}
			bool flag15 = GUI.Button(new Rect(355f, 80f, 80f, 30f), "blue --");
			if (flag15)
			{
				if(b > 0.01f)
				{
					b = b - 0.01f;
				}
				else
				{
					b = 0f;
				}
			}
			bool flag16 = GUI.Button(new Rect(435f, 80f, 80f, 30f), "blue ++");
			if (flag16)
			{
				if(b < 0.99f)
				{
					b = b + 0.01f;
				}
				else
				{
					b = 1f;
				}
			}
			bool flag17 = GUI.Button(new Rect(355f, 110f, 80f, 30f), "blue -");
			if (flag17)
			{
				if(b > 0.001f)
				{
					b = b - 0.001f;
				}
				else
				{
					b = 0f;
				}
			}
			bool flag18 = GUI.Button(new Rect(435f, 110f, 80f, 30f), "blue +");
			if (flag18)
			{
				if(b < 0.999f)
				{
					b = b + 0.001f;
				}
				else
				{
					b = 1f;
				}
			}
			bool flag19 = GUI.Button(new Rect(185f, 150f, 160f, 30f), "Load from file");
			if (flag19)
			{
				loadsettings();
			}
			bool flag20 = GUI.Button(new Rect(15f, 150f, 160f, 30f), "Save to file");
			if (flag20)
			{
				savesettings();
			}
			GUI.DragWindow();
		}
		
		private void savesettings()
		{
			string[] array = new string[3];
			
			string[] arg_11_0 = array;
			int arg_11_1 = 0;
			float num1 = r;
			arg_11_0[arg_11_1] = num1.ToString();
			
			string[] arg_12_0 = array;
			int arg_12_1 = 1;
			float num2 = g;
			arg_12_0[arg_12_1] = num2.ToString();
			
			string[] arg_13_0 = array;
			int arg_13_1 = 2;
			float num3 = b;
			arg_13_0[arg_13_1] = num3.ToString();
			
			File.WriteAllLines(path + "/Color.txt", array);
		}
		
		private void loadsettings()
		{
			string[] array = new string[3];
			if (File.Exists(path + "/Color.txt"))
			{
				array = File.ReadAllLines(path + "/Color.txt");
				
				r = float.Parse(array[0]);
				g = float.Parse(array[1]);
				b = float.Parse(array[2]);
			}
		}
    }
}
