﻿using HutongGames.PlayMaker;
using MSCLoader;
using UnityEngine;

namespace CheatBox
{
    public class CheatBox : Mod
    {
        public override string ID { get { return "CheatBox"; } }
        public override string Name { get { return "CheatBox"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private Keybind CheatsGuiKey = new Keybind("ShowCheatGUI", "Show Cheat GUI", KeyCode.C, KeyCode.LeftControl);
		private Rect guiBox = new Rect((Screen.width-400)/2, 10f, 400f, 700f);
		private bool guiShow;
		private bool needs;

        public override void OnLoad()
        {
			Keybind.Add(this, CheatsGuiKey);
        }
		
		public override void OnGUI()
		{
			bool guiShow = this.guiShow;
			if (guiShow)
			{
				GUI.ModalWindow(1, this.guiBox, new GUI.WindowFunction(this.Window), "CheatBox");
			}
		}
		
		private void Window(int windowId)
		{
			bool flag0 = GUI.Button(new Rect(150f, 650f, 100f, 30f), "Close");
			if (flag0)
			{
				this.guiShow = false;
			}
			GUI.Label(new Rect(47f, 25f, 120f, 30f), "Teleports");
			bool flag1 = GUI.Button(new Rect(15f, 50f, 120f, 30f), "Me to home");
			if (flag1)
			{
				TpTo("PLAYER", "GraveYardSpawn");
			}
			bool flag2 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Me to store");
			if (flag2)
			{
				TpTo("PLAYER", "SpawnToStore");
			}
			bool flag3 = GUI.Button(new Rect(15f, 120f, 120f, 30f), "Me to repair shop");
			if (flag3)
			{
				TpTo("PLAYER", "SpawnToRepair");
			}
			bool flag4 = GUI.Button(new Rect(15f, 155f, 120f, 30f), "Me to drag");
			if (flag4)
			{
				TpTo("PLAYER", "SpawnToDrag");
			}
			bool flag5 = GUI.Button(new Rect(15f, 190f, 120f, 30f), "Me to cottage");
			if (flag5)
			{
				TpTo("PLAYER", "SpawnToCottage");
			}
			bool flag6 = GUI.Button(new Rect(15f, 225f, 120f, 30f), "Me to Satsuma");
			if (flag6)
			{
				TpTo("PLAYER", "SATSUMA(557kg)");
			}
			bool flag7 = GUI.Button(new Rect(15f, 260f, 120f, 30f), "Satsuma to me");
			if (flag7)
			{
				TpMe("SATSUMA(557kg)", "PLAYER");
			}
			bool flag8 = GUI.Button(new Rect(15f, 295f, 120f, 30f), "Me to muscle car");
			if (flag8)
			{
				TpTo("PLAYER", "FERNDALE(1630kg)");
			}
			bool flag9 = GUI.Button(new Rect(15f, 330f, 120f, 30f), "Muscle car to me");
			if (flag9)
			{
				TpMe("FERNDALE(1630kg)", "PLAYER");
			}
			bool flag10 = GUI.Button(new Rect(15f, 365f, 120f, 30f), "Me to truck");
			if (flag10)
			{
				TpTo("PLAYER", "GIFU(750/450psi)");
			}
			bool flag11 = GUI.Button(new Rect(15f, 400f, 120f, 30f), "Truck to me");
			if (flag11)
			{
				TpMe("GIFU(750/450psi)", "PLAYER");
			}
			bool flag12 = GUI.Button(new Rect(15f, 435f, 120f, 30f), "Me to tractor");
			if (flag12)
			{
				TpTo("PLAYER", "KEKMET(350-400psi)");
			}
			bool flag13 = GUI.Button(new Rect(15f, 470f, 120f, 30f), "Tractor to me");
			if (flag13)
			{
				TpTo("KEKMET(350-400psi)", "PLAYER");
			}
			bool flag14 = GUI.Button(new Rect(15f, 505f, 120f, 30f), "Me to van");
			if (flag14)
			{
				TpTo("PLAYER", "HAYOSIKO(1500kg)");
			}
			bool flag15 = GUI.Button(new Rect(15f, 540f, 120f, 30f), "Van to me");
			if (flag15)
			{
				TpTo("HAYOSIKO(1500kg)", "PLAYER");
			}
			bool flag16 = GUI.Button(new Rect(15f, 575f, 120f, 30f), "Me to moped");
			if (flag16)
			{
				TpTo("PLAYER", "JONNEZ ES(Clone)");
			}
			bool flag17 = GUI.Button(new Rect(15f, 610f, 120f, 30f), "Moped to me");
			if (flag17)
			{
				TpTo("JONNEZ ES(Clone)", "PLAYER");
			}
			GUI.Label(new Rect(180f, 25f, 120f, 30f), "Needs");
			bool flag18 = GUI.Button(new Rect(140f, 50f, 120f, 30f), "off/on needs");
			if (flag18)
			{
				this.needs = !this.needs;
			}
			bool flag19 = GUI.Button(new Rect(140f, 85f, 120f, 30f), "Set full fatigue");
			if (flag19)
			{
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value = 100f;
			}
			GUI.Label(new Rect(180f, 130f, 120f, 30f), "Money");
			bool flag20 = GUI.Button(new Rect(140f, 155f, 120f, 30f), "Set 3 000mk");
			if (flag20)
			{
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = 3000;
			}
			bool flag21 = GUI.Button(new Rect(140f, 190f, 120f, 30f), "Set 50 000mk");
			if (flag21)
			{
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = 50000;
			}
			bool flag22 = GUI.Button(new Rect(140f, 225f, 120f, 30f), "Set 500 000mk");
			if (flag22)
			{
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = 500000;
			}
			GUI.Label(new Rect(162f, 270f, 120f, 30f), "Day of week");
			bool flag23 = GUI.Button(new Rect(140f, 295f, 120f, 30f), "Monday");
			if (flag23)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 1;
			}
			bool flag24 = GUI.Button(new Rect(140f, 330f, 120f, 30f), "Tuesday");
			if (flag24)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 2;
			}
			bool flag25 = GUI.Button(new Rect(140f, 365f, 120f, 30f), "Wednesday");
			if (flag25)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 3;
			}
			bool flag26 = GUI.Button(new Rect(140f, 400f, 120f, 30f), "Thursday");
			if (flag26)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 4;
			}
			bool flag27 = GUI.Button(new Rect(140f, 435f, 120f, 30f), "Friday");
			if (flag27)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 5;
			}
			bool flag28 = GUI.Button(new Rect(140f, 470f, 120f, 30f), "Saturday");
			if (flag28)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 6;
			}
			bool flag29 = GUI.Button(new Rect(140f, 505f, 120f, 30f), "Sunday");
			if (flag29)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 7;
			}
			GUI.Label(new Rect(280f, 25f, 120f, 30f), "Teleports to me");
			bool flag30 = GUI.Button(new Rect(265f, 50f, 120f, 30f), "Toolbox");
			if (flag30)
			{
				TpMe("tool box(itemx)", "PLAYER");
			}
			bool flag31 = GUI.Button(new Rect(265f, 85f, 120f, 30f), "Diesel jerrycan");
			if (flag31)
			{
				TpMe("diesel(itemx)", "PLAYER");
			}
			bool flag32 = GUI.Button(new Rect(265f, 120f, 120f, 30f), "Gasoline jerrycan");
			if (flag32)
			{
				TpMe("gasoline(itemx)", "PLAYER");
			}
			bool flag33 = GUI.Button(new Rect(265f, 155f, 120f, 30f), "Fuel tank");
			if (flag33)
			{
				TpMe("fuel tank(Clone)", "PLAYER");
			}
			bool flag34 = GUI.Button(new Rect(265f, 190f, 120f, 30f), "Muffler stock");
			if (flag34)
			{
				TpMe("exhaust muffler(Clone)", "PLAYER");
			}
			bool flag35 = GUI.Button(new Rect(265f, 225f, 120f, 30f), "Pipe stock");
			if (flag35)
			{
				TpMe("exhaust pipe(Clone)", "PLAYER");
			}
			bool flag36 = GUI.Button(new Rect(265f, 260f, 120f, 30f), "Muffler racing");
			if (flag36)
			{
				TpMe("racing muffler(Clone)", "PLAYER");
			}
			bool flag37 = GUI.Button(new Rect(265f, 295f, 120f, 30f), "Pipe racing");
			if (flag37)
			{
				TpMe("racing exhaust(Clone)", "PLAYER");
			}
			bool flag38 = GUI.Button(new Rect(265f, 330f, 120f, 30f), "Front bumper");
			if (flag38)
			{
				TpMe("bumper front(Clone)", "PLAYER");
			}
			bool flag39 = GUI.Button(new Rect(265f, 365f, 120f, 30f), "Rear bumper");
			if (flag39)
			{
				TpMe("bumper rear(Clone)", "PLAYER");
			}
			bool flag40 = GUI.Button(new Rect(265f, 400f, 120f, 30f), "Fender left");
			if (flag40)
			{
				TpMe("fender left(Clone)", "PLAYER");
			}
			bool flag41 = GUI.Button(new Rect(265f, 435f, 120f, 30f), "Fender right");
			if (flag41)
			{
				TpMe("fender right(Clone)", "PLAYER");
			}
			bool flag42 = GUI.Button(new Rect(265f, 470f, 120f, 30f), "Door left");
			if (flag42)
			{
				TpMe("door left(Clone)", "PLAYER");
			}
			bool flag43 = GUI.Button(new Rect(265f, 505f, 120f, 30f), "Door right");
			if (flag43)
			{
				TpMe("door right(Clone)", "PLAYER");
			}
			bool flag44 = GUI.Button(new Rect(265f, 540f, 120f, 30f), "Bootlid");
			if (flag44)
			{
				TpMe("bootlid(Clone)", "PLAYER");
			}
			bool flag45 = GUI.Button(new Rect(265f, 575f, 120f, 30f), "Hood");
			if (flag45)
			{
				TpMe("hood(Clone)", "PLAYER");
			}
			bool flag46 = GUI.Button(new Rect(265f, 610f, 120f, 30f), "Fiberglass hood");
			if (flag46)
			{
				TpMe("fiberglass hood(Clone)", "PLAYER");
			}
			GUI.DragWindow();
		}

        public override void Update()
        {
			if (CheatsGuiKey.IsDown()) { GuiShow(); };
			
			if(needs)
			{
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerDirtiness").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerDrunk").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerHunger").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerThirst").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerUrine").Value = 0.0f;
			}
        }
		
		private void GuiShow()
		{
			this.guiShow = !this.guiShow;
		}
		
		private void TpTo(string tpObject, string tptoObject)
        {
            ModConsole.Print("Teleportation to:" + tptoObject);
            var posFinder = GameObject.Find(tptoObject);
            Vector3 newPlayerPos = new Vector3(posFinder.transform.position.x + 3, posFinder.transform.position.y, posFinder.transform.position.z);
            GameObject.Find(tpObject).transform.position = newPlayerPos;
        }

        private void TpMe(string tpObject, string tptoObject)
        {
            ModConsole.Print("Teleporte me to:" + tptoObject);
            var posFinder = GameObject.Find(tptoObject);
            Vector3 newCarPos = new Vector3(posFinder.transform.position.x + 3, posFinder.transform.position.y, posFinder.transform.position.z);
            GameObject.Find(tpObject).transform.position = newCarPos;
        }
    }
}
