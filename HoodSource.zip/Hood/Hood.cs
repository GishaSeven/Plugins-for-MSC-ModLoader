﻿using MSCLoader;
using UnityEngine;
using System.Collections;

namespace Hood
{
    public class Hood : Mod
    {
        public override string ID { get { return "Hood"; } }
        public override string Name { get { return "Hood"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private bool loaded;
		private GameObject HOOD;
		private string path = ModLoader.ModsFolder+@"\Hood\";
		
        public override void Update()
        {
            if (Application.loadedLevelName == "GAME" && !loaded)
            {
				HOOD = GameObject.Find("fiberglass hood(Clone)");
							
				ObjImporter objimporter = new ObjImporter();
				Mesh new_mesh0 = new Mesh();
				new_mesh0 = objimporter.ImportFile(path + "hood.obj");
				
				HOOD.transform.GetComponent<MeshFilter>().mesh = new_mesh0;

				loaded = true;
            }
			
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
    }
}
