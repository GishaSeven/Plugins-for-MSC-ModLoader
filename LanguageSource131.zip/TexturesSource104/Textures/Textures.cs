﻿using MSCLoader;
using UnityEngine;
using System.Linq;
using HutongGames.PlayMaker;

namespace Textures
{
    public class Textures : Mod
    {
        public override string ID => "Textures";
        public override string Name => "Textures";
        public override string Author => "Roman266";
        public override string Version => "1.0.4";

		private bool compgames1;
		private bool compgames2;
		private bool compgames3;
		private bool compgames4;
		private bool compgames5;
		private bool compgames6;
		private bool compgames7;
		private bool compgames8;
		private bool compgames9;
		private bool compgames10;
		private bool compgames11;
		private bool compgames12;
		private bool compgames13;
		private bool compgames14;
		private bool compgames15;
		private bool compgames16;
		private bool compgames17;
		private bool compgames18;
		private bool compgames19;
		private bool compgames20;
		private bool compgames21;
		private bool compgames22;
		private bool compgames23;
		private bool compgames24;
		private bool compgames25;
		private bool compgames26;
		private bool compgames27;
		private bool compgames28;
		private bool compgames29;
		private bool compgames30;
		private bool compgames31;
		private bool compgames32;
		private bool compgames33;
		private bool compgames34;
		private bool compgames35;
		private bool compgames36;
		private bool compgames37;
		private bool compgames38;
		private bool compgames39;
		private bool compgames40;
		private bool compgames41;
		private bool compgames42;
		private bool compgames43;
		private bool compgames44;
		private bool compgames45;
		private bool compgames46;
		public override bool LoadInMenu => true;
		public override bool UseAssetsFolder => true;
		private Keybind ReloadTexturesKey = new Keybind("Reload Textures", "Reload Textures", KeyCode.F5);
		
		public override void OnMenuLoad() 
		{
			LoadTextures();
        }
		
		public override void OnLoad()
		{
			Keybind.Add(this, ReloadTexturesKey);
			
			LoadTextures();
        }
		
		public override void Update()
        {
			if (ReloadTexturesKey.IsDown()) 
			{ 
				LoadTextures();
			}
		}
		
		private void LoadTextures()
		{	
			if(Application.loadedLevelName == "MainMenu")
			{
				Texture2D texture1 = LoadAssets.LoadTexture(this, "drivers_lincence.dds");

				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Licence") >= 0).FirstOrDefault().transform.Find("Card/mesh").GetComponent<MeshRenderer>().material.mainTexture = texture1;
				
				ModConsole.Print("License texture changed!");
			}

			if(Application.loadedLevelName == "GAME")
			{
				Texture2D texture2 = LoadAssets.LoadTexture(this, "repairshop_01.dds");
				Texture2D texture3 = LoadAssets.LoadTexture(this, "repairshop_02.dds");
				Texture2D texture4 = LoadAssets.LoadTexture(this, "repairshop_03.dds");
				Texture2D texture5 = LoadAssets.LoadTexture(this, "repairshop_04.dds");
				Texture2D texture6 = LoadAssets.LoadTexture(this, "repairshop_05.dds");
				Texture2D texture7 = LoadAssets.LoadTexture(this, "repairshop_06.dds");
				Texture2D texture8 = LoadAssets.LoadTexture(this, "repairshop_07.dds");
				Texture2D texture9 = LoadAssets.LoadTexture(this, "repairshop_08.dds");

				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/PageFront/bg").GetComponent<MeshRenderer>().material.mainTexture = texture2;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/PageMisc/bg").GetComponent<MeshRenderer>().material.mainTexture = texture3;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/PageGearing/bg").GetComponent<MeshRenderer>().material.mainTexture = texture4;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/PageMetalwork/bg").GetComponent<MeshRenderer>().material.mainTexture = texture5;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/PagePaintCar/bg").GetComponent<MeshRenderer>().material.mainTexture = texture6;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/PagePaintRims/bg").GetComponent<MeshRenderer>().material.mainTexture = texture7;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/Background").GetComponent<MeshRenderer>().material.mainTexture = texture8;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ServiceBrochure/PageTirejob/bg").GetComponent<MeshRenderer>().material.mainTexture = texture9;
				
				ModConsole.Print("Repair shop textures changed!");
				
				if(GameObject.Find("register plate(Clone)") == null)
				{
					Texture2D texture10 = LoadAssets.LoadTexture(this, "inspection_recipiet_fi.dds");
					Texture2D texture11 = LoadAssets.LoadTexture(this, "inspection_recipiet_en.dds");
					Texture2D texture12 = LoadAssets.LoadTexture(this, "inspection_fail.dds");
					Texture2D texture13 = LoadAssets.LoadTexture(this, "inspection_pass.dds");

					Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("InspectionRecipiet/Background_FI").GetComponent<MeshRenderer>().material.mainTexture = texture10;
					Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("InspectionRecipiet/Background_EN").GetComponent<MeshRenderer>().material.mainTexture = texture11;
					Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("InspectionRecipiet/Checkmarks/ResultFail").GetComponent<MeshRenderer>().material.mainTexture = texture12;
					Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("InspectionRecipiet/Checkmarks/ResultPass").GetComponent<MeshRenderer>().material.mainTexture = texture13;
					
					ModConsole.Print("Inspection textures changed!");
				}

				Texture2D texture85 = LoadAssets.LoadTexture(this, "atkharrimainos.dds");
				Texture2D texture86 = LoadAssets.LoadTexture(this, "ATLAS_DOORS.dds");
				Texture2D texture87 = LoadAssets.LoadTexture(this, "magazine_template.dds");
				Texture2D texture88 = LoadAssets.LoadTexture(this, "page_audio.dds");
				Texture2D texture89 = LoadAssets.LoadTexture(this, "page_body.dds");
				Texture2D texture90 = LoadAssets.LoadTexture(this, "page_order.dds");
				Texture2D texture91 = LoadAssets.LoadTexture(this, "page_performance.dds");
				Texture2D texture92 = LoadAssets.LoadTexture(this, "page_performance2.dds");
				Texture2D texture93 = LoadAssets.LoadTexture(this, "page_poulstery.dds");
				Texture2D texture94 = LoadAssets.LoadTexture(this, "page_racing1.dds");
				Texture2D texture95 = LoadAssets.LoadTexture(this, "page_racing2.dds");
				Texture2D texture96 = LoadAssets.LoadTexture(this, "page_wheels.dds");
				Texture2D texture97 = LoadAssets.LoadTexture(this, "rally_register.dds");
				Texture2D texture98 = LoadAssets.LoadTexture(this, "rally_results.dds");
				Texture2D texture99 = LoadAssets.LoadTexture(this, "store_window_banners.dds");
				Texture2D texture100 = LoadAssets.LoadTexture(this, "ticket_bg.dds");
				Texture2D texture101 = LoadAssets.LoadTexture(this, "ATLAS_OFFICE.dds");
				Texture2D texture102 = LoadAssets.LoadTexture(this, "kuolinsyy.dds");
				Texture2D texture103 = LoadAssets.LoadTexture(this, "lottokuponki.dds");
				Texture2D texture104 = LoadAssets.LoadTexture(this, "procyon_letter.dds");
				Texture2D texture105 = LoadAssets.LoadTexture(this, "rally_ad.dds");
				Texture2D texture106 = LoadAssets.LoadTexture(this, "tt100.dds");
				Texture2D texture107 = LoadAssets.LoadTexture(this, "tt101.dds");
				Texture2D texture108 = LoadAssets.LoadTexture(this, "tt180.dds");
				Texture2D texture109 = LoadAssets.LoadTexture(this, "tt200.dds");
				Texture2D texture110 = LoadAssets.LoadTexture(this, "tt400.dds");
				Texture2D texture111 = LoadAssets.LoadTexture(this, "tt500.dds");
				Texture2D texture112 = LoadAssets.LoadTexture(this, "tt501.dds");
				
				texture106.filterMode = FilterMode.Point;
				texture107.filterMode = FilterMode.Point;
				texture108.filterMode = FilterMode.Point;
				texture109.filterMode = FilterMode.Point;
				texture110.filterMode = FilterMode.Point;
				texture111.filterMode = FilterMode.Point;
				texture112.filterMode = FilterMode.Point;

				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ComputerAD/Background").GetComponent<MeshRenderer>().material.mainTexture = texture85;
				
				GameObject.Find("INSPECTION").transform.Find("LOD/Door/mesh").GetComponent<MeshRenderer>().material.mainTexture = texture86;
				GameObject.Find("REPAIRSHOP").transform.Find("LOD/Door/mesh").GetComponent<MeshRenderer>().material.mainTexture = texture86;
				
				GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Paper/BG").GetComponent<MeshRenderer>().material.mainTexture = texture87;
				
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("Magazine/PageAudio/bg").GetComponent<MeshRenderer>().material.mainTexture = texture88;
				
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("Magazine/PageBody/bg").GetComponent<MeshRenderer>().material.mainTexture = texture89;
				
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("Magazine/Background").GetComponent<MeshRenderer>().material.mainTexture = texture90;
				
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("Magazine/PagePerformance 1/bg").GetComponent<MeshRenderer>().material.mainTexture = texture91;
				
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("Magazine/PagePerformance 2/bg").GetComponent<MeshRenderer>().material.mainTexture = texture92;
				
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("Magazine/PagePoulstery/bg").GetComponent<MeshRenderer>().material.mainTexture = texture93;
				
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("Magazine/PageRacing 1/bg").GetComponent<MeshRenderer>().material.mainTexture = texture94;
				
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("Magazine/PageRacing 2/bg").GetComponent<MeshRenderer>().material.mainTexture = texture95;
				
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("Magazine/PageWheels/bg").GetComponent<MeshRenderer>().material.mainTexture = texture96;
				
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("Rallyform/bg").GetComponent<MeshRenderer>().material.mainTexture = texture97;
				
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("RallyLeaderboard/bg").GetComponent<MeshRenderer>().material.mainTexture = texture98;
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("RallyResults/bg").GetComponent<MeshRenderer>().material.mainTexture = texture98;
				
				GameObject.Find("STORE").transform.Find("LOD/GFX_Store/store_windows").GetComponent<MeshRenderer>().sharedMaterial.mainTexture = texture99;
				
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("TrafficTicket/Background").GetComponent<MeshRenderer>().material.mainTexture = texture100;
				
				GameObject.Find("INSPECTION").transform.Find("LOD/inspection_posters").GetComponent<MeshRenderer>().material.mainTexture = texture101;
				GameObject.Find("STORE").transform.Find("LOD/GFX_Pub/paper_stand").GetComponent<MeshRenderer>().material.mainTexture = texture101;
				
				GameObject.Find("Systems").transform.Find("Death/GameOverScreen/Orbituary/Background").GetComponent<MeshRenderer>().material.mainTexture = texture102;
				
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("LottoTicket/BG/Background").GetComponent<MeshRenderer>().material.mainTexture = texture103;
				
				Resources.FindObjectsOfTypeAll<Transform>().Where(x => x.name.IndexOf("Sheets") >= 0).Last().transform.Find("ProcyonProducts/Background").GetComponent<MeshRenderer>().material.mainTexture = texture104;
				
				GameObject.Find("REPAIRSHOP").transform.Find("LOD/Office/Rally 1").GetComponent<MeshRenderer>().sharedMaterial.mainTexture = texture105;
				
				GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/100/bg").GetComponent<MeshRenderer>().material.mainTexture = texture106;
				GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/101/bg").GetComponent<MeshRenderer>().material.mainTexture = texture107;
				GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/180/bg").GetComponent<MeshRenderer>().material.mainTexture = texture108;
				GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/200/bg").GetComponent<MeshRenderer>().material.mainTexture = texture109;
				GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/400/bg").GetComponent<MeshRenderer>().material.mainTexture = texture110;
				GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/500/bg").GetComponent<MeshRenderer>().material.mainTexture = texture111;
				GameObject.Find("Systems").transform.Find("Teletext/VKTekstiTV/PAGES/501/bg").GetComponent<MeshRenderer>().material.mainTexture = texture112;
				
				ModConsole.Print("World textures changed!");
				
				if(GameObject.Find("YARD/Building/BEDROOM1") != null)
				{
					Texture2D texture14 = LoadAssets.LoadTexture(this, "Gauntlet-Fail.dds");
					Texture2D texture15 = LoadAssets.LoadTexture(this, "Gauntlet-GameScreen03.dds");
					Texture2D texture16 = LoadAssets.LoadTexture(this, "Gauntlet-MissionC.dds");
					Texture2D texture17 = LoadAssets.LoadTexture(this, "Gauntlet-NextDay.dds");
					Texture2D texture18 = LoadAssets.LoadTexture(this, "grilli-ikkuna.dds");
					Texture2D texture19 = LoadAssets.LoadTexture(this, "help1.dds");
					Texture2D texture20 = LoadAssets.LoadTexture(this, "JohnKemedyEnding.dds");
					Texture2D texture21 = LoadAssets.LoadTexture(this, "JohnKemedyGameOver.dds");
					Texture2D texture22 = LoadAssets.LoadTexture(this, "JohnKemedyInstructions.dds");
					Texture2D texture23 = LoadAssets.LoadTexture(this, "JohnKemedyMap.dds");
					Texture2D texture24 = LoadAssets.LoadTexture(this, "JohnKemedyPhase1.dds");
					Texture2D texture25 = LoadAssets.LoadTexture(this, "JohnKemedyPhase2.dds");
					Texture2D texture26 = LoadAssets.LoadTexture(this, "JohnKemedyPhase3.dds");
					Texture2D texture27 = LoadAssets.LoadTexture(this, "JohnKemedyRoad.dds");
					Texture2D texture28 = LoadAssets.LoadTexture(this, "JohnKemedyYouMadeIt.dds");
					Texture2D texture29 = LoadAssets.LoadTexture(this, "Joulupukki-GameOver.dds");
					Texture2D texture30 = LoadAssets.LoadTexture(this, "Joulupukki-HUD.dds");
					Texture2D texture31 = LoadAssets.LoadTexture(this, "Joulupukki-Level1.dds");
					Texture2D texture32 = LoadAssets.LoadTexture(this, "Joulupukki-Level2.dds");
					Texture2D texture33 = LoadAssets.LoadTexture(this, "Joulupukki-Level3.dds");
					Texture2D texture34 = LoadAssets.LoadTexture(this, "Joulupukki-Level4.dds");
					Texture2D texture35 = LoadAssets.LoadTexture(this, "Joulupukki-TitleScreen-Santa-FIN.dds");
					Texture2D texture36 = LoadAssets.LoadTexture(this, "lista1.dds");
					Texture2D texture37 = LoadAssets.LoadTexture(this, "Massacre-EndingText01.dds");
					Texture2D texture38 = LoadAssets.LoadTexture(this, "Massacre-EndingText02.dds");
					Texture2D texture39 = LoadAssets.LoadTexture(this, "Massacre-EndingText03.dds");
					Texture2D texture40 = LoadAssets.LoadTexture(this, "Massacre-EndingText04.dds");
					Texture2D texture41 = LoadAssets.LoadTexture(this, "Massacre-HUD.dds");
					Texture2D texture42 = LoadAssets.LoadTexture(this, "Massacre-Title2a.dds");
					Texture2D texture43 = LoadAssets.LoadTexture(this, "Massacre-Title2b.dds");
					Texture2D texture44 = LoadAssets.LoadTexture(this, "Massacre-Title2c2.dds");
					Texture2D texture45 = LoadAssets.LoadTexture(this, "Massacre-Title2d.dds");
					Texture2D texture46 = LoadAssets.LoadTexture(this, "Massacre-Title2e.dds");
					Texture2D texture47 = LoadAssets.LoadTexture(this, "menu1.dds");
					Texture2D texture48 = LoadAssets.LoadTexture(this, "menuohje.dds");
					Texture2D texture49 = LoadAssets.LoadTexture(this, "OjastaAlkoon-Loppu.dds");
					Texture2D texture50 = LoadAssets.LoadTexture(this, "OjastaAlkoon-peliohjeet_eng.dds");
					Texture2D texture51 = LoadAssets.LoadTexture(this, "OjastaAlkoon-peliohjeet_fin.dds");
					Texture2D texture52 = LoadAssets.LoadTexture(this, "OjastaAlkoon-peliruutu.dds");
					Texture2D texture53 = LoadAssets.LoadTexture(this, "OjastaAlkoon-TitleScreen.dds");
					Texture2D texture54 = LoadAssets.LoadTexture(this, "OjastaAlkoon-Voitto.dds");
					Texture2D texture55 = LoadAssets.LoadTexture(this, "PASI-energia.dds");
					Texture2D texture56 = LoadAssets.LoadTexture(this, "pasi-intro.dds");
					Texture2D texture57 = LoadAssets.LoadTexture(this, "PasiInvaders-TitleScreen.dds");
					Texture2D texture58 = LoadAssets.LoadTexture(this, "pasi-ohjeet_2.dds");
					Texture2D texture59 = LoadAssets.LoadTexture(this, "pieno-pianoscreen.dds");
					Texture2D texture60 = LoadAssets.LoadTexture(this, "pieno-titlescreen.dds");
					Texture2D texture61 = LoadAssets.LoadTexture(this, "Rehtori01-anim-lofi-screen01.dds");
					Texture2D texture62 = LoadAssets.LoadTexture(this, "Rehtori01-anim-lofi-screen02.dds");
					Texture2D texture63 = LoadAssets.LoadTexture(this, "RehtoriPasi01-anim-screen01.dds");
					Texture2D texture64 = LoadAssets.LoadTexture(this, "RehtoriPasi01-anim-screen02.dds");
					Texture2D texture65 = LoadAssets.LoadTexture(this, "title.dds");
					Texture2D texture66 = LoadAssets.LoadTexture(this, "WorldsMan-Magazine.dds");
					Texture2D texture67 = LoadAssets.LoadTexture(this, "Gauntlet-MissionA.dds");
					Texture2D texture68 = LoadAssets.LoadTexture(this, "Gauntlet-MissionB.dds");
					Texture2D texture69 = LoadAssets.LoadTexture(this, "poliisi.dds");
					Texture2D texture70 = LoadAssets.LoadTexture(this, "alkuvalikko.dds");
					Texture2D texture71 = LoadAssets.LoadTexture(this, "alkuvalikko2.dds");
					Texture2D texture72 = LoadAssets.LoadTexture(this, "loppu.dds");
					Texture2D texture73 = LoadAssets.LoadTexture(this, "nappi_kairaa.dds");
					Texture2D texture74 = LoadAssets.LoadTexture(this, "nappi_laske.dds");
					Texture2D texture75 = LoadAssets.LoadTexture(this, "nappi_nosta.dds");
					Texture2D texture76 = LoadAssets.LoadTexture(this, "pilkki_jarvi.dds");
					Texture2D texture77 = LoadAssets.LoadTexture(this, "punnitus.dds");
					Texture2D texture78 = LoadAssets.LoadTexture(this, "Rapula-endscreen.dds");
					Texture2D texture79 = LoadAssets.LoadTexture(this, "tulokset1.dds");
					Texture2D texture80 = LoadAssets.LoadTexture(this, "tulokset2.dds");
					Texture2D texture81 = LoadAssets.LoadTexture(this, "vakoile1.dds");
					Texture2D texture82 = LoadAssets.LoadTexture(this, "vakoile2.dds");
					Texture2D texture83 = LoadAssets.LoadTexture(this, "poistu.dds");
					Texture2D texture84 = LoadAssets.LoadTexture(this, "Massacre-GameOver.dds");
					Texture2D texture113 = LoadAssets.LoadTexture(this, "space.dds");
					
					texture14.filterMode = FilterMode.Point;
					texture15.filterMode = FilterMode.Point;
					texture16.filterMode = FilterMode.Point;
					texture17.filterMode = FilterMode.Point;
					texture18.filterMode = FilterMode.Point;
					texture19.filterMode = FilterMode.Point;
					texture20.filterMode = FilterMode.Point;
					texture21.filterMode = FilterMode.Point;
					texture22.filterMode = FilterMode.Point;
					texture23.filterMode = FilterMode.Point;
					texture24.filterMode = FilterMode.Point;
					texture25.filterMode = FilterMode.Point;
					texture26.filterMode = FilterMode.Point;
					texture27.filterMode = FilterMode.Point;
					texture28.filterMode = FilterMode.Point;
					texture29.filterMode = FilterMode.Point;
					texture30.filterMode = FilterMode.Point;
					texture31.filterMode = FilterMode.Point;
					texture32.filterMode = FilterMode.Point;
					texture33.filterMode = FilterMode.Point;
					texture34.filterMode = FilterMode.Point;
					texture35.filterMode = FilterMode.Point;
					texture36.filterMode = FilterMode.Point;
					texture37.filterMode = FilterMode.Point;
					texture38.filterMode = FilterMode.Point;
					texture39.filterMode = FilterMode.Point;
					texture40.filterMode = FilterMode.Point;
					texture41.filterMode = FilterMode.Point;
					texture42.filterMode = FilterMode.Point;
					texture43.filterMode = FilterMode.Point;
					texture44.filterMode = FilterMode.Point;
					texture45.filterMode = FilterMode.Point;
					texture46.filterMode = FilterMode.Point;
					texture47.filterMode = FilterMode.Point;
					texture48.filterMode = FilterMode.Point;
					texture49.filterMode = FilterMode.Point;
					texture50.filterMode = FilterMode.Point;
					texture51.filterMode = FilterMode.Point;
					texture52.filterMode = FilterMode.Point;
					texture53.filterMode = FilterMode.Point;
					texture54.filterMode = FilterMode.Point;
					texture55.filterMode = FilterMode.Point;
					texture56.filterMode = FilterMode.Point;
					texture57.filterMode = FilterMode.Point;
					texture58.filterMode = FilterMode.Point;
					texture59.filterMode = FilterMode.Point;
					texture60.filterMode = FilterMode.Point;
					texture61.filterMode = FilterMode.Point;
					texture62.filterMode = FilterMode.Point;
					texture63.filterMode = FilterMode.Point;
					texture64.filterMode = FilterMode.Point;
					texture65.filterMode = FilterMode.Point;
					texture66.filterMode = FilterMode.Point;
					texture67.filterMode = FilterMode.Point;
					texture68.filterMode = FilterMode.Point;
					texture69.filterMode = FilterMode.Point;
					texture70.filterMode = FilterMode.Point;
					texture71.filterMode = FilterMode.Point;
					texture72.filterMode = FilterMode.Point;
					texture73.filterMode = FilterMode.Point;
					texture74.filterMode = FilterMode.Point;
					texture75.filterMode = FilterMode.Point;
					texture76.filterMode = FilterMode.Point;
					texture77.filterMode = FilterMode.Point;
					texture78.filterMode = FilterMode.Point;
					texture79.filterMode = FilterMode.Point;
					texture80.filterMode = FilterMode.Point;
					texture81.filterMode = FilterMode.Point;
					texture82.filterMode = FilterMode.Point;
					texture83.filterMode = FilterMode.Point;
					texture84.filterMode = FilterMode.Point;
					texture113.filterMode = FilterMode.Point;

					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER").transform.Find("SYSTEM").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER").transform.Find("SYSTEM").gameObject.SetActive(true);
						compgames1 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-RunTheGauntlet").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-RunTheGauntlet").gameObject.SetActive(true);
						compgames2 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet").transform.Find("Gauntlet-LevelActivator").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet").transform.Find("Gauntlet-LevelActivator").gameObject.SetActive(true);
						compgames3 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet").transform.Find("Gauntlet-GameA").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet").transform.Find("Gauntlet-GameA").gameObject.SetActive(true);
						compgames4 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameA").transform.Find("Gauntlet-Player-GameA").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameA").transform.Find("Gauntlet-Player-GameA").gameObject.SetActive(true);
						compgames5 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet").transform.Find("Gauntlet-GameB").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet").transform.Find("Gauntlet-GameB").gameObject.SetActive(true);
						compgames6 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameB").transform.Find("Gauntlet-Player-GameB").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameB").transform.Find("Gauntlet-Player-GameB").gameObject.SetActive(true);
						compgames7 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet").transform.Find("Gauntlet-GameC").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet").transform.Find("Gauntlet-GameC").gameObject.SetActive(true);
						compgames8 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("Kaappis-Grilli").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("Kaappis-Grilli").gameObject.SetActive(true);
						compgames9 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("Kaappis-Wildvest").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("Kaappis-Wildvest").gameObject.SetActive(true);
						compgames10 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-JFK").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-JFK").gameObject.SetActive(true);
						compgames11 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK").transform.Find("JohnKemedyGameOver").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK").transform.Find("JohnKemedyGameOver").gameObject.SetActive(true);
						compgames12 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK").transform.Find("JohnKemedyPhaseActivator").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK").transform.Find("JohnKemedyPhaseActivator").gameObject.SetActive(true);
						compgames13 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK").transform.Find("JohnKemedyCar").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK").transform.Find("JohnKemedyCar").gameObject.SetActive(true);
						compgames14 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK").transform.Find("JohnKemedyMenuScreen").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK").transform.Find("JohnKemedyMenuScreen").gameObject.SetActive(true);
						compgames15 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-Joulupukki").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-Joulupukki").gameObject.SetActive(true);
						compgames16 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki").transform.Find("Joulupukki-Pelaaja").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki").transform.Find("Joulupukki-Pelaaja").gameObject.SetActive(true);
						compgames17 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki").transform.Find("Joulupukki-LevelMachine").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki").transform.Find("Joulupukki-LevelMachine").gameObject.SetActive(true);
						compgames18 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki").transform.Find("Joulupukki-Menu").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki").transform.Find("Joulupukki-Menu").gameObject.SetActive(true);
						compgames19 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-Massacre").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-Massacre").gameObject.SetActive(true);
						compgames20 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre").transform.Find("Massacre-Ending").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre").transform.Find("Massacre-Ending").gameObject.SetActive(true);
						compgames21 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre").transform.Find("Massacre-Menu").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre").transform.Find("Massacre-Menu").gameObject.SetActive(true);
						compgames22 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-OjastaAl(lik)koon").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-OjastaAl(lik)koon").gameObject.SetActive(true);
						compgames23 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-OjastaAl(lik)koon").transform.Find("OjastaAlkoon-CollectedBottles").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-OjastaAl(lik)koon").transform.Find("OjastaAlkoon-CollectedBottles").gameObject.SetActive(true);
						compgames24 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-OjastaAl(lik)koon").transform.Find("OjastaAlkoon-TitleScreen").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-OjastaAl(lik)koon").transform.Find("OjastaAlkoon-TitleScreen").gameObject.SetActive(true);
						compgames25 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-PasiInvaders").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-PasiInvaders").gameObject.SetActive(true);
						compgames26 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders").transform.Find("GameOver-ruutu").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders").transform.Find("GameOver-ruutu").gameObject.SetActive(true);
						compgames27 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders").transform.Find("Voittoruutu").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders").transform.Find("Voittoruutu").gameObject.SetActive(true);
						compgames28 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-Pieno").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-Pieno").gameObject.SetActive(true);
						compgames29 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Pieno").transform.Find("Pieno-Title").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Pieno").transform.Find("Pieno-Title").gameObject.SetActive(true);
						compgames30 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-WorldsMan").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-WorldsMan").gameObject.SetActive(true);
						compgames31 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-WorldsMan").transform.Find("WorldsMan-Truth").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-WorldsMan").transform.Find("WorldsMan-Truth").gameObject.SetActive(true);
						compgames32 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-Rapula").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("RAMI-Rapula").gameObject.SetActive(true);
						compgames33 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Rapula").transform.Find("Rapula-Ending").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Rapula").transform.Find("Rapula-Ending").gameObject.SetActive(true);
						compgames34 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("PROCYON-ProPilkki").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("PROCYON-ProPilkki").gameObject.SetActive(true);
						compgames35 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki").transform.Find("Alkuvalikko").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki").transform.Find("Alkuvalikko").gameObject.SetActive(true);
						compgames36 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Alkuvalikko").transform.Find("Valikko").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Alkuvalikko").transform.Find("Valikko").gameObject.SetActive(true);
						compgames37 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki").transform.Find("Peli").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki").transform.Find("Peli").gameObject.SetActive(true);
						compgames38 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli").transform.Find("Elementit").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli").transform.Find("Elementit").gameObject.SetActive(true);
						compgames39 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit").transform.Find("TapahtumaRuutu").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit").transform.Find("TapahtumaRuutu").gameObject.SetActive(true);
						compgames40 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit").transform.Find("VakoiluRuutu").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit").transform.Find("VakoiluRuutu").gameObject.SetActive(true);
						compgames41 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit").transform.Find("Toiminnot").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit").transform.Find("Toiminnot").gameObject.SetActive(true);
						compgames42 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki").transform.Find("Tulokset").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki").transform.Find("Tulokset").gameObject.SetActive(true);
						compgames43 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre").transform.Find("Massacre-Death").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre").transform.Find("Massacre-Death").gameObject.SetActive(true);
						compgames44 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("Kaappis-Fishgame").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").transform.Find("Kaappis-Fishgame").gameObject.SetActive(true);
						compgames45 = true;
					}
					
					if(!GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame").transform.Find("Viehe").gameObject.activeSelf)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame").transform.Find("Viehe").gameObject.SetActive(true);
						compgames46 = true;
					}
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture1 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-LevelActivator").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Alkuasetus").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture1.texture.Value = texture17;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture2 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-LevelActivator").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "GameC").Actions[6] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture2.texture.Value = texture15;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture3 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameA/Gauntlet-Player-GameA").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Caught 2").Actions[2] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture3.texture.Value = texture14;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture4 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameA/Gauntlet-Player-GameA").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "DefendFail 2").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture4.texture.Value = texture14;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture5 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameB/Gauntlet-Player-GameB").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Hit 2").Actions[2] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture5.texture.Value = texture14;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture6 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameC/Gauntlet-Player-GameC").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Alkuasetus").Actions[5] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture6.texture.Value = texture15;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture7 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameC/Gauntlet-Player-GameC").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Alkuasetus").Actions[6] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture7.texture.Value = texture16;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture8 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameC/Gauntlet-Player-GameC").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Caught 2").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture8.texture.Value = texture14;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture9 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameA/Gauntlet-Player-GameA").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Alkuasetus").Actions[2] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture9.texture.Value = texture67;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture10 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameB/Gauntlet-Player-GameB").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Alkuasetus").Actions[2] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture10.texture.Value = texture68;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture11 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Grilli/Lista").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture11.texture.Value = texture36;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture12 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Grilli/Main menu").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture12.texture.Value = texture47;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture13 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Grilli/Main menu").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Ohjeet").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture13.texture.Value = texture48;
					
					GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Grilli/Tausta").GetComponent<MeshRenderer>().material.mainTexture = texture18;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture14 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest/Menu").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Reset").Actions[4] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture14.texture.Value = texture65;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture15 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest/Menu").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[3] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture15.texture.Value = texture19;
					
					GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest/Poliisi").GetComponent<MeshRenderer>().material.mainTexture = texture69;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture16 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK/JohnKemedyGameOver").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "GameOver").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture16.texture.Value = texture21;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture17 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK/JohnKemedyPhaseActivator").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Pause 1").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture17.texture.Value = texture25;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture18 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK/JohnKemedyPhaseActivator").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Pause 2").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture18.texture.Value = texture26;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture19 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK/JohnKemedyPhaseActivator").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Aloitus").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture19.texture.Value = texture24;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture20 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK/JohnKemedyMenuScreen").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Instructions").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture20.texture.Value = texture22;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture21 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK/JohnKemedyCar").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "YouMadeIt").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture21.texture.Value = texture28;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture22 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK/JohnKemedyCar").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "EndScreen").Actions[1] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture22.texture.Value = texture20;
					
					GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK").transform.Find("JohnKemedyMap").GetComponent<MeshRenderer>().material.mainTexture = texture23;
					
					GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK").transform.Find("JohnKemedyRoad/JohnKemedyRoad-graphics").GetComponent<MeshRenderer>().material.mainTexture = texture27;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture23 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki/Joulupukki-Menu").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Settings").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture23.texture.Value = texture35;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture24 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki/Joulupukki-Menu").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Main Menu").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture24.texture.Value = texture35;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture25 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki/Joulupukki-Pelaaja").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "Game Over").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture25.texture.Value = texture29;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture26 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki/Joulupukki-LevelMachine").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Level 1 Ready").Actions[3] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture26.texture.Value = texture31;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture27 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki/Joulupukki-LevelMachine").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Level 2 Ready").Actions[8] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture27.texture.Value = texture32;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture28 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki/Joulupukki-LevelMachine").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Level 3 Ready").Actions[9] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture28.texture.Value = texture33;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture29 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki/Joulupukki-LevelMachine").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Level 4 Ready").Actions[9] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture29.texture.Value = texture34;
					
					GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki").transform.Find("Joulupukki-HUD").GetComponent<MeshRenderer>().material.mainTexture = texture30;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture30 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Ending").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[2] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture30.texture.Value = texture37;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture31 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Ending").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[1] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture31.texture.Value = texture38;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture32 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Ending").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 4").Actions[1] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture32.texture.Value = texture39;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture33 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Ending").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 5").Actions[1] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture33.texture.Value = texture40;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture34 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Menu").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Alkuasetukset").Actions[48] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture34.texture.Value = texture42;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture35 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Menu").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Menu").Actions[1] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture35.texture.Value = texture42;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture36 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Menu").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Start").Actions[15] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture36.texture.Value = texture41;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture37 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Menu").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Menu 2").Actions[1] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture37.texture.Value = texture43;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture38 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Menu").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Menu 3").Actions[1] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture38.texture.Value = texture44;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture39 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Menu").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Menu 4").Actions[1] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture39.texture.Value = texture45;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture40 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Menu").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Menu 5").Actions[1] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture40.texture.Value = texture46;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture41 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-OjastaAl(lik)koon/OjastaAlkoon-CollectedBottles").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "WIN").Actions[6] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture41.texture.Value = texture54;
					
					GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-OjastaAl(lik)koon").transform.Find("OjastaAlkoon-VoittoLoppu").GetComponent<MeshRenderer>().material.mainTexture = texture49;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture42 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-OjastaAl(lik)koon/OjastaAlkoon-TitleScreen").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture42.texture.Value = texture53;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture43 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-OjastaAl(lik)koon/OjastaAlkoon-TitleScreen").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Menu").Actions[1] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture43.texture.Value = texture53;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture44 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-OjastaAl(lik)koon/OjastaAlkoon-TitleScreen").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Ohjeet").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture44.texture.Value = texture51;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture45 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-OjastaAl(lik)koon/OjastaAlkoon-TitleScreen").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Aloita").Actions[14] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture45.texture.Value = texture52;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture46 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-OjastaAl(lik)koon/OjastaAlkoon-TitleScreen").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Ohjeet 2").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture46.texture.Value = texture50;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture47 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/GameOver-ruutu").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture47.texture.Value = texture63;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture48 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/GameOver-ruutu").GetComponents<PlayMakerFSM>()[0].FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture48.texture.Value = texture64;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture49 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Voittoruutu").GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture49.texture.Value = texture61;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture50 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Voittoruutu").GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture50.texture.Value = texture62;
					
					GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders").transform.Find("PasiInvaders-TitleScreen").GetComponent<MeshRenderer>().material.mainTexture = texture57;
					
					GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders").transform.Find("PasiInvaders-TitleScreen/Pasi-intro").GetComponent<MeshRenderer>().material.mainTexture = texture56;
					
					GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders").transform.Find("LopparinEnergiaGrafiikka").GetComponent<MeshRenderer>().material.mainTexture = texture55;
					
					GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders").transform.Find("PasiInvaders-TitleScreen/Ohjeet-Teksti").GetComponent<MeshRenderer>().material.mainTexture = texture58;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture51 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Pieno/Pieno-Title").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Aloita").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture51.texture.Value = texture59;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture52 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Pieno/Pieno-Title").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Alkuasetukset").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture52.texture.Value = texture60;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture53 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-WorldsMan/WorldsMan-Truth").GetComponents<PlayMakerFSM>()[1].FsmStates.FirstOrDefault(state => state.Name == "DeleteLines").Actions[3] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture53.texture.Value = texture66;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture54 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Rapula/Rapula-Ending").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "ENDING 1").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture54.texture.Value = texture78;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture55 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture55.texture.Value = texture70;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture56 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Alkuvalikko/Valikko").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture56.texture.Value = texture71;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture57 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Alkuvalikko/Valikko").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 4").Actions[1] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture57.texture.Value = texture70;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture58 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Alkuvalikko/Valikko").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 5").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture58.texture.Value = texture72;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture59 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Alkuvalikko/Valikko").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture59.texture.Value = texture70;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture60 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/TapahtumaRuutu").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 13").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture60.texture.Value = texture77;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture61 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/VakoiluRuutu").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[1] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture61.texture.Value = texture81;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture62 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/VakoiluRuutu").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 2").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture62.texture.Value = texture82;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture63 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/Toiminnot").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture63.texture.Value = texture73;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture64 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/Toiminnot").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 3").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture64.texture.Value = texture74;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture65 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/Toiminnot").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 4").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture65.texture.Value = texture73;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture66 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/Toiminnot").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 5").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture66.texture.Value = texture75;
					
					GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki").transform.Find("Peli/Kartta1/gfx").GetComponent<MeshRenderer>().material.mainTexture = texture76;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture67 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Tulokset").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "State 1").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture67.texture.Value = texture80;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture68 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Tulokset").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Resetoi").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture68.texture.Value = texture79;
					
					GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki").transform.Find("Peli/Elementit/Poistu").GetComponent<MeshRenderer>().material.mainTexture = texture83;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture69 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Death").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Game Over").Actions[0] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture69.texture.Value = texture84;
					
					HutongGames.PlayMaker.Actions.SetMaterialTexture gametexture70 = GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Viehe").GetComponent<PlayMakerFSM>().FsmStates.FirstOrDefault(state => state.Name == "Odotus").Actions[2] as HutongGames.PlayMaker.Actions.SetMaterialTexture;
					gametexture70.texture.Value = texture113;
					
					if(compgames46)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame/Viehe").gameObject.SetActive(false);
					}
					
					if(compgames45)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Fishgame").gameObject.SetActive(false);
					}
					
					if(compgames44)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Death").gameObject.SetActive(false);
					}
					
					if(compgames43)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Tulokset").gameObject.SetActive(false);
					}
					
					if(compgames42)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/Toiminnot").gameObject.SetActive(false);
					}
					
					if(compgames41)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/VakoiluRuutu").gameObject.SetActive(false);
					}
					
					if(compgames40)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit/TapahtumaRuutu").gameObject.SetActive(false);
					}
					
					if(compgames39)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli/Elementit").gameObject.SetActive(false);
					}
					
					if(compgames38)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Peli").gameObject.SetActive(false);
					}
					
					if(compgames37)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Alkuvalikko/Valikko").gameObject.SetActive(false);
					}
					
					if(compgames36)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki/Alkuvalikko").gameObject.SetActive(false);
					}

					if(compgames35)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/PROCYON-ProPilkki").gameObject.SetActive(false);
					}
					
					if(compgames34)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Rapula/Rapula-Ending").gameObject.SetActive(false);
					}

					if(compgames33)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Rapula").gameObject.SetActive(false);
					}

					if(compgames32)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-WorldsMan/WorldsMan-Truth").gameObject.SetActive(false);
					}
					
					if(compgames31)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-WorldsMan").gameObject.SetActive(false);
					}
					
					if(compgames30)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Pieno/Pieno-Title").gameObject.SetActive(false);
					}
					
					if(compgames29)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Pieno").gameObject.SetActive(false);
					}
					
					if(compgames28)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/Voittoruutu").gameObject.SetActive(false);
					}
					
					if(compgames27)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders/GameOver-ruutu").gameObject.SetActive(false);
					}
					
					if(compgames26)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-PasiInvaders").gameObject.SetActive(false);
					}
					
					if(compgames25)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-OjastaAl(lik)koon/OjastaAlkoon-TitleScreen").gameObject.SetActive(false);
					}
					
					if(compgames24)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-OjastaAl(lik)koon/OjastaAlkoon-CollectedBottles").gameObject.SetActive(false);
					}
					
					if(compgames23)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-OjastaAl(lik)koon").gameObject.SetActive(false);
					}
					
					if(compgames22)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Menu").gameObject.SetActive(false);
					}
					
					if(compgames21)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre/Massacre-Ending").gameObject.SetActive(false);
					}
					
					if(compgames20)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Massacre").gameObject.SetActive(false);
					}
					
					if(compgames19)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki/Joulupukki-Menu").gameObject.SetActive(false);
					}
					
					if(compgames18)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki/Joulupukki-LevelMachine").gameObject.SetActive(false);
					}
					
					if(compgames17)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki/Joulupukki-Pelaaja").gameObject.SetActive(false);
					}
					
					if(compgames16)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-Joulupukki").gameObject.SetActive(false);
					}
					
					if(compgames15)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK/JohnKemedyMenuScreen").gameObject.SetActive(false);
					}
					
					if(compgames14)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK/JohnKemedyCar").gameObject.SetActive(false);
					}
					
					if(compgames13)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK/JohnKemedyPhaseActivator").gameObject.SetActive(false);
					}
					
					if(compgames12)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK/JohnKemedyGameOver").gameObject.SetActive(false);
					}
					
					if(compgames11)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-JFK").gameObject.SetActive(false);
					}
					
					if(compgames10)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Wildvest").gameObject.SetActive(false);
					}
					
					if(compgames9)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/Kaappis-Grilli").gameObject.SetActive(false);
					}
					
					if(compgames8)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameC").gameObject.SetActive(false);
					}
					
					if(compgames7)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameB/Gauntlet-Player-GameB").gameObject.SetActive(false);
					}
					
					if(compgames6)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameB").gameObject.SetActive(false);
					}
					
					if(compgames5)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameA/Gauntlet-Player-GameA").gameObject.SetActive(false);
					}
					
					if(compgames4)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-GameA").gameObject.SetActive(false);
					}
					
					if(compgames3)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet/Gauntlet-LevelActivator").gameObject.SetActive(false);
					}
					
					if(compgames2)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM/RAMI-RunTheGauntlet").gameObject.SetActive(false);
					}
					
					if(compgames1)
					{
						GameObject.Find("YARD/Building/BEDROOM1/COMPUTER/SYSTEM").gameObject.SetActive(false);
					}
					
					compgames1 = false;
					compgames2 = false;
					compgames3 = false;
					compgames4 = false;
					compgames5 = false;
					compgames6 = false;
					compgames7 = false;
					compgames8 = false;
					compgames9 = false;
					compgames10 = false;
					compgames11 = false;
					compgames12 = false;
					compgames13 = false;
					compgames14 = false;
					compgames15 = false;
					compgames16 = false;
					compgames17 = false;
					compgames18 = false;
					compgames19 = false;
					compgames20 = false;
					compgames21 = false;
					compgames22 = false;
					compgames23 = false;
					compgames24 = false;
					compgames25 = false;
					compgames26 = false;
					compgames27 = false;
					compgames28 = false;
					compgames29 = false;
					compgames30 = false;
					compgames31 = false;
					compgames32 = false;
					compgames33 = false;
					compgames34 = false;
					compgames35 = false;
					compgames36 = false;
					compgames37 = false;
					compgames38 = false;
					compgames39 = false;
					compgames40 = false;
					compgames41 = false;
					compgames42 = false;
					compgames43 = false;
					compgames44 = false;
					compgames45 = false;
					compgames46 = false;
					
					ModConsole.Print("Computer textures changed!");
				}
			}
		}
    }
}
