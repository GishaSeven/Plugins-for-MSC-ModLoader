﻿using MSCLoader;
using UnityEngine;

namespace LFHUDFix
{
    public class LFHUDFix : Mod
    {
        public override string ID => "LFHUDFix";
        public override string Name => "LFHUDFix";
        public override string Author => "Roman266";
        public override string Version => "1.0.0";

		public override bool UseAssetsFolder => false;
		
		public override void OnLoad()
		{
			GameObject.Find("GUI/HUD/Mortal/HUDValue").transform.localPosition = new Vector3(GameObject.Find("GUI/HUD/Mortal/HUDValue").transform.localPosition.x, GameObject.Find("GUI/HUD/Mortal/HUDValue").transform.localPosition.y - 0.071f, GameObject.Find("GUI/HUD/Mortal/HUDValue").transform.localPosition.z);
			
			GameObject.Find("GUI/HUD/Day/HUDValue").transform.localPosition = new Vector3(GameObject.Find("GUI/HUD/Day/HUDValue").transform.localPosition.x + 0.03f, GameObject.Find("GUI/HUD/Day/HUDValue").transform.localPosition.y - 0.071f, GameObject.Find("GUI/HUD/Day/HUDValue").transform.localPosition.z);
			
			GameObject.Find("GUI/HUD/Hunger/HUDLabel").transform.localPosition = new Vector3(GameObject.Find("GUI/HUD/Hunger/HUDLabel").transform.localPosition.x, GameObject.Find("GUI/HUD/Hunger/HUDLabel").transform.localPosition.y - 0.111f, GameObject.Find("GUI/HUD/Hunger/HUDLabel").transform.localPosition.z);
			
			GameObject.Find("GUI/HUD/Thrist/HUDLabel").transform.localPosition = new Vector3(GameObject.Find("GUI/HUD/Thrist/HUDLabel").transform.localPosition.x, GameObject.Find("GUI/HUD/Thrist/HUDLabel").transform.localPosition.y - 0.111f, GameObject.Find("GUI/HUD/Thrist/HUDLabel").transform.localPosition.z);
			
			GameObject.Find("GUI/HUD/Stress/HUDLabel").transform.localPosition = new Vector3(GameObject.Find("GUI/HUD/Stress/HUDLabel").transform.localPosition.x, GameObject.Find("GUI/HUD/Stress/HUDLabel").transform.localPosition.y - 0.111f, GameObject.Find("GUI/HUD/Stress/HUDLabel").transform.localPosition.z);
			
			GameObject.Find("GUI/HUD/Urine/HUDLabel").transform.localPosition = new Vector3(GameObject.Find("GUI/HUD/Urine/HUDLabel").transform.localPosition.x, GameObject.Find("GUI/HUD/Urine/HUDLabel").transform.localPosition.y - 0.111f, GameObject.Find("GUI/HUD/Urine/HUDLabel").transform.localPosition.z);
			
			GameObject.Find("GUI/HUD/Fatigue/HUDLabel").transform.localPosition = new Vector3(GameObject.Find("GUI/HUD/Fatigue/HUDLabel").transform.localPosition.x + 0.1f, GameObject.Find("GUI/HUD/Fatigue/HUDLabel").transform.localPosition.y - 0.111f, GameObject.Find("GUI/HUD/Fatigue/HUDLabel").transform.localPosition.z);
			
			GameObject.Find("GUI/HUD/Dirty/HUDLabel").transform.localPosition = new Vector3(GameObject.Find("GUI/HUD/Dirty/HUDLabel").transform.localPosition.x + 0.1f, GameObject.Find("GUI/HUD/Dirty/HUDLabel").transform.localPosition.y - 0.111f, GameObject.Find("GUI/HUD/Dirty/HUDLabel").transform.localPosition.z);
			
			GameObject.Find("GUI/HUD/Money/HUDLabel").transform.localPosition = new Vector3(GameObject.Find("GUI/HUD/Money/HUDLabel").transform.localPosition.x, GameObject.Find("GUI/HUD/Money/HUDLabel").transform.localPosition.y - 0.111f, GameObject.Find("GUI/HUD/Money/HUDLabel").transform.localPosition.z);
			
			GameObject.Find("GUI/HUD/Money/HUDValue").transform.localPosition = new Vector3(GameObject.Find("GUI/HUD/Money/HUDValue").transform.localPosition.x, GameObject.Find("GUI/HUD/Money/HUDValue").transform.localPosition.y - 0.111f, GameObject.Find("GUI/HUD/Money/HUDValue").transform.localPosition.z);
        }
    }
}
