﻿using MSCLoader;
using UnityEngine;

namespace ThirdPerson
{
    public class ThirdPerson : Mod
    {
        public override string ID { get { return "ThirdPerson"; } }
        public override string Name { get { return "Third person camera for vehicles"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.1"; } }

        private bool loaded;
		private GameObject PLAYER;
		private GameObject PIVOT;
		private GameObject CAMERA;
		
        private Keybind camera1Key = new Keybind("CameraKey1", "Reset camera", KeyCode.Alpha1, KeyCode.LeftAlt);
        private Keybind camera2Key = new Keybind("CameraKey2", "Reset camera for Satsuma", KeyCode.Alpha2, KeyCode.LeftAlt);
        private Keybind camera3Key = new Keybind("CameraKey3", "Camera for Satsuma", KeyCode.Alpha3, KeyCode.LeftAlt);
		private Keybind camera4Key = new Keybind("CameraKey4", "Camera for others vehicles", KeyCode.Alpha4, KeyCode.LeftAlt);
		
		public override void OnLoad()
        {
            Keybind.Add(this, camera1Key);
            Keybind.Add(this, camera2Key);
            Keybind.Add(this, camera3Key);
			Keybind.Add(this, camera4Key);
        }
		
        public override void Update()
        {
			if (camera1Key.IsDown()) { Camera1(); };
            if (camera2Key.IsDown()) { Camera2(); };
            if (camera3Key.IsDown()) { Camera3(); };
			if (camera4Key.IsDown()) { Camera4(); };
			
			if (Application.loadedLevelName == "GAME" && !loaded)
            {
                this.PLAYER = GameObject.Find("PLAYER");
				this.PIVOT = this.PLAYER.transform.FindChild("Pivot").gameObject;
				this.CAMERA = this.PIVOT.transform.FindChild("Camera").gameObject;
                loaded = true;
            }

            if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
		
		private void Camera1()
        {
            this.CAMERA.transform.localPosition = new Vector3(0f, 0.3f, 0f);
        }

        private void Camera2()
        {
            this.CAMERA.transform.localPosition = new Vector3(0f, 0.05f, 0f);
        }

        private void Camera3()
        {
            this.CAMERA.transform.localPosition = new Vector3(0.282f, 0.5f, -3.5f);
        }
		
		private void Camera4()
        {
            this.CAMERA.transform.localPosition = new Vector3(0.4f, 2f, -4.5f);
        }
    }
}
