﻿using MSCLoader;
using UnityEngine;
using System.Collections;

namespace FenderFlares
{
    public class FenderFlares : Mod
    {
        public override string ID { get { return "FenderFlares"; } }
        public override string Name { get { return "Fender Flares"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.1"; } }

        private bool loaded;
		private GameObject FLAREFL;
		private GameObject FLAREFR;
		private GameObject FLARERL;
		private GameObject FLARERR;
		private string path = ModLoader.ModsFolder+@"\FenderFlares\";
		
        public override void Update()
        {
            if (Application.loadedLevelName == "GAME" && !loaded)
            {
				if(GameObject.Find("fender flare fl(Clone)").activeSelf == true)
				{
					FLAREFL = GameObject.Find("fender flare fl(Clone)");
					FLAREFR = GameObject.Find("fender flare fr(Clone)");
					FLARERL = GameObject.Find("fender flare rl(Clone)");
					FLARERR = GameObject.Find("fender flare rr(Clone)");
							
					ObjImporter objimporter = new ObjImporter();
					Mesh new_mesh0 = new Mesh();
					new_mesh0 = objimporter.ImportFile(path + "fl_flare.obj");
					Mesh new_mesh1 = new Mesh();
					new_mesh1 = objimporter.ImportFile(path + "fr_flare.obj");
					Mesh new_mesh2 = new Mesh();
					new_mesh2 = objimporter.ImportFile(path + "rl_flare.obj");
					Mesh new_mesh3 = new Mesh();
					new_mesh3 = objimporter.ImportFile(path + "rr_flare.obj");
				
					FLAREFL.transform.GetComponent<MeshFilter>().mesh = new_mesh0;
					FLAREFR.transform.GetComponent<MeshFilter>().mesh = new_mesh1;
					FLARERL.transform.GetComponent<MeshFilter>().mesh = new_mesh2;
					FLARERR.transform.GetComponent<MeshFilter>().mesh = new_mesh3;
				}
				
				loaded = true;
            }
			
			if (Application.loadedLevelName != "GAME" && loaded)
            {
                loaded = false;
            }
        }
    }
}
