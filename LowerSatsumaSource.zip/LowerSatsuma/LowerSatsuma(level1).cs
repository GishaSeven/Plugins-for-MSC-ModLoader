﻿using MSCLoader;
using UnityEngine;

namespace LowerSatsuma
{
    public class LowerSatsuma : Mod
    {
        public override string ID { get { return "LowerSatsuma"; } }
        public override string Name { get { return "Lower Satsuma"; } }
        public override string Author { get { return "Roman266"; } }
        public override string Version { get { return "1.0.0"; } }

        private GameObject SATSUMA;
		private GameObject AIRINTAKE;
		private GameObject DRIVERHEADPIVOT;
		private GameObject HOOKFRONT;
		private GameObject HOOKREAR;
		private GameObject INTERIOR;
		private GameObject BODY;
		private GameObject CHASSIS;
		private GameObject MISCPARTS;
		private GameObject DASHBOARD;
		private GameObject WIPERS;
		private GameObject HOOKS;
		private GameObject SOUNDS;
		private GameObject CARSIMULATION;
		private GameObject ELECTRICITY;
		private GameObject PLAYERTRIGGER;
		private GameObject COLIDERS;
		private GameObject FIRE;
		private GameObject COG;
		private GameObject GENERALPIVOT;
		private GameObject SOUNDPOSITION;
		private GameObject STAGINGWHEEL;
		private GameObject CARSHADOWPROJECTOR;
		private GameObject PATHSLAYER;
		private GameObject CARREARMIRRORPIVOT;
		private GameObject GETINPIVOT;
		private GameObject DEADBODY;
		
        public override void Update()
        {	
			this.SATSUMA = GameObject.Find("SATSUMA(557kg)");
			this.AIRINTAKE = this.SATSUMA.transform.FindChild("AirIntake").gameObject;
			this.DRIVERHEADPIVOT = this.SATSUMA.transform.FindChild("DriverHeadPivot").gameObject;
			this.HOOKFRONT = this.SATSUMA.transform.FindChild("HookFront").gameObject;
			this.HOOKREAR = this.SATSUMA.transform.FindChild("HookRear").gameObject;
			this.INTERIOR = this.SATSUMA.transform.FindChild("Interior").gameObject;
			this.BODY = this.SATSUMA.transform.FindChild("Body").gameObject;
			this.CHASSIS = this.SATSUMA.transform.FindChild("Chassis").gameObject;
			this.MISCPARTS = this.SATSUMA.transform.FindChild("MiscParts").gameObject;
			this.DASHBOARD = this.SATSUMA.transform.FindChild("Dashboard").gameObject;
			this.WIPERS = this.SATSUMA.transform.FindChild("Wipers").gameObject;
			this.HOOKS = this.SATSUMA.transform.FindChild("Hooks").gameObject;
			this.SOUNDS = this.SATSUMA.transform.FindChild("Sounds").gameObject;
			this.CARSIMULATION = this.SATSUMA.transform.FindChild("CarSimulation").gameObject;
			this.ELECTRICITY = this.SATSUMA.transform.FindChild("Electricity").gameObject;
			this.PLAYERTRIGGER = this.SATSUMA.transform.FindChild("PlayerTrigger").gameObject;
			this.COLIDERS = this.SATSUMA.transform.FindChild("Colliders").gameObject;
			this.FIRE = this.SATSUMA.transform.FindChild("FIRE").gameObject;
			this.COG = this.SATSUMA.transform.FindChild("CoG").gameObject;
			this.GENERALPIVOT = this.SATSUMA.transform.FindChild("generalPivot").gameObject;
			this.SOUNDPOSITION = this.SATSUMA.transform.FindChild("Soundposition").gameObject;
			this.STAGINGWHEEL = this.SATSUMA.transform.FindChild("StagingWheel").gameObject;
			this.CARSHADOWPROJECTOR = this.SATSUMA.transform.FindChild("CarShadowProjector").gameObject;
			this.PATHSLAYER = this.SATSUMA.transform.FindChild("PathSlayer").gameObject;
			this.CARREARMIRRORPIVOT = this.SATSUMA.transform.FindChild("CarRearMirrorPivot").gameObject;
			this.GETINPIVOT = this.SATSUMA.transform.FindChild("GetInPivot").gameObject;
			this.DEADBODY = this.SATSUMA.transform.FindChild("DeadBody").gameObject;
			
			this.AIRINTAKE.transform.localPosition = new Vector3(this.AIRINTAKE.transform.localPosition.x, 0.195f, this.AIRINTAKE.transform.localPosition.z);
			this.DRIVERHEADPIVOT.transform.localPosition = new Vector3(this.DRIVERHEADPIVOT.transform.localPosition.x, 0.530809f, this.DRIVERHEADPIVOT.transform.localPosition.z);
			this.HOOKFRONT.transform.localPosition = new Vector3(this.HOOKFRONT.transform.localPosition.x, -0.23f, this.HOOKFRONT.transform.localPosition.z);
			this.HOOKREAR.transform.localPosition = new Vector3(this.HOOKREAR.transform.localPosition.x, -0.23f, this.HOOKREAR.transform.localPosition.z);
			this.INTERIOR.transform.localPosition = new Vector3(this.INTERIOR.transform.localPosition.x, -0.03f, this.INTERIOR.transform.localPosition.z);
			this.BODY.transform.localPosition = new Vector3(this.BODY.transform.localPosition.x, -0.569191f, this.BODY.transform.localPosition.z);
			this.CHASSIS.transform.localPosition = new Vector3(this.CHASSIS.transform.localPosition.x, -0.03f, this.CHASSIS.transform.localPosition.z);
			this.MISCPARTS.transform.localPosition = new Vector3(this.MISCPARTS.transform.localPosition.x, -0.571713f, this.MISCPARTS.transform.localPosition.z);
			this.DASHBOARD.transform.localPosition = new Vector3(this.DASHBOARD.transform.localPosition.x, -0.571713f, this.DASHBOARD.transform.localPosition.z);
			this.WIPERS.transform.localPosition = new Vector3(this.WIPERS.transform.localPosition.x, -0.569191f, this.WIPERS.transform.localPosition.z);
			this.HOOKS.transform.localPosition = new Vector3(this.HOOKS.transform.localPosition.x, -0.03f, this.HOOKS.transform.localPosition.z);
			this.SOUNDS.transform.localPosition = new Vector3(this.SOUNDS.transform.localPosition.x, -0.03f, this.SOUNDS.transform.localPosition.z);
			this.CARSIMULATION.transform.localPosition = new Vector3(this.CARSIMULATION.transform.localPosition.x, -0.03f, this.CARSIMULATION.transform.localPosition.z);
			this.ELECTRICITY.transform.localPosition = new Vector3(this.ELECTRICITY.transform.localPosition.x, -0.03f, this.ELECTRICITY.transform.localPosition.z);
			this.PLAYERTRIGGER.transform.localPosition = new Vector3(this.PLAYERTRIGGER.transform.localPosition.x, 0.023279f, this.PLAYERTRIGGER.transform.localPosition.z);
			this.COLIDERS.transform.localPosition = new Vector3(this.COLIDERS.transform.localPosition.x, -0.569191f, this.COLIDERS.transform.localPosition.z);
			this.FIRE.transform.localPosition = new Vector3(this.FIRE.transform.localPosition.x, -0.157441f, this.FIRE.transform.localPosition.z);
			this.COG.transform.localPosition = new Vector3(this.COG.transform.localPosition.x, 0.02f, this.COG.transform.localPosition.z);
			this.GENERALPIVOT.transform.localPosition = new Vector3(this.GENERALPIVOT.transform.localPosition.x, -0.569191f, this.GENERALPIVOT.transform.localPosition.z);
			this.SOUNDPOSITION.transform.localPosition = new Vector3(this.SOUNDPOSITION.transform.localPosition.x, -0.03f, this.SOUNDPOSITION.transform.localPosition.z);
			this.STAGINGWHEEL.transform.localPosition = new Vector3(this.STAGINGWHEEL.transform.localPosition.x, 0.07f, this.STAGINGWHEEL.transform.localPosition.z);
			this.CARSHADOWPROJECTOR.transform.localPosition = new Vector3(this.CARSHADOWPROJECTOR.transform.localPosition.x, -0.23f, this.CARSHADOWPROJECTOR.transform.localPosition.z);
			this.PATHSLAYER.transform.localPosition = new Vector3(this.PATHSLAYER.transform.localPosition.x, -0.231f, this.PATHSLAYER.transform.localPosition.z);
			this.CARREARMIRRORPIVOT.transform.localPosition = new Vector3(this.CARREARMIRRORPIVOT.transform.localPosition.x, 0.6085f, this.CARREARMIRRORPIVOT.transform.localPosition.z);
			this.GETINPIVOT.transform.localPosition = new Vector3(this.GETINPIVOT.transform.localPosition.x, -0.53f, this.GETINPIVOT.transform.localPosition.z);
			this.DEADBODY.transform.localPosition = new Vector3(this.DEADBODY.transform.localPosition.x, 0.162f, this.DEADBODY.transform.localPosition.z);
        }
    }
}
