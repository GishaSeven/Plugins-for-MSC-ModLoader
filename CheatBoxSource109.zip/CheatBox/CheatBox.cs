﻿using HutongGames.PlayMaker;
using MSCLoader;
using UnityEngine;

namespace CheatBox
{
    public class CheatBox : Mod
    {
        public override string ID => "CheatBox";
        public override string Name => "CheatBox";
        public override string Author => "Roman266";
        public override string Version => "1.0.9";

        public override bool UseAssetsFolder => false;
		
		private Keybind CheatsGuiKey = new Keybind("ShowGUI", "Show Cheat GUI", KeyCode.C, KeyCode.LeftControl);
		private Keybind teleportKey1 = new Keybind("teleportKey1", "Teleport to home", KeyCode.Alpha1, KeyCode.LeftControl);
		private Keybind teleportKey2 = new Keybind("teleportKey2", "Teleport to store", KeyCode.Alpha2, KeyCode.LeftControl);
		private Keybind teleportKey3 = new Keybind("teleportKey3", "Teleport to repair shop", KeyCode.Alpha3, KeyCode.LeftControl);
		private Keybind teleportKey4 = new Keybind("teleportKey4", "Teleport to drag", KeyCode.Alpha4, KeyCode.LeftControl);
		private Keybind teleportKey5 = new Keybind("teleportKey5", "Teleport to cottage", KeyCode.Alpha5, KeyCode.LeftControl);
		private Keybind teleportKey6 = new Keybind("teleportKey6", "Teleport to ventti pig", KeyCode.Alpha6, KeyCode.LeftControl);
		private Keybind teleportKey7 = new Keybind("teleportKey7", "Teleport to Satsuma", KeyCode.Alpha7, KeyCode.LeftControl);
		private Keybind teleportKey8 = new Keybind("teleportKey8", "Teleport to muscle car", KeyCode.Alpha8, KeyCode.LeftControl);
		private Keybind teleportKey9 = new Keybind("teleportKey9", "Teleport to truck", KeyCode.Alpha9, KeyCode.LeftControl);
		private Keybind teleportKey10 = new Keybind("teleportKey10", "Teleport to tractor", KeyCode.Alpha0, KeyCode.LeftControl);
		private Keybind teleportKey11 = new Keybind("teleportKey11", "Teleport to van", KeyCode.Alpha0, KeyCode.RightControl);
		private Keybind teleportKey12 = new Keybind("teleportKey12", "Teleport to moped", KeyCode.Alpha9, KeyCode.RightControl);
		private Keybind teleportKey13 = new Keybind("teleportKey13", "Teleport to pig's car", KeyCode.Alpha8, KeyCode.RightControl);
		private Rect guiBox = new Rect((Screen.width-750)/2, 10, 470, 800);
		private bool guiShow;
		private bool needs;
		private bool windowTwoStatus;
		private bool windowTwo2Status;
		private bool windowTwo3Status;
		private bool windowTwo4Status;
		private bool windowTwo5Status;
		private bool windowTwo6Status;
		private bool windowTwo7Status;
		private bool windowTwo8Status;
		private bool windowTwo9Status;
		private bool windowTwo10Status;
		private bool windowTwo11Status;
		private bool windowTwo12Status;
		private GameObject PLAYER;
		
        public override void OnLoad()
        {
			Keybind.Add(this, CheatsGuiKey);
			Keybind.Add(this, teleportKey1);
			Keybind.Add(this, teleportKey2);
			Keybind.Add(this, teleportKey3);
			Keybind.Add(this, teleportKey4);
			Keybind.Add(this, teleportKey5);
			Keybind.Add(this, teleportKey6);
			Keybind.Add(this, teleportKey7);
			Keybind.Add(this, teleportKey8);
			Keybind.Add(this, teleportKey9);
			Keybind.Add(this, teleportKey10);
			Keybind.Add(this, teleportKey11);
			Keybind.Add(this, teleportKey12);
			Keybind.Add(this, teleportKey13);
        }

		public override void OnGUI()
		{
			if (guiShow)
			{
                GUI.Window(1, this.guiBox, new GUI.WindowFunction(this.Window), "CheatBox"); 
            }

            if (windowTwoStatus & guiShow)
            {
                GUI.Window(2, new Rect((Screen.width+200)/2, 10f, 150, 800), WindowTwo, "Tools");
            }
			
			if (windowTwo2Status & guiShow)
            {
                GUI.Window(2, new Rect((Screen.width+200)/2, 10f, 150, 800), WindowTwo2, "Car items");
            }
			
			if (windowTwo3Status & guiShow)
            {
                GUI.Window(2, new Rect((Screen.width+200)/2, 10f, 150, 800), WindowTwo3, "Items");
            }
			
			if (windowTwo4Status & guiShow)
            {
                GUI.Window(2, new Rect((Screen.width+200)/2, 10f, 150, 800), WindowTwo4, "Suspension");
            }
			
			if (windowTwo5Status & guiShow)
            {
                GUI.Window(2, new Rect((Screen.width+200)/2, 10f, 150, 800), WindowTwo5, "Exhaust & fuel");
            }
			
			if (windowTwo6Status & guiShow)
            {
                GUI.Window(2, new Rect((Screen.width+200)/2, 10f, 275, 800), WindowTwo6, "Body parts");
            }
			
			if (windowTwo7Status & guiShow)
            {
                GUI.Window(2, new Rect((Screen.width+200)/2, 10f, 150, 800), WindowTwo7, "Wheels");
            }
			
			if (windowTwo8Status & guiShow)
            {
                GUI.Window(2, new Rect((Screen.width+200)/2, 10f, 275, 800), WindowTwo8, "Engine parts");
            }
			
			if (windowTwo9Status & guiShow)
            {
                GUI.Window(2, new Rect((Screen.width+200)/2, 10f, 150, 800), WindowTwo9, "Engine parts 2");
            }
			
			if (windowTwo10Status & guiShow)
            {
                GUI.Window(2, new Rect((Screen.width+200)/2, 10f, 150, 800), WindowTwo10, "Engine bay");
            }
			
			if (windowTwo11Status & guiShow)
            {
                GUI.Window(2, new Rect((Screen.width+200)/2, 10f, 150, 800), WindowTwo11, "Gauges");
            }
			
			if (windowTwo12Status & guiShow)
            {
                GUI.Window(2, new Rect((Screen.width+200)/2, 10f, 275, 800), WindowTwo12, "Interior");
            }
        }

        private void WindowTwo(int windowId)
        {
            bool flag0 = GUI.Button(new Rect(15f, 50f, 120f, 30f), "Spanner set");
			if (flag0)
			{
				TpMe("spanner set(itemx)", "PLAYER");
			}
			bool flag1 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Ratchet set");
			if (flag1)
			{
				TpMe("ratchet set(Clone)", "PLAYER");
			}
			bool flag2 = GUI.Button(new Rect(15f, 120f, 120f, 30f), "Floor jack");
			if (flag2)
			{
				TpMe2("floor jack(itemx)", "PLAYER");
			}
			bool flag3 = GUI.Button(new Rect(15f, 155f, 120f, 30f), "Motor hoist");
			if (flag3)
			{
				TpMe3("motor hoist(itemx)", "PLAYER");
			}
			bool flag4 = GUI.Button(new Rect(15f, 190f, 120f, 30f), "Car jack");
			if (flag4)
			{
				TpMe("car jack(itemx)", "PLAYER");
			}
            GUI.DragWindow();
        }
		
		private void WindowTwo2(int windowId)
        {
			bool flag0 = GUI.Button(new Rect(15f, 50f, 120f, 30f), "Diesel jerrycan");
			if (flag0)
			{
				TpMe("diesel(itemx)", "PLAYER");
			}
			bool flag1 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Gasoline jerrycan");
			if (flag1)
			{
				TpMe("gasoline(itemx)", "PLAYER");
			}
			
			bool flag2 = GUI.Button(new Rect(15f, 120f, 120f, 30f), "Fire exth. holder");
			if (flag2)
			{
				TpMe("fire extinguisher holder(Clone)", "PLAYER");
			}
			bool flag3 = GUI.Button(new Rect(15f, 155f, 120f, 30f), "Xmas lights");
			if (flag3)
			{
				TpMe("xmas lights(Clone)", "PLAYER");
			}
			bool flag4 = GUI.Button(new Rect(15f, 190f, 120f, 30f), "Warning triangle");
			if (flag4)
			{
				TpMe("warning triangle(Clone)", "PLAYER");
			}
			bool flag5 = GUI.Button(new Rect(15f, 225f, 120f, 30f), "Fur dices");
			if (flag5)
			{
				TpMe("fur dices(Clone)", "PLAYER");
			}
			bool flag6 = GUI.Button(new Rect(15f, 260f, 120f, 30f), "CD Disc");
			if (flag6)
			{
				TpMe("cd(item1)", "PLAYER");
			}
			bool flag7 = GUI.Button(new Rect(15f, 295f, 120f, 30f), "CD Case");
			if (flag7)
			{
				TpMe("cd case(Clone)", "PLAYER");
			}
            GUI.DragWindow();
        }
		
		private void WindowTwo3(int windowId)
        {
			bool flag0 = GUI.Button(new Rect(15f, 50f, 120f, 30f), "Flashlight");
			if (flag0)
			{
				TpMe("flashlight(itemx)", "PLAYER");
			}
			bool flag1 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Sledgehammer");
			if (flag1)
			{
				TpMe("sledgehammer(itemx)", "PLAYER");
			}
			bool flag2 = GUI.Button(new Rect(15f, 120f, 120f, 30f), "Lantern");
			if (flag2)
			{
				TpMe("lantern(itemx)", "PLAYER");
			}
			bool flag3 = GUI.Button(new Rect(15f, 155f, 120f, 30f), "Bucket");
			if (flag3)
			{
				TpMe("bucket(itemx)", "PLAYER");
			}
			bool flag4 = GUI.Button(new Rect(15f, 190f, 120f, 30f), "Bucket lid");
			if (flag4)
			{
				TpMe("bucket lid(itemx)", "PLAYER");
			}
			bool flag5 = GUI.Button(new Rect(15f, 225f, 120f, 30f), "Fish trap");
			if (flag5)
			{
				TpMe("fish trap(itemx)", "PLAYER");
			}
			bool flag6 = GUI.Button(new Rect(15f, 260f, 120f, 30f), "Water bucket");
			if (flag6)
			{
				TpMe("water bucket(itemx)", "PLAYER");
			}
			bool flag7 = GUI.Button(new Rect(15f, 295f, 120f, 30f), "Dipper");
			if (flag7)
			{
				TpMe("dipper(itemx)", "PLAYER");
			}
			bool flag8 = GUI.Button(new Rect(15f, 330f, 120f, 30f), "Ax");
			if (flag8)
			{
				TpMe("ax(itemx)", "PLAYER");
			}
			bool flag9 = GUI.Button(new Rect(15f, 365f, 120f, 30f), "Basketball");
			if (flag9)
			{
				TpMe("basketball(Clone)", "PLAYER");
			}
			bool flag10 = GUI.Button(new Rect(15f, 400f, 120f, 30f), "Radio");
			if (flag10)
			{
				TpMe("radio(itemx)", "PLAYER");
			}
			bool flag11 = GUI.Button(new Rect(15f, 435f, 120f, 30f), "Sofa");
			if (flag11)
			{
				TpMe("sofa(itemx)", "PLAYER");
			}
			bool flag12 = GUI.Button(new Rect(15f, 470f, 120f, 30f), "Shopping bag");
			if (flag12)
			{
				TpMe("shopping bag(itemx)", "PLAYER");
			}
			bool flag13 = GUI.Button(new Rect(15f, 505f, 120f, 30f), "Envelope");
			if (flag13)
			{
				TpMe("envelope(xxxxx)", "PLAYER");
			}
			bool flag14 = GUI.Button(new Rect(15f, 540f, 120f, 30f), "Camera");
			if (flag14)
			{
				TpMe("camera(itemx)", "PLAYER");
			}
			bool flag15 = GUI.Button(new Rect(15f, 575f, 120f, 30f), "Suitcase");
			if (flag15)
			{
				TpMe("suitcase(itemx)", "PLAYER");
			}
			bool flag16 = GUI.Button(new Rect(15f, 610f, 120f, 30f), "Fireworks bag");
			if (flag16)
			{
				TpMe("fireworks bag(itemx)", "PLAYER");
			}
			bool flag17 = GUI.Button(new Rect(15f, 645f, 120f, 30f), "Wood carrier");
			if (flag17)
			{
				TpMe("wood carrier(itemx)", "PLAYER");
			}
            GUI.DragWindow();
        }
		
		private void WindowTwo4(int windowId)
        {
			bool flag0 = GUI.Button(new Rect(15f, 50f, 120f, 30f), "Wishbone FL");
			if (flag0)
			{
				TpMe("wishbone fl(Clone)", "PLAYER");
			}
			bool flag1 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Spindle FL");
			if (flag1)
			{
				TpMe("spindle fl(Clone)", "PLAYER");
			}
			bool flag2 = GUI.Button(new Rect(15f, 120f, 120f, 30f), "Strut FL");
			if (flag2)
			{
				TpMe("strut fl(Clone)", "PLAYER");
			}
			bool flag3 = GUI.Button(new Rect(15f, 155f, 120f, 30f), "Disc brake");
			if (flag3)
			{
				TpMe("disc brake(Clone)", "PLAYER");
			}
			bool flag4 = GUI.Button(new Rect(15f, 190f, 120f, 30f), "Wishbone FR");
			if (flag4)
			{
				TpMe("wishbone fr(Clone)", "PLAYER");
			}
			bool flag5 = GUI.Button(new Rect(15f, 225f, 120f, 30f), "Spindle FR");
			if (flag5)
			{
				TpMe("spindle fr(Clone)", "PLAYER");
			}
			bool flag6 = GUI.Button(new Rect(15f, 260f, 120f, 30f), "Strut FR");
			if (flag6)
			{
				TpMe("strut fr(Clone)", "PLAYER");
			}
			bool flag7 = GUI.Button(new Rect(15f, 295f, 120f, 30f), "Trail arm RL");
			if (flag7)
			{
				TpMe("trail arm rl(Clone)", "PLAYER");
			}
			bool flag8 = GUI.Button(new Rect(15f, 330f, 120f, 30f), "Coil spring");
			if (flag8)
			{
				TpMe("coil spring(Clone)", "PLAYER");
			}
			bool flag9 = GUI.Button(new Rect(15f, 365f, 120f, 30f), "Long coil spring");
			if (flag9)
			{
				TpMe("long coil spring(Clone)", "PLAYER");
			}
			bool flag10 = GUI.Button(new Rect(15f, 400f, 120f, 30f), "Shock absorber");
			if (flag10)
			{
				TpMe("shock absorber(Clone)", "PLAYER");
			}
			bool flag11 = GUI.Button(new Rect(15f, 435f, 120f, 30f), "Drum brake");
			if (flag11)
			{
				TpMe("drum brake(Clone)", "PLAYER");
			}
			bool flag12 = GUI.Button(new Rect(15f, 470f, 120f, 30f), "Trail arm RR");
			if (flag12)
			{
				TpMe("trail arm rr(Clone)", "PLAYER");
			}
			bool flag13 = GUI.Button(new Rect(15f, 505f, 120f, 30f), "Rally strut FL");
			if (flag13)
			{
				TpMe("rally strut fl(Clone)", "PLAYER");
			}
			bool flag14 = GUI.Button(new Rect(15f, 540f, 120f, 30f), "Rally strut FR");
			if (flag14)
			{
				TpMe("rally strut fr(Clone)", "PLAYER");
			}
			bool flag15 = GUI.Button(new Rect(15f, 575f, 120f, 30f), "Rally coil spring");
			if (flag15)
			{
				TpMe("rally coil spring(Clone)", "PLAYER");
			}
			bool flag16 = GUI.Button(new Rect(15f, 610f, 120f, 30f), "Rally shock absor.");
			if (flag16)
			{
				TpMe("rally shock absorber(Clone)", "PLAYER");
			}
            GUI.DragWindow();
        }
		
		private void WindowTwo5(int windowId)
        {
            bool flag0 = GUI.Button(new Rect(15f, 50f, 120f, 30f), "Muffler stock");
			if (flag0)
			{
				TpMe("exhaust muffler(Clone)", "PLAYER");
			}
			bool flag1 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Pipe stock");
			if (flag1)
			{
				TpMe("exhaust pipe(Clone)", "PLAYER");
			}
			bool flag2 = GUI.Button(new Rect(15f, 120f, 120f, 30f), "Muffler racing");
			if (flag2)
			{
				TpMe("racing muffler(Clone)", "PLAYER");
			}
			bool flag3 = GUI.Button(new Rect(15f, 155f, 120f, 30f), "Pipe racing");
			if (flag3)
			{
				TpMe("racing exhaust(Clone)", "PLAYER");
			}
			bool flag4 = GUI.Button(new Rect(15f, 190f, 120f, 30f), "Fuel tank");
			if (flag4)
			{
				TpMe("fuel tank(Clone)", "PLAYER");
			}
			bool flag5 = GUI.Button(new Rect(15f, 225f, 120f, 30f), "Fuel tank pipe");
			if (flag5)
			{
				TpMe("fuel tank pipe(Clone)", "PLAYER");
			}
            GUI.DragWindow();
        }
		
		private void WindowTwo6(int windowId)
        {
			bool flag0 = GUI.Button(new Rect(15f, 50f, 120f, 30f), "Front bumper");
			if (flag0)
			{
				TpMe("bumper front(Clone)", "PLAYER");
			}
			bool flag1 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Rear bumper");
			if (flag1)
			{
				TpMe("bumper rear(Clone)", "PLAYER");
			}
			bool flag2 = GUI.Button(new Rect(15f, 120f, 120f, 30f), "Fender left");
			if (flag2)
			{
				TpMe("fender left(Clone)", "PLAYER");
			}
			bool flag3 = GUI.Button(new Rect(15f, 155f, 120f, 30f), "Fender right");
			if (flag3)
			{
				TpMe("fender right(Clone)", "PLAYER");
			}
			bool flag4 = GUI.Button(new Rect(15f, 190f, 120f, 30f), "Door left");
			if (flag4)
			{
				TpMe("door left(Clone)", "PLAYER");
			}
			bool flag5 = GUI.Button(new Rect(15f, 225f, 120f, 30f), "Door right");
			if (flag5)
			{
				TpMe("door right(Clone)", "PLAYER");
			}
			bool flag6 = GUI.Button(new Rect(15f, 260f, 120f, 30f), "Bootlid");
			if (flag6)
			{
				TpMe("bootlid(Clone)", "PLAYER");
			}
			bool flag7 = GUI.Button(new Rect(15f, 295f, 120f, 30f), "Hood");
			if (flag7)
			{
				TpMe("hood(Clone)", "PLAYER");
			}
			bool flag8 = GUI.Button(new Rect(15f, 330f, 120f, 30f), "Grille");
			if (flag8)
			{
				TpMe("grille(Clone)", "PLAYER");
			}
			bool flag9 = GUI.Button(new Rect(15f, 365f, 120f, 30f), "Headlight");
			if (flag9)
			{
				TpMe("headlight(Clone)", "PLAYER");
			}
			bool flag10 = GUI.Button(new Rect(15f, 400f, 120f, 30f), "Rear light left");
			if (flag10)
			{
				TpMe("rear light left(Clone)", "PLAYER");
			}
			bool flag11 = GUI.Button(new Rect(15f, 435f, 120f, 30f), "Rear light right");
			if (flag11)
			{
				TpMe("rear light right(Clone)", "PLAYER");
			}
			bool flag12 = GUI.Button(new Rect(15f, 470f, 120f, 30f), "Fiberglass hood");
			if (flag12)
			{
				TpMe("fiberglass hood(Clone)", "PLAYER");
			}
			bool flag13 = GUI.Button(new Rect(15f, 505f, 120f, 30f), "Fender flare FL");
			if (flag13)
			{
				TpMe("fender flare fl(Clone)", "PLAYER");
			}
			bool flag14 = GUI.Button(new Rect(15f, 540f, 120f, 30f), "Fender flare FR");
			if (flag14)
			{
				TpMe("fender flare fr(Clone)", "PLAYER");
			}
			bool flag15 = GUI.Button(new Rect(15f, 575f, 120f, 30f), "Fender flare RL");
			if (flag15)
			{
				TpMe("fender flare rl(Clone)", "PLAYER");
			}
			bool flag16 = GUI.Button(new Rect(15f, 610f, 120f, 30f), "Fender flare RR");
			if (flag16)
			{
				TpMe("fender flare rr(Clone)", "PLAYER");
			}
			bool flag17 = GUI.Button(new Rect(15f, 645f, 120f, 30f), "Fen. flare spoiler");
			if (flag17)
			{
				TpMe("fender flare spoiler(Clone)", "PLAYER");
			}
			bool flag18 = GUI.Button(new Rect(15f, 680f, 120f, 30f), "Front spoiler");
			if (flag18)
			{
				TpMe("front spoiler(Clone)", "PLAYER");
			}
			bool flag19 = GUI.Button(new Rect(15f, 715f, 120f, 30f), "Rear spoiler");
			if (flag19)
			{
				TpMe("rear spoiler(Clone)", "PLAYER");
			}
			bool flag20 = GUI.Button(new Rect(140f, 50f, 120f, 30f), "Rear spoiler 2");
			if (flag20)
			{
				TpMe("rear spoiler2(Clone)", "PLAYER");
			}
			bool flag21 = GUI.Button(new Rect(140f, 85f, 120f, 30f), "Window grille");
			if (flag21)
			{
				TpMe("window grille(Clone)", "PLAYER");
			}
			bool flag22 = GUI.Button(new Rect(140f, 120f, 120f, 30f), "Wind. black wrap");
			if (flag22)
			{
				TpMe("windows black wrap(Clone)", "PLAYER");
			}
			bool flag23 = GUI.Button(new Rect(140f, 155f, 120f, 30f), "Register plate");
			if (flag23)
			{
				TpMe("register plate(Clone)", "PLAYER");
			}			
            GUI.DragWindow();
        }
		
		private void WindowTwo7(int windowId)
        {			
			bool flag0 = GUI.Button(new Rect(15f, 50f, 120f, 30f), "Wheel no offset");
			if (flag0)
			{
				TpMe("wheel_regula", "PLAYER");
			}
			bool flag1 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Wheel offset");
			if (flag1)
			{
				TpMe("wheel_offset", "PLAYER");
			}
			bool flag20 = GUI.Button(new Rect(15f, 120f, 120f, 30f), "Hubcap FL");
			if (flag20)
			{
				TpMe("hubcap fl(Clone)", "PLAYER");
			}
			bool flag21 = GUI.Button(new Rect(15f, 155f, 120f, 30f), "Hubcap FR");
			if (flag21)
			{
				TpMe("hubcap fr(Clone)", "PLAYER");
			}
			bool flag22 = GUI.Button(new Rect(15f, 190f, 120f, 30f), "Hubcap RL");
			if (flag22)
			{
				TpMe("hubcap rl(Clone)", "PLAYER");
			}
			bool flag23 = GUI.Button(new Rect(15f, 225f, 120f, 30f), "Hubcap RR");
			if (flag23)
			{
				TpMe("hubcap rr(Clone)", "PLAYER");
			}
            GUI.DragWindow();
        }
		
		private void WindowTwo8(int windowId)
        {		
			bool flag0 = GUI.Button(new Rect(15f, 50f, 120f, 30f), "Main bridge 1");
			if (flag0)
			{
				TpMe("main bearing1(Clone)", "PLAYER");
			}
			bool flag1 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Main bridge 2");
			if (flag1)
			{
				TpMe("main bearing2(Clone)", "PLAYER");
			}
			bool flag2 = GUI.Button(new Rect(15f, 120f, 120f, 30f), "Main bridge 3");
			if (flag2)
			{
				TpMe("main bearing3(Clone)", "PLAYER");
			}			
			bool flag3 = GUI.Button(new Rect(15f, 155f, 120f, 30f), "Block");
			if (flag3)
			{
				TpMe("block(Clone)", "PLAYER");
			}
			bool flag4 = GUI.Button(new Rect(15f, 190f, 120f, 30f), "Crankshaft");
			if (flag4)
			{
				TpMe("crankshaft(Clone)", "PLAYER");
			}
			bool flag5 = GUI.Button(new Rect(15f, 225f, 120f, 30f), "Piston 1");
			if (flag5)
			{
				TpMe("piston1(Clone)", "PLAYER");
			}
			bool flag6 = GUI.Button(new Rect(15f, 260f, 120f, 30f), "Piston 2");
			if (flag6)
			{
				TpMe("piston2(Clone)", "PLAYER");
			}
			bool flag7 = GUI.Button(new Rect(15f, 295f, 120f, 30f), "Piston 3");
			if (flag7)
			{
				TpMe("piston3(Clone)", "PLAYER");
			}
			bool flag8 = GUI.Button(new Rect(15f, 330f, 120f, 30f), "Piston 4");
			if (flag8)
			{
				TpMe("piston4(Clone)", "PLAYER");
			}
			bool flag9 = GUI.Button(new Rect(15f, 365f, 120f, 30f), "Camshaft");
			if (flag9)
			{
				TpMe("camshaft(Clone)", "PLAYER");
			}
			bool flag10 = GUI.Button(new Rect(15f, 400f, 120f, 30f), "Camshaft gear");
			if (flag10)
			{
				TpMe("camshaft gear(Clone)", "PLAYER");
			}
			bool flag11 = GUI.Button(new Rect(15f, 435f, 120f, 30f), "Timing chain");
			if (flag11)
			{
				TpMe("timing chain(Clone)", "PLAYER");
			}
			bool flag12 = GUI.Button(new Rect(15f, 470f, 120f, 30f), "Timing cover");
			if (flag12)
			{
				TpMe("timing cover(Clone)", "PLAYER");
			}
			bool flag13 = GUI.Button(new Rect(15f, 505f, 120f, 30f), "Water pump");
			if (flag13)
			{
				TpMe("water pump(Clone)", "PLAYER");
			}
			bool flag14 = GUI.Button(new Rect(15f, 540f, 120f, 30f), "Water pump pulley");
			if (flag14)
			{
				TpMe("water pump pulley(Clone)", "PLAYER");
			}
			bool flag15 = GUI.Button(new Rect(15f, 575f, 120f, 30f), "Flywheel");
			if (flag15)
			{
				TpMe("flywheel(Clone)", "PLAYER");
			}
			bool flag16 = GUI.Button(new Rect(15f, 610f, 120f, 30f), "Clutch cover plate");
			if (flag16)
			{
				TpMe("clutch cover plate(Clone)", "PLAYER");
			}
			bool flag17 = GUI.Button(new Rect(15f, 645f, 120f, 30f), "Clutch disc");
			if (flag17)
			{
				TpMe("clutch disc(Clone)", "PLAYER");
			}
			bool flag18 = GUI.Button(new Rect(15f, 680f, 120f, 30f), "Clutch pres. plate");
			if (flag18)
			{
				TpMe("clutch pressure plate(Clone)", "PLAYER");
			}
			bool flag19 = GUI.Button(new Rect(15f, 715f, 120f, 30f), "Engine plate");
			if (flag19)
			{
				TpMe("engine plate(Clone)", "PLAYER");
			}
			bool flag20 = GUI.Button(new Rect(140f, 50f, 120f, 30f), "Gearbox");
			if (flag20)
			{
				TpMe("gearbox(Clone)", "PLAYER");
			}
			bool flag21 = GUI.Button(new Rect(140f, 85f, 120f, 30f), "Crankshaft pulley");
			if (flag21)
			{
				TpMe("crankshaft pulley(Clone)", "PLAYER");
			}
			bool flag22 = GUI.Button(new Rect(140f, 120f, 120f, 30f), "Drive gear");
			if (flag22)
			{
				TpMe("drive gear(Clone)", "PLAYER");
			}
			bool flag23 = GUI.Button(new Rect(140f, 155f, 120f, 30f), "Oilpan");
			if (flag23)
			{
				TpMe("oilpan(Clone)", "PLAYER");
			}
			bool flag24 = GUI.Button(new Rect(140f, 190f, 120f, 30f), "Alternator");
			if (flag24)
			{
				TpMe("alternator(Clone)", "PLAYER");
			}
			bool flag25 = GUI.Button(new Rect(140f, 225f, 120f, 30f), "Fan belt");
			if (flag25)
			{
				TpMe("fan belt(Clone)", "PLAYER");
			}
			bool flag26 = GUI.Button(new Rect(140f, 260f, 120f, 30f), "Starter");
			if (flag26)
			{
				TpMe("starter(Clone)", "PLAYER");
			}
			bool flag27 = GUI.Button(new Rect(140f, 295f, 120f, 30f), "Head gasket");
			if (flag27)
			{
				TpMe("head gasket(Clone)", "PLAYER");
			}
			bool flag28 = GUI.Button(new Rect(140f, 330f, 120f, 30f), "Cylinder head");
			if (flag28)
			{
				TpMe("cylinder head(Clone)", "PLAYER");
			}
			bool flag29 = GUI.Button(new Rect(140f, 365f, 120f, 30f), "Rocker shaft");
			if (flag29)
			{
				TpMe("rocker shaft(Clone)", "PLAYER");
			}
			bool flag30 = GUI.Button(new Rect(140f, 400f, 120f, 30f), "Rocker cover");
			if (flag30)
			{
				TpMe("rocker cover(Clone)", "PLAYER");
			}
			bool flag31 = GUI.Button(new Rect(140f, 435f, 120f, 30f), "Distributor");
			if (flag31)
			{
				TpMe("distributor(Clone)", "PLAYER");
			}
			bool flag32 = GUI.Button(new Rect(140f, 470f, 120f, 30f), "Oil filter");
			if (flag32)
			{
				TpMe("oil filter(Clone)", "PLAYER");
			}
			bool flag33 = GUI.Button(new Rect(140f, 505f, 120f, 30f), "Fuel pump");
			if (flag33)
			{
				TpMe("fuel pump(Clone)", "PLAYER");
			}
			bool flag34 = GUI.Button(new Rect(140f, 540f, 120f, 30f), "Spark plug 1");
			if (flag34)
			{
				TpMe("spark plug 1(Clone)", "PLAYER");
			}
			bool flag35 = GUI.Button(new Rect(140f, 575f, 120f, 30f), "Spark plug 2");
			if (flag35)
			{
				TpMe("spark plug 2(Clone)", "PLAYER");
			}
			bool flag36 = GUI.Button(new Rect(140f, 610f, 120f, 30f), "Spark plug 3");
			if (flag36)
			{
				TpMe("spark plug 3(Clone)", "PLAYER");
			}
			bool flag37 = GUI.Button(new Rect(140f, 645f, 120f, 30f), "Spark plug 4");
			if (flag37)
			{
				TpMe("spark plug 4(Clone)", "PLAYER");
			}
			bool flag38 = GUI.Button(new Rect(140f, 680f, 120f, 30f), "Headers");
			if (flag38)
			{
				TpMe("headers(Clone)", "PLAYER");
			}
			bool flag39 = GUI.Button(new Rect(140f, 715f, 120f, 30f), "Carburator");
			if (flag39)
			{
				TpMe("carburator(Clone)", "PLAYER");
			}
            GUI.DragWindow();
        }
		
		private void WindowTwo9(int windowId)
        {
			bool flag6 = GUI.Button(new Rect(15f, 50f, 120f, 30f), "Air filter");
			if (flag6)
			{
				TpMe("airfilter(Clone)", "PLAYER");
			}
			bool flag7 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Steel headers");
			if (flag7)
			{
				TpMe("steel headers(Clone)", "PLAYER");
			}
			bool flag8 = GUI.Button(new Rect(15f, 120f, 120f, 30f), "Twin carburators");
			if (flag8)
			{
				TpMe("twin carburators(Clone)", "PLAYER");
			}
			bool flag9 = GUI.Button(new Rect(15f, 155f, 120f, 30f), "Racing carburat.");
			if (flag9)
			{
				TpMe("racing carburators(Clone)", "PLAYER");
			}
			bool flag10 = GUI.Button(new Rect(15f, 190f, 120f, 30f), "N2O bottle holder");
			if (flag10)
			{
				TpMe("n2o bottle holder(Clone)", "PLAYER");
			}
			bool flag11 = GUI.Button(new Rect(15f, 225f, 120f, 30f), "N2O bottle");
			if (flag11)
			{
				TpMe("n2o bottle(Clone)", "PLAYER");
			}
			bool flag12 = GUI.Button(new Rect(15f, 260f, 120f, 30f), "N2O button panel");
			if (flag12)
			{
				TpMe("n2o button panel(Clone)", "PLAYER");
			}
			bool flag13 = GUI.Button(new Rect(15f, 295f, 120f, 30f), "N2O injectors");
			if (flag13)
			{
				TpMe("n2o injectors(Clone)", "PLAYER");
			}
            GUI.DragWindow();
        }
		
		private void WindowTwo10(int windowId)
        {
			bool flag0 = GUI.Button(new Rect(15f, 50f, 120f, 30f), "Sub frame");
			if (flag0)
			{
				TpMe("sub frame(Clone)", "PLAYER");
			}
			bool flag1 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Steering rack");
			if (flag1)
			{
				TpMe("steering rack(Clone)", "PLAYER");
			}
			bool flag2 = GUI.Button(new Rect(15f, 120f, 120f, 30f), "Steering column");
			if (flag2)
			{
				TpMe("steering column(Clone)", "PLAYER");
			}
			bool flag3 = GUI.Button(new Rect(15f, 155f, 120f, 30f), "Steering rod FL");
			if (flag3)
			{
				TpMe("steering rod fl(Clone)", "PLAYER");
			}
			bool flag4 = GUI.Button(new Rect(15f, 190f, 120f, 30f), "Steering rod FR");
			if (flag4)
			{
				TpMe("steering rod fr(Clone)", "PLAYER");
			}
			bool flag5 = GUI.Button(new Rect(15f, 225f, 120f, 30f), "Radiator");
			if (flag5)
			{
				TpMe("radiator(Clone)", "PLAYER");
			}
			bool flag6 = GUI.Button(new Rect(15f, 260f, 120f, 30f), "Racing radiator");
			if (flag6)
			{
				TpMe("racing radiator(Clone)", "PLAYER");
			}
			bool flag7 = GUI.Button(new Rect(15f, 295f, 120f, 30f), "Radiator hose 1");
			if (flag7)
			{
				TpMe("radiator hose1(Clone)", "PLAYER");
			}
			bool flag8 = GUI.Button(new Rect(15f, 330f, 120f, 30f), "Radiator hose 2");
			if (flag8)
			{
				TpMe("radiator hose2(Clone)", "PLAYER");
			}
			bool flag9 = GUI.Button(new Rect(15f, 365f, 120f, 30f), "Radiator hose 3");
			if (flag9)
			{
				TpMe("radiator hose3(Clone)", "PLAYER");
			}
			bool flag10 = GUI.Button(new Rect(15f, 400f, 120f, 30f), "Battery");
			if (flag10)
			{
				TpMe("battery(Clone)", "PLAYER");
			}
			bool flag11 = GUI.Button(new Rect(15f, 435f, 120f, 30f), "Electrics");
			if (flag11)
			{
				TpMe("electrics(Clone)", "PLAYER");
			}
			bool flag12 = GUI.Button(new Rect(15f, 470f, 120f, 30f), "Brake lining");
			if (flag12)
			{
				TpMe("brake lining(Clone)", "PLAYER");
			}
			bool flag13 = GUI.Button(new Rect(15f, 505f, 120f, 30f), "Clutch lining");
			if (flag13)
			{
				TpMe("clutch lining(Clone)", "PLAYER");
			}
			bool flag14 = GUI.Button(new Rect(15f, 540f, 120f, 30f), "Brake master cyl.");
			if (flag14)
			{
				TpMe("brake master cylinder(Clone)", "PLAYER");
			}
			bool flag15 = GUI.Button(new Rect(15f, 575f, 120f, 30f), "Clutch master cyl.");
			if (flag15)
			{
				TpMe("clutch master cylinder(Clone)", "PLAYER");
			}
			bool flag16 = GUI.Button(new Rect(15f, 610f, 120f, 30f), "Fuel strainer");
			if (flag16)
			{
				TpMe("fuel strainer(Clone)", "PLAYER");
			}
			bool flag17 = GUI.Button(new Rect(15f, 645f, 120f, 30f), "Gear linkage");
			if (flag17)
			{
				TpMe("gear linkage(Clone)", "PLAYER");
			}
			bool flag18 = GUI.Button(new Rect(15f, 680f, 120f, 30f), "Halfshaft");
			if (flag18)
			{
				TpMe("halfshaft(Clone)", "PLAYER");
			}
            GUI.DragWindow();
        }
		
		private void WindowTwo11(int windowId)
        {
			bool flag0 = GUI.Button(new Rect(15f, 50f, 120f, 30f), "RPM gauge");
			if (flag0)
			{
				TpMe("rpm gauge(Clone)", "PLAYER");
			}
			bool flag1 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Clock gauge");
			if (flag1)
			{
				TpMe("clock gauge(Clone)", "PLAYER");
			}
			bool flag2 = GUI.Button(new Rect(15f, 120f, 120f, 30f), "Fuel mixtur. gauge");
			if (flag2)
			{
				TpMe("fuel mixture gauge(Clone)", "PLAYER");
			}
			bool flag3 = GUI.Button(new Rect(15f, 155f, 120f, 30f), "Extra gauges");
			if (flag3)
			{
				TpMe("extra gauges(Clone)", "PLAYER");
			}
			bool flag4 = GUI.Button(new Rect(15f, 190f, 120f, 30f), "Tachometer");
			if (flag4)
			{
				TpMe("tachometer(Clone)", "PLAYER");
			}
			bool flag5 = GUI.Button(new Rect(15f, 225f, 120f, 30f), "Dashboard meters");
			if (flag5)
			{
				TpMe("dashboard meters(Clone)", "PLAYER");
			}
            GUI.DragWindow();
        }
		
		private void WindowTwo12(int windowId)
        {
			bool flag0 = GUI.Button(new Rect(15f, 50f, 120f, 30f), "Seat driver");
			if (flag0)
			{
				TpMe("seat driver(Clone)", "PLAYER");
			}
			bool flag1 = GUI.Button(new Rect(15f, 85f, 120f, 30f), "Seat passenger");
			if (flag1)
			{
				TpMe("seat passenger(Clone)", "PLAYER");
			}
			bool flag2 = GUI.Button(new Rect(15f, 120f, 120f, 30f), "Seat rear");
			if (flag2)
			{
				TpMe("seat rear(Clone)", "PLAYER");
			}			
			bool flag3 = GUI.Button(new Rect(15f, 155f, 120f, 30f), "Dashboard");
			if (flag3)
			{
				TpMe("dashboard(Clone)", "PLAYER");
			}
			bool flag4 = GUI.Button(new Rect(15f, 190f, 120f, 30f), "Stock steer. wheel");
			if (flag4)
			{
				TpMe("stock steering wheel(Clone)", "PLAYER");
			}
			bool flag5 = GUI.Button(new Rect(15f, 225f, 120f, 30f), "Gear stick");
			if (flag5)
			{
				TpMe("gear stick(Clone)", "PLAYER");
			}
			bool flag6 = GUI.Button(new Rect(15f, 260f, 120f, 30f), "Handbrake");
			if (flag6)
			{
				TpMe("handbrake(Clone)", "PLAYER");
			}
			bool flag7 = GUI.Button(new Rect(15f, 295f, 120f, 30f), "Radio");
			if (flag7)
			{
				TpMe("radio(Clone)", "PLAYER");
			}
			bool flag8 = GUI.Button(new Rect(15f, 330f, 120f, 30f), "CD player");
			if (flag8)
			{
				TpMe("cd player(Clone)", "PLAYER");
			}
			bool flag9 = GUI.Button(new Rect(15f, 365f, 120f, 30f), "Back panel");
			if (flag9)
			{
				TpMe("back panel(Clone)", "PLAYER");
			}
			bool flag10 = GUI.Button(new Rect(15f, 400f, 120f, 30f), "Subwoofer panel");
			if (flag10)
			{
				TpMe("subwoofer panel(Clone)", "PLAYER");
			}
			bool flag11 = GUI.Button(new Rect(15f, 435f, 120f, 30f), "Subwoofer left");
			if (flag11)
			{
				TpMe("subwoofer left(Clone)", "PLAYER");
			}
			bool flag12 = GUI.Button(new Rect(15f, 470f, 120f, 30f), "Subwoofer right");
			if (flag12)
			{
				TpMe("subwoofer right(Clone)", "PLAYER");
			}
			bool flag13 = GUI.Button(new Rect(15f, 505f, 120f, 30f), "Wheel cov. leop.");
			if (flag13)
			{
				TpMe("wheel cover leopard(Clone)", "PLAYER");
			}
			bool flag14 = GUI.Button(new Rect(15f, 540f, 120f, 30f), "Wheel cov. plush");
			if (flag14)
			{
				TpMe("wheel cover plush(Clone)", "PLAYER");
			}
			bool flag15 = GUI.Button(new Rect(15f, 575f, 120f, 30f), "Wheel cov. zebra");
			if (flag15)
			{
				TpMe("wheel cover zebra(Clone)", "PLAYER");
			}
			bool flag16 = GUI.Button(new Rect(15f, 610f, 120f, 30f), "Dash cov. leopard");
			if (flag16)
			{
				TpMe("dash cover leopard(Clone)", "PLAYER");
			}
			bool flag17 = GUI.Button(new Rect(15f, 645f, 120f, 30f), "Dash cov. plush");
			if (flag17)
			{
				TpMe("dash cover plush(Clone)", "PLAYER");
			}
			bool flag18 = GUI.Button(new Rect(15f, 680f, 120f, 30f), "Dash cov. zebra");
			if (flag18)
			{
				TpMe("dash cover zebra(Clone)", "PLAYER");
			}
			bool flag19 = GUI.Button(new Rect(15f, 715f, 120f, 30f), "Seat cov. leopard");
			if (flag19)
			{
				TpMe("seat cover leopard(Clone)", "PLAYER");
			}
			bool flag20 = GUI.Button(new Rect(140f, 50f, 120f, 30f), "Seat cov. plush");
			if (flag20)
			{
				TpMe("seat cover plush(Clone)", "PLAYER");
			}
			bool flag21 = GUI.Button(new Rect(140f, 85f, 120f, 30f), "Seat cov. zebra");
			if (flag21)
			{
				TpMe("seat cover zebra(Clone)", "PLAYER");
			}
			bool flag22 = GUI.Button(new Rect(140f, 120f, 120f, 30f), "Bucket seat driver");
			if (flag22)
			{
				TpMe("bucket seat driver(Clone)", "PLAYER");
			}
			bool flag23 = GUI.Button(new Rect(140f, 155f, 120f, 30f), "Bucket seat pass.");
			if (flag23)
			{
				TpMe("bucket seat passenger(Clone)", "PLAYER");
			}
			bool flag24 = GUI.Button(new Rect(140f, 190f, 120f, 30f), "Racing harness");
			if (flag24)
			{
				TpMe("racing harness(Clone)", "PLAYER");
			}
			bool flag25 = GUI.Button(new Rect(140f, 225f, 120f, 30f), "Sport steer. wheel");
			if (flag25)
			{
				TpMe("sport steering wheel(Clone)", "PLAYER");
			}
			bool flag26 = GUI.Button(new Rect(140f, 260f, 120f, 30f), "Rally steer. wheel");
			if (flag26)
			{
				TpMe("rally steering wheel(Clone)", "PLAYER");
			}
			bool flag27 = GUI.Button(new Rect(140f, 295f, 120f, 30f), "Seat cov. Suomi");
			if (flag27)
			{
				TpMe("seat cover suomi(Clone)", "PLAYER");
			}
			bool flag28 = GUI.Button(new Rect(140f, 330f, 120f, 30f), "Dash cov. Suomi");
			if (flag28)
			{
				TpMe("dash cover suomi(Clone)", "PLAYER");
			}
			bool flag29 = GUI.Button(new Rect(140f, 365f, 120f, 30f), "Wheel cov. Suomi");
			if (flag29)
			{
				TpMe("wheel cover suomi(Clone)", "PLAYER");
			}
            GUI.DragWindow();
        }
		
		private void WindowTwo13(int windowId)
        {
            GUI.DragWindow();
        }
		
		private void Window(int windowId)
		{
			bool flag0 = GUI.Button(new Rect(380f, 750f, 60f, 30f), "Close");
			if (flag0)
			{
				GuiShow();
			}
			GUI.Label(new Rect(117f, 25f, 120f, 30f), "Teleports");
			bool flag1 = GUI.Button(new Rect(85f, 50f, 120f, 30f), "Me to home");
			if (flag1)
			{
				TpTo("PLAYER", "GraveYardSpawn");
			}
			GUI.Label(new Rect(15f, 55f, 120f, 30f), "L.CTRL + 1");
			bool flag2 = GUI.Button(new Rect(85f, 85f, 120f, 30f), "Me to store");
			if (flag2)
			{
				TpTo("PLAYER", "SpawnToStore");
			}
			GUI.Label(new Rect(15f, 90f, 120f, 30f), "L.CTRL + 2");
			bool flag3 = GUI.Button(new Rect(85f, 120f, 120f, 30f), "Me to repair shop");
			if (flag3)
			{
				TpTo("PLAYER", "SpawnToRepair");
			}
			GUI.Label(new Rect(15f, 125f, 120f, 30f), "L.CTRL + 3");
			bool flag4 = GUI.Button(new Rect(85f, 155f, 120f, 30f), "Me to drag");
			if (flag4)
			{
				TpTo("PLAYER", "SpawnToDrag");
			}
			GUI.Label(new Rect(15f, 160f, 120f, 30f), "L.CTRL + 4");
			bool flag5 = GUI.Button(new Rect(85f, 190f, 120f, 30f), "Me to cottage");
			if (flag5)
			{
				TpTo("PLAYER", "SpawnToCottage");
			}
			GUI.Label(new Rect(15f, 195f, 120f, 30f), "L.CTRL + 5");
			bool flag06 = GUI.Button(new Rect(85f, 225f, 120f, 30f), "Me to ventti pig");
			if (flag06)
			{
				TpTo("PLAYER", "SpawnToVenttiPig");
			}
			GUI.Label(new Rect(15f, 230f, 120f, 30f), "L.CTRL + 6");
			bool flag6 = GUI.Button(new Rect(85f, 260f, 120f, 30f), "Me to Satsuma");
			if (flag6)
			{
				TpTo("PLAYER", "SATSUMA(557kg, 248)");
			}
			GUI.Label(new Rect(15f, 265f, 120f, 30f), "L.CTRL + 7");
			bool flag7 = GUI.Button(new Rect(85f, 295f, 120f, 30f), "Satsuma to me");
			if (flag7)
			{
				TpMe("SATSUMA(557kg, 248)", "PLAYER");
			}
			bool flag8 = GUI.Button(new Rect(85f, 330f, 120f, 30f), "Me to muscle car");
			if (flag8)
			{
				TpTo("PLAYER", "FERNDALE(1630kg)");
			}
			GUI.Label(new Rect(15f, 335f, 120f, 30f), "L.CTRL + 8");
			bool flag9 = GUI.Button(new Rect(85f, 365f, 120f, 30f), "Muscle car to me");
			if (flag9)
			{
				TpMe("FERNDALE(1630kg)", "PLAYER");
			}
			bool flag10 = GUI.Button(new Rect(85f, 400f, 120f, 30f), "Me to truck");
			if (flag10)
			{
				TpTo("PLAYER", "GIFU(750/450psi)");
			}
			GUI.Label(new Rect(15f, 405f, 120f, 30f), "L.CTRL + 9");
			bool flag11 = GUI.Button(new Rect(85f, 435f, 120f, 30f), "Truck to me");
			if (flag11)
			{
				TpMe("GIFU(750/450psi)", "PLAYER");
			}
			bool flag12 = GUI.Button(new Rect(85f, 470f, 120f, 30f), "Me to tractor");
			if (flag12)
			{
				TpTo("PLAYER", "KEKMET(350-400psi)");
			}
			GUI.Label(new Rect(15f, 475f, 120f, 30f), "L.CTRL + 0");
			bool flag13 = GUI.Button(new Rect(85f, 505f, 120f, 30f), "Tractor to me");
			if (flag13)
			{
				TpTo("KEKMET(350-400psi)", "PLAYER");
			}
			bool flag14 = GUI.Button(new Rect(85f, 540f, 120f, 30f), "Me to van");
			if (flag14)
			{
				TpTo("PLAYER", "HAYOSIKO(1500kg, 250)");
			}
			GUI.Label(new Rect(15f, 545f, 120f, 30f), "R.CTRL + 0");
			bool flag15 = GUI.Button(new Rect(85f, 575f, 120f, 30f), "Van to me");
			if (flag15)
			{
				TpTo("HAYOSIKO(1500kg, 250)", "PLAYER");
			}
			bool flag16 = GUI.Button(new Rect(85f, 610f, 120f, 30f), "Me to moped");
			if (flag16)
			{
				TpTo("PLAYER", "JONNEZ ES(Clone)");
			}
			GUI.Label(new Rect(15f, 615f, 120f, 30f), "R.CTRL + 9");
			bool flag17 = GUI.Button(new Rect(85f, 645f, 120f, 30f), "Moped to me");
			if (flag17)
			{
				TpTo("JONNEZ ES(Clone)", "PLAYER");
			}
			bool flag016 = GUI.Button(new Rect(85f, 680f, 120f, 30f), "Me to pig's car");
			if (flag016)
			{
				TpTo("PLAYER", "RCO_RUSCKO12(270)");
			}
			GUI.Label(new Rect(15f, 685f, 120f, 30f), "R.CTRL + 8");
			bool flag017 = GUI.Button(new Rect(85f, 715f, 120f, 30f), "pig's car to me");
			if (flag017)
			{
				TpTo("RCO_RUSCKO12(270)", "PLAYER");
			}
			GUI.Label(new Rect(250f, 25f, 120f, 30f), "Needs");
			bool flag18 = GUI.Button(new Rect(210f, 50f, 120f, 30f), "off/on needs");
			if (flag18)
			{
				this.needs = !this.needs;
			}
			bool flag19 = GUI.Button(new Rect(210f, 85f, 120f, 30f), "Set full fatigue");
			if (flag19)
			{
				this.needs = false;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value = 100f;
			}
			GUI.Label(new Rect(250f, 130f, 120f, 30f), "Money");
			bool flag20 = GUI.Button(new Rect(210f, 155f, 120f, 30f), "Set 3 000mk");
			if (flag20)
			{
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = 3000;
			}
			bool flag21 = GUI.Button(new Rect(210f, 190f, 120f, 30f), "Set 50 000mk");
			if (flag21)
			{
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = 50000;
			}
			bool flag22 = GUI.Button(new Rect(210f, 225f, 120f, 30f), "Set 500 000mk");
			if (flag22)
			{
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerMoney").Value = 500000;
			}
			GUI.Label(new Rect(232f, 270f, 120f, 30f), "Day of week");
			bool flag23 = GUI.Button(new Rect(210f, 295f, 120f, 30f), "Monday");
			if (flag23)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 1;
			}
			bool flag24 = GUI.Button(new Rect(210f, 330f, 120f, 30f), "Tuesday");
			if (flag24)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 2;
			}
			bool flag25 = GUI.Button(new Rect(210f, 365f, 120f, 30f), "Wednesday");
			if (flag25)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 3;
			}
			bool flag26 = GUI.Button(new Rect(210f, 400f, 120f, 30f), "Thursday");
			if (flag26)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 4;
			}
			bool flag27 = GUI.Button(new Rect(210f, 435f, 120f, 30f), "Friday");
			if (flag27)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 5;
			}
			bool flag28 = GUI.Button(new Rect(210f, 470f, 120f, 30f), "Saturday");
			if (flag28)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 6;
			}
			bool flag29 = GUI.Button(new Rect(210f, 505f, 120f, 30f), "Sunday");
			if (flag29)
			{
				FsmVariables.GlobalVariables.FindFsmInt("GlobalDay").Value = 7;
			}
			GUI.Label(new Rect(350f, 25f, 120f, 30f), "Teleports to me");
			bool flag30 = GUI.Button(new Rect(335f, 50f, 120f, 30f), "Tools");
			if (flag30)
			{
				windowTwo2Status = false;
				windowTwo3Status = false;
				windowTwo4Status = false;
				windowTwo5Status = false;
				windowTwo6Status = false;
				windowTwo7Status = false;
				windowTwo8Status = false;
				windowTwo9Status = false;
				windowTwo10Status = false;
				windowTwo11Status = false;
				windowTwo12Status = false;
				
				this.windowTwoStatus = !this.windowTwoStatus;
			}
			bool flag31 = GUI.Button(new Rect(335f, 85f, 120f, 30f), "Car items");
			if (flag31)
			{
				windowTwoStatus = false;
				windowTwo3Status = false;
				windowTwo4Status = false;
				windowTwo5Status = false;
				windowTwo6Status = false;
				windowTwo7Status = false;
				windowTwo8Status = false;
				windowTwo9Status = false;
				windowTwo10Status = false;
				windowTwo11Status = false;
				windowTwo12Status = false;
				
				this.windowTwo2Status = !this.windowTwo2Status;
			}
			bool flag32 = GUI.Button(new Rect(335f, 120f, 120f, 30f), "Items");
			if (flag32)
			{
				windowTwoStatus = false;
				windowTwo2Status = false;
				windowTwo4Status = false;
				windowTwo5Status = false;
				windowTwo6Status = false;
				windowTwo7Status = false;
				windowTwo8Status = false;
				windowTwo9Status = false;
				windowTwo10Status = false;
				windowTwo11Status = false;
				windowTwo12Status = false;
				
				this.windowTwo3Status = !this.windowTwo3Status;
			}
			bool flag33 = GUI.Button(new Rect(335f, 155f, 120f, 30f), "Suspension");
			if (flag33)
			{
				windowTwoStatus = false;
				windowTwo2Status = false;
				windowTwo3Status = false;
				windowTwo5Status = false;
				windowTwo6Status = false;
				windowTwo7Status = false;
				windowTwo8Status = false;
				windowTwo9Status = false;
				windowTwo10Status = false;
				windowTwo11Status = false;
				windowTwo12Status = false;
				
				this.windowTwo4Status = !this.windowTwo4Status;
			}
			bool flag34 = GUI.Button(new Rect(335f, 190f, 120f, 30f), "Exhaust & fuel");
			if (flag34)
			{
				windowTwoStatus = false;
				windowTwo2Status = false;
				windowTwo3Status = false;
				windowTwo4Status = false;
				windowTwo6Status = false;
				windowTwo7Status = false;
				windowTwo8Status = false;
				windowTwo9Status = false;
				windowTwo10Status = false;
				windowTwo11Status = false;
				windowTwo12Status = false;
				
				this.windowTwo5Status = !this.windowTwo5Status;
			}
			bool flag35 = GUI.Button(new Rect(335f, 225f, 120f, 30f), "Body parts");
			if (flag35)
			{
				windowTwoStatus = false;
				windowTwo2Status = false;
				windowTwo3Status = false;
				windowTwo4Status = false;
				windowTwo5Status = false;
				windowTwo7Status = false;
				windowTwo8Status = false;
				windowTwo9Status = false;
				windowTwo10Status = false;
				windowTwo11Status = false;
				windowTwo12Status = false;
				
				this.windowTwo6Status = !this.windowTwo6Status;
			}
			bool flag36 = GUI.Button(new Rect(335f, 260f, 120f, 30f), "Wheels");
			if (flag36)
			{
				windowTwoStatus = false;
				windowTwo2Status = false;
				windowTwo3Status = false;
				windowTwo4Status = false;
				windowTwo5Status = false;
				windowTwo6Status = false;
				windowTwo8Status = false;
				windowTwo9Status = false;
				windowTwo10Status = false;
				windowTwo11Status = false;
				windowTwo12Status = false;
				
				this.windowTwo7Status = !this.windowTwo7Status;
			}
			bool flag37 = GUI.Button(new Rect(335f, 295f, 120f, 30f), "Engine parts");
			if (flag37)
			{
				windowTwoStatus = false;
				windowTwo2Status = false;
				windowTwo3Status = false;
				windowTwo4Status = false;
				windowTwo5Status = false;
				windowTwo6Status = false;
				windowTwo7Status = false;
				windowTwo9Status = false;
				windowTwo10Status = false;
				windowTwo11Status = false;
				windowTwo12Status = false;
				
				this.windowTwo8Status = !this.windowTwo8Status;
			}
			bool flag38 = GUI.Button(new Rect(335f, 330f, 120f, 30f), "Engine parts 2");
			if (flag38)
			{
				windowTwoStatus = false;
				windowTwo2Status = false;
				windowTwo3Status = false;
				windowTwo4Status = false;
				windowTwo5Status = false;
				windowTwo6Status = false;
				windowTwo7Status = false;
				windowTwo8Status = false;
				windowTwo10Status = false;
				windowTwo11Status = false;
				windowTwo12Status = false;
				
				this.windowTwo9Status = !this.windowTwo9Status;
			}
			bool flag39 = GUI.Button(new Rect(335f, 365f, 120f, 30f), "Engine bay");
			if (flag39)
			{
				windowTwoStatus = false;
				windowTwo2Status = false;
				windowTwo3Status = false;
				windowTwo4Status = false;
				windowTwo5Status = false;
				windowTwo6Status = false;
				windowTwo7Status = false;
				windowTwo8Status = false;
				windowTwo9Status = false;
				windowTwo11Status = false;
				windowTwo12Status = false;
				
				this.windowTwo10Status = !this.windowTwo10Status;
			}
			bool flag40 = GUI.Button(new Rect(335f, 400f, 120f, 30f), "Gauges");
			if (flag40)
			{
				windowTwoStatus = false;
				windowTwo2Status = false;
				windowTwo3Status = false;
				windowTwo4Status = false;
				windowTwo5Status = false;
				windowTwo6Status = false;
				windowTwo7Status = false;
				windowTwo8Status = false;
				windowTwo9Status = false;
				windowTwo9Status = false;
				windowTwo10Status = false;
				windowTwo12Status = false;
				
				this.windowTwo11Status = !this.windowTwo11Status;
			}
			bool flag41 = GUI.Button(new Rect(335f, 435f, 120f, 30f), "Interior");
			if (flag41)
			{
				windowTwoStatus = false;
				windowTwo2Status = false;
				windowTwo3Status = false;
				windowTwo4Status = false;
				windowTwo5Status = false;
				windowTwo6Status = false;
				windowTwo7Status = false;
				windowTwo8Status = false;
				windowTwo9Status = false;
				windowTwo9Status = false;
				windowTwo10Status = false;
				windowTwo11Status = false;
				
				this.windowTwo12Status = !this.windowTwo12Status;
			}
		}

        public override void Update()
        {
			if (CheatsGuiKey.IsDown()) { GuiShow(); };
			if (teleportKey1.IsDown()) { Telep1(); };
			if (teleportKey2.IsDown()) { Telep2(); };
			if (teleportKey3.IsDown()) { Telep3(); };
			if (teleportKey4.IsDown()) { Telep4(); };
			if (teleportKey5.IsDown()) { Telep5(); };
			if (teleportKey6.IsDown()) { Telep6(); };
			if (teleportKey7.IsDown()) { Telep7(); };
			if (teleportKey8.IsDown()) { Telep8(); };
			if (teleportKey9.IsDown()) { Telep9(); };
			if (teleportKey10.IsDown()) { Telep10(); };
			if (teleportKey11.IsDown()) { Telep11(); };
			if (teleportKey12.IsDown()) { Telep12(); };
			if (teleportKey13.IsDown()) { Telep13(); };
			
			if(needs)
			{
				this.PLAYER = GameObject.Find("PLAYER");
			
				PlayMakerFSM[] componentsInChildren = this.PLAYER.GetComponentsInChildren<PlayMakerFSM>();
				for (int i = 0; i < componentsInChildren.Length; i++)
				{
					PlayMakerFSM playMakerFSM = componentsInChildren[i];
					if (playMakerFSM.name == "PlayerStress")
					{
						playMakerFSM.enabled = false;
					}
				
					if (playMakerFSM.name == "PlayerStressRate")
					{
						playMakerFSM.enabled = false;
					}
				}
					
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerFatigue").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerDirtiness").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerDrunk").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerHunger").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerThirst").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerUrine").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerStress").Value = 0.0f;
				FsmVariables.GlobalVariables.FindFsmFloat("PlayerStressRate").Value = 0.0f;
			}
        }
		
		private void GuiShow()
		{
			this.guiShow = !this.guiShow;
			
			if(guiShow)
			{
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = true;
			}
			else
			{
				FsmVariables.GlobalVariables.FindFsmBool("PlayerInMenu").Value = false;
			}
		}
		
		private void TpTo(string tpObject, string tptoObject)
        {
            ModConsole.Print("Teleportation to:" + tptoObject);
            var posFinder = GameObject.Find(tptoObject);
            Vector3 newPlayerPos = new Vector3(posFinder.transform.position.x + 3, posFinder.transform.position.y, posFinder.transform.position.z);
            GameObject.Find(tpObject).transform.position = newPlayerPos;
        }

        private void TpMe(string tpObject, string tptoObject)
        {
            ModConsole.Print("Teleporte me to:" + tptoObject);
            var posFinder = GameObject.Find(tptoObject);
            Vector3 newCarPos = new Vector3(posFinder.transform.position.x + 3, posFinder.transform.position.y, posFinder.transform.position.z);
            GameObject.Find(tpObject).transform.position = newCarPos;
        }
		
		private void TpMe2(string tpObject, string tptoObject)
        {
            ModConsole.Print("Teleporte me to:" + tptoObject);
            var posFinder = GameObject.Find(tptoObject);
            Vector3 newCarPos = new Vector3(posFinder.transform.position.x + 3, posFinder.transform.position.y - 0.15f, posFinder.transform.position.z);
            GameObject.Find(tpObject).transform.position = newCarPos;
        }
		
		private void TpMe3(string tpObject, string tptoObject)
        {
            ModConsole.Print("Teleporte me to:" + tptoObject);
            var posFinder = GameObject.Find(tptoObject);
            Vector3 newCarPos = new Vector3(posFinder.transform.position.x + 3, posFinder.transform.position.y - 0.22f, posFinder.transform.position.z);
            GameObject.Find(tpObject).transform.position = newCarPos;
        }
		
		private void Telep1()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "GraveYardSpawn");
			}
        }
		
		private void Telep2()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "SpawnToStore");
			}
        }
		
		private void Telep3()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "SpawnToRepair");
			}
        }
		
		private void Telep4()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "SpawnToDrag");
			}
        }
		
		private void Telep5()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "SpawnToCottage");
			}
        }
		
		private void Telep6()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "SpawnToVenttiPig");
			}
        }
		
		private void Telep7()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "SATSUMA(557kg, 248)");
			}
        }
		
		private void Telep8()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "FERNDALE(1630kg)");
			}
        }
		
		private void Telep9()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "GIFU(750/450psi)");
			}
        }
		
		private void Telep10()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "KEKMET(350-400psi)");
			}
        }
		
		private void Telep11()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "HAYOSIKO(1500kg, 250)");
			}
        }
		
		private void Telep12()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "JONNEZ ES(Clone)");
			}
        }
		
		private void Telep13()
        {
            if(guiShow)
			{
				TpTo("PLAYER", "RCO_RUSCKO12(270)");
			}
        }
    }
}
