﻿using MSCLoader;
using UnityEngine;
using System.Threading;

namespace Textures
{
    public class Textures : Mod
    {
        public override string ID => "Textures";
        public override string Name => "Textures";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

		public override bool LoadInMenu => true;
		public override bool UseAssetsFolder => true;
		private Texture2D texture1;
		private Texture2D texture2;
		private Texture2D texture3;
		private Texture2D texture4;
		private Texture2D texture5;
		private Texture2D texture6;
		private Texture2D texture7;
		private Texture2D texture8;
		private Texture2D texture9;
		private Texture2D texture10;
		private Texture2D texture11;
		private Texture2D texture12;
		private Texture2D texture13;
		private Keybind ReloadTexturesKey = new Keybind("Reload Textures", "Reload Textures", KeyCode.F5);
		
		public override void OnMenuLoad() 
		{
			AssetBundle texres = LoadAssets.LoadBundle(this,"textures.unity3d");
			texture1 = texres.LoadAsset("drivers_lincence.dds") as Texture2D; 
			texres.Unload(false);
			
			new Thread(MenuCheck).Start();
        }
		
		private void MenuCheck()
		{
			Thread.Sleep( 1 * 1000 );
			if(GameObject.Find("Licence/Card/mesh") != null)
			{
				GameObject.Find("Licence/Card/mesh").GetComponent<MeshRenderer>().material.mainTexture = texture1;
			}
			else
			{
				MenuCheck();
			}
		}
		
		public override void OnLoad()
		{
			Keybind.Add(this, ReloadTexturesKey);
			
			AssetBundle texres = LoadAssets.LoadBundle(this,"textures.unity3d");
			texture2 = texres.LoadAsset("repairshop_01.dds") as Texture2D;
			texture3 = texres.LoadAsset("repairshop_02.dds") as Texture2D;
			texture4 = texres.LoadAsset("repairshop_03.dds") as Texture2D;
			texture5 = texres.LoadAsset("repairshop_04.dds") as Texture2D;
			texture6 = texres.LoadAsset("repairshop_05.dds") as Texture2D;
			texture7 = texres.LoadAsset("repairshop_06.dds") as Texture2D;
			texture8 = texres.LoadAsset("repairshop_07.dds") as Texture2D;
			texture9 = texres.LoadAsset("repairshop_08.dds") as Texture2D;
			texture10 = texres.LoadAsset("inspection_recipiet_fi.dds") as Texture2D;
			texture11 = texres.LoadAsset("inspection_recipiet_en.dds") as Texture2D;
			texture12 = texres.LoadAsset("inspection_fail.dds") as Texture2D;
			texture13 = texres.LoadAsset("inspection_pass.dds") as Texture2D;
			texres.Unload(false);
			
			new Thread(RepairCheck).Start();
			
			if(GameObject.Find("register plate(Clone)") == null)
			{
				new Thread(InspectCheck).Start();
			}
        }
		
		public override void Update()
        {
			if (ReloadTexturesKey.IsDown()) 
			{ 
				ReloadTextures();
			}
		}
		
		private void ReloadTextures()
		{
			AssetBundle texres = LoadAssets.LoadBundle(this,"textures.unity3d");
			texture1 = texres.LoadAsset("drivers_lincence.dds") as Texture2D;
			texture2 = texres.LoadAsset("repairshop_01.dds") as Texture2D;
			texture3 = texres.LoadAsset("repairshop_02.dds") as Texture2D;
			texture4 = texres.LoadAsset("repairshop_03.dds") as Texture2D;
			texture5 = texres.LoadAsset("repairshop_04.dds") as Texture2D;
			texture6 = texres.LoadAsset("repairshop_05.dds") as Texture2D;
			texture7 = texres.LoadAsset("repairshop_06.dds") as Texture2D;
			texture8 = texres.LoadAsset("repairshop_07.dds") as Texture2D;
			texture9 = texres.LoadAsset("repairshop_08.dds") as Texture2D;
			texture10 = texres.LoadAsset("inspection_recipiet_fi.dds") as Texture2D;
			texture11 = texres.LoadAsset("inspection_recipiet_en.dds") as Texture2D;
			texture12 = texres.LoadAsset("inspection_fail.dds") as Texture2D;
			texture13 = texres.LoadAsset("inspection_pass.dds") as Texture2D;
			texres.Unload(false);
			
			if(GameObject.Find("Licence/Card/mesh") != null)
			{
				GameObject.Find("Licence/Card/mesh").GetComponent<MeshRenderer>().material.mainTexture = texture1;
			}
			
			if(GameObject.Find("Sheets/ServiceBrochure/PageFront/bg") != null)
			{
				GameObject.Find("Sheets/ServiceBrochure/PageFront/bg").GetComponent<MeshRenderer>().material.mainTexture = texture2;
				
				GameObject.Find("Sheets/ServiceBrochure/PageMisc/bg").GetComponent<MeshRenderer>().material.mainTexture = texture3;
				
				GameObject.Find("Sheets/ServiceBrochure/PageGearing/bg").GetComponent<MeshRenderer>().material.mainTexture = texture4;
				
				GameObject.Find("Sheets/ServiceBrochure/PageMetalwork/bg").GetComponent<MeshRenderer>().material.mainTexture = texture5;
				
				GameObject.Find("Sheets/ServiceBrochure/PagePaintCar/bg").GetComponent<MeshRenderer>().material.mainTexture = texture6;
				
				GameObject.Find("Sheets/ServiceBrochure/PagePaintRims/bg").GetComponent<MeshRenderer>().material.mainTexture = texture7;
				
				GameObject.Find("Sheets/ServiceBrochure/Background").GetComponent<MeshRenderer>().material.mainTexture = texture8;
				
				GameObject.Find("Sheets/ServiceBrochure/PageTirejob/bg").GetComponent<MeshRenderer>().material.mainTexture = texture9;
			}
			
			if(GameObject.Find("Sheets/InspectionRecipiet/Background_FI") != null)
			{
				GameObject.Find("Sheets/InspectionRecipiet/Background_FI").GetComponent<MeshRenderer>().material.mainTexture = texture10;
				
				GameObject.Find("Sheets/InspectionRecipiet/Background_EN").GetComponent<MeshRenderer>().material.mainTexture = texture11;
				
				GameObject.Find("Sheets/InspectionRecipiet/Checkmarks/ResultFail").GetComponent<MeshRenderer>().material.mainTexture = texture12;
				
				GameObject.Find("Sheets/InspectionRecipiet/Checkmarks/ResultPass").GetComponent<MeshRenderer>().material.mainTexture = texture13;
			}
		}
		
		private void RepairCheck()
		{
			Thread.Sleep( 2 * 1000 );
			if(GameObject.Find("Sheets/ServiceBrochure/PageFront/bg") != null)
			{
				GameObject.Find("Sheets/ServiceBrochure/PageFront/bg").GetComponent<MeshRenderer>().material.mainTexture = texture2;
				
				GameObject.Find("Sheets/ServiceBrochure/PageMisc/bg").GetComponent<MeshRenderer>().material.mainTexture = texture3;
				
				GameObject.Find("Sheets/ServiceBrochure/PageGearing/bg").GetComponent<MeshRenderer>().material.mainTexture = texture4;
				
				GameObject.Find("Sheets/ServiceBrochure/PageMetalwork/bg").GetComponent<MeshRenderer>().material.mainTexture = texture5;
				
				GameObject.Find("Sheets/ServiceBrochure/PagePaintCar/bg").GetComponent<MeshRenderer>().material.mainTexture = texture6;
				
				GameObject.Find("Sheets/ServiceBrochure/PagePaintRims/bg").GetComponent<MeshRenderer>().material.mainTexture = texture7;
				
				GameObject.Find("Sheets/ServiceBrochure/Background").GetComponent<MeshRenderer>().material.mainTexture = texture8;
				
				GameObject.Find("Sheets/ServiceBrochure/PageTirejob/bg").GetComponent<MeshRenderer>().material.mainTexture = texture9;
			}
			else
			{
				RepairCheck();
			}
		}
		
		private void InspectCheck()
		{
			Thread.Sleep( 2 * 1000 );
			if(GameObject.Find("Sheets/InspectionRecipiet/Background_FI") != null)
			{
				GameObject.Find("Sheets/InspectionRecipiet/Background_FI").GetComponent<MeshRenderer>().material.mainTexture = texture10;
				
				GameObject.Find("Sheets/InspectionRecipiet/Background_EN").GetComponent<MeshRenderer>().material.mainTexture = texture11;
				
				GameObject.Find("Sheets/InspectionRecipiet/Checkmarks/ResultFail").GetComponent<MeshRenderer>().material.mainTexture = texture12;
				
				GameObject.Find("Sheets/InspectionRecipiet/Checkmarks/ResultPass").GetComponent<MeshRenderer>().material.mainTexture = texture13;
			}
			else
			{
				InspectCheck();
			}
		}
    }
}
