﻿using MSCLoader;
using UnityEngine;
using System.Threading;

namespace TachometerPosition
{
    public class TachometerPosition : Mod
    {
        public override string ID => "TachometerPosition";
        public override string Name => "Tachometer Position";
        public override string Author => "Roman266";
        public override string Version => "1.0.4";

        public override bool UseAssetsFolder => false;

        private GameObject SATSUMA;
		private GameObject DASHBOARD;
		private GameObject STEERING;
		private GameObject COLUMN;
		private GameObject TACHOMETER;
		private GameObject TRIGGER;
		private GameObject DASHBOARDPIVOT;
		private GameObject DASHBOARCLONE;
		private GameObject FUELMIXTURE;
		private GameObject TRIGGERFUEL;
		private GameObject METERSPIVOT;
		private GameObject METERSCLONE;
		private GameObject PANEL;
		private GameObject PANELTRIGGER;
		
		public override void OnLoad()
        {			
			new Thread(waiting).Start();
        }
		
        private void waiting()
        {		
			Thread.Sleep( 20 * 1000 );
			
			this.SATSUMA = GameObject.Find("SATSUMA(557kg, 248)");
			this.DASHBOARD = this.SATSUMA.transform.FindChild("Dashboard").gameObject;
			this.STEERING = this.DASHBOARD.transform.FindChild("Steering").gameObject;
			this.COLUMN = this.STEERING.transform.FindChild("steering_column2").gameObject;
			this.TACHOMETER = this.COLUMN.transform.FindChild("tachometer(xxxxx)").gameObject;
			this.TRIGGER = this.COLUMN.transform.FindChild("trigger_tachometer").gameObject;
			this.DASHBOARDPIVOT = this.DASHBOARD.transform.FindChild("pivot_dashboard").gameObject;
			this.DASHBOARCLONE = this.DASHBOARDPIVOT.transform.FindChild("dashboard(Clone)").gameObject;
			this.FUELMIXTURE = this.DASHBOARCLONE.transform.FindChild("fuel mixture gauge(xxxxx)").gameObject;
			this.TRIGGERFUEL = this.DASHBOARCLONE.transform.FindChild("trigger_fuel_mix_gauge").gameObject;
			this.METERSPIVOT = this.DASHBOARCLONE.transform.FindChild("pivot_meters").gameObject;
			this.METERSCLONE = this.METERSPIVOT.transform.FindChild("dashboard meters(Clone)").gameObject;
			this.PANEL = this.METERSCLONE.transform.FindChild("n2o button panel(xxxxx)").gameObject;
			this.PANELTRIGGER = this.METERSCLONE.transform.FindChild("trigger_n2o_button_panel").gameObject;
					
            if(DASHBOARCLONE.transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
			{
				this.TACHOMETER.transform.localPosition = new Vector3(0.25f, -0.35f, 0.21f);
				this.TACHOMETER.transform.localRotation = new Quaternion(1f, 0.5f, -1f, 7f);
				this.TRIGGER.transform.localPosition = new Vector3(0.25f, -0.35f, 0.21f);
				this.FUELMIXTURE.transform.localPosition = new Vector3(0.11f, -0.02f, 0.15f);
				this.FUELMIXTURE.transform.localRotation = new Quaternion(1f, 0f, 25f, 90f);
				this.TRIGGERFUEL.transform.localPosition = new Vector3(0.11f, -0.02f, 0.15f);
				
				if(METERSCLONE.transform.localPosition == new Vector3(0.0f, 0.0f, 0.0f))
				{
					this.PANEL.transform.localPosition = new Vector3(0.259200f, -0.028f, 0.03f);
					this.PANELTRIGGER.transform.localPosition = new Vector3(0.259200f, -0.028f, 0.03f);
				}
			}            
        }
    }
}
