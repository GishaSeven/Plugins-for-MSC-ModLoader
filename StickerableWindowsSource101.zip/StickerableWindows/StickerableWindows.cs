﻿using MSCLoader;
using UnityEngine;
using System.Threading;

namespace StickerableWindows
{
    public class StickerableWindows : Mod
    {
        public override string ID => "StickerableWindows";
        public override string Name => "Stickerable Windows";
        public override string Author => "Roman266";
        public override string Version => "1.0.1";

        public override bool UseAssetsFolder => true;
		
		private GameObject WINDOWS;

		public override void OnLoad()
        {
			WINDOWS = GameObject.Find("Sticker");
						
            Mesh new_mesh1 = LoadAssets.LoadOBJMesh(this, "windows.obj");
			
			WINDOWS.GetComponent<MeshFilter>().mesh = new_mesh1;
        }
    }
}
